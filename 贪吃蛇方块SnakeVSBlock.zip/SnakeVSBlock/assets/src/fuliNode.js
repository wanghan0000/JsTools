cc.Class({
    extends: cc.Component,
    properties: {
        yqLb: cc.Label,
        hxLb: cc.Label,
        videoLb: cc.Label,
        goldCount: cc.Label
    },
    onShow: function() {
        this.showGold();
    },
    showGold: function() {
        this.yqLb.string = "邀请(" + Global.getYaoqingCount() + "/" + Global.yqMaxCount + ")",
            this.hxLb.string = "邀请(" + Global.getHuanxingCount() + "/" + Global.hxMaxCount + ")",
            this.videoLb.string = "观看(" + Global.getVideoCount() + "/" + Global.VideoMaxCount + ")",
            this.goldCount.string = "今日已领: " + (Global.getYaoqingCount() * Global.yqGold + Global.getHuanxingCount() * Global.hxGold + Global.getVideoCount() * Global.videoGold) + "金币",
            this.node.parent.getComponent("mainScene").showGold();
    },
    hxBtnClick: function() {
        this.scheduleOnce(function() {
            Global.toast("如果分享成功，有人点击进入游戏即可获得奖励！");
        }, .5), Global.shareGame2({
            title: Global.title,
            imageUrl: Global.imageUrl,
            query: "",
            djName: "yaoqing",
            shareID: "014",
            propName: "yaoqing"
        }, function(e) {
            e.confirm;
        }), Global.getTongJi("047", 1);
    },
    yqBtnClick: function() {
        this.scheduleOnce(function() {
            Global.toast("如果分享成功，有人点击进入游戏即可获得奖励！");
        }, .5), Global.shareGame2({
            title: Global.title,
            imageUrl: Global.imageUrl,
            query: "",
            djName: "yaoqing",
            shareID: "014",
            propName: "yaoqing"
        }, function(e) {
            e.confirm;
        }), Global.getTongJi("046", 1);
    },
    getAudioManager: function() {
        return this._tempAudioManager || (this._tempAudioManager = cc.find("AudioManager").getComponent("AudioManager")),
            this._tempAudioManager;
    },
    kggClick: function() {
        var e = this;
        Global.getVideoCount() >= Global.VideoMaxCount ? Global.toast("今日的观看次数已满，请明天再来") : Global.showVideoAD(function() {
            Global.operateGold(Global.videoGold), Global.setVideoCount(Global.getVideoCount() + 1),
                e.showGold(), e.getAudioManager().playCoin2(), Global.toast("谢谢观看，你获得" + Global.videoGold + "金币！");
        }, "043");
    },
    closeClick: function() {
        this.node.destroy();
    }
})
cc.Class({
    extends: cc.Component,
    properties: {
        lock: cc.Node,
        select: cc.Node,
        index: 0,
        unLockSelect: cc.Node
    },
    show: function(e) {
        var t = this;
        this.index = e;
        var o = "itembg" + e;
        cc.loader.loadRes("Scene/" + o, cc.SpriteFrame, function(e, o) {
            e || (t.node.getComponent(cc.Sprite).spriteFrame = o);
        }), Global.getIsUnLockScene(e) && (this.lock.active = !1, Global.sceneData.select == e && (this.select.active = !0));
    },
    selectItemClick: function() {
        this.lock.active ? this.unLockSelect.active = !0 : this.select.active = !0, this.node.emit("select", this.index);
    },
    selectItem: function(e) {
        this.select.active = e;
    },
    unLock: function() {
        this.lock.active = !1;
    },
    clearShowLockSelect: function() {
        this.unLockSelect.active = !1;
    }
})
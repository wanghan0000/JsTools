cc.Class({
    extends: cc.Component,
    properties: {
        scoreLb: cc.Label,
        skinNodePrefab: cc.Prefab,
        bgNodePrefab: cc.Prefab,
        groupNodePrefab: cc.Prefab,
        dailyNodePrefab: cc.Prefab,
        gameEnd: cc.Prefab,
        skinItemPre: cc.Prefab,
        fuliPre: cc.Prefab,
        hbnodePre: cc.Prefab,
        skinContent: cc.Node,
        unLockgoldLb: cc.Label,
        unlockTips: cc.Label,
        unLockBtn: cc.Node,
        useSkinBtn: cc.Node,
        goldCount: cc.Label,
        playTips: cc.Node,
        lblGold: cc.Label,
        topBar: cc.Node
    },
    onLoad: function() {
        Global.initData(), Global.checkTimeSkin(), this.showMusicBtn(), this.getAudioManager().stopAllAudio(),
            this.getAudioManager().playBgMusic(), this.scoreLb.string = "最高分: " + Global.historyScore,
            this.addTouchEvent(), this.playTips.runAction(cc.repeatForever(cc.sequence(cc.delayTime(1), cc.fadeTo(1, 50), cc.fadeTo(.5, 255)))),
            wx.postMessage({
                message: "HideRankingList"
            }), this.setGoldBgPos(), this.showGold();
    },
    start: function() {
        Global.getShare();
        var e = this;
        wx.showShareMenu({
            withShareTicket: !0
        }), wx.onShareAppMessage(function() {
            return Global.ShareAppMessage();
        }), wx.onShow(function(t) {
            e.node && (Global.openId && Global.onShow(t), cc.game.isPaused() && cc.game.resume(),
                Global.haveShare && (Global.haveShare = !1, setTimeout(function() {
                    Global.shareCancel ? Global.alertGameDialog("您取消了分享，请分享到群") : void 0 != Global.callBack && (new Date().getTime() - Global.shareStartTime < 4e3 ? Global.alertGameDialog("分享失败，请分享到不同的群") : Global.callBack({
                        confirm: !0
                    }));
                }, 200)));
        }), wx.onHide(function() {
            e.node && (cc.game.isPaused() || cc.game.pause());
        }), wx.onAudioInterruptionEnd(function() {}), this.showSkin(), this.node.on("ReShowMainAD", function(e) {
            e && (Global.showBannerId(4, this.node), e.stopPropagation());
        }.bind(this)), Global.showBannerId(4, this.node), Global.isCheckDailyEnd = 0, this.scheduleOnce(function() {
            this.showDailyNode(!0);
        }, .2), this.adaper(), this.setElemPos();
    },
    adaper: function() {
        var e = cc.winSize.width,
            t = cc.winSize.height,
            o = cc.view.getFrameSize().height;
        if (t / e >= 1.8 && (Global.isFullScreen = !0), t / e < 2) {
            var i = this.topBar.getComponent(cc.Widget);
            i.isAlignTop = !0, i.top = t / o * 11, i.isAbsoluteTop = !0;
        } else {
            var n = this.topBar.getComponent(cc.Widget);
            n.isAlignTop = !0, n.top = t / o * 43, n.isAbsoluteTop = !0;
        }
    },
    showGold: function() {
        this.lblGold.string = Global.gold;
    },
    setGoldBgPos: function() {
        var e = this.lblGold.node.parent.getComponent(cc.Widget),
            t = cc.view.getFrameSize(),
            o = 0;
        o = t.height / t.width <= 2 ? 12 : 50, e.isAlignTop = !0, e.top = cc.director.getWinSize().height / cc.view.getFrameSize().height * o,
            e.isAlignBottom = !1;
    },
    setElemPos: function() {
        var e = this.node.getChildByName("loopDock").getComponent(cc.Widget);
        e.isAlignBottom = !0;
        var t = this.node.getChildByName("bgColor").getChildByName("playTipsLb").getComponent(cc.Widget);
        if (t.isAlignBottom = !0, Global.isiPhoneFull) e.bottom = Global.adHeight + Global.iPhoneFullAddH,
            t.bottom = e.bottom + 170;
        else if (Global.isSmallPhone) {
            e.bottom = Global.adHeight + 43, t.bottom = e.bottom + 170;
            var o = this.node.getChildByName("bgColor").getChildByName("btnLayout").getComponent(cc.Widget);
            o.isAlignBottom = !0, o.bottom = e.bottom + 184;
        }
    },
    showDailyNode: function(e) {
        var t = this,
            o = this.node.getChildByName("dailyNode");
        if (!o) {
            (o = cc.instantiate(this.dailyNodePrefab)).name = "dailyNode";
            var i = this.lblGold.node.parent.getChildByName("icon"),
                n = cc.v2(i.parent.x + i.x, i.parent.y + i.y);
            o.getComponent("dailyNode").checkDaily(n, function() {
                t.showFD();
            }), this.node.addChild(o, 2e3);
        }
        Global.isCheckDailyEnd = 1, e ? o.getComponent("dailyNode").haveAward ? (o.active = !0,
            Global.isCheckDailyEnd = 2) : o.active = !1 : o.active = !0;
    },
    update: function() {
        Global.isGetConfig && !Global.haveCheckHb && Global.isCheckDailyEnd > 0 && (Global.haveCheckHb = !0,
            1 == Global.isCheckDailyEnd && this.showFD());
    },
    showFD: function() {
        if (Global.getIsShowStartFD()) {
            var e = cc.instantiate(this.hbnodePre);
            e.parent = cc.director.getScene(), e.zIndex = 1e3, e.getComponent("hbNode").showGetHbNode();
        }
    },
    showMusicBtn: function() {
        var e = this.node.getChildByName("bgColor").getChildByName("title").getChildByName("btnAudio"),
            t = this.node.getChildByName("bgColor").getChildByName("title").getChildByName("btnMute");
        e.active = !Global.isMute, t.active = Global.isMute;
    },
    audioClick: function() {
        Global.setMute(1), this.showMusicBtn(), this.getAudioManager().stopAllAudio();
    },
    muteClick: function() {
        Global.setMute(0), this.showMusicBtn(), this.getAudioManager().playBgMusic();
    },
    skinClick: function() {
        Global.closeBanner();
        var e = this.node.getChildByName("SkinNode");
        e || (e = cc.instantiate(this.skinNodePrefab), this.node.addChild(e, 100), e.setName("SkinNode"),
            e.on("skinNodeClose", this.changeSkin.bind(this))), e.active = !0, e.getComponent("skinNode").showNode(Global.skinData.select < 10 ? 1 : 2);
    },
    sceneBgClick: function() {
        Global.closeBanner();
        var e = this.node.getChildByName("SceneNode");
        e || (e = cc.instantiate(this.bgNodePrefab), this.node.addChild(e, 100), e.setName("SceneNode")),
            e.active = !0, e.getComponent("bgNode").show();
    },
    fuliClick: function() {
        var e = cc.instantiate(this.fuliPre);
        e.parent = this.node, e.zIndex = 1e3, e.getComponent("fuliNode").onShow();
    },
    startClick: function() {
        this.isstarGame || (this.isstarGame = !0, Global.checkTimeSkin(), cc.director.loadScene("gameScene"));
    },
    groupClick: function() {
        Global.closeBanner();
        var e = cc.instantiate(this.groupNodePrefab);
        e.getComponent("sortNode").showNode(0), this.node.addChild(e);
    },
    getAudioManager: function() {
        return this._tempAudioManager || (this._tempAudioManager = cc.find("AudioManager").getComponent("AudioManager")),
            this._tempAudioManager;
    },
    shareClick: function() {
        Global.shareGameOnly("002", function(e) {}), Global.getShare();
    },
    showSkin: function() {
        this.spriteList = [], this.skinIndexList = [], this.selectId = 0, this.skinDistance = 50,
            this.selectScale = 1.2, this.normalScale = .8, this.haveMoveSkinAction = !1;
        for (var e = 1; e <= 16; e++)
            if (Global.getIsCanShow(e)) {
                var t = cc.instantiate(this.skinItemPre);
                t.getComponent("skinItem").show(e), t.y = 0, t.x = -200, this.skinContent.addChild(t),
                    this.spriteList.push(t), this.skinIndexList.push(e), this.itemW = t.width, t.scale = this.normalScale,
                    Global.getIsUnLockSkin(e) || (t.opacity = 125);
            }
        var o = 0,
            i = 0;
        this.curSelectSkin = Global.skinData.select - 1, this.selectItem(this.curSelectSkin),
            (o = Global.skinData.select - 1 - 2) < 0 && (o += this.spriteList.length), (i = Global.skinData.select - 1 + 2) > this.spriteList.length - 1 && (i -= this.spriteList.length);
        var n = [];
        if (o > i) {
            for (var a = o; a < this.spriteList.length; a++) n.push(a);
            for (var s = 0; s <= i; s++) n.push(s);
        } else
            for (var l = o; l <= i; l++) n.push(l);
        for (var c = 0; c < n.length; c++) {
            var h = this.spriteList[n[c]];
            h.x = c * (this.itemW + this.skinDistance) + h.width / 2, this.skinIndexList[n[c]] == Global.skinData.select && (h.scale = this.selectScale);
        }
    },
    addTouchEvent: function() {
        this.skinContent.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this), this.skinContent.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this),
            this.skinContent.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this), this.node.getChildByName("bgColor").on(cc.Node.EventType.TOUCH_START, function(e) {
                e.target && e.target != this.skinContent && this.startClick();
            }.bind(this));
    },
    getStartAndEnd: function() {
        for (var e = this.skinContent.width + this.itemW, t = 0 - this.itemW, o = 0, i = 0, n = 0; n < this.spriteList.length; n++) {
            var a = this.spriteList[n];
            a.x < e && a.x >= -this.itemW && (e = a.x, o = n), a.x > t && a.x <= this.skinContent.width + this.itemW && (t = a.x,
                i = n);
        }
        return {
            start: o,
            end: i,
            sx: e,
            ex: t
        };
    },
    onTouchMove: function(e) {
        if (!this.haveMoveSkinAction) {
            var t = e.getDeltaX(),
                o = this.getStartAndEnd(),
                i = o.start,
                n = o.end,
                a = o.sx,
                s = o.ex,
                l = [];
            if (i > n) {
                for (var c = i; c < this.spriteList.length; c++) l.push(c);
                for (var h = 0; h <= n; h++) l.push(h);
            } else
                for (var r = i; r <= n; r++) l.push(r);
            for (var d = 0; d < l.length; d++) {
                this.spriteList[l[d]].x += t;
            }
            a += t, s += t, 0 == i ? i = this.spriteList.length - 1 : i--, n == this.spriteList.length - 1 ? n = 0 : n++,
                this.spriteList[i].x = a - this.itemW - this.skinDistance, this.spriteList[n].x = s + this.itemW + this.skinDistance;
            for (var u = 0; u < this.spriteList.length; u++) {
                var g = this.spriteList[u];
                g.scale = this.normalScale, Math.abs(g.x - this.skinContent.width / 2) < 160 && (g.scale = Math.max(this.selectScale - Math.abs(g.x - this.skinContent.width / 2) / 220, this.normalScale));
            }
        }
    },
    onTouchEnd: function(e) {
        this.selectSkinEnd();
    },
    onTouchCancel: function(e) {
        this.selectSkinEnd();
    },
    selectSkinEnd: function() {
        var e = this,
            t = this.getStartAndEnd(),
            o = t.start,
            i = t.end,
            n = t.sx,
            a = t.ex,
            s = [];
        if (o > i) {
            for (var l = o; l < this.spriteList.length; l++) s.push(l);
            for (var c = 0; c <= i; c++) s.push(c);
        } else
            for (var h = o; h <= i; h++) s.push(h);
        0 == o ? o = this.spriteList.length - 1 : o--, s.unshift(o), i == this.spriteList.length - 1 ? i = 0 : i++,
            s.push(i), this.spriteList[o].x = n - this.itemW - this.skinDistance, this.spriteList[i].x = a + this.itemW + this.skinDistance;
        for (var r = this.skinContent.width, d = 0, u = 0; u < s.length; u++) {
            var g = this.spriteList[s[u]];
            Math.abs(g.x - this.skinContent.width / 2) < r && (r = Math.abs(g.x - this.skinContent.width / 2),
                d = u);
        }
        if (r > 0) {
            this.spriteList[s[d]].x > this.skinContent.width / 2 && (r = 0 - r);
            for (var p = Math.abs(r) / 200, m = 0; m < s.length; m++) {
                var f = this.spriteList[s[m]],
                    b = this.normalScale;
                d == m && (b = this.selectScale), f.runAction(cc.spawn(cc.moveBy(p, r, 0), cc.scaleTo(p, b)));
            }
            this.haveMoveSkinAction = !0, this.node.runAction(cc.sequence(cc.delayTime(p), cc.callFunc(function() {
                e.haveMoveSkinAction = !1, e.selectItem(e.skinIndexList[s[d]] - 1);
            }, this)));
        }
    },
    timeToStr: function(e) {
        var t = Math.floor(e / 60),
            o = Math.floor(e - 60 * t);
        return "剩余 " + (t >= 10 ? t : "0" + t) + ":" + (o >= 10 ? o : "0" + o);
    },
    selectItem: function(e) {
        var t = !1;
        if (Global.getIsUnLockSkin(e + 1)) {
            var o = Global.getTimeSkinTime(e + 1);
            this.unlockTips.string = o > 0 ? this.timeToStr(o) : "已拥有", t = !0;
        } else this.unLockgoldLb.string = "" + Global.skinGold[e];
        this.unLockBtn.active = !t, this.useSkinBtn.active = t, this.unLockgoldLb.node.parent.active = !t,
            this.unlockTips.node.active = t, this.curSelectSkin = e;
        for (var i = 0, n = 0; n < this.skinIndexList.length; n++) e + 1 == this.skinIndexList[n] && (i = n);
        t ? (this.spriteList[i].opacity = 255, Global.setSelectIndex(this.curSelectSkin + 1)) : this.spriteList[i].opacity = 125;
    },
    addGold: function(e) {
        Global.operateGold(e), this.showGold(), this.getAudioManager().playCoin2();
    },
    unLockNoGoldShare: function() {
        var e = this;
        Global.actionShare2(Global.unLockSkinBtnShareID, function() {
            Global.toast("谢谢分享，获得25金币"), e.addGold(25);
        });
    },
    unLockNoGold: function() {
        if (Global.getisShowVideo2(Global.unLockSkinBtnShareID)) {
            var e = this;
            Global.showVideoAD(function() {
                Global.toast("谢谢观看，获得25金币"), e.addGold(25);
            }, Global.unLockSkinBtnVideoID, function() {
                Global.isOldPlayer() && e.unLockNoGoldShare();
            });
        } else this.unLockNoGoldShare();
    },
    unLockBtnClick: function() {
        var e = Global.skinGold[this.curSelectSkin];
        if (Global.gold < e) return Global.toast("金币不足" + e + "，无法解锁！"), void this.unLockNoGold();
        Global.operateGold(-e), Global.toast("解锁皮肤成功！"), Global.unLockSkin(this.curSelectSkin + 1),
            Global.setSelectIndex(this.curSelectSkin + 1), this.goldCount.string = Global.gold,
            this.unLockBtn.active = !1, this.useSkinBtn.active = !0, this.spriteList[this.curSelectSkin].opacity = 255;
    },
    useSkinBtnClick: function() {
        this.startClick();
    },
    refreshSkin: function(e) {
        this.curSelectSkin == e && this.selectItem(e), this.spriteList[e].opacity = 255;
    }
})
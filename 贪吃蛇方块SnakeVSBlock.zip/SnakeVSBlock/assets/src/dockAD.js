window.docktouchN = 0;
var i = require('HTTP');
cc.Class({
    extends: cc.Component,
    properties: {},
    onLoad: function() {},
    start: function() {
        console.log("dock start"), window.docktouchN = 0, DockAniAD.curADs = [], this.node.opacity = 0;
        var e = this;
        null == DockAniAD.show ? e.getDockAdData(function(t) {
            t && e.canshow(function() {
                1 == DockAniAD.show ? e.showAd() : e.node.active = !1;
            });
        }) : 1 == DockAniAD.show ? e.showAd() : e.node.active = !1;
    },
    showAd: function() {
        this.node.opacity = 255;
        for (var e = 1; e < 5; e++) this.node.getChildByName("dockDyn" + e).active = !1;
        for (var t = 0; t < Math.min(DockAniAD.realN, 4); t++) this.node.getChildByName("dockDyn" + (t + 1)).active = !0,
            this.node.getChildByName("dockDyn" + (t + 1)).getComponent("dockdynamicImage").showDynamicImage();
        console.log("=====DockAniAD.realN=======", DockAniAD.realN), void 0 != DockAniAD.realN && 0 != DockAniAD.realN || (this.node.active = !1);
    },
    canshow: function(e) {
        var t = Global.host + "/gameconf/" + Global.appid + "/getADswitch/2/",
            o = cc.loader.getXMLHttpRequest();
        o.onreadystatechange = function() {
            if (4 == o.readyState && o.status >= 200 && o.status < 400) {
                var t = o.responseText;
                DockAniAD.show = !1, "0" == t ? DockAniAD.show = !1 : "1" == t && (DockAniAD.show = !0),
                    e && e(), console.log("DockAniAD canshow = " + t);
            }
        }, o.open("GET", t, !0), o.send();
    },
    getDockReqUrl: function(e) {
        var t = "",
            o = "",
            i = Global.getData("IPAddr");
        void 0 != i && "" != i && (t = i[0], o = i[1]);
        var n = Global.host + "/gameconf/" + Global.appid + "/wechatGetDockAniAD/?touchN=" + e + "&city=" + t + "&region=" + o;
        return console.log("=====请求地址是===reqUrl====", n), n;
    },
    getDockAdData: function(e) {
        this.touchN = 0;
        var t = this.getDockReqUrl(this.touchN);
        i.Request(t, function(t) {
            t && 200 === t.code ? (DockAniAD.max = t.data.max, DockAniAD.realN = t.data.realN,
                void 0 == DockAniAD.realN && (DockAniAD.realN = 0), e(!0)) : (console.log("=====获取dock配置数据失败===="),
                e(!1));
        });
    }
})
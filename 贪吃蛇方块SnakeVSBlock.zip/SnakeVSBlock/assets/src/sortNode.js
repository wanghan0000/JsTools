cc.Class({
    extends: cc.Component,
    properties: {
        display: cc.Sprite
    },
    onLoad: function() {
        sharedCanvas.width = this.display.node.width, sharedCanvas.height = this.display.node.height,
            this.tex = new cc.Texture2D(), this.node.on("touchmove", this.onTouchMove.bind(this));
    },
    showNode: function(e, t) {
        this._type = e, wx.postMessage({
            message: "HideRankingList"
        }), 0 == e ? wx.postMessage({
            message: "ShowRankingList",
            yoff: 0,
            contentH: this.display.node.height
        }) : wx.postMessage({
            message: "ShowRankingListGroup",
            val: t,
            yoff: 0,
            contentH: this.display.node.height
        });
    },
    showfriendByEnd: function() {
        this.showNode(0), this._isEnd = !0;
    },
    onTouchMove: function(e) {
        var t = e.getDeltaY();
        this.isDirty = !0, wx.postMessage({
            message: "scroll",
            val: t
        });
    },
    update: function() {
        this._updateSubDomainCanvas();
    },
    _updateSubDomainCanvas: function() {
        this.tex && (this.tex.initWithElement(sharedCanvas), this.tex.handleLoadedTexture(),
            this.display.spriteFrame = new cc.SpriteFrame(this.tex));
    },
    ReShowMainSceneAD: function() {
        var e = new cc.Event.EventCustom("ReShowMainAD", !0);
        this.node.dispatchEvent(e);
    },
    btnCloseClick: function() {
        wx.postMessage({
                message: "HideRankingList"
            }), this._isEnd && this.node.parent.getComponent("gameEnd").setCanvas(), this.ReShowMainSceneAD(),
            this.node.destroy();
    },
    btnGroupClick: function() {
        var e = this;
        Global.shareGameOnly("003", function(t) {
            t.shareTickets ? e.showNode(1, t.shareTickets) : Global.alertDialog("请分享到微信群");
        }), Global.getShare();
    }
})
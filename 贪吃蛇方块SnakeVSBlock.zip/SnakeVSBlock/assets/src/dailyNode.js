cc.Class({
    extends: cc.Component,
    properties: {
        haveAward: 0,
        diamondSp: cc.Node,
        skinItemPre: cc.Prefab
    },
    onLoad: function() {
        var e = Global.adHeight,
            t = this.node.getChildByName("bg"),
            o = t.getComponent(cc.Widget);
        o.isAlignBottom = !0, o.bottom = (cc.winSize.height - e - t.height) / 2 + e;
        var i = this.node.getChildByName("btnGet").getComponent(cc.Button).getComponent(cc.Widget);
        i.isAlignBottom = !0, i.bottom = Global.adHeight, this.scheduleOnce(function() {
            this.node.getChildByName("btnGet").active = !0;
        }, Global.passBtnShowTime), this.updateTime = 0;
    },
    changePassBtnPos: function() {
        var e = this.node.getChildByName("btnGet").getComponent(cc.Widget);
        e.isAlignBottom = !0, e.bottom = Global.bannerHeight;
    },
    start: function() {},
    update: function(e) {
        this.updateTime += e, this.updateTime > 1 && (this.changePassBtnPos(), this.updateTime = 0);
    },
    checkDaily: function(e, t) {
        this.continueDays = 0, this.haveAward = this.getLoginDay(), this.changeStatus(),
            this.diamondPos = e, this.closeCallFun = t;
    },
    changeStatus: function() {
        var e = this.continueDays;
        this.haveAward && (e -= 1);
        for (var t = 1; t <= e; t++) {
            this.getSignNode(t).active = !0;
        }
        this.changeBtn();
    },
    btnAction: function(e) {
        if (e.active) {
            e.stopAllActions(), e.scale = 1;
            e.runAction(cc.repeatForever(cc.sequence(cc.scaleTo(.8, 1.1), cc.scaleTo(.8, 1))));
        }
    },
    changeBtn: function() {
        this.node.getChildByName("btnGet").getComponent(cc.Button).interactable = this.haveAward;
        var e = this.node.getChildByName("bg").getChildByName("btnVideo").getComponent(cc.Button);
        e.interactable = this.haveAward, e.node.active = this.continueDays < 7;
        var t = this.node.getChildByName("bg").getChildByName("btnGet").getComponent(cc.Button);
        t.interactable = this.haveAward, t.node.active = 7 == this.continueDays, this.btnAction(e.node);
    },
    getSignNode: function(e) {
        return this.node.getChildByName("bg").getChildByName("day" + e).getChildByName("getSign");
    },
    getLoginDay: function() {
        var e = parseInt(this.getData("continueDays", 0)),
            t = parseInt(this.getData("dayLastTime", 0));
        if (0 == t) return this.continueDays = 1, 1;
        var o = Math.floor(t / 864e5),
            i = Math.floor(new Date().getTime() / 864e5);
        return i - o <= 0 ? (this.continueDays = e, 0) : i - o == 1 ? ((e += 1) > 7 && (e = 1),
            this.continueDays = e, 1) : (this.continueDays = 1, 1);
    },
    addCoin: function(e, t) {
        var o = this,
            i = this.diamondPos,
            n = t.sub(i).mag() / 1e3;
        Global.operateGold(e - 10 * Math.floor(e / 10)), this.getAudioManager().playCoin2();
        for (var a = function(a) {
                var s = cc.instantiate(o.diamondSp);
                s.position = t, s.parent = o.node, s.runAction(cc.sequence(cc.delayTime(a / 15), cc.callFunc(function() {
                    s.opacity = 255;
                }), cc.moveTo(n, i).easing(cc.easeSineInOut()), cc.callFunc(function() {
                    Global.operateGold(Math.floor(e / 10)), o.node.parent.getComponent("mainScene").showGold(),
                        s.destroy();
                })));
            }, s = 0; s < 10; s++) a(s);
        this.node.runAction(cc.sequence(cc.delayTime(n + 10 / 15 + .5), cc.callFunc(function() {
            void 0 != o.closeCallFun && o.closeCallFun();
        }), cc.removeSelf()));
    },
    getAward: function(e, t) {
        this.node.getChildByName("btnGet").getComponent(cc.Button).interactable = !1, this.node.getChildByName("bg").getChildByName("btnVideo").getComponent(cc.Button).interactable = !1;
        var o = "",
            i = 0,
            n = 0;
        switch (e) {
            case 1:
                i = 25 * t;
                break;

            case 2:
                i = 50 * t;
                break;

            case 3:
                i = 100 * t;
                break;

            case 4:
                i = 150 * t;
                break;

            case 5:
                i = 200 * t;
                break;

            case 6:
                i = 300 * t;
                break;

            case 7:
                n = Global.getRandUnLockSkin();
        }
        var a = this.getSignNode(this.continueDays);
        if (a.active = !0, this.haveAward = 0, this.changeBtn(), this.setData("continueDays", this.continueDays),
            this.setData("dayLastTime", new Date().getTime()), i > 0) this.scheduleOnce(function() {
            o = "恭喜获得" + i + "金币";
            var e = cc.v2(a.parent.position.x + a.parent.parent.position.x, a.parent.position.y + a.parent.parent.position.y);
            Global.toast(o), this.addCoin(i, e);
        }, .5);
        else {
            if (0 == n) return void this.node.destroy();
            this.scheduleOnce(function() {
                this.showDjAction(n);
            }, .5);
        }
    },
    showDjAction: function(e) {
        var t = this.node.getChildByName("djNode");
        t.active = !0;
        var o = t.getChildByName("light");
        this.changeSkin(e), o.runAction(cc.repeatForever(cc.rotateBy(1.2, 90))), this.node.runAction(cc.sequence(cc.delayTime(3), cc.removeSelf())),
            Global.unLockSkin(e), this.node.parent.getComponent("mainScene").refreshSkin(e - 1),
            Global.toast("恭喜获得新款贪吃蛇皮肤一个！");
    },
    getClick: function() {
        this.getAward(this.continueDays, 1);
    },
    shareAndGet: function() {
        var e = this;
        Global.actionShare2(Global.dailyShareID, function() {
            e.getAward(e.continueDays, 2);
        });
    },
    videoClick: function() {
        var e = this;
        Global.getisShowVideo2(Global.dailyShareID) ? Global.showVideoAD(function() {
            e.getAward(e.continueDays, 2);
        }, "040", function() {
            Global.isOldPlayer() && e.shareAndGet();
        }) : this.shareAndGet();
    },
    closeClick: function() {
        this.node.active = !1;
    },
    getAudioManager: function() {
        return this._tempAudioManager || (this._tempAudioManager = cc.find("AudioManager").getComponent("AudioManager")),
            this._tempAudioManager;
    },
    setData: function(e, t) {
        cc.sys.localStorage.setItem(e, t);
    },
    getData: function(e, t) {
        var o = cc.sys.localStorage.getItem(e);
        return o || 0 === o ? o : t;
    },
    changeSkin: function(e) {
        var t = this.node.getChildByName("djNode"),
            o = cc.instantiate(this.skinItemPre);
        o.getComponent("skinItem").show(e), o.y = 59.6, o.x = 0, o.scale = 1.5, o.parent = t;
    }
})
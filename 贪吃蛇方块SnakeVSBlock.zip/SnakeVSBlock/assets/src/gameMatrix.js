require('prefabPool');
cc.Class({
    extends: cc.Component,
    properties: {
        shouldInEat: 0,
        inEat: 0,
        shouldUnEat: 0,
        scrollSpeed: 5,
        sumBall: 0,
        snakePosX: 0,
        isGameEnd: !1,
        bodyCountLb: cc.Label,
        snakeHead: cc.Node,
        huDunNode: cc.Node,
        gameEndPrefab: cc.Prefab,
        boxNodePrefab: cc.Prefab,
        guideNodePrefab: cc.Prefab,
        hbNodePre: cc.Prefab,
        hbIcon: cc.Node,
        fuhuoTimes: 0,
        invincibleTimes: 0,
        tailNode: cc.Node,
        effectBg: cc.Node,
        head2: cc.Node,
        magnetNode: cc.Node
    },
    editor: {
        executionOrder: -1
    },
    onLoad: function() {
        var e = this;
        Global.setPlayGameTimes(Global.playGameTimes + 1), Global.sceneData.select > 1 && cc.loader.loadRes("Scene/bg" + Global.sceneData.select, cc.SpriteFrame, function(t, o) {
                t ? console.log("change Scene" + t) : e.node.getComponent(cc.Sprite).spriteFrame = o;
            }), this.shouldInEat = 0, this.inEat = 0, this.snakePosX = 0, this.lastPosX = 0,
            this.sumBall = 0, this.timeCount = 0, this.line = 0, this.timeInterVal = this.node.width / 5,
            this.eatArrayPos = [], this.barArrayPos = [], this.defaultY = 1.2 * this.node.width,
            this.isGameEnd = !1, this.isGamePause = !1, this.canNotTouchBlock = null, this._score = 0,
            this.fuhuoTimes = 0, this.sequenceCount = 0, this.magnetTime = 0, this.shootTime = 0,
            this.iceTime = 0, this.guideTime = 0, this.guideIndex = 0, this.addGoldCount = 0,
            this.lastShowFDLine = 0, this.lastFDIsShow = !1;
        for (var t = 0; t < 5; t++) this.eatArrayPos[t] = this.node.width * (t - 2) * .2,
            t < 4 && (this.barArrayPos[t] = this.node.width * (.2 * (t - 2) + .1));
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.touchMove, this), this.bodyCountLb.node.zIndex = 1e3,
            this.magnetNode.color = Global.snakeBombColor[Global.skinData.select - 1];
    },
    getAudioManager: function() {
        return this._tempAudioManager || (this._tempAudioManager = cc.find("AudioManager").getComponent("AudioManager")),
            this._tempAudioManager;
    },
    start: function() {
        this.changeHead(), this.addBalls(Global.StartBody), this.checkShowHddj = Global.getisShowhddj(Global.playGameTimes),
            Global.getisShowkjsdj(Global.playGameTimes) && this.scheduleOnce(function() {
                this.showBoxNode(2);
            }, .1);
    },
    showGuideNode: function(e) {
        if (Global.isShowNormalGuide || !(e > 3)) {
            var t = this.node.parent.getChildByName("guideNode");
            t || ((t = cc.instantiate(this.guideNodePrefab)).name = "guideNode", t.parent = this.node.parent,
                t.zIndex = 2e3), t.getComponent("guideNode").show(e);
        }
    },
    closeGuideNode: function() {
        var e = this.node.parent.getChildByName("guideNode");
        e && (e.stopAllActions(), e.destroy());
    },
    changeHead: function() {
        var e = this,
            t = "pifu_" + ("" + (Global.skinData.select < 10 ? "0" + Global.skinData.select : Global.skinData.select));
        cc.loader.loadRes("Skin/" + t, cc.SpriteFrame, function(t, o) {
            if (t) console.log(t);
            else {
                e.head2.getComponent(cc.Sprite).spriteFrame = o, e.snakeHead.width = e.head2.width,
                    e.snakeHead.height = e.head2.height;
                var i = e.head2.width > e.head2.height ? e.head2.width : e.head2.height;
                e.magnetNode.width = i - 10, e.magnetNode.height = i - 10;
            }
        });
    },
    touchMove: function(e) {
        if (!this.isGameEnd && !this.isGamePause) {
            this.lastPosX = this.snakePosX, this.lastPosX = 1.1 * e.getDelta().x + this.lastPosX;
            var t = this.snakeHead;
            this.lastPosX < -this.node.width / 2 + t.width / 2 ? this.lastPosX = -this.node.width / 2 + t.width / 2 : this.lastPosX > this.node.width / 2 - t.width / 2 && (this.lastPosX = this.node.width / 2 - t.width / 2),
                this.snakePosX = this.lastPosX, this.clearCanNotTouch();
        }
    },
    update: function(e) {
        if (Global.isShowNormalGuide || this.isGamePause || (this.guideTime += e, this.guideTime > .6 && (this.showGuideNode(this.guideIndex),
                this.guideIndex++, this.guideTime = 0, this.guideIndex >= 3 && (Global.isShowNormalGuide = 1))),
            this.isGamePause || (this.invincibleTimes > 0 && (this.invincibleTimes -= e, this.invincibleTimes <= 0 && (this.scrollSpeed = this.lastSpeed,
                        this.invincibleTimes = 0, this.playAndStopHuDunEffect(!1), this.clearEffect()),
                    this.node.parent.getComponent("gameScene").changePrg(this.invincibleTimes / this.allInvincibleTimes)),
                this.magnetTime > 0 && (this.magnetTime -= e, this.magnetTime <= 0 && this.useAndStopMagnet(!0)),
                this.iceTime > 0 && (this.iceTime -= e, this.iceTime <= 0 && (this.scrollSpeed = this.lastSpeed,
                    this.iceTime = 0), this.node.parent.getComponent("gameScene").changeIcePrg(this.iceTime / Global.iceTime))),
            this.showBodyCount(), this.checkTouchShootBall(), this.shouldInEat) return this.shouldInEat = 0,
            void(this.inEat = 1);
        this.shouldUnEat && (this.shouldUnEat = 0, this.inEat = 0), this.checkTouchBlock();
    },
    elementMove: function() {
        if (!(this.isGameEnd || this.isGamePause || this.shouldInEat || this.inEat)) {
            for (var e = this.node.childrenCount, t = 0; t < e; t++)
                if (this.node.children[t]) {
                    var o = this.node.children[t];
                    if ("block" == o.name || "food" == o.name || "bar" == o.name || "propBox" == o.name || "SkinBox" == o.name) {
                        if ("food" == o.name) {
                            var i = this.node.children[t].getComponent("food");
                            if (i && i.isPickUped) continue;
                        }
                        this.node.children[t].y -= this.scrollSpeed, "block" == o.name && this.node.children[t].getComponent("block") && this.node.children[t].getComponent("block").checkEnd();
                    }
                }
            for (var n = this.node.parent.getChildByName("lblNode"), a = n.childrenCount, s = 0; s < a; s++) {
                var l = n.children[s];
                0 != l.name.length && (l.y -= this.scrollSpeed);
            }
            for (var c = this.node.parent.getChildByName("particleNode"), h = c.childrenCount, r = 0; r < h; r++) c.children[r] && (c.children[r].y -= this.scrollSpeed);
            this.rollMatrix();
        }
    },
    clearCanNotTouch: function() {
        this.canNotTouchBlock && (this.canNotTouchBlock.getComponent("block").canNotTouch = !1),
            this.canNotTouchBlock = null;
    },
    checkTouchShootBall: function() {
        if (!this.isGameEnd && !this.isGamePause) {
            for (var e = [], t = [], o = this.node.childrenCount, i = 0; i < o; i++)
                if (this.node.children[i]) {
                    var n = this.node.children[i];
                    if ("block" != n.name) {
                        if ("shootBall" == n.name) {
                            var a = this.node.children[i].getComponent("shootBall");
                            a && t.push(a);
                        }
                    } else {
                        var s = n.getComponent("block");
                        s && e.push(s);
                    }
                }
            for (var l = 0; l < t.length; l++)
                for (var c = t[l], h = 0; h < e.length; h++) {
                    var r = e[h];
                    if (r) {
                        var d = r.isTouchBall(c.node);
                        if (d > 0) {
                            2 == d && (e[h] = null);
                            break;
                        }
                    }
                }
        }
    },
    checkTouchBlock: function() {
        if (!(this.isGameEnd || this.isGamePause || this.shouldInEat || this.inEat)) {
            for (var e = this.node.childrenCount, t = [], o = 0; o < e; o++) {
                if (this.node.children[o])
                    if ("block" == this.node.children[o].name) {
                        var i = this.node.children[o].getComponent("block");
                        i && i.checkTouch() && t.push(i);
                    }
            }
            if (t.length > 0) {
                var n = t[0],
                    a = 0;
                if (t.length > 1) {
                    for (var s = 1; s < t.length; s++) {
                        var l = t[s];
                        l && l.hDistance < n.hDistance && (n = l, a = s);
                    }
                    a = 0 == a ? 1 : 0;
                }
                if (n.canNotTouch) return;
                var c = n.onPicked();
                t.length > 1 && c && (this.canNotTouchBlock = t[a], this.canNotTouchBlock.canNotTouch = !0,
                    this.canNotTouchBlock.touchPosX = this.snakeHead.x);
            }
        }
    },
    useSkill: function(e) {
        this.isGameEnd || (1 == e ? this.useHuDun(6) : 2 == e ? this.useAndStopMagnet() : 3 == e && this.useAndStopShoot());
    },
    showBodyCount: function() {
        this.bodyCountLb.string = this.sumBall, this.bodyCountLb.node.setPosition(this.snakeHead.x, this.snakeHead.y + this.snakeHead.height / 2 + 25),
            this.huDunNode.active && (this.huDunNode.setPosition(this.snakeHead.x, this.snakeHead.y),
                this.bodyCountLb.node.y += 8), this.tailNode.active && (this.tailNode.position = this.snakeHead.position),
            this.magnetNode.active && (this.magnetNode.position = this.snakeHead.position);
    },
    subBall: function(e) {
        var t = this;
        this.sumBall -= e;
        for (var o = this.node.getChildByName("head"), i = o.childrenCount, n = 0; n < e; n++)
            if (0 <= i - 1 - n) {
                var a = o.children[i - 1 - n];
                o.removeChild(a), cc.poolNode.bodyPool.Push(a);
            }
        this.changeScore(e), this.sumBall < 0 && (this.isGameEnd = !0, this.useAndStopMagnet(!0),
            Global.setWeekScore(this._score), this.bodyCountLb.node.active = !1, this.node.runAction(cc.sequence(cc.delayTime(.3), cc.callFunc(function() {
                t.gameOver();
            }))), this.sumBall = 0), this.showBodyCount();
    },
    changeScore: function(e, t) {
        this._score += e, this.node.parent.getComponent("gameScene").changeScore(this._score),
            t ? this.getAudioManager().playExplo() : this.getAudioManager().playHit();
    },
    gameOver: function() {
        var e = this.node.parent.getChildByName("gameEndNode");
        e || (e = cc.instantiate(this.gameEndPrefab), this.node.parent.addChild(e, 1e3),
                e.setName("gameEndNode")), e.active = !0, 2 == this.fuhuoTimes ? e.getComponent("gameEnd").showEnd(this._score, this.addGoldCount) : e.getComponent("gameEnd").showFirstHuohuo(this._score, this.fuhuoTimes, this.addGoldCount),
            this.closeGuideNode();
    },
    fuHuo: function(e) {
        this.bodyCountLb.node.active = !0;
        var t = this.node.getChildByName("head");
        t.getComponent("snakeHead").resetTrace(), t.active = !0, this.deleteCanTouchBlock(),
            this.addBalls(15), this.fuhuoTimes++, this.isGameEnd = !1;
    },
    deleteCanTouchBlock: function() {
        for (var e = this.node.childrenCount, t = [], o = 0; o < e; o++)
            if (this.node.children[o].getComponent("block")) {
                var i = this.node.children[o];
                if (Math.abs(i.y - this.snakeHead.y) - i.height / 2 - this.snakeHead.height / 2 > 0) continue;
                i.y > this.snakeHead.y && this.snakeHead.x + this.snakeHead.width / 2 > i.x - i.width / 2 && this.snakeHead.x - this.snakeHead.width / 2 < i.x + i.width / 2 && t.push(i);
            }
        for (var n = 0; n < t.length; n++) t[n].getComponent("block").removeSelf();
    },
    showBoxNode: function(e, t) {
        var o = this.node.parent.getChildByName("BoxNode");
        o || (o = cc.instantiate(this.boxNodePrefab), this.node.parent.addChild(o, 1e3),
                o.setName("BoxNode")), 1 == e ? o.getComponent("boxNode").showHuNode() : 2 == e ? o.getComponent("boxNode").showKaiJuDaoJuNode() : 3 == e ? o.getComponent("boxNode").showPropBaoXiang() : 4 == e && o.getComponent("boxNode").showSkinNode(t),
            o.active = !0, this.isGamePause = !0;
    },
    closeBoxNode: function() {
        this.isGamePause = !1;
    },
    useHuDun: function(e) {
        return !this.inGoldGuan && (this.isGamePause = !1, this.invincibleTimes <= 0 && (this.scrollSpeed != Global.invincibleSpeed && this.scrollSpeed != Global.iceSpeed && (this.lastSpeed = this.scrollSpeed),
                this.playAndStopHuDunEffect(!0)), this.iceTime > 0 && (this.iceTime = 0, this.node.parent.getComponent("gameScene").changeIcePrg(0)),
            this.invincibleTimes = Global.huDunTime, this.allInvincibleTimes = Global.huDunTime,
            this.scrollSpeed = Global.invincibleSpeed, this.getAudioManager().playQuest(), !0);
    },
    useIce: function() {
        this.invincibleTimes > 0 || (this.scrollSpeed != Global.invincibleSpeed && this.scrollSpeed != Global.iceSpeed && (this.lastSpeed = this.scrollSpeed),
            this.iceTime = Global.iceTime, this.scrollSpeed = Global.iceSpeed);
    },
    useHudun2: function() {
        this.huDunNode.active = !0, this.showBodyCount();
    },
    playAndStopHuDunEffect: function(e) {
        if (e) {
            this.tailNode.active = !0, this.effectBg.active = !0, this.tailNode.position = this.snakeHead.position,
                this.tailNode.getComponent(cc.ParticleSystem).resetSystem();
            var t = Global.invincibleColor;
            this.snakeHead.color = t, this.head2.color = t;
            for (var o = 0; o < this.snakeHead.childrenCount; o++) {
                this.snakeHead.children[o].color = t;
            }
            var i = cc.repeatForever(cc.sequence(cc.moveBy(.03, 2, 1), cc.moveBy(.03, -2, -1)));
            this.effectBg.runAction(i);
        } else {
            this.tailNode.active = !1, this.effectBg.active = !1, this.effectBg.stopAllActions(),
                this.effectBg.setPosition(0, 0);
            var n = cc.Color.WHITE;
            this.snakeHead.color = n, this.head2.color = n;
            for (var a = 0; a < this.snakeHead.childrenCount; a++) {
                this.snakeHead.children[a].color = n;
            }
        }
    },
    useAndStopMagnet: function(e) {
        if (e) this.magnetTime = 0, this.magnetNode.stopAllActions(), this.magnetNode.active = !1;
        else {
            if (this.getAudioManager().playMagnet(), this.magnetTime > 0) return void(this.magnetTime = Global.magnetTime);
            this.magnetNode.stopAllActions(), this.magnetTime = Global.magnetTime, this.magnetNode.active = !0;
            var t = 3.5;
            10 == Global.skinData.select || 11 == Global.skinData.select ? t = 2.8 : 15 == Global.skinData.select && (t = 2.5),
                this.magnetNode.scale = t, this.magnetNode.opacity = 0;
            var o = cc.callFunc(function() {
                this.magnetNode.scale = t, this.magnetNode.opacity = 0;
            }, this);
            this.magnetNode.runAction(cc.repeatForever(cc.sequence(cc.spawn(cc.scaleTo(.5, 1.5, 1.5), cc.fadeTo(.5, 255)), o, cc.delayTime(.3))));
        }
    },
    useAndStopShoot: function(e) {
        return e ? (this.shootTime = 0, this.unschedule(this.shootBall), !0) : !this.inGoldGuan && (this.getAudioManager().playStartShoot(),
            this.shootTime > 0 ? (this.shootTime = Global.shootTime, !0) : (this.shootTime = Global.shootTime,
                this.schedule(this.shootBall, Global.shootInterval), !0));
    },
    shootBall: function() {
        if (!this.isGamePause)
            if (this.isGameEnd) this.useAndStopShoot(!0);
            else {
                this.shootTime -= Global.shootInterval, this.shootTime <= 0 && this.useAndStopShoot(!0),
                    this.getAudioManager().playShoot();
                var e = cc.poolNode.shootBallPool.Get();
                e.position = this.snakeHead.position, e.y += this.snakeHead.height / 2 + e.height / 2 + 1,
                    3 == Global.skinData.select ? e.y -= 20 : 6 == Global.skinData.select && (e.y -= 16),
                    this.node.addChild(e);
            }
    },
    useAddBall: function(e) {
        this.isGamePause = !1, this.addBalls(e);
    },
    addBalls: function(e, t) {
        this.node.getChildByName("head").getComponent("snakeHead").resetAddBall();
        for (var o = 0; o < e; o++) this.addBall();
        this.showBodyCount(), t && this.getAudioManager().playCollect();
    },
    addBall: function() {
        var e = this.node.getChildByName("head"),
            t = cc.poolNode.bodyPool.Get();
        e.addChild(t), this.sumBall++, t.setPosition(cc.v2(0, e.height - e.height * (this.sumBall + 1))),
            this.invincibleTimes > 0 && (t.color = Global.invincibleColor);
    },
    showFD: function() {
        if (!(Global.getHBCount() >= 1800)) {
            this.isGamePause = !0;
            var e = cc.instantiate(this.hbNodePre);
            e.parent = this.node.parent, e.zIndex = 1e3, e.getComponent("hbNode").showGetHbNode();
        }
    },
    addBlock: function(e, t, o, i, n) {
        if (o > 0) {
            var a = cc.poolNode.blockPool.Get();
            a.setPosition(e, t), this.node.addChild(a);
            var s = cc.poolNode.labelPool.Get();
            s.getComponent(cc.Label).string = o, s.getComponent(cc.Label).fontSize = 55, s.setPosition(e, t),
                s.color = cc.color(0, 0, 0, 255), this.node.parent.getChildByName("lblNode").addChild(s),
                a.getComponent("block").lblData = s;
            var l = a.getChildByName("hbIcon");
            if (l && (l.active = !1), i) {
                l ? l.active = !0 : ((l = cc.instantiate(this.hbIcon)).name = "hbIcon", l.position = cc.v2(0, 0),
                    l.zIndex = 2e3, a.addChild(l)), s.active = !0;
                var c = t + a.height / 2 - (a.height - (s.height + 6 + l.height)) / 2;
                s.setPosition(e, c - s.height / 2), l.setPosition(0, -s.height / 2);
            } else {
                if (n) {
                    var h = cc.poolNode.skillPool.Get();
                    h.getComponent("skill").setSkillType(n), this.node.parent.getChildByName("particleNode").addChild(h);
                    var r = t + a.height / 2 - (a.height - (s.height + 6 + h.height)) / 2;
                    s.setPosition(e, r - s.height / 2), h.setPosition(e, r - s.height - 6 - h.height / 2),
                        a.getComponent("block").skillType = n, a.getComponent("block").skillData = h;
                }
                s.active = !0;
            }
            a.getComponent("block").setValue(o);
        }
    },
    addFood: function(e, t, o) {
        if (o > 0) {
            var i = cc.poolNode.foodPool.Get();
            i.setPosition(e, t), this.node.addChild(i);
            var n = 1;
            i.height > 80 && (n = .7), i.scale = n;
            var a = cc.poolNode.labelPool.Get();
            a.setPosition(e, t + i.height * n / 2 + 18), a.getComponent(cc.Label).string = o,
                a.getComponent(cc.Label).fontSize = 36, a.color = cc.color(255, 255, 255, 255),
                a.active = !0, this.node.parent.getChildByName("lblNode").addChild(a), i.getComponent("food").lblData = a,
                i.getComponent("food").setValue(o);
        }
    },
    addBar: function(e, t) {
        var o = cc.poolNode.barPool.Get();
        o.setPosition(e, t), this.node.addChild(o);
    },
    addLongBar: function(e, t) {
        var o = cc.poolNode.longBarPool.Get();
        o.setPosition(e, t), this.node.addChild(o);
    },
    addSkinBox: function(e, t, o, i) {
        var n = cc.poolNode.skinBoxPool.Get();
        n.setPosition(e, t), n.getComponent("skinBox").setSkin(this.getUnLockSkin(o, i)),
            this.node.addChild(n);
    },
    clearEffect: function() {
        for (var e = this.node.childrenCount, t = [], o = 0; o < e; o++) {
            var i = this.node.children[o];
            i.getComponent("effectLine") && t.push(i);
        }
        for (var n = 0; n < t.length; n++) t[n].getComponent("effectLine").removeSelf();
    },
    getUnLockSkin: function(e, t) {
        var o = 1,
            i = 5;
        do {
            if (o = Global.getRand(e, t), 0 == --i) break;
        } while (Global.getIsUnLockSkin(o));
        if (!Global.getIsCanShow(o) || Global.getIsUnLockSkin(o))
            for (var n = e; n <= t; n++)
                if (!Global.getIsUnLockSkin(n) && Global.getIsCanShow(n)) {
                    o = n;
                    break;
                }
        return o;
    },
    addGold: function() {
        this.addGoldCount++, this.node.parent.getComponent("gameScene").addGold(1);
    },
    addPropBox: function(e, t, o) {
        var i = null;
        (i = 1 != o ? cc.poolNode.propBoxPool.Get() : cc.poolNode.goldPool.Get()).setPosition(e, t),
            i.getComponent("propBox").showProp(o), this.node.addChild(i);
    },
    addStartFood: function() {
        for (var e = 0, t = 1; t <= 3; t++) {
            for (var o = this.getRand(0, 2), i = []; o > 0;) {
                var n = this.getRand(0, 4);
                if (i.length > 0) {
                    for (var a = 0; a < i.length && i[a] != n; a++)
                        if (a == i.length - 1) {
                            i.push(n), o--;
                            break;
                        }
                } else i.push(n), o--;
            }
            for (var s = 0; s < i.length; s++)
                if (this.addFood(this.eatArrayPos[i[s]], this.defaultY - 142 * t, this.getRand(Global.OneFoodNum.min, Global.OneFoodNum.max)),
                    ++e >= 3) return;
        }
    },
    getRand: function(e, t) {
        return Math.floor(Math.random() * (t + 1 - e) + e);
    },
    rollMatrix: function() {
        this.timeCount = (this.timeCount + 1) % (this.timeInterVal / this.scrollSpeed + 1),
            0 == Math.floor(this.timeCount) && (this.rollLine(this.line, this.sumBall), this.line += 1);
    },
    getSkillType: function() {
        var e = Math.random();
        return e <= .2 ? 1 : e <= .6 ? 2 : 3;
    },
    startAndStopGoldLine: function(e) {
        e ? (this.invincibleTimes > 0 && (this.scrollSpeed = this.lastSpeed, this.invincibleTimes = 0,
                this.node.parent.getComponent("gameScene").changePrg(0), this.playAndStopHuDunEffect(!1),
                this.clearEffect()), this.magnetTime > 0 && this.useAndStopMagnet(!0), this.shootTime > 0 && this.useAndStopShoot(!0),
            this.iceTime > 0 && (this.iceTime = 0, this.scrollSpeed = this.lastSpeed, this.node.parent.getComponent("gameScene").changeIcePrg(0)),
            this.lastSpeed = this.scrollSpeed, this.scrollSpeed = Global.goldLineSpeed, this.effectBg.active = !0,
            this.inGoldGuan = !0) : (this.scrollSpeed = this.lastSpeed, this.effectBg.active = !1,
            this.inGoldGuan = !1);
    },
    getIsShowFDInLine: function(e) {
        return !!Global.canshowHB() && (!Global.haveMaxHBCount() && (!this.lastFDIsShow && (e % (Global.showFDLineCount + 1) == this.lastShowFDLine && (this.lastFDIsShow = !0,
            !0))));
    },
    resetShowFDLevel: function(e) {
        if ((e - 1) % Global.showFDLineCount == 0) {
            var t = 1;
            1 == e && (t = 2), this.lastShowFDLine = this.getRand(t, Global.showFDLineCount),
                this.lastFDIsShow = !1;
        }
    },
    rollLine: function(e, t) {
        if (0 == e) {
            for (var o = 0; o < 5; o++) this.addBlock(this.eatArrayPos[o], this.defaultY, this.getRand(1, 2));
            this.addStartFood(), this.barrier = e + this.getRand(Global.BarrierSpacing.min, Global.BarrierSpacing.max),
                this.sequenceCount++, this.resetShowFDLevel(this.sequenceCount), this.isShowGoldLine = !1,
                this.goldLine = 0, this.GenerateElePos();
        } else if (this.barrier == e) {
            if (!this.isShowGoldLine && Global.getIsShowGold(this.sequenceCount) && (this.goldLine = 3,
                    this.isShowGoldLine = !0, this.lineCount = 5), this.goldLine > 0) {
                for (var i = 0; i < 5; i++) this.addPropBox(this.eatArrayPos[i], this.defaultY, 1);
                var n = this.getRand(Global.BarrierSpacing.min, Global.BarrierSpacing.max);
                return this.barrier = e + n, 1 == this.goldLine && (this.barrier += 2, this.lineCount = 5 + n - 1),
                    this.GenerateElePos(0, !0), void this.goldLine--;
            }
            this.isShowGoldLine = !1, this.goldLine = 0, this.sequenceCount++, this.resetShowFDLevel(this.sequenceCount);
            var a = 0,
                s = 0;
            if (Global.getisShowSkill(this.sequenceCount))
                for (var l = Math.random() <= .7 ? 1 : 2, c = 0; c < l; c++) Math.random() <= .5 ? a++ : s++;
            for (var h = [], r = 0; r < 5; r++) h[r] = this.getRand(1, 50);
            for (var d = [], u = 0; u < 5; u++) d.push(u);
            var g = [];
            if (a > 0)
                for (var p = 0; p < a; p++) {
                    var m = this.getRand(0, d.length - 1);
                    g.push(d[m]), d.splice(m, 1);
                }
            for (var f = [], b = 0; b < 2; b++) {
                var v = this.getRand(0, d.length - 1);
                f.push(d[v]), d.splice(v, 1);
            }
            var G = !1;
            this.getIsShowFDInLine(this.sequenceCount) && (G = !0);
            for (var k = 0; k < 5; k++) {
                for (var y = !1, S = 0; S < g.length; S++)
                    if (g[S] == k) {
                        this._score <= 100 ? h[k] = this.getRand(5, 10) : this._score <= 200 ? h[k] = this.getRand(5, 20) : h[k] = this.getRand(10, 25),
                            this.addBlock(this.eatArrayPos[k], this.defaultY, h[k], !1, this.getSkillType()),
                            y = !0;
                        break;
                    }
                if (!y) {
                    for (var C = 0; C < f.length; C++)
                        if (f[C] == k) {
                            y = !0, t > 1 && (h[k] > t && (h[k] = this.getRand(t > 10 ? 5 : 1, t < 50 ? t : 50)),
                                G ? (G = !1, this.addBlock(this.eatArrayPos[k], this.defaultY, h[k], !0)) : this.addBlock(this.eatArrayPos[k], this.defaultY, h[k], !1));
                            break;
                        }
                    y || y || this.addBlock(this.eatArrayPos[k], this.defaultY, h[k], !1);
                }
            }
            this.barrier = e + this.getRand(Global.BarrierSpacing.min, Global.BarrierSpacing.max),
                this.GenerateElePos(s), this.invincibleTimes <= 0 && this.scrollSpeed != Global.iceSpeed && (this.scrollSpeed += Global.addSpeed,
                    this.scrollSpeed >= Global.maxSpeed && (this.scrollSpeed = Global.maxSpeed));
        } else {
            var A = this.barrier - e,
                D = this.barPos.length;
            this.lineCount > 0 && (this.lineCount--, 0 == this.lineCount && (this.goldLine > 0 ? this.startAndStopGoldLine(!0) : this.startAndStopGoldLine(!1)));
            for (var N = 0; N < 4; N++) 1 === this.barPos[D - A][N] ? this.addBar(this.barArrayPos[N], this.defaultY) : 2 === this.barPos[D - A][N] && this.addLongBar(this.barArrayPos[N], this.defaultY + this.node.width / 10);
            for (var w = 0; w < 5; w++) {
                var x = this.foodAndBlockPos[D - A][w];
                if (3 === x || 100 === x) {
                    var T = 0;
                    100 === x && (T = this._score <= 100 ? this.getRand(5, 10) : this._score <= 200 ? this.getRand(5, 20) : this.getRand(10, 25)),
                        this.addBlock(this.eatArrayPos[w], this.defaultY, 100 == x ? T : this.getRand(1, 50), !1, 100 == x ? this.getSkillType() : 0);
                } else 4 === x ? this.addFood(this.eatArrayPos[w], this.defaultY, this.getRand(Global.OneFoodNum.min, Global.OneFoodNum.max)) : 5 === x ? this.addSkinBox(this.eatArrayPos[w], this.defaultY, 2, 9) : 6 === x ? this.addPropBox(this.eatArrayPos[w], this.defaultY, 0) : 7 === x ? this.addSkinBox(this.eatArrayPos[w], this.defaultY, 10, 16) : 8 === x ? this.addPropBox(this.eatArrayPos[w], this.defaultY, 1) : 9 === x ? this.addPropBox(this.eatArrayPos[w], this.defaultY, 2) : 10 === x && this.addPropBox(this.eatArrayPos[w], this.defaultY, 3);
            }
        }
    },
    GenerateElePos: function(e, t) {
        var o = this.barrier - this.line;
        this.barPos = [], this.foodAndBlockPos = [];
        for (var i = 0; i < o - 1; i++) {
            this.barPos[i] = [], this.foodAndBlockPos[i] = [];
            for (var n = 0; n < 4; n++) this.barPos[i][n] = 0;
            for (var a = 0; a < 5; a++) this.foodAndBlockPos[i][a] = 0;
        }
        t && 1 == this.goldLine && (o -= 2);
        for (var s = 4 * (o - 1), l = [], c = 0; c < o - 1; c++) l[c] = 0;
        for (var h = this.getRand(Global.BarCount.min, Global.BarCount.max), r = 0; h > 0 && s > 0;) {
            for (var d = this.getRand(1, s), u = 0; u < d; u++)
                for (; r = (r + 1) % (4 * (o - 1)),
                    0 !== this.barPos[Math.floor(r / 4)][r % 4];);
            var g = Math.floor(r / 4),
                p = !1;
            if (g + 2 < o - 1 && 1 === l[g + 1] && 1 === l[g + 2] ? p = !0 : g + 1 < o - 1 && g - 1 >= 0 && 1 === l[g + 1] && 1 === l[g - 1] ? p = !0 : g - 2 >= 0 && 1 === l[g - 1] && 1 === l[g - 2] && (p = !0),
                s--, p) {
                for (var m = 0; m < 4; m++) this.barPos[g][m] = -1;
                s -= 3;
            } else h--, l[g] = 1, this.barPos[g][r % 4] = 1;
        }
        for (var f = 0; f < 4 * (o - 1); f++) 1 === this.barPos[Math.floor(f / 4)][f % 4] && (this.foodAndBlockPos[Math.floor(f / 4)][f % 4] = -1,
            this.foodAndBlockPos[Math.floor(f / 4)][f % 4 + 1] = -1);
        for (var b = 5 * (o - 1), v = 0; v < 5 * (o - 1); v++) - 1 === this.foodAndBlockPos[Math.floor(v / 5)][v % 5] && b--;
        for (var G = 0; G < 5; G++) 0 === this.foodAndBlockPos[0][G] && (this.foodAndBlockPos[0][G] = -1,
            b--), 0 === this.foodAndBlockPos[o - 2][G] && (this.foodAndBlockPos[o - 2][G] = -1,
            b--);
        var k = this.getRand(Global.BlockCount.min, Global.BlockCount.max);
        t && (k = Global.BlockCount.max);
        for (var y = 0; k > 0 && b > 0;) {
            for (var S = this.getRand(1, b), C = 0; C < S; C++)
                for (; y = (y + 1) % (5 * (o - 1)),
                    0 !== this.foodAndBlockPos[Math.floor(y / 5)][y % 5];);
            k--, b--;
            var A = Math.floor(y / 5);
            if (this.foodAndBlockPos[A][y % 5] = 3, A > 0)
                for (var D = 0; D < 5; D++) 0 === this.foodAndBlockPos[A - 1][D] && (this.foodAndBlockPos[A - 1][D] = -1,
                    b--);
            if (A < o - 2)
                for (var N = 0; N < 5; N++) 0 === this.foodAndBlockPos[A + 1][N] && (this.foodAndBlockPos[A + 1][N] = -1,
                    b--);
            for (var w = 0, x = 0; x < 5; x++) 3 === this.foodAndBlockPos[A][x] && w++;
            if (w >= 2)
                for (var T = 0; T < 5; T++) 0 === this.foodAndBlockPos[A][T] && (this.foodAndBlockPos[A][T] = -1,
                    b--);
        }
        for (var I = 5 * (o - 1), B = 0; B < 5 * (o - 1); B++) 3 === this.foodAndBlockPos[Math.floor(B / 5)][B % 5] && I--;
        var P = this.getRand(Global.FoodCount.min, Global.FoodCount.max);
        t && (P = Global.FoodCount.max + 4);
        for (var L = 0; P > 0 && I > 0;) {
            for (var M = this.getRand(1, I), _ = 0; _ < M; _++)
                for (; L = (L + 1) % (5 * (o - 1)),
                    3 === this.foodAndBlockPos[Math.floor(L / 5)][L % 5];);
            P--, I--;
            var F = Math.floor(L / 5);
            this.foodAndBlockPos[F][L % 5] = 4;
        }
        for (var H = 0; H < 4 * (o - 2); H++) 1 == this.barPos[Math.floor(H / 4)][H % 4] && 1 == this.barPos[Math.floor((H + 4) / 4)][H % 4] && (this.barPos[Math.floor(H / 4)][H % 4] = 2,
            this.barPos[Math.floor((H + 4) / 4)][H % 4] = 0);
        if (t)
            for (var R = 0; R < 5 * (o - 1); R++) 3 !== this.foodAndBlockPos[Math.floor(R / 5)][R % 5] && 4 !== this.foodAndBlockPos[Math.floor(R / 5)][R % 5] || (this.foodAndBlockPos[Math.floor(R / 5)][R % 5] = 8);
        else {
            for (var E = 5 * (o - 1), q = 0; q < 5 * (o - 1); q++) 3 !== this.foodAndBlockPos[Math.floor(q / 5)][q % 5] && 4 !== this.foodAndBlockPos[Math.floor(q / 5)][q % 5] || E--;
            if (Global.getisShowqpztcspf(this.sequenceCount)) {
                for (var O = !1, J = 2; J <= 9; J++)
                    if (Global.getIsCanShow(J) && !Global.getIsUnLockSkin(J)) {
                        O = !0;
                        break;
                    }
                if (O) {
                    for (var U = 0, V = this.getRand(1, E), X = 0; X < V; X++)
                        for (; U = (U + 1) % (5 * (o - 1)),
                            3 === this.foodAndBlockPos[Math.floor(U / 5)][U % 5] || 4 === this.foodAndBlockPos[Math.floor(U / 5)][U % 5];);
                    var z = Math.floor(U / 5);
                    this.foodAndBlockPos[z][U % 5] = 5, E--;
                }
            }
            if (Global.getisShowqpzbx(this.sequenceCount)) {
                for (var j = 0, W = this.getRand(1, E), Y = 0; Y < W; Y++)
                    for (; j = (j + 1) % (5 * (o - 1)),
                        3 === this.foodAndBlockPos[Math.floor(j / 5)][j % 5] || 4 === this.foodAndBlockPos[Math.floor(j / 5)][j % 5] || 5 === this.foodAndBlockPos[Math.floor(j / 5)][j % 5];);
                var K = Math.floor(j / 5);
                this.foodAndBlockPos[K][j % 5] = 6, E--;
            }
            if (Global.getisShowqpztcsxypf(this.sequenceCount)) {
                for (var Q = !1, Z = 10; Z <= 16; Z++)
                    if (Global.getIsCanShow(Z) && !Global.getIsUnLockSkin(Z)) {
                        Q = !0;
                        break;
                    }
                if (Q) {
                    for (var $ = 0, ee = this.getRand(1, E), te = 0; te < ee; te++)
                        for (; $ = ($ + 1) % (5 * (o - 1)),
                            3 === this.foodAndBlockPos[Math.floor($ / 5)][$ % 5] || 4 === this.foodAndBlockPos[Math.floor($ / 5)][$ % 5] || 5 === this.foodAndBlockPos[Math.floor($ / 5)][$ % 5] || 6 === this.foodAndBlockPos[Math.floor($ / 5)][$ % 5];);
                    var oe = Math.floor($ / 5);
                    this.foodAndBlockPos[oe][$ % 5] = 7, E--;
                }
            }
            if (Global.getIsShowQpdj(this.sequenceCount))
                for (var ie = 1, ne = 0; ie > 0 && E > 0;) {
                    for (var ae = this.getRand(1, E), se = 0; se < ae; se++)
                        for (; ne = (ne + 1) % (5 * (o - 1)),
                            3 === this.foodAndBlockPos[Math.floor(ne / 5)][ne % 5] || 4 === this.foodAndBlockPos[Math.floor(ne / 5)][ne % 5] || 5 === this.foodAndBlockPos[Math.floor(ne / 5)][ne % 5] || 6 === this.foodAndBlockPos[Math.floor(ne / 5)][ne % 5];);
                    ie--, E--;
                    var le = Math.floor(ne / 5);
                    this.foodAndBlockPos[le][ne % 5] = 0 == this.getRand(0, 1) ? 9 : 10;
                }
            if (e > 0) {
                for (var ce = [], he = 0; he < o - 1; he++)
                    for (var re = 0; re < 5; re++) 3 === this.foodAndBlockPos[he][re] && ce.push(5 * he + re);
                for (var de = 0; de < e; de++) {
                    var ue = this.getRand(0, ce.length - 1);
                    this.foodAndBlockPos[Math.floor(ce[ue] / 5)][ce[ue] % 5] = 100, ce.slice(ue, 1);
                }
            }
        }
    }
})
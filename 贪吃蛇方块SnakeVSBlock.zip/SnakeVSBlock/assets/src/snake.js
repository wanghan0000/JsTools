cc.Class({
    extends: cc.Component,
    properties: {
        snakeHead: cc.Node,
        sum: 0
    },
    onLoad: function() {
        this.distance = 0, this.snakeUIs = [], this.track = [], this.snakeHeadY = 0, this.snakeGap = -8,
            this.secondIndex = 0, this.snakeHead.zIndex = 1e3, this.speed = 6, this.snakeUIs.push(this.snakeHead),
            this.lastPosX = -1;
    },
    addBody: function(e, t) {
        if (0 == this.sum)
            for (var o = 0; o < e; o++) {
                var i = cc.poolNode.bodyPool.Get();
                i.position = cc.v2(0, 0 - (this.sum + 1) * i.height), this.node.addChild(i), this.sum++,
                    this.snakeUIs.push(i);
            } else
                for (var n = 0; n < e; n++) this.scheduleOnce(function() {
                    var e = cc.poolNode.bodyPool.Get();
                    this.node.addChild(e), this.sum++, this.snakeUIs.push(e), e.active = !1;
                }, .05 * (n + 1));
    },
    isVoid: function(e) {
        return null == e || void 0 == e;
    },
    removeBody: function() {
        var e = this.snakeUIs[1];
        e.parent && e.parent.removeChild(e), this.snakeUIs.splice(1, 1), this.snakeUIs.length > 0 && (this.snakeHead = this.snakeUIs[0],
                this.isVoid(this.secondIndex) || this.track.slice(this.secondIndex)), this.snakeHead.position = e.position,
            Math.abs(this.snakeHead.y) > 40 && cc.log("123");
    },
    moveToNextFrame: function() {
        var e = this.node.parent.getComponent("gameMatrix");
        this.scrollSpeed = e.scrollSpeed;
        var t = (e.snakePosX - this.snakeHead.x) / 3,
            o = Math.atan(t / this.scrollSpeed) / Math.PI * 180;
        o > 45 ? o = 45 : o < -45 && (o = -45);
        for (var i = Math.floor(this.scrollSpeed), n = 1; n <= i; n++) {
            this.node.parent.getComponent("gameMatrix").inEat || this.node.parent.getComponent("gameMatrix").shouldInEat ? console.log("123") : this.distance--;
            var a = this.snakeHead.x + t * (n / i);
            this.track.push({
                x: a,
                y: this.distance,
                r: o
            });
        }
        this.lastPosX = e.snakePosX;
    },
    updateSnake: function() {
        if (!(this.snakeUIs.length < 1)) {
            this.moveToNextFrame();
            var e = this.track.length - 1;
            this.snakeHead.x = this.track[e].x, this.snakeHead.y = this.snakeHead.y + this.distance - this.track[e].y,
                this.snakeHead.y < this.snakeHeadY ? (this.snakeHead.y += this.speed, this.snakeHead.y >= this.snakeHeadY && (this.snakeHead.y = this.snakeHeadY,
                    this.isReady || (this.isReady = !0), this.node.parent.getComponent("gameMatrix").inEat && (this.node.parent.getComponent("gameMatrix").shouldUnEat = 1))) : this.node.parent.getComponent("gameMatrix").inEat && (this.node.parent.getComponent("gameMatrix").shouldUnEat = 1),
                this.snakeHead.rotation = this.track[e].r, e--;
            for (var t = this.isReady ? this.snakeHeadY : this.snakeHead.y, o = 1; o < this.snakeUIs.length; o++) {
                for (; e - 1 >= 0;) {
                    var i = this.track[e - 1].x - this.snakeUIs[o - 1].x,
                        n = t + this.distance - this.track[e - 1].y - this.snakeUIs[o - 1].y,
                        a = i * i + n * n,
                        s = 180 - Math.abs(this.track[e - 1].r - this.snakeUIs[o - 1].rotation),
                        l = (48.3 + this.snakeGap) * s / 180;
                    if (a >= l * l) {
                        var c = this.snakeUIs[o];
                        c.active = !0, c.y = t + this.distance - this.track[e].y, c.x = this.track[e].x,
                            c.rotation = this.track[e].r, 1 == o && (this.secondIndex = e), e--;
                        break;
                    }
                    e--;
                }
                if (0 > e - 1) break;
            }
            this.track.length > this.node.height && this.track.splice(0, this.track.length - this.node.height);
        }
    }
})
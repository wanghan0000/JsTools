cc.Class({
    extends: cc.Component,
    properties: {},
    update: function(e) {
        this.node.y - this.node.height / 2 > this.node.parent.height / 2 ? this.removeSelf() : this.node.parent.getComponent("gameMatrix").isGamePause || (this.node.parent.getComponent("gameMatrix").isGameEnd ? this.removeSelf() : this.node.y = this.node.y + 1e3 * e);
    },
    removeSelf: function() {
        cc.poolNode.shootBallPool.Push(this.node), this.node.parent.removeChild(this.node, !1);
    }
})
var prefabPool = require('prefabPool');
cc.Class({
    extends: cc.Component,
    properties: {
        blockPrefab: cc.Prefab,
        barPrefab: cc.Prefab,
        longBarPrefab: cc.Prefab,
        labelPrefab: cc.Prefab,
        blockParticle: cc.Prefab,
        foodPrefab: cc.Prefab,
        bodyPrefab: cc.Prefab,
        bodyParticle: cc.Prefab,
        propBox: cc.Prefab,
        skinBox: cc.Prefab,
        skillPrefab: cc.Prefab,
        shootBallPrefab: cc.Prefab,
        lastSelectSkin: 0
    },
    onLoad: function() {
        cc.game.addPersistRootNode(this.node), this.lastSelectSkin = 1, this.initPool(),
            cc.poolNode = this;
    },
    initPool: function() {
        this.foodPool = new prefabPool(this.foodPrefab, 15), this.bodyPool = new prefabPool(this.bodyPrefab, 100),
            this.checkPool(), this.blockPool = new prefabPool(this.blockPrefab, 20), this.barPool = new prefabPool(this.barPrefab, 20),
            this.longBarPool = new prefabPool(this.longBarPrefab, 20), this.labelPool = new prefabPool(this.labelPrefab, 30),
            this.blockParticlePool = new prefabPool(this.blockParticle, 2), this.bodyParticlePool = new prefabPool(this.bodyParticle, 5),
            this.propBoxPool = new prefabPool(this.propBox, 1), this.skinBoxPool = new prefabPool(this.skinBox, 0),
            this.shootBallPool = new prefabPool(this.shootBallPrefab, 5), this.skillPool = new prefabPool(this.skillPrefab, 0),
            this.goldPool = new prefabPool(this.propBox, 20);
    },
    checkPool: function() {
        if (this.lastSelectSkin != Global.skinData.select) {
            this.lastSelectSkin = Global.skinData.select;
            var e = "body_" + ("" + (this.lastSelectSkin < 10 ? "0" + this.lastSelectSkin : this.lastSelectSkin)),
                t = this,
                o = cc.instantiate(this.foodPrefab),
                i = cc.instantiate(this.bodyPrefab);
            cc.loader.loadRes("Skin/" + e, cc.SpriteFrame, function(e, n) {
                e || (o.getComponent(cc.Sprite).spriteFrame = n, t.foodPool.changePrefab(o), i.getComponent(cc.Sprite).spriteFrame = n,
                    t.bodyPool.changePrefab(i));
            });
            for (var n = this.foodPool.getArr(), a = function(t) {
                    var o = n[t];
                    cc.loader.loadRes("Skin/" + e, cc.SpriteFrame, function(e, t) {
                        e || (o.getComponent(cc.Sprite).spriteFrame = t);
                    });
                }, s = 0; s < n.length; s++) a(s);
            var l = this.bodyPool.getArr(),
                c = function(t) {
                    var o = l[t];
                    cc.loader.loadRes("Skin/" + e, cc.SpriteFrame, function(e, t) {
                        e || (o.getComponent(cc.Sprite).spriteFrame = t);
                    });
                };
            for (s = 0; s < l.length; s++) c(s);
        }
    }
})
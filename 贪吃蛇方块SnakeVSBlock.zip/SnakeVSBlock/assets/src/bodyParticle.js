cc.Class({
    extends: cc.Component,
    properties: {
        isPlay: !1
    },
    play: function() {
        this.isPlay = !0, this._tempTimes = 0, this.getComponent(cc.ParticleSystem).resetSystem();
    },
    update: function(e) {
        this.isPlay && (this._tempTimes += e, this._tempTimes >= 2 && (this.isPlay = !1,
            this._tempTimes = 0, this.playEnd()));
    },
    playEnd: function() {
        this.node.parent && (this.node.parent.removeChild(this.node), cc.poolNode.bodyParticlePool.Push(this.node));
    }
})
cc.Class({
    extends: cc.Component,
    properties: {
        bgAudio: {
            type: cc.AudioClip,
            default: null
        },
        hit: {
            type: cc.AudioClip,
            default: null
        },
        collect: {
            type: cc.AudioClip,
            default: null
        },
        explo: {
            type: cc.AudioClip,
            default: null
        },
        quest: {
            type: cc.AudioClip,
            default: null
        },
        magnet: {
            type: cc.AudioClip,
            default: null
        },
        shoot: {
            type: cc.AudioClip,
            default: null
        },
        startShoot: {
            type: cc.AudioClip,
            default: null
        },
        coin: {
            type: cc.AudioClip,
            default: null
        },
        coin2: {
            type: cc.AudioClip,
            default: null
        },
        times: {
            type: cc.AudioClip,
            default: null
        }
    },
    onLoad: function() {
        cc.game.addPersistRootNode(this.node);
    },
    stopAllAudio: function() {
        cc.audioEngine.stopAll();
    },
    checkAndResumeBgMusic: function() {
        if (this.bgAudio && !Global.isMute && (console.log("this.audioID" + this.audioID),
                void 0 != this.audioID)) {
            var e = cc.audioEngine.getState(this.audioID);
            e == cc.audioEngine.AudioState.ERROR ? (console.log("bgState = ERROR"), this.playBgMusic()) : e == cc.audioEngine.AudioState.INITIALZING ? console.log("bgState = INITIALZING") : e == cc.audioEngine.AudioState.PLAYING ? console.log("bgState = PLAYING") : e == cc.audioEngine.AudioState.PAUSED && (console.log("bgState = PAUSED"),
                cc.audioEngine.resume(this.audioID));
        }
    },
    playBgMusic: function() {
        this.bgAudio && (Global.isMute || (this.audioID = cc.audioEngine.play(this.bgAudio, !0, .5)));
    },
    playCoin: function() {
        this.coin && (Global.isMute || cc.audioEngine.play(this.coin, !1, 1));
    },
    playCoin2: function() {
        this.coin && (Global.isMute || cc.audioEngine.play(this.coin2, !1, 1));
    },
    playTimes: function() {
        this.coin && (Global.isMute || cc.audioEngine.play(this.times, !1, 1));
    },
    playHit: function() {
        this.hit && (Global.isMute || cc.audioEngine.play(this.hit, !1, 1));
    },
    playCollect: function() {
        this.collect && (Global.isMute || cc.audioEngine.play(this.collect, !1, 1));
    },
    playExplo: function() {
        this.explo && (Global.isMute || cc.audioEngine.play(this.explo, !1, 1));
    },
    playQuest: function() {
        this.quest && (Global.isMute || cc.audioEngine.play(this.quest, !1, 1));
    },
    playMagnet: function() {
        this.magnet && (Global.isMute || cc.audioEngine.play(this.magnet, !1, 1));
    },
    playShoot: function() {
        this.shoot && (Global.isMute || cc.audioEngine.play(this.shoot, !1, 1));
    },
    playStartShoot: function() {
        this.startShoot && (Global.isMute || cc.audioEngine.play(this.startShoot, !1, 1));
    }
})
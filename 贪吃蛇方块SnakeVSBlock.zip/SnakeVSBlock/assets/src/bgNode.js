cc.Class({
    extends: cc.Component,
    properties: {
        bgItemPrefab: cc.Prefab,
        selectUnLock: 0,
        goldCount: cc.Label,
        time: 0
    },
    show: function() {
        this.selectUnLock = 0, this.goldCount.string = Global.gold;
        var e = this.node.getChildByName("ItemLayout");
        if (0 == e.childrenCount)
            for (var t = 1; t <= 4; t++) {
                var o = cc.instantiate(this.bgItemPrefab);
                o.getComponent("bgItem").show(t), e.addChild(o), o.on("select", this.onSelect.bind(this));
            }
    },
    update: function(e) {
        this.time += e, this.time > 1 && (this.goldCount.string = Global.gold);
    },
    onSelect: function(e) {
        e && (console.log("event.detail" + e), this.selectUnLock = 0, Global.getIsUnLockScene(e) ? this.changeSelectItem(e) : (this.selectUnLock = e,
            this.clearShowLockSelect(this.selectUnLock)));
    },
    changeSelectItem: function(e) {
        Global.setSceneSelectIndex(e);
        for (var t = this.node.getChildByName("ItemLayout"), o = 0; o < t.childrenCount; o++) {
            var i = t.children[o];
            i.getComponent("bgItem").clearShowLockSelect(), i.getComponent("bgItem").index != e ? i.getComponent("bgItem").selectItem(!1) : i.getComponent("bgItem").selectItem(!0);
        }
    },
    clearShowLockSelect: function(e) {
        for (var t = this.node.getChildByName("ItemLayout"), o = 0; o < t.childrenCount; o++) {
            var i = t.children[o];
            i.getComponent("bgItem").index != e && i.getComponent("bgItem").clearShowLockSelect();
        }
    },
    unLockSelectScene: function() {
        Global.toast("解锁场景成功！"), Global.unLockScene(this.selectUnLock), Global.setSceneSelectIndex(this.selectUnLock),
            Global.getTongJi("022", 1);
        for (var e = this.node.getChildByName("ItemLayout"), t = 0; t < e.childrenCount; t++) {
            var o = e.children[t];
            o.getComponent("bgItem").index == this.selectUnLock ? (o.getComponent("bgItem").unLock(),
                o.getComponent("bgItem").selectItem(!0)) : o.getComponent("bgItem").selectItem(!1);
        }
        this.selectUnLock = 0;
    },
    shareAndUnLock: function() {
        var e = this;
        Global.actionShare2(Global.sceneShareID, function() {
            e.unLockSelectScene();
        });
    },
    unLockSceneClick: function() {
        if (this.selectUnLock <= 0) Global.toast("请先选择需要解锁的场景!");
        else {
            var e = this;
            Global.getisShowVideo2(Global.sceneShareID) ? Global.showVideoAD(function() {
                e.unLockSelectScene();
            }, "038", function() {
                Global.isOldPlayer() && e.shareAndUnLock();
            }) : this.shareAndUnLock();
        }
    },
    onBackClick: function() {
        this.node.active = !1, this.ReShowMainSceneAD();
    },
    ReShowMainSceneAD: function() {
        var e = new cc.Event.EventCustom("ReShowMainAD", !0);
        this.node.dispatchEvent(e);
    },
    helpClick: function() {}
})
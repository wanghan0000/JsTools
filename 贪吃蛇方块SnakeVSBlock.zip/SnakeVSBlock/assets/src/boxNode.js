cc.Class({
    extends: cc.Component,
    properties: {
        huDunNode: cc.Node,
        kaiJuDaoJuNode: cc.Node,
        propBaoXiang: cc.Node,
        skinNode: cc.Node
    },
    closeAllNode: function() {
        this.huDunNode.active = !1, this.kaiJuDaoJuNode.active = !1, this.propBaoXiang.active = !1,
            this.skinNode.active = !1, this.node.getChildByName("bgColor").active = !1;
    },
    closeNode: function(e) {
        this.unschedule(this.updateTimer), this.node.active = !1;
        var t = new cc.Event.EventCustom("closeBoxNode", !0);
        t.detail = e || 0, this.node.dispatchEvent(t);
    },
    checkEvent: function() {},
    showHuNode: function() {
        this.closeAllNode(), this.huDunNode.active = !0, Global.btnAction(this.huDunNode.getChildByName("btnVideo")),
            this.huDunNode.getChildByName("btnClose").active = !1, this.scheduleOnce(function() {
                this.huDunNode.getChildByName("btnClose").active = !0;
            }, Global.passBtnShowTime);
    },
    updateTimer: function() {},
    UseHuDun: function(e) {
        this.node.active = !1, this.unschedule(this.updateTimer);
        var t = new cc.Event.EventCustom("useHuDun", !0);
        t.detail = e, this.node.dispatchEvent(t);
    },
    closeHuDunClick: function() {
        if (Global.isNormal) this.closeNode();
        else {
            var e = this,
                t = function() {
                    e.closeNode();
                };
            Global.alertGameDialog2(function(o) {
                o.confirm ? e.btnUseHuDunClick() : t && t();
            });
        }
    },
    btnUseHuDunClick: function() {
        var e = this;
        Global.actionShare2(Global.useHDShareID, function() {
            e.UseHuDun(6);
        }, function() {});
    },
    showKaiJuDaoJuNode: function() {
        this.closeAllNode(), this.kaiJuDaoJuNode.active = !0, Global.btnAction(this.kaiJuDaoJuNode.getChildByName("btnVideo")),
            this.kaiJuDaoJuNode.getChildByName("btnClose").active = !1, this.scheduleOnce(function() {
                this.kaiJuDaoJuNode.getChildByName("btnClose").active = !0;
            }, Global.passBtnShowTime);
    },
    closeKJDJClick: function() {
        if (Global.isNormal) this.closeNode();
        else {
            var e = this,
                t = function() {
                    e.closeNode();
                };
            Global.alertGameDialog2(function(o) {
                o.confirm ? e.btnUseKaiJuDaoJuClick() : t && t();
            });
        }
    },
    btnUseKaiJuDaoJuClick: function() {
        var e = this;
        this.unschedule(this.updateTimer), Global.actionShare2(Global.useKJDJShareID, function() {
            e.UseHuDun(6);
        }, function() {});
    },
    UseAddBalls: function(e) {
        this.node.active = !1, this.unschedule(this.updateTimer);
        var t = new cc.Event.EventCustom("AddBalls", !0);
        t.detail = e, this.node.dispatchEvent(t);
    },
    videoClick: function() {
        var e = this;
        if (this.kaiJuDaoJuNode.active) {
            if (this.unschedule(this.updateTimer), !Global.getIsFirstUseKJDJ()) return Global.setIsFirstUseKJDJ(),
                void e.UseHuDun(6);
            Global.getisShowVideo2(Global.useKJDJShareID) ? Global.showVideoAD(function() {
                e.UseHuDun(6);
            }, "029", function() {}) : this.btnUseKaiJuDaoJuClick();
        } else if (this.huDunNode.active) {
            if (this.unschedule(this.updateTimer), !Global.getIsFirstUseHD()) return Global.setIsFirstUseHD(),
                void e.UseHuDun(6);
            Global.getisShowVideo2(Global.useHDShareID) ? Global.showVideoAD(function() {
                e.UseHuDun(6);
            }, "030", function() {
                Global.isOldPlayer() && e.btnUseHuDunClick();
            }) : this.btnUseHuDunClick();
        } else if (this.propBaoXiang.active) Global.getisShowVideo2(Global.openPropBXShareID) ? Global.showVideoAD(function() {
            Global.operateGold(e._tempGold), e.UseAddBalls(e._temBodyCount);
        }, "031", function() {
            Global.isOldPlayer() && e.btnGetPropBaoXiang();
        }) : this.btnGetPropBaoXiang();
        else if (this.skinNode.active) {
            var t = "032",
                o = Global.getNormalTimeSkinID;
            e.curSkinIndex > 9 && (t = "033", o = Global.getSpecialTimeSkinID), Global.getisShowVideo2(o) ? Global.showVideoAD(function() {
                Global.toast("成功领取皮肤一个，快去主界面选用吧~"), Global.addTimeSkin(e.curSkinIndex), e.closeNode(1);
            }, t, function() {
                Global.isOldPlayer() && e.btnGetSkinClick();
            }) : this.btnGetSkinClick();
        }
    },
    showPropBaoXiang: function() {
        this.closeAllNode(), this.node.getChildByName("bgColor").active = !0, this.propBaoXiang.active = !0,
            this._tempGold = Global.getRand(25, 50), this._temBodyCount = Global.getRand(10, 20),
            this.propBaoXiang.getChildByName("gold").getChildByName("goldLb").getComponent(cc.Label).string = "+" + this._tempGold,
            this.propBaoXiang.getChildByName("body").getChildByName("bodyLb").getComponent(cc.Label).string = "+" + this._temBodyCount,
            Global.btnAction(this.propBaoXiang.getChildByName("btnVideo")), Global.showBannerId(3, this.node),
            this.propBaoXiang.getChildByName("btnClose").active = !1, this.scheduleOnce(function() {
                this.propBaoXiang.getChildByName("btnClose").active = !0;
            }, Global.passBtnShowTime);
    },
    btnGetPropBaoXiang: function() {
        var e = this;
        this.unschedule(this.updateTimer), Global.actionShare2(Global.openPropBXShareID, function() {
            Global.operateGold(e._tempGold), e.UseAddBalls(e._temBodyCount);
        });
    },
    closePropBaoXiangClick: function() {
        if (Global.isNormal) this.closeNode();
        else {
            var e = this,
                t = function() {
                    e.closeNode();
                };
            Global.alertGameDialog2(function(o) {
                o.confirm ? e.btnGetPropBaoXiang() : t && t();
            });
        }
    },
    changeSkin: function(e) {
        var t = this;
        this.curSkinIndex = e;
        var o = this.skinNode,
            i = "" + (this.curSkinIndex < 10 ? "0" + this.curSkinIndex : this.curSkinIndex),
            n = "pifu_" + i,
            a = "body_" + i,
            s = 4;
        10 == this.curSkinIndex || 11 == this.curSkinIndex ? s = 3 : 15 == this.curSkinIndex && (s = 2);
        for (var l = [42, 57, 71, 53, 59, 65, 57, 59, 57, 66, 66, 62, 65, 65, 101, 49], c = [40, 40, 40, 40, 40, 40, 40, 40, 40, 66, 66, 40, 40, 40, 101, 26], h = 1; h < 4; h++) {
            var r = o.getChildByName("body" + h);
            r && (o.removeChild(r), r.destroy());
        }
        var d = o.getChildByName("head");
        d.x = 0, 6 == this.curSkinIndex ? d.x = 2 : 9 == this.curSkinIndex && (d.x = -4);
        for (var u = function(e) {
                var i = null,
                    s = a;
                0 == e ? (s = n, i = d) : ((i = new cc.Node("body" + e)).addComponent(cc.Sprite),
                        i.parent = o, i.x = 0, i.y = d.y - (l[t.curSkinIndex - 1] / 2 + c[t.curSkinIndex - 1] / 2 + c[t.curSkinIndex - 1] * (e - 1)),
                        1 != t.curSkinIndex && 9 != t.curSkinIndex && 10 != t.curSkinIndex && 11 != t.curSkinIndex && 15 != t.curSkinIndex && 16 != t.curSkinIndex && (i.y += 10)),
                    i.zIndex = 4 - e, cc.loader.loadRes("Skin/" + s, cc.SpriteFrame, function(e, t) {
                        e || (i.getComponent(cc.Sprite).spriteFrame = t);
                    });
            }, g = 0; g < s; g++) u(g);
    },
    showSkinNode: function(e) {
        this.closeAllNode(), this.skinNode.active = !0, this.node.getChildByName("bgColor").active = !0,
            this.skinNode.getChildByName("sy").active = e > 9;
        var t = this.skinNode.getChildByName("contentLb").getComponent(cc.Label);
        t.string = e > 9 ? "恭喜获得稀有贪吃蛇一个，可以免费使用30分钟~" : "恭喜获得新款贪吃蛇一个，可以免费使用30分钟~";
        var o = this.skinNode.getChildByName("light");
        o.stopAllActions(), o.runAction(cc.repeatForever(cc.rotateBy(1, 90))), this.changeSkin(e),
            Global.btnAction(this.skinNode.getChildByName("btnVideo")), Global.showBannerId(3, this.node),
            this.skinNode.getChildByName("btnClose").active = !1, this.scheduleOnce(function() {
                this.skinNode.getChildByName("btnClose").active = !0;
            }, Global.passBtnShowTime);
    },
    closeSkinNodeClick: function() {
        if (Global.isNormal) this.closeNode(1);
        else {
            var e = this,
                t = function() {
                    e.closeNode(1);
                };
            Global.alertGameDialog2(function(o) {
                o.confirm ? e.btnGetSkinClick() : t && t();
            });
        }
    },
    btnGetSkinClick: function() {
        var e = this;
        this.unschedule(this.updateTimer);
        var t = Global.getNormalTimeSkinID;
        e.curSkinIndex > 9 && (t = Global.getSpecialTimeSkinID), Global.actionShare2(t, function() {
            Global.addTimeSkin(e.curSkinIndex), e.closeNode(1), Global.toast("成功领取皮肤一个，快去主界面选用吧~");
        });
    },
    btnCloseClick: function() {
        this.closeNode();
    }
})
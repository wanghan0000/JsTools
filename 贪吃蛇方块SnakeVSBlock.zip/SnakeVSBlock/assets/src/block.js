cc.Class({
    extends: cc.Component,
    properties: {
        value: 1,
        lastValue: 1,
        hDistance: 0,
        canNotTouch: !1,
        touchPosX: 0,
        skillType: 0,
        lblData: {
            default: null,
            type: cc.Node
        },
        skillData: {
            default: null,
            type: cc.Node
        }
    },
    onLoad: function() {},
    checkEnd: function() {
        this.node.y < Global.eleHidePosY && this.removeSelf();
    },
    checkTouch: function() {
        var e = this.node.parent.getChildByName("head"),
            t = this.node.parent.getComponent("gameMatrix").snakePosX,
            o = Math.abs(this.node.y - e.y) - this.node.height / 2 - e.height / 2;
        if (o <= -2) {
            if (!this.canNotTouch && this.node.y > e.y && e.x + e.width / 2 > this.node.x - this.node.width / 2 && e.x - e.width / 2 < this.node.x + this.node.width / 2) return this.hDistance = Math.abs(e.x - this.node.x),
                !0;
            if (e.x > this.node.x) {
                var i = this.node.x + this.node.width / 2 + e.width / 2 + 1;
                t < i && (this.node.parent.getComponent("gameMatrix").snakePosX = i);
            } else {
                var n = this.node.x - this.node.width / 2 - e.width / 2 - 1;
                t > n && (this.node.parent.getComponent("gameMatrix").snakePosX = n);
            }
        } else o <= 480 && this.skillType > 0 && (1 == this.skillType ? Global.guideData.wdGuide || this.node.parent.getComponent("gameMatrix").showGuideNode(6) : 2 == this.skillType ? Global.guideData.ctGuide || this.node.parent.getComponent("gameMatrix").showGuideNode(5) : Global.guideData.zdGuide || this.node.parent.getComponent("gameMatrix").showGuideNode(4));
        return !1;
    },
    removeSelf: function() {
        var e = this.lblData;
        cc.poolNode.labelPool.Push(e), e.parent.removeChild(e), this.lblData = null, cc.poolNode.blockPool.Push(this.node),
            this.node.parent.removeChild(this.node), this.node.scale = 1, this.canNotTouch = !1,
            this.skillType = 0, this.skillData && (cc.poolNode.skillPool.Push(this.skillData),
                this.skillData.parent.removeChild(this.skillData)), this.skillData = null;
    },
    onPicked: function() {
        var e = this.node.parent.getComponent("gameMatrix");
        if (e.invincibleTimes <= 0 && this.value == this.lastValue && e.checkShowHddj && e.sumBall < this.value && !e.huDunNode.active) return e.checkShowHddj = !1,
            e.lastSequenceCount = e.sequenceCount, e.showBoxNode(1), !1;
        if (this.shrink(), e.huDunNode.active || e.invincibleTimes > 0) e.invincibleTimes <= 0 && (e.huDunNode.active = !1),
            e.changeScore(this.value, !0), this.value = 0;
        else {
            this.setValue(this.value - 1), e.subBall(1);
            var t = cc.v2(e.snakeHead.x, this.node.y - this.node.height / 2);
            this.bodyBomb(t, Global.snakeBombColor[Global.skinData.select - 1]), e.shouldInEat++;
        }
        return 0 == this.value && (this.blockBomb(), !0);
    },
    isTouchBall: function(e) {
        if (e.x - e.width > this.node.x + this.node.width / 2 || e.x + e.width < this.node.x - this.node.width / 2) return 0;
        if (Math.abs(this.node.y - e.y) - this.node.height / 2 - e.height / 2 > 1) return 0;
        this.shrink(), e.getComponent("shootBall").removeSelf();
        var t = cc.v2(e.x, this.node.y - this.node.height / 2);
        return this.bodyBomb(t, e.color), this.setValue(this.value - 1), this.node.parent.getComponent("gameMatrix").changeScore(1),
            0 == this.value ? (this.blockBomb(), 2) : 1;
    },
    bodyBomb: function(e, t) {
        var o = this.node.parent.parent.getChildByName("particleNode"),
            i = cc.poolNode.bodyParticlePool.Get();
        i.getComponent("bodyParticle").play(), 
        i.position = e, 
        o.addChild(i);
        var n = i.getComponent(cc.ParticleSystem);
        t = t || cc.color(255,255,255)
        n.startColor = cc.color(t.getR(), t.getG(), t.getB(), 127), 
        n.startColorVar = cc.color(0, 0, 0, 0),
        n.endColor = cc.color(t.getR(), t.getG(), t.getB(), 0), 
        n.endColorVar = cc.color(0, 0, 0, 0);
    },
    blockBomb: function() {
        var e = this.node.getChildByName("hbIcon");
        e && e.active && (e.active = !1, this.node.parent.getComponent("gameMatrix").showFD());
        var t = this.node.parent.parent.getChildByName("particleNode"),
            o = cc.poolNode.blockParticlePool.Get();
        (o.getComponent("blockParticle").play(), o.position = this.node.position, t.addChild(o),
            this.skillType > 0) && this.node.parent.getComponent("gameMatrix").useSkill(this.skillType);
        this.removeSelf();
    },
    updateColor: function() {
        var e = 0;
        this.value > 0 && (e = Math.floor((this.value - 1) / 10));
        var t = Global.getBlockColor(e),
            o = t[0],
            i = t[1],
            n = t[2];
        if (this.value % 10 != 1) {
            var a = e + 1,
                s = (this.value - 1) % 10 / 10,
                l = Global.getBlockColor(a);
            o += (l[0] - o) * s, i += (l[1] - i) * s, n += (l[2] - n) * s;
        }
        this.node.getChildByName("bg").color = cc.color(o, i, n);
    },
    updateValue: function() {
        this.lblData.getComponent(cc.Label).string = this.value;
    },
    setValue: function(e) {
        e != this.value && (this.value = e, this.lastValue = e, this.updateColor(), this.updateValue());
    },
    getValue: function() {
        return this.value;
    },
    shrink: function() {
        this.node.scale = 1, this.node.stopAllActions(), this.node.runAction(cc.sequence(cc.scaleTo(.02, .95, .95), cc.scaleTo(.02, 1, 1)));
    },
    unShrink: function() {}
})
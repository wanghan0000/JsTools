// cc.Class({
    // extends: cc.Component,
module.exports= class PrefabPool {
    constructor(e, t) {
        this.prefab = e, this.Arr = [];
        for (var o = 0; o < t; o++) {
            var i = cc.instantiate(this.prefab);
            this.Arr.push(i);
        }
    }
    Get() {
        if (0 == this.Arr.length) {
            var e = cc.instantiate(this.prefab);
            this.Arr.push(e);
        }
        return this.Arr.pop();
    }
    Push(e) {
        this.Arr.push(e);
    }
    changePrefab(e) {
        this.prefab = e;
    }
    getArr() {
        return this.Arr;
    }
}
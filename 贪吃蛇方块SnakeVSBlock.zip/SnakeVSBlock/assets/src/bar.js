cc.Class({
    extends: cc.Component,
    properties: {},
    editor: {
        executionOrder: 1
    },
    update: function() {
        if (this.node.y < Global.eleHidePosY) this.removeSelf();
        else {
            var e = this.node.parent.getChildByName("head"),
                t = this.node.parent.getComponent("gameMatrix").snakePosX;
            if (!(Math.abs(this.node.y - e.y) - this.node.height / 2 - e.height / 2 > 0))
                if (e.x > this.node.x) {
                    var o = this.node.x + this.node.width / 2 + e.width / 2 + 1;
                    t < o && (this.node.parent.getComponent("gameMatrix").snakePosX = o);
                } else {
                    var i = this.node.x - this.node.width / 2 - e.width / 2 - 1;
                    t > i && (this.node.parent.getComponent("gameMatrix").snakePosX = i);
                }
        }
    },
    removeSelf: function() {
        this.node.height > 160 ? cc.poolNode.longBarPool.Push(this.node) : cc.poolNode.barPool.Push(this.node),
            this.node.parent.removeChild(this.node);
    }
})
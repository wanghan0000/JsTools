cc.Class({
    extends: cc.Component,
    properties: {
        hbnodePre: cc.Prefab,
        dlqNode: cc.Node,
        lblval: cc.Label
    },
    start: function() {
        this.dt = 0, this.lblval.node.active = !0, this.lblval.string = "0", this.updateBtnState();
    },
    hbClick: function() {
        if (this.node.active && !(this.node.opacity < 255)) {
            var e = new cc.Event.EventCustom("openHBNode", !0);
            if (e.detail = 0, this.node.dispatchEvent(e), this.dlqNode.active) {
                var t = cc.instantiate(this.hbnodePre);
                t.parent = cc.director.getScene(), t.zIndex = 1e3, t.getComponent("hbNode").showGetHbNode();
            } else {
                var o = cc.instantiate(this.hbnodePre);
                o.parent = cc.director.getScene(), o.zIndex = 1e3, o.getComponent("hbNode").showYuNode();
            }
        }
    },
    updateBtnState: function() {
        if (!Global.canshowHB()) return this.dlqNode.active = !1, this.lblval.node.active = !1,
            this.node.opacity = 0, void(this.node.active = !0);
        this.node.opacity = 255, this.node.active = !0, this.getComponent(cc.Animation).stop(),
            "1" != Global.getDLQ() ? (this.dlqNode.active = !1, this.lblval.node.active = !0,
                this.lblval.string = Global.getHBCount()) : "1" == Global.getDLQ() && (this.dlqNode.active = !0,
                this.lblval.node.active = !1, this.getComponent(cc.Animation).play());
    },
    update: function(e) {
        this.dt += e, this.dt >= 1 && (this.dt = 0, this.updateBtnState());
    }
})
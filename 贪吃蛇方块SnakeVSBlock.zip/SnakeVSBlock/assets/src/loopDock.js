window.docktouchN = 0;
var i = require('HTTP');
cc.Class({
    extends: cc.Component,
    properties: {
        groupSpaceX: 30
    },
    onLoad: function() {},
    start: function() {
        var e = this;
        console.log("dock start"), window.docktouchN = 0, DockAniAD.curADs = [], this.node.opacity = 0,
            this.group = this.node.getChildByName("dockNode").getChildByName("group"), this.groupWidth = this.group.width,
            this.dockGroups = [], this.loop = !1, this.dir = -1;
        var t = this;
        null == DockAniAD.show ? t.getDockAdData(function(e) {
                e && t.canshow(function() {
                    1 == DockAniAD.show ? t.showAd() : t.node.active = !1;
                });
            }) : 1 == DockAniAD.show ? t.showAd() : t.node.active = !1, this.node.getChildByName("moveNode").on(cc.Node.EventType.TOUCH_START, function(e) {}, this),
            this.node.getChildByName("moveNode").on(cc.Node.EventType.TOUCH_MOVE, function(t) {
                1 == e.loop && (e.node.getChildByName("dockNode").x += t.getDeltaX(), t.getDeltaX() < 0 ? e.dir = -1 : t.getDeltaX() > 0 && (e.dir = 1));
            }, this), this.node.getChildByName("moveNode").on(cc.Node.EventType.TOUCH_END, function(t) {
                var o = cc.v2(t.getStartLocation()).sub(cc.v2(t.getLocation()));
                Math.abs(o.x) <= 5 && e.checkClick(cc.v2(t.getLocation()));
            }, this), this.node.getChildByName("moveNode").on(cc.Node.EventType.TOUCH_CANCEL, function(e) {}, this);
    },
    showAd: function() {
        this.node.opacity = 255;
        var e = Math.floor(cc.winSize.width / (this.groupWidth + this.groupSpaceX));
        console.log("可以放下" + e);
        var t = (cc.winSize.width - (DockAniAD.realN - 1) * this.groupSpaceX - DockAniAD.realN * this.groupWidth) / 2;
        DockAniAD.realN > e && (this.loop = !0, t = this.groupSpaceX);
        for (var o = 0; o < DockAniAD.realN; o++) {
            var i = null;
            0 == o ? i = this.group : (i = cc.instantiate(this.group)).parent = this.group.parent,
                this.dockGroups.push(i), i.active = !0, i.x = -cc.winSize.width / 2 + t + this.groupWidth / 2 + o * (this.groupWidth + this.groupSpaceX),
                i.getComponent("loopDockImgs").showDynamicImage();
        }
        console.log("=====DockAniAD.realN=======", DockAniAD.realN), void 0 != DockAniAD.realN && 0 != DockAniAD.realN || (this.node.active = !1);
    },
    canshow: function(e) {
        var t = Global.host + "/gameconf/" + Global.appid + "/getADswitch/2/",
            o = cc.loader.getXMLHttpRequest();
        o.onreadystatechange = function() {
            if (4 == o.readyState && o.status >= 200 && o.status < 400) {
                var t = o.responseText;
                DockAniAD.show = !1, "0" == t ? DockAniAD.show = !1 : "1" == t && (DockAniAD.show = !0),
                    e && e(), console.log("DockAniAD canshow = " + t);
            }
        }, o.open("GET", t, !0), o.send();
    },
    getDockReqUrl: function(e) {
        var t = "",
            o = "",
            i = Global.getData("IPAddr");
        void 0 != i && "" != i && (t = i[0], o = i[1]);
        var n = Global.host + "/gameconf/" + Global.appid + "/wechatGetDockAniAD/?touchN=" + e + "&city=" + t + "&region=" + o;
        return console.log("=====请求地址是===reqUrl====", n), n;
    },
    getDockAdData: function(e) {
        this.touchN = 0;
        var t = this.getDockReqUrl(this.touchN);
        i.Request(t, function(t) {
            t && 200 === t.code ? (DockAniAD.max = t.data.max, DockAniAD.realN = t.data.realN,
                void 0 == DockAniAD.realN && (DockAniAD.realN = 0), e(!0)) : (console.log("=====获取dock配置数据失败===="),
                e(!1));
        });
    },
    checkClick: function(e) {
        for (var t = 0; t < this.dockGroups.length; t++) {
            var o = this.dockGroups[t],
                i = o.parent.convertToWorldSpaceAR(o.position),
                n = e.sub(i);
            if (Math.abs(n.x) <= this.groupWidth / 2 && Math.abs(n.y) <= this.groupWidth / 2) return void o.getComponent("loopDockImgs").moreGame();
        }
    },
    changePos: function() {
        if (-1 == this.dir) {
            var e = this.dockGroups[0];
            e.parent.convertToWorldSpaceAR(e.position).x + this.groupWidth / 2 <= -2 && (this.dockGroups.shift(),
                this.dockGroups.push(e), e.x += this.dockGroups.length * (this.groupWidth + this.groupSpaceX));
        } else if (1 == this.dir) {
            var t = this.dockGroups[0];
            if (t.parent.convertToWorldSpaceAR(t.position).x - this.groupWidth / 2 >= 2) {
                var o = this.dockGroups.pop();
                this.dockGroups.unshift(o), o.x -= this.dockGroups.length * (this.groupWidth + this.groupSpaceX);
            }
        }
    },
    update: function(e) {
        1 == this.loop && (this.node.getChildByName("dockNode").x += 6 * e * this.dir, this.changePos());
    }
})
cc.Class({
    extends: cc.Component,
    properties: {
        skill1: cc.SpriteFrame,
        skill2: cc.SpriteFrame,
        skill3: cc.SpriteFrame,
        type: 0
    },
    setSkillType: function(e) {
        if (this.type != e) switch (this.type = e, e) {
            case 1:
                this.node.getComponent(cc.Sprite).spriteFrame = this.skill1;
                break;

            case 2:
                this.node.getComponent(cc.Sprite).spriteFrame = this.skill2;
                break;

            case 3:
                this.node.getComponent(cc.Sprite).spriteFrame = this.skill3;
        }
    },
    update: function(e) {},
    removeSelf: function() {
        cc.poolNode.skillPool.Push(this.node), this.node.parent.removeChild(this.node, !1);
    }
})
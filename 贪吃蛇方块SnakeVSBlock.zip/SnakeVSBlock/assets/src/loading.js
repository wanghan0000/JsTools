cc.Class({
    extends: cc.Component,
    properties: {
        percentLb: cc.Label
    },
    onLoad: function() {
        Global.initData(), this.loadProgess = 0, this.updateTime = 0, cc.director.preloadScene("mainScene");
    },
    updatePrg: function() {
        this.percentLb.string = this.loadProgess + "%";
    },
    update: function(e) {
        this.loadProgess >= 99 ? this.showMain() : (this.updateTime += e, this.updateTime > .03 && (this.loadProgess += 1,
            this.updateTime = 0), Global.isFinishGetIp && (this.loadProgess = 99), this.updatePrg());
    },
    showMain: function() {
        this.isshowMain || (this.isshowMain = !0, cc.director.loadScene("mainScene"));
    }
})
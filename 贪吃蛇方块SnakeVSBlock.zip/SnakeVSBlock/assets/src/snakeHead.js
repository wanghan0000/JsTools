cc.Class({
    extends: cc.Component,
    properties: {},
    editor: {
        executionOrder: 2
    },
    onLoad: function() {
        this.scrollSpeed = 0, this.y1ScrollSpeed = 0, this.y1 = 0, this.AddBally = 0, this.AddBallx = 0,
            this.defaultY = 0, this.count = 0, this.snakeWidth = 40, 10 == Global.skinData.select || 11 == Global.skinData.select ? this.snakeWidth = 70 : 15 == Global.skinData.select ? this.snakeWidth = 101 : 16 == Global.skinData.select && (this.snakeWidth = 30);
    },
    start: function() {
        this.TraceX = [], this.TraceY = [];
    },
    getC: function(e, t) {
        return Math.sqrt(e * e + t * t);
    },
    resetAddBall: function() {
        if (this.inited) {
            var e = this.node.childrenCount;
            if (0 === e) return this.AddBally = this.node.y, void(this.AddBallx = this.node.x);
            this.AddBally = this.node.children[e - 1].y + this.node.y, this.AddBallx = this.node.children[e - 1].x + this.node.x;
        } else this.inited = !0;
    },
    resetTrace: function() {
        this.TraceX = [], this.TraceY = [];
    },
    snakeMove: function(e) {
        var t = this.node.parent.getComponent("gameMatrix");
        if (!t.isGameEnd && !t.isGamePause)
            if (this.count > 0) this.count -= e;
            else {
                this.scrollSpeed = t.scrollSpeed;
                var o = t.snakePosX,
                    i = this.snakeWidth,
                    n = t.snakePosX - this.node.x,
                    a = Math.sqrt(this.node.width * this.node.width - this.scrollSpeed * this.scrollSpeed);
                a < n ? o = a + this.node.x : -a > n && (o = -a + this.node.x);
                var s = (t.snakePosX - this.node.x) / 3,
                    l = Math.atan(s / this.scrollSpeed) / Math.PI * 180;
                l > 45 ? l = 45 : l < -45 && (l = -45);
                var c = this.scrollSpeed,
                    h = 0;
                if (this.node.childrenCount > 0) {
                    for (var r, d = this.y1ScrollSpeed = 0; d < this.TraceX.length; d++)
                        if (r = 0 == d ? this.getC(this.TraceY[d] - this.node.y, this.TraceX[d] - o) : this.getC(this.TraceY[d] - this.TraceY[d - 1], this.TraceX[d] - this.TraceX[d - 1]),
                            i - 1 - c < (h += r = Math.max(1, r))) {
                            this.y1ScrollSpeed = d;
                            break;
                        }
                    this.y1 = this.TraceY[this.y1ScrollSpeed], Math.abs(this.y1) <= 10 && (this.y1 = -10);
                }
                this.node.parent.getComponent("gameMatrix").shouldInEat && (c = 0, this.node.y = this.y1,
                    this.TraceX = this.TraceX.slice(this.y1ScrollSpeed), this.TraceY = this.TraceY.slice(this.y1ScrollSpeed),
                    this.count = Global.deleteSnakeTime), this.node.parent.getComponent("gameMatrix").inEat && (c = 0,
                    this.node.y += this.scrollSpeed, this.node.y > this.defaultY && (this.node.y = this.defaultY,
                        this.node.parent.getComponent("gameMatrix").shouldUnEat = 1)), h = 0, this.node.x = o;
                for (var u = this.node.childrenCount, g = 0, p = 0; p < this.TraceX.length; p++) {
                    var m = 0;
                    if (m = 0 == p ? this.getC(this.TraceY[p] - this.node.y, this.TraceX[p] - o) : this.getC(this.TraceY[p] - this.TraceY[p - 1], this.TraceX[p] - this.TraceX[p - 1]),
                        h += m = Math.max(this.scrollSpeed / 10, m), u <= g) break;
                    this.TraceY[p] < this.AddBally ? (this.node.children[g].x = this.AddBallx - this.node.x,
                        this.node.children[g].y = this.AddBally - this.node.y, g++) : (g + 1) * (i - 1) < h && (this.node.children[g].x = this.TraceX[p] - this.node.x,
                        this.node.children[g].y = this.TraceY[p] - this.node.y, g++);
                }
                for (var f = g; f < u; f++) 0 == f ? (this.node.children[f].x = 0, this.node.children[f].y = -i) : (this.node.children[f].x = this.node.children[f - 1].x,
                    this.node.children[f].y = this.node.children[f - 1].y - i);
                this.AddBally -= c;
                for (var b = this.TraceX.length + 10; b >= 10; b--) this.TraceX[b] = this.TraceX[b - 10],
                    this.TraceY[b] = this.TraceY[b - 10] - c;
                this.TraceX[0] = this.node.x, this.TraceY[0] = this.node.y;
                for (var v = 1; v < 10; v++) this.TraceX[v] = ((10 - v) * this.TraceX[0] + v * this.TraceX[10]) / 10,
                    this.TraceY[v] = ((10 - v) * this.TraceY[0] + v * this.TraceY[10]) / 10;
                this.TraceX.length > 2 * this.node.parent.height && (this.TraceX.length = Math.floor(2 * this.node.parent.height),
                        this.TraceY.length = Math.floor(2 * this.node.parent.height)), t.head2.position = this.node.position,
                    6 == Global.skinData.select ? t.head2.x += 2 : 9 == Global.skinData.select && (t.head2.x -= 4),
                    10 == Global.skinData.select || 11 == Global.skinData.select || 15 == Global.skinData.select || (t.head2.rotation = l),
                    t.elementMove();
            }
    },
    update: function(e) {
        this.snakeMove(e);
    }
})
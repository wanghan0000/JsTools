"use strict";
cc._RF.push(module, '109c5mf+g5MBKI6L3IcWXgp', 'gameScene');
// src/gameScene.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        scoreLB: cc.Label,
        timeLB: cc.Label,
        goldLb: cc.Label,
        hdprg: cc.ProgressBar,
        goldIcon: cc.Node,
        icePrg: cc.ProgressBar,
        display: cc.Sprite
    },
    editor: {
        executionOrder: -1
    },
    onLoad: function onLoad() {
        wx.postMessage({
            message: "HideRankingList"
        }), this._times = 0, this._type = 0, this._fuhuoType = 0, this._videoTimes = 0, this.getEvent(), Global.showBannerId(1, this.node);
    },
    getEvent: function getEvent() {
        this.node.on("fuHuo", function (e) {
            e && (this._type = 1, this._fuhuoType = e.detail, this.showTimes(), e.stopPropagation());
        }.bind(this)), this.node.on("useHuDun", function (e) {
            e && (this.node.getChildByName("gameMatrix").getComponent("gameMatrix").useHuDun(e.detail), e.stopPropagation());
        }.bind(this)), this.node.on("AddBalls", function (e) {
            e && (this.node.getChildByName("gameMatrix").getComponent("gameMatrix").useAddBall(e.detail), e.stopPropagation());
        }.bind(this)), this.node.on("closeBoxNode", function (e) {
            e && (e.detail > 0 ? (this._type = 2, this.showTimes()) : this.node.getChildByName("gameMatrix").getComponent("gameMatrix").closeBoxNode(), e.stopPropagation());
        }.bind(this)), this.node.on("ReShowMainAD", function (e) {
            e && (Global.showBannerId(1, this.node), e.stopPropagation());
        }.bind(this)), this.node.on("openHBNode", function (e) {
            e && !this.gameMatrix.isGameEnd && (this.setGamePause(!0), e.stopPropagation());
        }, this), cc.systemEvent.on("closeHBNode", function () {
            this.gameMatrix.isGameEnd || this.setGamePause(!1);
        }, this), cc.systemEvent.on("showBoutique", function () {
            this.gameMatrix.isGameEnd || this.setGamePause(!0);
        }, this), cc.systemEvent.on("hideBoutique", function () {
            this.gameMatrix.isGameEnd || this.setGamePause(!1);
        }, this);
    },
    showTimes: function showTimes() {
        this.timeLB.node.parent.active = !0, this.timeLB.string = 3, this._times = 3, this.schedule(this.updateTimer, .5);
    },
    updateTimer: function updateTimer() {
        this._times--, this.timeLB.string = this._times, 0 == this._times && (this.unschedule(this.updateTimer), this.timeLB.node.parent.active = !1, 1 == this._type ? this.node.getChildByName("gameMatrix").getComponent("gameMatrix").fuHuo(this._fuhuoType) : 2 == this._type && this.node.getChildByName("gameMatrix").getComponent("gameMatrix").closeBoxNode(), Global.showBannerId(1, this.node));
    },
    start: function start() {
        Global.getShare();
        var e = this;
        wx.showShareMenu({
            withShareTicket: !0
        }), wx.onShareAppMessage(function () {
            return Global.ShareAppMessage();
        }), wx.onShow(function (t) {
            e.node && (Global.openId && Global.onShow(t), cc.game.isPaused() && cc.game.resume(), Global.haveShare && (Global.haveShare = !1, setTimeout(function () {
                Global.shareCancel ? Global.alertGameDialog("您取消了分享，请分享到群") : void 0 != Global.callBack && (new Date().getTime() - Global.shareStartTime < 4e3 ? Global.alertGameDialog("分享失败，请分享到不同的群") : Global.callBack({
                    confirm: !0
                }));
            }, 200)));
        }), wx.onHide(function () {
            e.node && (cc.game.isPaused() || cc.game.pause());
        }), wx.onAudioInterruptionEnd(function () {}), cc.poolNode.checkPool(), this.setElementTop(this.scoreLB.node, 0), this.setElementTop(this.goldLb.node.parent, 0), this.setElementTop(this.icePrg.node, 75), this.setElementTop(this.display.node, 40), this.showGold(), this.setShareCanvas(), this.tex = new cc.Texture2D(), this.gameMatrix = this.node.getChildByName("gameMatrix").getComponent("gameMatrix"), this._updateTime = 0;
    },
    setShareCanvas: function setShareCanvas() {
        sharedCanvas.width = this.display.node.width, sharedCanvas.height = this.display.node.height;
    },
    _updateSubDomainCanvas: function _updateSubDomainCanvas() {
        this.tex && (this.tex.initWithElement(sharedCanvas), this.tex.handleLoadedTexture(), this.display.spriteFrame = new cc.SpriteFrame(this.tex));
    },
    showGold: function showGold() {
        this.goldLb.string = Global.gold;
    },
    update: function update(e) {
        if (this._updateTime += e, this._updateTime > 1 && !this.gameMatrix.isGameEnd) {
            this._updateSubDomainCanvas();
            var t = this.gameMatrix._score;
            wx.postMessage({
                message: "updateScore",
                yoff: 0,
                val: t
            }), this._updateTime = 0;
        }
    },
    setElementTop: function setElementTop(e, t) {
        var o = cc.view.getFrameSize(),
            i = 0;
        i = o.height / o.width <= 2 ? 12 : 50, i += t;
        var n = e.getComponent(cc.Widget);
        n.isAlignTop = !0, n.top = cc.director.getWinSize().height / o.height * i, n.isAlignBottom = !1;
    },
    changeScore: function changeScore(e) {
        this.scoreLB.string = e, this._score = e;
    },
    changePrg: function changePrg(e) {
        this.hdprg.node.active = e > 0, this.hdprg.progress = e;
    },
    changeIcePrg: function changeIcePrg(e) {
        this.icePrg.node.active = e > 0, this.icePrg.progress = e;
    },
    getAudioManager: function getAudioManager() {
        return this._tempAudioManager || (this._tempAudioManager = cc.find("AudioManager").getComponent("AudioManager")), this._tempAudioManager;
    },
    setGamePause: function setGamePause(e) {
        this.gameMatrix.isGamePause = e;
    },
    addBall: function addBall() {
        this.gameMatrix.addBalls(10 + 5 * this._videoTimes), this._videoTimes++;
    },
    addGold: function addGold(e) {
        Global.operateGold(e), this.showGold(), this.getAudioManager().playCoin();
    },
    shareAndGetGold: function shareAndGetGold() {
        var e = this;
        Global.actionShare2(Global.useSkillNotGoldShareID, function () {
            Global.operateGold(25), Global.toast("谢谢分享，获得25金币"), e.setGamePause(!1), e.showGold(), e.getAudioManager().playCoin2();
        }, function () {
            e.setGamePause(!1);
        });
    },
    showVideo: function showVideo() {
        var e = this;
        e.setGamePause(!0), this.unschedule(this.updateTimer), Global.getisShowVideo2(Global.useSkillNotGoldShareID) ? Global.showVideoAD(function () {
            Global.operateGold(25), Global.toast("谢谢观看，获得25金币"), e.setGamePause(!1), e.showGold(), e.getAudioManager().playCoin2();
        }, "045", function () {
            Global.isOldPlayer() ? e.shareAndGetGold() : e.setGamePause(!1);
        }) : e.shareAndGetGold();
    },
    invincibleClick: function invincibleClick() {
        if (Global.gold < Global.huDunGold) return this.showVideo(), void Global.toast("金币不足，无法使用");
        this.gameMatrix.useHuDun(Global.huDunTime) && (Global.operateGold(-Global.huDunGold), this.showGold());
    },
    shootClick: function shootClick() {
        if (Global.gold < Global.shootGold) return this.showVideo(), void Global.toast("金币不足，无法使用");
        this.gameMatrix.useAndStopShoot(!1) && (Global.operateGold(-Global.shootGold), this.showGold());
    }
});

cc._RF.pop();
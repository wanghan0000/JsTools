"use strict";
cc._RF.push(module, '3a2a8o0dflCZaK1XGSBIUkb', 'food');
// src/food.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        value: 0,
        isPickUped: !1,
        pickRadius: 0,
        lblData: {
            default: null,
            type: cc.Node
        }
    },
    setValue: function setValue(e) {
        this.value != e && (this.value = e, this.lblData.getComponent(cc.Label).string = this.value);
    },
    getDistance: function getDistance() {
        var e = this.node.parent.getChildByName("head").getPosition();
        return this.node.getPosition().sub(e).mag();
    },
    onPicked: function onPicked() {
        this.node.parent.getComponent("gameMatrix").addBalls(this.value, !0), this.removeSelf();
    },
    update: function update() {
        if (!this.node.parent.getComponent("gameMatrix").isGamePause) if (this.node.parent.getComponent("gameMatrix").isGameEnd) this.isPickUped && this.removeSelf();else if (this.getDistance() < this.pickRadius) this.onPicked();else {
            var e = this.node.parent.getComponent("gameMatrix");
            if (e.magnetTime > 0 && !this.isPickUped && this.node.y >= -Global.magnetHeight && this.node.y <= Global.magnetHeight && (this.isPickUped = !0, this.lblData.name = "", this.index = 0, this.lblH = this.lblData.position.y - this.node.position.y, this.node.zIndex = 10), this.isPickUped) {
                var t = e.snakeHead.position.sub(this.node.position).normalizeSelf(),
                    o = this.node.position.addSelf(t.mulSelf(14 + .4 * this.index));
                return this.node.position = o, this.lblData.setPosition(o.x, o.y + this.lblH), void this.index++;
            }
            this.node.y < Global.eleHidePosY && this.removeSelf();
        }
    },
    removeSelf: function removeSelf() {
        this.index = 0, this.isPickUped = !1;
        var e = this.lblData;
        this.lblData.name = "Label", cc.poolNode.labelPool.Push(e), e.parent.removeChild(e), this.lblData = null, cc.poolNode.foodPool.Push(this.node), this.node.parent.removeChild(this.node, !1);
    }
});

cc._RF.pop();
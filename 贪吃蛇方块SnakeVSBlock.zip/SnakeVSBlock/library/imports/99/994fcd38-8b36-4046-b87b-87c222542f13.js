"use strict";
cc._RF.push(module, '994fc04izZARrh7h8IiVC8T', 'dockdynamicImage');
// src/dockdynamicImage.js

"use strict";

var i = require('HTTP');
cc.Class({
    extends: cc.Component,
    properties: {},
    start: function start() {},
    getData: function getData(e, t) {
        return window.docktouchN;
    },
    setData: function setData(e, t) {
        window.docktouchN = t;
    },
    showDynamicImage: function showDynamicImage() {
        var e = this.getData("touchN", "0");
        e = parseInt(e), this.oldN = this.touchN, this.touchN = e % DockAniAD.realN;
        var t = this;
        console.log("dock touchNum = " + t.touchN);
        var o = "",
            i = "",
            n = Global.getData("IPAddr", "");
        "" != n && (o = n[0], i = n[1]);
        var a = Global.host + "/gameconf/" + Global.appid + "/wechatGetDockAniAD/?touchN=" + this.touchN + "&city=" + o + "&region=" + i;
        e += 1, t.setData("touchN", e), this.getAdInfo(a, function () {
            if (t.dynamicAdInfo) {
                for (var e = [], o = 0, i = 0; i < t.dynamicAdInfo.dynamic_small_image.length; i++) {
                    (function (i) {
                        cc.loader.load(t.dynamicAdInfo.dynamic_small_image[i], function (n, a) {
                            if (!n && (o++, e[i] = a, o === t.dynamicAdInfo.dynamic_small_image.length)) {
                                t.node.active = !0, t.unscheduleAllCallbacks();
                                var s = 0;
                                t.node.getChildByName("frame").getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(e[s]), t.node.getChildByName("lblname").getComponent(cc.Label).string = t.dynamicAdInfo.app_name.substr(0, 6), s++, t.schedule(function () {
                                    s >= e.length && (s = 0), t.node.getChildByName("frame").getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(e[s]), t.node.getChildByName("lblname").getComponent(cc.Label).string = t.dynamicAdInfo.app_name.substr(0, 6), s++;
                                }, t.dynamicAdInfo.dur, cc.macro.REPEAT_FOREVER);
                            }
                        });
                    })(i);
                }t.dynamicAdInfo.dynamic_small_image.length <= 0 && cc.loader.load(t.dynamicAdInfo.small_image, function (e, o) {
                    e || (t.unscheduleAllCallbacks(), t.node.active = !0, t.node.getChildByName("frame").getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(o), t.node.getChildByName("lblname").getComponent(cc.Label).string = t.dynamicAdInfo.app_name.substr(0, 6));
                });
            }
        });
    },
    getAdInfo: function getAdInfo(e, t, o) {
        var n = this,
            a = this;
        if (o = a.touchN || 0, DockAniAD.ADs[a.touchN]) {
            var s = this.nextAds(a.touchN, a.oldN);
            return this.removeCurAds(a.oldN), a.touchN = s, this.addCurAds(s), a.dynamicAdInfo = DockAniAD.ADs[s], t(), void console.log("Dock 从缓存里拿去数据 touchn=" + a.touchN);
        }
        i.Request(e, function (e) {
            e && 200 === e.code && (n.removeCurAds(a.oldN), n.addCurAds(o), DockAniAD.ADs[o] = e.data, DockAniAD.max = e.data.max, DockAniAD.realN = e.data.realN, a && a.node && (a.dynamicAdInfo = e.data, t()));
        });
    },
    removeCurAds: function removeCurAds(e) {
        for (var t = [], o = 0; o < DockAniAD.curADs.length; o++) {
            void 0 != e && e == DockAniAD.curADs[o] || t.push(DockAniAD.curADs[o]);
        }DockAniAD.curADs = t, console.log("remove " + e + ",curAds=" + JSON.stringify(DockAniAD.curADs));
    },
    addCurAds: function addCurAds(e) {
        this.removeCurAds(e), DockAniAD.curADs.push(e), console.log("add " + e + " curAds=" + JSON.stringify(DockAniAD.curADs));
    },
    nextAds: function nextAds(e, t) {
        for (var o = e, i = !1, n = 0; n < DockAniAD.ADs.length; n++) {
            if (!this.isInCurAds(o % DockAniAD.realN)) {
                i = !0;
                break;
            }
            console.log("已经存在 cur=" + o), o++;
        }
        return i ? o % DockAniAD.realN : t;
    },
    isInCurAds: function isInCurAds(e) {
        for (var t = 0; t < DockAniAD.curADs.length; t++) {
            if (void 0 != e && e == DockAniAD.curADs[t]) return !0;
        }return !1;
    },
    moreGame: function moreGame(e, t) {
        if (this.dynamicAdInfo) {
            this.postPoint(), this.postADClick();
            if (this.dynamicAdInfo) {
                var o = !1;
                if (!this.dynamicAdInfo.scan) {
                    var i = wx.getSystemInfoSync();
                    if (i) for (var n = i.version.split("."), a = [6, 6, 7], s = 0; s < n.length; s++) {
                        if (parseInt(n[s]) > a[s]) {
                            o = !0;
                            break;
                        }
                        if (parseInt(n[s]) !== a[s]) {
                            o = !1;
                            break;
                        }
                        o = !0;
                    }
                }
                o ? window.wx && wx.navigateToMiniProgram({
                    appId: this.dynamicAdInfo.first_appid,
                    path: this.dynamicAdInfo.first_path,
                    extraData: {
                        second_appid: this.dynamicAdInfo.second_appid,
                        second_path: this.dynamicAdInfo.second_path,
                        channel: Global.channel
                    },
                    envVersion: this.dynamicAdInfo.envVersion,
                    success: function success() {},
                    fail: function fail() {},
                    complete: function complete() {}
                }) : wx.previewImage({
                    urls: [this.dynamicAdInfo.big_image],
                    success: function success(e) {}
                }), this.showDynamicImage();
            }
        }
    },
    postPoint: function postPoint() {
        var e = cc.loader.getXMLHttpRequest();
        e.onreadystatechange = function () {
            if (4 == e.readyState && e.status >= 200 && e.status < 400) {
                var t = e.responseText;
                console.log("http 打点上报 dock = " + t);
            }
        };
        var t = Global.host + "/wxgame/data/recommendGameData.php?game_id=" + Global.gameID + "&app_id=" + this.dynamicAdInfo.point_id;
        console.log("打点上报 dock  url=" + t), e.open("GET", t, !0), e.send();
    },
    postADClick: function postADClick() {
        var e = cc.loader.getXMLHttpRequest();
        e.onreadystatechange = function () {
            if (4 == e.readyState && e.status >= 200 && e.status < 400) {
                var t = e.responseText;
                console.log("postADClick 打点上报 dock = " + t);
            }
        };
        var t = Global.host + "/gameconf/" + Global.appid + "/postADClick/" + this.dynamicAdInfo.point_id + "/2/";
        console.log(" 打点上报 dock url=" + t), e.open("GET", t, !0), e.send();
    }
});

cc._RF.pop();
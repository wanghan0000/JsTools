"use strict";
cc._RF.push(module, '58c5db7dCFJiYZw8zzQe/JZ', 'guideNode');
// src/guideNode.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        tipsLb: cc.Label,
        icon: cc.Sprite
    },
    onLoad: function onLoad() {
        this.ArrList = [];
    },
    show: function show(e) {
        for (var t = 0; t < this.ArrList.length; t++) {
            if (this.ArrList[t] == e) return;
        }this.changeValue(e), this.ArrList.push(e), 1 == this.ArrList.length && this.showGuideAction();
    },
    showGuideAction: function showGuideAction() {
        var e = this;
        0 == this.ArrList.length && this.node.destroy();
        var t = cc.callFunc(function () {
            var t = e.ArrList[0];
            e.showGuide(t);
        }),
            o = cc.callFunc(function () {
            e.ArrList.splice(0, 1), e.showGuideAction();
        });
        this.node.runAction(cc.sequence(t, cc.delayTime(3), o));
    },
    changeValue: function changeValue(e) {
        switch (e) {
            case 0:
            case 1:
            case 2:
            case 3:
                break;

            case 4:
                Global.guideData.zdGuide = 1;
                break;

            case 5:
                Global.guideData.ctGuide = 1;
                break;

            case 6:
                Global.guideData.wdGuide = 1;
                break;

            case 7:
                Global.guideData.xhGuide = 1;
                break;

            case 8:
                Global.guideData.hdGuide = 1;
                break;

            case 9:
                Global.guideData.cdGuide = 1;
        }
    },
    showGuide: function showGuide(e) {
        var t = this,
            o = "",
            i = "";
        switch (this.icon.node.getChildByName("countLb").active = !1, e) {
            case 0:
                o = "左右滑动来控制贪吃蛇", i = "guide/img_jiantou";
                break;

            case 1:
                o = "避开数字大的方块，选择数字小的方块吃掉", i = "guide/img_jiantou";
                break;

            case 2:
                o = "吃食物可以增加蛇身的长度", i = "Skin/body_01", this.icon.node.getChildByName("countLb").active = !0;
                break;

            case 3:
                o = "在撞到方块后，贪吃蛇的长度会相应的减小，并获得相应的分数", Global.setIsShowNormalGuide(1);
                break;

            case 4:
                o = "子弹让贪吃蛇发射子弹攻击方块", i = "guide/shoot_icon", Global.guideData.zdGuide = 1, Global.setGuide();
                break;

            case 5:
                o = "磁铁让贪吃蛇可以自动吸引周围的食物并吃掉", i = "guide/magnet_icon", Global.guideData.ctGuide = 1, Global.setGuide();
                break;

            case 6:
                o = "无敌让贪吃蛇无视撞击并加速冲刺", i = "guide/invincible_icon", Global.guideData.wdGuide = 1, Global.setGuide();
                break;

            case 7:
                o = "雪花能够减慢贪吃蛇的移动速度", i = "guide/img_xuehua", Global.guideData.xhGuide = 1, Global.setGuide();
                break;

            case 8:
                o = "泡泡能够帮助贪吃蛇抵挡一次撞击", i = "guide/pp-transparency", Global.guideData.hdGuide = 1, Global.setGuide();
                break;

            case 9:
                o = "虫洞能够让贪吃蛇穿越到洞口的另一端", Global.guideData.cdGuide = 1, Global.setGuide();
        }
        this.tipsLb.string = o, i.length > 0 ? (this.icon.node.active = !0, cc.loader.loadRes(i, cc.SpriteFrame, function (e, o) {
            e || (t.icon.spriteFrame = o);
        })) : this.icon.node.active = !1;
    }
});

cc._RF.pop();
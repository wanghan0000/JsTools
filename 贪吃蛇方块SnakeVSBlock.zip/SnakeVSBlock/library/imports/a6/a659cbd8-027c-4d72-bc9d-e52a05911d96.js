"use strict";
cc._RF.push(module, 'a659cvYAnxNcryd5SoFkR2W', 'dynamicImage2');
// src/dynamicImage2.js

"use strict";

var i = require('HTTP');
cc.Class({
    extends: cc.Component,
    properties: {},
    onLoad: function onLoad() {},
    start: function start() {
        var e = this;
        console.log("dyn2 start"), this.delta = 0, this.touchN = 0, this.nextN = 0, this.byDur = 6, this.hideall(), null == AniAD2.show ? this.canshow(function () {
            1 == AniAD2.show ? e.showDynamicImage() : e.node.active = !1;
        }) : 1 == AniAD2.show ? this.showDynamicImage() : this.node.active = !1;
    },
    showall: function showall() {
        for (var e = this.node.children, t = 0; t < e.length; t++) {
            e[t].opacity = 255;
        }
    },
    hideall: function hideall() {
        for (var e = this.node.children, t = 0; t < e.length; t++) {
            e[t].opacity = 0;
        }
    },
    update: function update(e) {
        this.delta += e, this.delta >= this.byDur && 1 == AniAD2.show && (this.delta = 0, this.showDynamicImage());
    },
    getData: function getData(e, t) {
        return window.touchN;
    },
    setData: function setData(e, t) {
        window.touchN = t;
    },
    showDynamicImage: function showDynamicImage() {
        var e = this;
        e.touchN = e.nextN;
        var t = "",
            o = "",
            i = Global.getData("IPAddr", "");
        "" != i && (t = i[0], o = i[1]);
        var n = Global.host + "/gameconf/" + Global.appid + "/wechatGetAniAD2/?touchN=" + this.touchN + "&city=" + t + "&region=" + o;
        e.nextN += 1, e.nextN = e.nextN % AniAD2.max, this.getAdInfo(n, function () {
            if (e.dynamicAdInfo) {
                e.delta = 0;
                for (var t = [], o = 0, i = 0; i < e.dynamicAdInfo.dynamic_small_image.length; i++) {
                    (function (i) {
                        cc.loader.load(e.dynamicAdInfo.dynamic_small_image[i], function (n, a) {
                            if (!n && (o++, t[i] = a, o === e.dynamicAdInfo.dynamic_small_image.length)) {
                                e.delta = 0, e.unscheduleAllCallbacks(), e.showall();
                                var s = 0;
                                e.node.getChildByName("frame").getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(t[s]), e.node.getChildByName("lblname").getComponent(cc.Label).string = e.dynamicAdInfo.app_name.substr(0, 6), s++, e.schedule(function () {
                                    s >= t.length && (s = 0), e.node.getChildByName("frame").getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(t[s]), e.node.getChildByName("lblname").getComponent(cc.Label).string = e.dynamicAdInfo.app_name.substr(0, 6), s++;
                                }, e.dynamicAdInfo.dur, cc.macro.REPEAT_FOREVER);
                            }
                        });
                    })(i);
                }e.dynamicAdInfo.dynamic_small_image.length <= 0 && (e.delta = 0, cc.loader.load(e.dynamicAdInfo.small_image, function (t, o) {
                    t || (e.unscheduleAllCallbacks(), e.showall(), e.node.getChildByName("frame").getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(o), e.node.getChildByName("lblname").getComponent(cc.Label).string = e.dynamicAdInfo.app_name.substr(0, 6));
                }));
            }
        });
    },
    getAdInfo: function getAdInfo(e, t, o) {
        var n = this;
        if (o = n.touchN || 0, AniAD2[n.touchN]) return n.dynamicAdInfo = AniAD2[n.touchN], t(), void console.log("Ani2 从缓存里拿去数据 touchn=" + n.touchN);
        i.Request(e, function (e) {
            e && 200 === e.code && (AniAD2[o] = e.data, AniAD2.max = e.data.max, n.byDur = e.data.byDur, n && n.node && (n.dynamicAdInfo = e.data, t()));
        });
    },
    moreGame: function moreGame(e, t) {
        this.delta = 0, this.postPoint(), this.postADClick();
        if (this.dynamicAdInfo) {
            var o = !1;
            if (!this.dynamicAdInfo.scan) {
                var i = wx.getSystemInfoSync();
                if (i) for (var n = i.version.split("."), a = [6, 6, 7], s = 0; s < n.length; s++) {
                    if (parseInt(n[s]) > a[s]) {
                        o = !0;
                        break;
                    }
                    if (parseInt(n[s]) !== a[s]) {
                        o = !1;
                        break;
                    }
                    o = !0;
                }
            }
            o ? window.wx && wx.navigateToMiniProgram({
                appId: this.dynamicAdInfo.first_appid,
                path: this.dynamicAdInfo.first_path,
                extraData: {
                    second_appid: this.dynamicAdInfo.second_appid,
                    second_path: this.dynamicAdInfo.second_path,
                    channel: Global.channel
                },
                envVersion: this.dynamicAdInfo.envVersion,
                success: function success() {},
                fail: function fail() {},
                complete: function complete() {}
            }) : wx.previewImage({
                urls: [this.dynamicAdInfo.big_image],
                success: function success(e) {}
            }), this.showDynamicImage();
        }
    },
    postPoint: function postPoint() {
        var e = cc.loader.getXMLHttpRequest();
        e.onreadystatechange = function () {
            if (4 == e.readyState && e.status >= 200 && e.status < 400) {
                var t = e.responseText;
                console.log("http 打点上报 单个组件 = " + t);
            }
        };
        var t = Global.host + "/wxgame/data/recommendGameData.php?game_id=" + Global.gameID + "&app_id=" + this.dynamicAdInfo.point_id;
        console.log(" 打点上报 单个组件 url=" + t), e.open("GET", t, !0), e.send();
    },
    postADClick: function postADClick() {
        var e = cc.loader.getXMLHttpRequest();
        e.onreadystatechange = function () {
            if (4 == e.readyState && e.status >= 200 && e.status < 400) {
                var t = e.responseText;
                console.log("postADClick 打点上报 单个组件 = " + t);
            }
        };
        var t = Global.host + "/gameconf/" + Global.appid + "/postADClick/" + this.dynamicAdInfo.point_id + "/3/";
        console.log(" 打点上报 单个组件 url=" + t), e.open("GET", t, !0), e.send();
    },
    canshow: function canshow(e) {
        var t = Global.host + "/gameconf/" + Global.appid + "/getADswitch/3/",
            o = cc.loader.getXMLHttpRequest();
        o.onreadystatechange = function () {
            if (4 == o.readyState && o.status >= 200 && o.status < 400) {
                var t = o.responseText;
                AniAD2.show = !1, "0" == t ? AniAD2.show = !1 : "1" == t && (AniAD2.show = !0), e && e(), console.log("Ani2AD2 canshow = " + t);
            }
        }, o.open("GET", t, !0), o.send();
    }
});

cc._RF.pop();
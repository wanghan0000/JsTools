"use strict";
cc._RF.push(module, '43342ZZ2IpCWL0Btd6whpdR', 'hbNode');
// src/hbNode.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        yuNode: cc.Node,
        getHbNode: cc.Node,
        openNode: cc.Node,
        fcShopPre: cc.Prefab
    },
    onLoad: function onLoad() {},
    closeAllNode: function closeAllNode() {
        this.yuNode.active = !1, this.getHbNode.active = !1, this.openNode.active = !1;
    },
    closeNode: function closeNode() {
        cc.systemEvent.emit("closeHBNode"), this.node.destroy();
    },
    closeClick: function closeClick() {
        if (this.getHbNode.active) {
            0;
            var e = this,
                t = function t() {
                Global.setDLQ("1"), e.node.dispatchEvent(new cc.Event.EventCustom("closeHb", !0)), e.closeNode();
            };
            if (!Global.isNormal) return void Global.alertGameDialog2(function (o) {
                o.confirm ? e.shareAndOpen() : t && t();
            });
            Global.setDLQ("1"), this.node.dispatchEvent(new cc.Event.EventCustom("closeHb", !0));
        }
        this.closeNode();
    },
    showYuNode: function showYuNode() {
        this.closeAllNode(), this.yuNode.active = !0, this.yuNode.getChildByName("lbRMB").getComponent(cc.Label).string = "余额: " + Global.getHBCount() + "福卡";
    },
    showGetHbNode: function showGetHbNode() {
        if (Global.getHBCount() > 1800) return Global.setDLQ("0"), void this.closeNode();
        this.closeAllNode(), this.getHbNode.active = !0, this.scheduleOnce(function () {
            this.getHbNode.getChildByName("btnCose").active = !0;
        }, Global.passBtnShowTime);
    },
    shareAndOpen: function shareAndOpen(e) {
        var t = this;
        Global.actionShare({
            title: Global.title,
            imageUrl: Global.imageUrl,
            query: "",
            shareID: Global.fkShareID
        }, function (o) {
            if (o.confirm) {
                if (Global.getIsMustFailed(Global.fkShareID)) return void Global.alertGameDialog("分享失败，请分享到不同的群");
                t.showOpenNode(), Global.getTongJi(Global.fkShareID, 2), Global.addShareTimes(Global.fkShareID);
            } else e && e(null);
        });
    },
    openHb: function openHb() {
        if (this.getHbNode.active) {
            console.log("打开红包");
            var e = this;
            Global.getisShowVideo2(Global.fkShareID) ? Global.showVideoAD(function () {
                e.showOpenNode();
            }, Global.fkVideoId, function () {
                Global.isOldPlayer() && e.shareAndOpen();
            }) : this.shareAndOpen();
        }
    },
    showOpenNode: function showOpenNode() {
        if (this.closeAllNode(), Global.getHBCount() > 1800) this.closeNode();else {
            Global.setDLQ("0"), this.openNode.active = !0;
            var e = this.openNode.getChildByName("lbRMB").getComponent(cc.Label),
                t = Global.getRandHbCount();
            Global.getHBCount() <= 200 && !Global.isFirstOpenGameHb() && (t = Global.getRand(150, 250), Global.setIsFirstOpenGameHb()), this.openNode.getChildByName("lbGet").getComponent(cc.Label).string = t + "福卡", Global.setHbCount(t), e.string = "余额: " + Global.getHBCount() + "福卡", Global.toast("成功领取福卡");
            var o = new cc.Event.EventCustom("openHb", !0);
            this.node.dispatchEvent(o);
        }
    },
    shopClick: function shopClick() {
        var e = cc.instantiate(this.fcShopPre);
        this.node.addChild(e);
    }
});

cc._RF.pop();
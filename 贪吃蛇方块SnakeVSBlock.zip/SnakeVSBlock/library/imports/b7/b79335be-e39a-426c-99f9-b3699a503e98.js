"use strict";
cc._RF.push(module, 'b7933W+45pCbJn5s2maUD6Y', 'skinItem');
// src/skinItem.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        index: 0
    },
    onLoad: function onLoad() {},
    show: function show(e) {
        this.index = e, this.changeSkin(e);
    },
    changeSkin: function changeSkin(e) {
        this.index = e;
        var t = "" + (e < 10 ? "0" + e : e),
            o = "pifu_" + t,
            i = "body_" + t,
            n = 4;
        15 == e ? n = 3 : 16 == e && (n = 5);
        var a = [42, 57, 71, 53, 59, 65, 57, 59, 57, 66, 66, 62, 65, 65, 101, 49],
            s = [40, 40, 40, 40, 40, 40, 40, 40, 40, 66, 66, 40, 40, 40, 101, 26],
            l = this.node.getChildByName("head"),
            c = this.node.getChildByName("bodyLayout");
        l.x = 0, l.zIndex = 100, 6 == e ? l.x = 2 : 9 == e && (l.x = -4);
        var h = 0;
        11 != e && 10 != e && 15 != e || (h = 1);
        for (var r = function r(e) {
            var t = null,
                n = i;
            0 == e ? (n = o, t = l) : ((t = new cc.Node("body" + e)).addComponent(cc.Sprite), t.parent = c), cc.loader.loadRes("Skin/" + n, cc.SpriteFrame, function (e, o) {
                e || (t.getComponent(cc.Sprite).spriteFrame = o);
            });
        }, d = h; d < n; d++) {
            r(d);
        }if (11 != e && 10 != e && 15 != e) {
            var u = [0, 8, 8, 8, 8, 6, 6, 6, 6, 6, 6, 8, 8, 6, 6, 0],
                g = (this.node.height - (a[e - 1] + s[e - 1] * (n - 1) - u[e - 1])) / 2;
            l.y = this.node.height / 2 - g - a[e - 1] / 2, c.y = l.y - s[e - 1] * (n - 1) / 2 - a[e - 1] / 2 + u[e - 1];
        }
    }
});

cc._RF.pop();
"use strict";
cc._RF.push(module, '53606SIlGlPM5xiMw9L//gd', 'getGoldNode');
// src/getGoldNode.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        goldLb: cc.Label,
        btnDouble: cc.Button,
        btnClose: cc.Button
    },
    onLoad: function onLoad() {
        this.updateTime = 0;
    },
    show: function show(e) {
        this.gold = e, this.goldLb.string = e, this.adjustNode(this.node.getChildByName("bg")), this.btnAction(this.btnDouble.node), this.scheduleOnce(function () {
            this.node.getChildByName("bg").getChildByName("btnClose").active = !0;
        }, Global.passBtnShowTime);
    },
    adjustNode: function adjustNode(e) {
        if (e.active) {
            var t = Global.adHeight,
                o = e.getComponent(cc.Widget);
            o.isAlignBottom = !0, o.bottom = (this.node.height - t - e.height) / 2 + t;
        }
    },
    btnAction: function btnAction(e) {
        if (e.active) {
            e.stopAllActions(), e.scale = 1;
            e.runAction(cc.repeatForever(cc.sequence(cc.scaleTo(.8, 1.1), cc.scaleTo(.8, 1))));
        }
    },
    changePassBtnPos: function changePassBtnPos() {
        var e = this.node.getChildByName("bg").getChildByName("btnClose").getComponent(cc.Widget);
        e.isAlignBottom = !0, e.bottom = Global.bannerHeight;
    },
    update: function update(e) {
        this.updateTime += e, this.updateTime > 1 && (this.changePassBtnPos(), this.updateTime = 0);
    },
    gameSceneShowGold: function gameSceneShowGold() {
        cc.find("gameScene").getComponent("gameScene").showGold();
    },
    shareAndGetGold: function shareAndGetGold() {
        var e = this;
        Global.actionShare2(Global.doubleGetGoldShareID, function () {
            e.doubleGold();
        });
    },
    btnDoubleClick: function btnDoubleClick() {
        var e = this;
        Global.getisShowVideo2(Global.doubleGetGoldShareID) ? Global.showVideoAD(function () {
            e.doubleGold();
        }, "040", function () {
            Global.isOldPlayer() && e.shareAndGetGold();
        }) : this.shareAndGetGold();
    },
    getAudioManager: function getAudioManager() {
        return this._tempAudioManager || (this._tempAudioManager = cc.find("AudioManager").getComponent("AudioManager")), this._tempAudioManager;
    },
    doubleGold: function doubleGold() {
        Global.operateGold(this.gold), this.gameSceneShowGold(), Global.toast("谢谢观看，获得" + this.gold + "金币"), this.btnCloseClick(), this.getAudioManager().playCoin2();
    },
    btnCloseClick: function btnCloseClick() {
        this.node.destroy();
    }
});

cc._RF.pop();
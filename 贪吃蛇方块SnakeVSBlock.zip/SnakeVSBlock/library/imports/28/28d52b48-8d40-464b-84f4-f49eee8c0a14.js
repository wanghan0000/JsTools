"use strict";
cc._RF.push(module, '28d52tIjUBGS4T09J7ujAoU', 'propBox');
// src/propBox.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        pickRadius: 0,
        boxSpriteFrame: cc.SpriteFrame,
        goldSpriteFrame: cc.SpriteFrame,
        iceSpriteFrame: cc.SpriteFrame,
        huDunSpriteFrame: cc.SpriteFrame,
        propType: -1
    },
    showProp: function showProp(e) {
        if (this.propType != e) {
            switch (e) {
                case 0:
                    this.node.getComponent(cc.Sprite).spriteFrame = this.boxSpriteFrame;
                    break;

                case 1:
                    this.node.getComponent(cc.Sprite).spriteFrame = this.goldSpriteFrame;
                    break;

                case 2:
                    this.node.getComponent(cc.Sprite).spriteFrame = this.iceSpriteFrame;
                    break;

                case 3:
                    this.node.getComponent(cc.Sprite).spriteFrame = this.huDunSpriteFrame;
            }
            this.propType = e;
        }
    },
    getDistance: function getDistance() {
        var e = this.node.parent.getChildByName("head").getPosition();
        return this.node.getPosition().sub(e).mag();
    },
    onPicked: function onPicked() {
        switch (this.propType) {
            case 0:
                this.node.parent.getComponent("gameMatrix").showBoxNode(3);
                break;

            case 1:
                this.node.parent.getComponent("gameMatrix").addGold();
                break;

            case 2:
                this.node.parent.getComponent("gameMatrix").useIce();
                break;

            case 3:
                this.node.parent.getComponent("gameMatrix").useHudun2();
        }
        this.removeSelf();
    },
    update: function update() {
        var e = this.node.parent.getChildByName("head"),
            t = Math.abs(this.node.y - e.y) - this.node.height / 2 - e.height / 2;
        this.node.getPosition().sub(e.getPosition()).mag() < this.pickRadius ? this.onPicked() : t <= 480 && (2 == this.propType ? Global.guideData.xhGuide || this.node.parent.getComponent("gameMatrix").showGuideNode(7) : 3 == this.propType && (Global.guideData.hdGuide || this.node.parent.getComponent("gameMatrix").showGuideNode(8))), this.node.y < Global.eleHidePosY && this.removeSelf();
    },
    removeSelf: function removeSelf() {
        1 != this.propType ? (cc.poolNode.propBoxPool.Push(this.node), this.propType = -1, this.node.getComponent(cc.Sprite).spriteFrame = null) : cc.poolNode.goldPool.Push(this.node), this.node.parent.removeChild(this.node, !1);
    }
});

cc._RF.pop();
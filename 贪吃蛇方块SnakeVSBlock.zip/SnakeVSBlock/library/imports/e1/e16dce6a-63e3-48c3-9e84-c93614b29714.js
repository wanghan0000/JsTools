"use strict";
cc._RF.push(module, 'e16dc5qY+NIw56EyTYUspcU', 'HTTP');
// src/HTTP.js

"use strict";

var i = require('Md5'),
    n = "https://baidu.com/";
window.AniAD = {
    max: 4,
    show: null
}, window.AniAD2 = {
    max: 4,
    show: null,
    doutiqueShow: null
}, window.DockAniAD = {
    max: 8,
    realN: 8,
    show: null,
    curADs: [],
    ADs: [],
    curDoutiqueAds: [],
    DoutiqueAds: []
};
var a = function a(e) {
    var t = [];
    for (var o in e) {
        var n = "" + o + e[o] + "&";
        t.push(n);
    }
    t.sort();
    var a = "!@#$%(12345)";
    t.forEach(function (e) {
        a += e;
    });
    var s = i.hex_md5(a);
    console.log(a + "[签名] == " + s), e.sign = s;
    var l = "?";
    for (var o in e) {
        "?" != l && (l += "&"), l += o + "=" + e[o];
    }return l;
},
    s = cc.Class({
    extends: cc.Component,
    statics: {
        sessionId: 0,
        userId: 0,
        master_url: n,
        url: n,
        Get: function Get(e, t, o) {
            var i = cc.loader.getXMLHttpRequest();
            i.timeout = 5e3;
            var n = a(t),
                l = s.url + e + encodeURI(n);
            return console.log("Get URL ========= " + l), i.open("GET", l, !0), cc.sys.isNative && i.setRequestHeader("Accept-Encoding", "gzip,deflate", "text/html;charset=UTF-8"), i.onreadystatechange = function () {
                if (4 === i.readyState) if (i.status >= 200 && i.status < 300) {
                    console.log("Http Get返回 ： " + i.responseText);
                    try {
                        var e = JSON.parse(i.responseText);
                        o && o(e);
                    } catch (e) {
                        console.log("err:" + e), console.log("err:" + l);
                    }
                } else {
                    console.log("XMLHttpRequest 调用失败！requestURL:" + l), s.showToast();
                    var t = {
                        errcode: -2,
                        errmsg: "XMLHttpRequest Error"
                    };
                    o(t);
                }
            }, i.send(), i;
        },
        GetWithHeader: function GetWithHeader(e, t, o) {
            var i = cc.loader.getXMLHttpRequest();
            i.timeout = 5e3;
            var n = s.url + e;
            for (var a in i.open("GET", n, !0), t) {
                i.setRequestHeader(a + "", t[a] + "");
            }return i.onreadystatechange = function () {
                if (4 === i.readyState) if (i.status >= 200 && i.status < 300) {
                    console.log("Http Get返回 ： " + i.responseText);
                    try {
                        var e = JSON.parse(i.responseText);
                        o && o(e);
                    } catch (e) {
                        console.log("err:" + e), console.log("err:" + n);
                    }
                } else {
                    console.log("XMLHttpRequest 调用失败！requestURL:" + n), s.showToast();
                    var t = {
                        errcode: -2,
                        errmsg: "XMLHttpRequest Error"
                    };
                    o(t);
                }
            }, i.send(), i;
        },
        Post: function Post(e, t, o) {
            var i = cc.loader.getXMLHttpRequest();
            i.timeout = 5e3;
            a(t);
            var n = s.url + e;
            return i.open("POST", n, !0), cc.sys.isNative && i.setRequestHeader("Accept-Encoding", "gzip,deflate", "application/json;charset=UTF-8"), i.onreadystatechange = function () {
                if (4 === i.readyState && i.status >= 200 && i.status < 300) try {
                    var e = JSON.parse(i.responseText);
                    null !== o && o(e);
                } catch (e) {
                    console.log("err:" + e), console.log("err:" + n);
                } else console.log("XMLHttpRequest 调用失败！requestURL:" + n), s.showToast();
            }, i.send(JSON.stringify(t)), i;
        },
        Request: function Request(e, t) {
            var o = cc.loader.getXMLHttpRequest();
            return o.timeout = 5e3, o.open("GET", e, !0), cc.sys.isNative && o.setRequestHeader("Accept-Encoding", "gzip,deflate", "text/html;charset=UTF-8"), o.onreadystatechange = function () {
                if (4 === o.readyState) if (o.status >= 200 && o.status < 300) try {
                    var i = JSON.parse(o.responseText);
                    t && t(i);
                } catch (t) {
                    console.log("err:" + t), console.log("err:" + e);
                } else {
                    console.log("XMLHttpRequest 调用失败！requestURL:" + e), s.showToast();
                }
            }, o.send(), o;
        },
        getDockReqUrl: function getDockReqUrl(e) {
            var t = "",
                o = "",
                i = Global.getData("IPAddr");
            void 0 != i && "" != i && (t = i[0], o = i[1]);
            var n = Global.host + "/gameconf/" + Global.appid + "/wechatGetDockAniAD/?touchN=" + e + "&city=" + t + "&region=" + o;
            return console.log("=====请求地址是===reqUrl====", n), n;
        },
        showToast: function showToast() {}
    }
});

cc._RF.pop();
"use strict";
cc._RF.push(module, '81ca04wJf9MiJay1AyZjueR', 'skinBox');
// src/skinBox.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        skinIndex: 0,
        pickRadius: 0
    },
    onLoad: function onLoad() {
        var e = this.node.getChildByName("light");
        e.stopAllActions(), e.runAction(cc.repeatForever(cc.rotateBy(1, 90)));
    },
    setSkin: function setSkin(e) {
        if (this.skinIndex != e) {
            this.skinIndex = e;
            var t = this.node,
                o = "pifu_" + ("" + (this.skinIndex < 10 ? "0" + this.skinIndex : this.skinIndex)),
                i = t.getChildByName("pifu");
            i.scale = .8, i.x = 0, 6 == this.skinIndex ? i.x = 2 : 9 == this.skinIndex && (i.x = -4), this.node.getChildByName("sy").active = e > 9, cc.loader.loadRes("Skin/" + o, cc.SpriteFrame, function (e, t) {
                e || (i.getComponent(cc.Sprite).spriteFrame = t);
            });
        }
    },
    getDistance: function getDistance() {
        var e = this.node.parent.getChildByName("head").getPosition();
        return this.node.getPosition().sub(e).mag();
    },
    onPicked: function onPicked() {
        this.node.parent.getComponent("gameMatrix").showBoxNode(4, this.skinIndex), this.removeSelf();
    },
    update: function update() {
        this.getDistance() < this.pickRadius && this.onPicked(), this.node.y < Global.eleHidePosY && this.removeSelf();
    },
    removeSelf: function removeSelf() {
        cc.poolNode.skinBoxPool.Push(this.node), this.node.parent.removeChild(this.node, !1);
    }
});

cc._RF.pop();
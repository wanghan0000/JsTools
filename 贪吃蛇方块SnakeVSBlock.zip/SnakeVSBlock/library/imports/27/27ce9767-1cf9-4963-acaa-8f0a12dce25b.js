"use strict";
cc._RF.push(module, '27ce9dnHPlJY6yqjwoS3OJb', 'loading');
// src/loading.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        percentLb: cc.Label
    },
    onLoad: function onLoad() {
        Global.initData(), this.loadProgess = 0, this.updateTime = 0, cc.director.preloadScene("mainScene");
    },
    updatePrg: function updatePrg() {
        this.percentLb.string = this.loadProgess + "%";
    },
    update: function update(e) {
        this.loadProgess >= 99 ? this.showMain() : (this.updateTime += e, this.updateTime > .03 && (this.loadProgess += 1, this.updateTime = 0), Global.isFinishGetIp && (this.loadProgess = 99), this.updatePrg());
    },
    showMain: function showMain() {
        this.isshowMain || (this.isshowMain = !0, cc.director.loadScene("mainScene"));
    }
});

cc._RF.pop();
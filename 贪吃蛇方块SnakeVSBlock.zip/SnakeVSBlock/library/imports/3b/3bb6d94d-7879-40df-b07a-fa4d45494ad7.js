"use strict";
cc._RF.push(module, '3bb6dlNeHlA37B6+k1FSUrX', 'bgItem');
// src/bgItem.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        lock: cc.Node,
        select: cc.Node,
        index: 0,
        unLockSelect: cc.Node
    },
    show: function show(e) {
        var t = this;
        this.index = e;
        var o = "itembg" + e;
        cc.loader.loadRes("Scene/" + o, cc.SpriteFrame, function (e, o) {
            e || (t.node.getComponent(cc.Sprite).spriteFrame = o);
        }), Global.getIsUnLockScene(e) && (this.lock.active = !1, Global.sceneData.select == e && (this.select.active = !0));
    },
    selectItemClick: function selectItemClick() {
        this.lock.active ? this.unLockSelect.active = !0 : this.select.active = !0, this.node.emit("select", this.index);
    },
    selectItem: function selectItem(e) {
        this.select.active = e;
    },
    unLock: function unLock() {
        this.lock.active = !1;
    },
    clearShowLockSelect: function clearShowLockSelect() {
        this.unLockSelect.active = !1;
    }
});

cc._RF.pop();
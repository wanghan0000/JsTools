"use strict";
cc._RF.push(module, '42196/AxTtHIKZ7nF2sHvJ2', 'BoutiqueDockAD');
// src/BoutiqueDockAD.js

"use strict";

var i = require('HTTP'),
    n = 130,
    a = 170,
    s = 720;
cc.Class({
    extends: cc.Component,
    properties: {
        dockDyn: cc.Prefab,
        container: cc.Node,
        backBtn: cc.Node,
        showBtn: cc.Node
    },
    onLoad: function onLoad() {
        var e = this;
        e.containerSize = e.container.getContentSize(), e.container.x = -s, e.setBtnState(!0), e.dockPool = new cc.NodePool();
        for (var t = null, o = 0; o < 10; o++) {
            t = cc.instantiate(e.dockDyn), e.dockPool.put(t);
        }window.docktouchN = 0, DockAniAD.curDoutiqueAds = [], e.node.opacity = 0;
        null == DockAniAD.doutiqueShow ? e.getDockAdData(function (t) {
            t && e.canshow(function () {
                1 == DockAniAD.doutiqueShow ? e.showAd() : e.node.active = !1;
            });
        }) : 1 == DockAniAD.doutiqueShow ? e.showAd() : e.node.active = !1;
    },
    showAd: function showAd() {
        this.node.opacity = 255;
        var e = null,
            t = null,
            o = {
            x: 0,
            y: 0
        };
        o.x = 4 * -n / 2 + n / 2, o.y = 3 * a / 2 + a / 4 - 5;
        var i = DockAniAD.realN;
        i > 12 && (i = 12);
        for (var s = 0; s < i; s++) {
            e = this.dockPool.size() > 0 ? this.dockPool.get() : cc.instantiate(this.dockDyn), (t = {
                x: 0,
                y: 0
            }).x = o.x + s % 4 * n, t.y = o.y - Math.ceil((s + 1) / 4) * a, e.parent = this.container, e.setPosition(cc.v2(t.x, t.y)), e.getComponent("BoutiquenamicImage").showDynamicImage();
        }
    },
    setBtnState: function setBtnState(e) {
        this.backBtn.active = !e, this.showBtn.active = e;
    },
    clickBack: function clickBack() {
        var e = this;
        this.container.stopAllActions(), this.container.runAction(cc.sequence(cc.moveTo(.8, -s, 85), cc.callFunc(function () {
            e.setBtnState(!0), cc.systemEvent.emit("hideBoutique");
        }, this)));
    },
    clickShow: function clickShow() {
        this.setBtnState(!1), cc.systemEvent.emit("showBoutique"), this.container.stopAllActions(), this.container.runAction(cc.sequence(cc.moveTo(.8, (this.containerSize.width - s) / 2, 85), cc.callFunc(function () {}, this)));
    },
    canshow: function canshow(e) {
        var t = Global.host + "/gameconf/" + Global.appid + "/getADswitch/2/",
            o = cc.loader.getXMLHttpRequest();
        o.onreadystatechange = function () {
            if (4 == o.readyState && o.status >= 200 && o.status < 400) {
                var t = o.responseText;
                DockAniAD.doutiqueShow = !1, "0" == t ? DockAniAD.doutiqueShow = !1 : "1" == t && (DockAniAD.doutiqueShow = !0), e && e();
            }
        }, o.open("GET", t, !0), o.send();
    },
    getDockAdData: function getDockAdData(e) {
        this.touchN = 0;
        var t = i.getDockReqUrl(this.touchN);
        i.Request(t, function (t) {
            t && 200 === t.code ? (DockAniAD.max = t.data.max, DockAniAD.realN = t.data.realN, e(!0)) : e(!1);
        });
    }
});

cc._RF.pop();
"use strict";
cc._RF.push(module, 'ea3ed3zxZVKSpTk7SZ7Roxm', 'Md5');
// src/Md5.js

"use strict";

var i = 1,
    n = 8;

function a(e) {
    return p(s(g(e), e.length * n));
}

function s(e, t) {
    e[t >> 5] |= 128 << t % 32, e[14 + (t + 64 >>> 9 << 4)] = t;
    for (var o = 1732584193, i = -271733879, n = -1732584194, a = 271733878, s = 0; s < e.length; s += 16) {
        var l = o,
            g = i,
            p = n,
            m = a;
        i = d(i = d(i = d(i = d(i = r(i = r(i = r(i = r(i = h(i = h(i = h(i = h(i = c(i = c(i = c(i = c(i, n = c(n, a = c(a, o = c(o, i, n, a, e[s + 0], 7, -680876936), i, n, e[s + 1], 12, -389564586), o, i, e[s + 2], 17, 606105819), a, o, e[s + 3], 22, -1044525330), n = c(n, a = c(a, o = c(o, i, n, a, e[s + 4], 7, -176418897), i, n, e[s + 5], 12, 1200080426), o, i, e[s + 6], 17, -1473231341), a, o, e[s + 7], 22, -45705983), n = c(n, a = c(a, o = c(o, i, n, a, e[s + 8], 7, 1770035416), i, n, e[s + 9], 12, -1958414417), o, i, e[s + 10], 17, -42063), a, o, e[s + 11], 22, -1990404162), n = c(n, a = c(a, o = c(o, i, n, a, e[s + 12], 7, 1804603682), i, n, e[s + 13], 12, -40341101), o, i, e[s + 14], 17, -1502002290), a, o, e[s + 15], 22, 1236535329), n = h(n, a = h(a, o = h(o, i, n, a, e[s + 1], 5, -165796510), i, n, e[s + 6], 9, -1069501632), o, i, e[s + 11], 14, 643717713), a, o, e[s + 0], 20, -373897302), n = h(n, a = h(a, o = h(o, i, n, a, e[s + 5], 5, -701558691), i, n, e[s + 10], 9, 38016083), o, i, e[s + 15], 14, -660478335), a, o, e[s + 4], 20, -405537848), n = h(n, a = h(a, o = h(o, i, n, a, e[s + 9], 5, 568446438), i, n, e[s + 14], 9, -1019803690), o, i, e[s + 3], 14, -187363961), a, o, e[s + 8], 20, 1163531501), n = h(n, a = h(a, o = h(o, i, n, a, e[s + 13], 5, -1444681467), i, n, e[s + 2], 9, -51403784), o, i, e[s + 7], 14, 1735328473), a, o, e[s + 12], 20, -1926607734), n = r(n, a = r(a, o = r(o, i, n, a, e[s + 5], 4, -378558), i, n, e[s + 8], 11, -2022574463), o, i, e[s + 11], 16, 1839030562), a, o, e[s + 14], 23, -35309556), n = r(n, a = r(a, o = r(o, i, n, a, e[s + 1], 4, -1530992060), i, n, e[s + 4], 11, 1272893353), o, i, e[s + 7], 16, -155497632), a, o, e[s + 10], 23, -1094730640), n = r(n, a = r(a, o = r(o, i, n, a, e[s + 13], 4, 681279174), i, n, e[s + 0], 11, -358537222), o, i, e[s + 3], 16, -722521979), a, o, e[s + 6], 23, 76029189), n = r(n, a = r(a, o = r(o, i, n, a, e[s + 9], 4, -640364487), i, n, e[s + 12], 11, -421815835), o, i, e[s + 15], 16, 530742520), a, o, e[s + 2], 23, -995338651), n = d(n, a = d(a, o = d(o, i, n, a, e[s + 0], 6, -198630844), i, n, e[s + 7], 10, 1126891415), o, i, e[s + 14], 15, -1416354905), a, o, e[s + 5], 21, -57434055), n = d(n, a = d(a, o = d(o, i, n, a, e[s + 12], 6, 1700485571), i, n, e[s + 3], 10, -1894986606), o, i, e[s + 10], 15, -1051523), a, o, e[s + 1], 21, -2054922799), n = d(n, a = d(a, o = d(o, i, n, a, e[s + 8], 6, 1873313359), i, n, e[s + 15], 10, -30611744), o, i, e[s + 6], 15, -1560198380), a, o, e[s + 13], 21, 1309151649), n = d(n, a = d(a, o = d(o, i, n, a, e[s + 4], 6, -145523070), i, n, e[s + 11], 10, -1120210379), o, i, e[s + 2], 15, 718787259), a, o, e[s + 9], 21, -343485551), o = u(o, l), i = u(i, g), n = u(n, p), a = u(a, m);
    }
    return Array(o, i, n, a);
}

function l(e, t, o, i, n, a) {
    return u(function (e, t) {
        return e << t | e >>> 32 - t;
    }(u(u(t, e), u(i, a)), n), o);
}

function c(e, t, o, i, n, a, s) {
    return l(t & o | ~t & i, e, t, n, a, s);
}

function h(e, t, o, i, n, a, s) {
    return l(t & i | o & ~i, e, t, n, a, s);
}

function r(e, t, o, i, n, a, s) {
    return l(t ^ o ^ i, e, t, n, a, s);
}

function d(e, t, o, i, n, a, s) {
    return l(o ^ (t | ~i), e, t, n, a, s);
}

function u(e, t) {
    var o = (65535 & e) + (65535 & t);
    return (e >> 16) + (t >> 16) + (o >> 16) << 16 | 65535 & o;
}

function g(e) {
    for (var t = Array(), o = (1 << n) - 1, i = 0; i < e.length * n; i += n) {
        t[i >> 5] |= (e.charCodeAt(i / n) & o) << i % 32;
    }return t;
}

function p(e) {
    for (var t = i ? "0123456789ABCDEF" : "0123456789abcdef", o = "", n = 0; n < 4 * e.length; n++) {
        o += t.charAt(e[n >> 2] >> n % 4 * 8 + 4 & 15) + t.charAt(e[n >> 2] >> n % 4 * 8 & 15);
    }return o;
}
module.exports.hex_md5 = a;

cc._RF.pop();
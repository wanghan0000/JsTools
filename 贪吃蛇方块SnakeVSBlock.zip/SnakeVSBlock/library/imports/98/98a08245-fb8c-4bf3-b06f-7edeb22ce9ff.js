"use strict";
cc._RF.push(module, '98a08JF+4xL87Bvft6yLOn/', 'skinNode');
// src/skinNode.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        itemPrefab: cc.Prefab,
        layout1: cc.Node,
        layout2: cc.Node,
        scrollNode: cc.Node,
        curShowPage: 0,
        selectUnLock: -1,
        unLockGold: cc.Label,
        goldCount: cc.Label,
        lastPosX: 0,
        time: 0
    },
    onLoad: function onLoad() {
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.touchMove, this), this.node.on(cc.Node.EventType.TOUCH_END, this.touchEnd, this), this.offset = 0, this.canMove = !1, this.preX = -360;
    },
    showNode: function showNode(e) {
        this.curShowPage != e && (1 == e ? (this.offset = 0, this.scrollNode.x = this.preX) : (this.offset = -this.layout1.width, this.scrollNode.x = this.preX + this.offset), this.show(e)), this.isShowVideo = Global.isShowVideoAD("007", !0), this.node.getChildByName("btnHelp").getChildByName("help").active = this.isShowVideo;
    },
    update: function update(e) {
        this.time += e, this.time > 1 && (this.goldCount.string = Global.gold);
    },
    touchMove: function touchMove(e) {
        this.lastPosX += e.getDelta().x, Math.abs(this.lastPosX) >= 10 && (this.canMove = !0), this.canMove && (this.offset += e.getDeltaX(), this.offset >= 0 && (this.offset = 0), this.offset <= -this.layout1.width && (this.offset = -this.layout1.width), this.scrollNode.x = this.preX + this.offset);
    },
    touchEnd: function touchEnd(e) {
        this.canMove = !1;
        var t = e.getLocation();
        this.layout1.convertToNodeSpaceAR(t);
        this.checkTouch(t), this.lastPosX = 0;
    },
    checkTouch: function checkTouch(e) {
        if (Math.abs(this.lastPosX) > 10) {
            var t = this.curShowPage,
                o = Math.abs(this.scrollNode.x - this.preX);
            console.log("this.offset = " + this.offset + ",  absoff =" + o + ", posx=" + this.lastPosX), this.lastPosX > 0 && o <= this.layout1.width && o >= 0 ? --t <= 0 && (t = 1) : this.lastPosX < 0 && o >= this.layout1.width / 3 && o <= this.layout1.width && ++t >= 2 && (t = 2), this.show(t);
        } else {
            var i = this.layout1;
            2 == this.curShowPage && (i = this.layout2);
            for (var n = i.convertToNodeSpaceAR(e), a = 0; a < i.childrenCount; a++) {
                var s = i.children[a];
                if (n.x >= s.x - s.width / 2 && n.x <= s.x + s.width / 2 && n.y >= s.y - s.height / 2 && n.y <= s.y + s.height / 2) {
                    s.getComponent("skinItem").selectClick();
                    break;
                }
            }
        }
    },
    show: function show(e) {
        this.lastPosX = 0, this.layout1.active = !0, this.layout2.active = !0, this.curShowPage = e, this.selectUnLock = -1, this.clearShowLockSelect(-1), this.goldCount.string = Global.gold;
        var t = this.node.getChildByName("btnLayout1").getChildByName("pageSelect"),
            o = this.node.getChildByName("btnLayout1").getChildByName("pageUnSelect");
        t.active = 1 == e, o.active = !(1 == e);
        var i = this.node.getChildByName("btnLayout2").getChildByName("pageSelect"),
            n = this.node.getChildByName("btnLayout2").getChildByName("pageUnSelect");
        if (i.active = 2 == e, n.active = !(2 == e), 1 == e) {
            this.unLockGold.string = "250";
            var a = Math.abs(this.preX - this.scrollNode.x);
            this.scrollNode.runAction(cc.moveTo(a / 800, cc.v2(this.preX, this.scrollNode.y))), this.offset = 0;
        } else {
            this.unLockGold.string = "500";
            var s = cc.v2(this.preX - this.layout1.width, this.scrollNode.y),
                l = Math.abs(s.x - this.scrollNode.x);
            this.scrollNode.runAction(cc.moveTo(l / 800, cc.v2(s.x, this.scrollNode.y))), this.offset = -this.layout1.width;
        }
        if (this.layout1.childrenCount <= 0) for (var c = 1; c <= 9; c++) {
            var h = cc.instantiate(this.itemPrefab);
            h.getComponent("skinItem").show(c), h.on("select", this.selectItem.bind(this)), this.layout1.addChild(h);
        }
        if (this.layout2.childrenCount <= 0) for (var r = 10; r <= 16; r++) {
            var d = cc.instantiate(this.itemPrefab);
            d.getComponent("skinItem").show(r), d.on("select", this.selectItem.bind(this)), this.layout2.addChild(d);
        }
    },
    selectItem: function selectItem(e) {
        this.selectUnLock = -1, e && (console.log("event.detail" + e), Global.getIsUnLockSkin(e) ? this.changeSelectItem(e) : (this.selectUnLock = e, this.clearShowLockSelect(this.selectUnLock)));
    },
    changeSelectItem: function changeSelectItem(e) {
        Global.setSelectIndex(e);
        for (var t = 0; t < this.layout1.childrenCount; t++) {
            var o = this.layout1.children[t];
            o.getComponent("skinItem").clearShowLockSelect(), o.getComponent("skinItem").index != e ? o.getComponent("skinItem").selectItem(!1) : o.getComponent("skinItem").selectItem(!0);
        }
        for (var i = 0; i < this.layout2.childrenCount; i++) {
            var n = this.layout2.children[i];
            n.getComponent("skinItem").clearShowLockSelect(), n.getComponent("skinItem").index != e ? n.getComponent("skinItem").selectItem(!1) : n.getComponent("skinItem").selectItem(!0);
        }
    },
    clearShowLockSelect: function clearShowLockSelect(e) {
        for (var t = 0; t < this.layout1.childrenCount; t++) {
            var o = this.layout1.children[t];
            o.getComponent("skinItem").index != e && o.getComponent("skinItem").clearShowLockSelect();
        }
        for (var i = 0; i < this.layout2.childrenCount; i++) {
            var n = this.layout2.children[i];
            n.getComponent("skinItem").index != e && n.getComponent("skinItem").clearShowLockSelect();
        }
    },
    unLockSkinClick: function unLockSkinClick() {
        if (this.selectUnLock < 0) Global.toast("请先选择需要解锁的皮肤!");else {
            var e = 250;
            if (2 == this.curShowPage && (e = 500), Global.gold < e) Global.toast("金币不足" + e + "，无法解锁！");else {
                Global.operateGold(-e), Global.toast("解锁皮肤成功！"), Global.unLockSkin(this.selectUnLock), Global.setSelectIndex(this.selectUnLock), this.goldCount.string = Global.gold, Global.getTongJi("021", 1);
                for (var t = 0; t < this.layout1.childrenCount; t++) {
                    var o = this.layout1.children[t];
                    o.getComponent("skinItem").index == this.selectUnLock ? (o.getComponent("skinItem").unLock(), o.getComponent("skinItem").selectItem(!0)) : o.getComponent("skinItem").selectItem(!1);
                }
                for (var i = 0; i < this.layout2.childrenCount; i++) {
                    var n = this.layout2.children[i];
                    n.getComponent("skinItem").index == this.selectUnLock ? (n.getComponent("skinItem").unLock(), n.getComponent("skinItem").selectItem(!0)) : n.getComponent("skinItem").selectItem(!1);
                }
                this.selectUnLock = -1;
            }
        }
    },
    clickShowPage: function clickShowPage(e, t) {
        1 == t && 1 != this.curShowPage ? this.show(1) : 2 == t && 2 != this.curShowPage && this.show(2);
    },
    backClick: function backClick() {
        this.node.active = !1, this.node.emit("skinNodeClose"), this.ReShowMainSceneAD();
    },
    ReShowMainSceneAD: function ReShowMainSceneAD() {
        var e = new cc.Event.EventCustom("ReShowMainAD", !0);
        this.node.dispatchEvent(e);
    },
    helpClick: function helpClick() {
        this.isShowVideo ? Global.showVideoAD(function () {
            Global.toast("感谢观看，获得25金币"), Global.operateGold(25);
        }, "036") : Global.isNormal ? Global.shareGame("007", function (e) {
            (Global.toast("分享成功~"), Global.getData("firstShare", !1)) || (Global.saveData("firstShare", !0), cc.find("AudioManager").getComponent("AudioManager").node.runAction(cc.sequence(cc.delayTime(5), cc.callFunc(function () {
                Global.toast("成功邀请1位玩家进入游戏，奖励你25个金币"), Global.operateGold(25);
            }))));
        }) : Global.shareGame2({
            title: Global.title,
            imageUrl: Global.imageUrl,
            query: "",
            djName: "skinShare",
            shareID: "007",
            propName: "gold"
        }, function (e) {
            e.confirm && (Global.toast("分享成功，找群友帮忙更容易成功哦~"), Global.getData("firstShare", !1) || (Global.saveData("firstShare", !0), cc.find("AudioManager").getComponent("AudioManager").node.runAction(cc.sequence(cc.delayTime(5), cc.callFunc(function () {
                Global.toast("成功邀请1位玩家进入游戏，奖励你25个金币"), Global.operateGold(25);
            })))));
        }), Global.getShare();
    }
});

cc._RF.pop();
"use strict";
cc._RF.push(module, 'b4e2adhsDlEtowZ6I6gpBkX', 'blockParticle');
// src/blockParticle.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        isPlay: !1
    },
    play: function play() {
        this.isPlay = !0, this._tempTimes = 0, this.getComponent(cc.ParticleSystem).resetSystem();
    },
    update: function update(e) {
        this.isPlay && (this._tempTimes += e, this._tempTimes >= 2.2 && (this.isPlay = !1, this._tempTimes = 0, this.playEnd()));
    },
    playEnd: function playEnd() {
        this.node.parent && (this.node.parent.removeChild(this.node), cc.poolNode.blockParticlePool.Push(this.node));
    }
});

cc._RF.pop();
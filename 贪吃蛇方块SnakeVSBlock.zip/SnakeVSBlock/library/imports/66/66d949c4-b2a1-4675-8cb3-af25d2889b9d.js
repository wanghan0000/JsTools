"use strict";
cc._RF.push(module, '66d94nEsqFGdYyzryXSiJud', 'gameEnd');
// src/gameEnd.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        endNode: cc.Node,
        endNodeBg: cc.Node,
        firstFuhuo: cc.Node,
        display: cc.Sprite,
        groupNodePrefab: cc.Prefab,
        getGoldNodePrefab: cc.Prefab,
        topBar: cc.Node
    },
    onLoad: function onLoad() {
        this.updateTime = 0;
    },
    start: function start() {
        this.tex = new cc.Texture2D();
    },
    adjustNode: function adjustNode(e, t, o) {
        if (e.active) {
            var i = Global.adHeight;
            o && (i += Global.iPhoneFullAddH + 40 + 40);
            var n = e.getComponent(cc.Widget);
            n.isAlignBottom = !0, n.bottom = (cc.winSize.height - i - e.height) / 2 + i + t / 2;
        }
    },
    btnAction: function btnAction(e) {
        if (e.active) {
            e.stopAllActions(), e.scale = 1;
            e.runAction(cc.repeatForever(cc.sequence(cc.scaleTo(.8, 1.1), cc.scaleTo(.8, 1))));
        }
    },
    getAudioManager: function getAudioManager() {
        return this._tempAudioManager || (this._tempAudioManager = cc.find("AudioManager").getComponent("AudioManager")), this._tempAudioManager;
    },
    gameSceneShowGold: function gameSceneShowGold() {
        cc.find("gameScene").getComponent("gameScene").showGold();
    },
    adaper: function adaper() {
        var e = cc.winSize.width,
            t = cc.winSize.height,
            o = cc.view.getFrameSize().height;
        if (t / e >= 1.8 && (Global.isFullScreen = !0), t / e < 2) {
            var i = this.topBar.getComponent(cc.Widget);
            i.isAlignTop = !0, i.top = t / o * 11, i.isAbsoluteTop = !0;
        } else {
            var n = this.topBar.getComponent(cc.Widget);
            n.isAlignTop = !0, n.top = t / o * 43, n.isAbsoluteTop = !0;
        }
    },
    showEnd: function showEnd(e, t) {
        if (t > 0) {
            var o = cc.instantiate(this.getGoldNodePrefab);
            o.parent = this.node, o.getComponent("getGoldNode").show(t);
        }
        wx.postMessage({
            message: "HideRankingList"
        }), this.endNodeBg.active = !0, this.firstFuhuo.active = !1, this.topBar.active = !0, this.adjustNode(this.endNodeBg, 100), this.adaper(), this.endNode.getChildByName("scoreLb").getComponent(cc.Label).string = e, this.endNode.getChildByName("historyLb").getComponent(cc.Label).string = "历史最高: " + Global.historyScore, this._score = e, Global.saveHistoryScore(Global.weekScore), this.btnAction(this.endNode.getChildByName("btnBack"));
        var i = this.node.getChildByName("btnBack2");
        i.active = !0, this.setElementTop(i), this.setCanvas(), Global.showBannerId(5, this.node), this.setDockPos();
    },
    setDockPos: function setDockPos() {
        var e = this.endNodeBg.getChildByName("loopDock").getComponent(cc.Widget);
        e.isAlignBottom = !0, Global.isiPhoneFull ? e.bottom = Global.adHeight + Global.iPhoneFullAddH : Global.isSmallPhone && (e.bottom = Global.adHeight + 43);
    },
    setElementTop: function setElementTop(e) {
        var t = cc.view.getFrameSize(),
            o = 0;
        o = t.height / t.width <= 2 ? 12 : 50;
        var i = e.getComponent(cc.Widget);
        i.isAlignTop = !0, i.top = cc.director.getWinSize().height / t.height * o + 15, i.isAlignBottom = !1;
    },
    setCanvas: function setCanvas() {
        this._sort = 1, sharedCanvas.width = this.display.node.width, sharedCanvas.height = this.display.node.height, wx.postMessage({
            message: "ShowSimpleRankingList",
            yoff: 0,
            contentH: this.display.node.height
        });
    },
    changePassBtnPos: function changePassBtnPos() {
        if (this.firstFuhuo.active) {
            var e = this.firstFuhuo.getChildByName("btnPass").getComponent(cc.Widget);
            e.isAlignBottom = !0, e.bottom = Global.bannerHeight;
        }
    },
    update: function update(e) {
        this.updateTime += e, this.updateTime > 1 && (this.changePassBtnPos(), this.updateTime = 0), this._sort && this._updateSubDomainCanvas();
    },
    _updateSubDomainCanvas: function _updateSubDomainCanvas() {
        this.tex && (this.tex.initWithElement(sharedCanvas), this.tex.handleLoadedTexture(), this.display.spriteFrame = new cc.SpriteFrame(this.tex));
    },
    chaoyueClick: function chaoyueClick() {
        Global.qiuChaoyue("042", Global.historyScore);
    },
    yaoqinghaoyouClick: function yaoqinghaoyouClick() {
        Global.shareGameOnly("017", void 0, "敢于我一战吗？谁输谁发红包！", "https://www.baidu.com/images/tcsdzfk/share/05.png");
    },
    backClick: function backClick() {
        cc.director.loadScene("mainScene");
    },
    againClick: function againClick() {
        cc.director.loadScene("gameScene");
    },
    sortClick: function sortClick() {
        Global.closeBanner(), wx.postMessage({
            message: "HideRankingList"
        });
        var e = cc.instantiate(this.groupNodePrefab);
        e.getComponent("sortNode").showfriendByEnd(), this.node.addChild(e);
    },
    showFirstHuohuo: function showFirstHuohuo(e, t, o) {
        this.endNodeBg.active = !1, this.firstFuhuo.active = !0, this.topBar.active = !1, this.node.getChildByName("btnBack2").active = !1;
        var i = this.firstFuhuo.getChildByName("btnVideoFh"),
            n = this.firstFuhuo.getChildByName("btnFuhuo");
        n.getChildByName("Label").getComponent(cc.RichText).string = '<color=#2F2F2F>立即复活  <img src="gold" />' + 25 * (t + 1) + "</c>", this.firstFuhuo.getChildByName("btnFreeGold").stopAllActions(), this.adjustNode(this.firstFuhuo, 0, Global.isiPhoneFull), n.active = !0, this.btnAction(i), this.firstFuhuo.getChildByName("scoreLb").getComponent(cc.Label).string = e, this.firstFuhuo.getChildByName("historyLb").getComponent(cc.Label).string = "历史最高: " + Global.historyScore, this.times = 15, this.schedule(this.updateTimer, 1), this.firstFuhuo.getChildByName("timeSp").getChildByName("label").getComponent(cc.Label).string = this.times, this._score = e, this._gold = o, this.fuhuoTimes = t, Global.showBannerId(2, this.node), this.btnAction(this.firstFuhuo.getChildByName("btnFreeGold")), this.scheduleOnce(function () {
            this.firstFuhuo.getChildByName("btnPass").active = !0;
        }, Global.passBtnShowTime);
    },
    fhShareAndGetGold: function fhShareAndGetGold() {
        var e = this,
            t = this;
        Global.actionShare2(Global.fhFreeGoldShareID, function () {
            Global.operateGold(25), t.gameSceneShowGold(), Global.toast("谢谢分享，获得25金币"), t.getAudioManager().playCoin2(), t.schedule(e.updateTimer, 1);
        }, function () {
            t.schedule(e.updateTimer, 1);
        });
    },
    btnFreeGoldClick: function btnFreeGoldClick() {
        var e = this,
            t = this;
        this.unschedule(this.updateTimer), Global.getisShowVideo2(Global.fhFreeGoldShareID) ? Global.showVideoAD(function () {
            Global.operateGold(25), t.gameSceneShowGold(), Global.toast("谢谢观看，获得25金币"), t.getAudioManager().playCoin2(), t.schedule(e.updateTimer, 1);
        }, "044", function () {
            Global.isOldPlayer() ? t.fhShareAndGetGold() : t.schedule(e.updateTimer, 1);
        }) : t.fhShareAndGetGold();
    },
    fuhuo: function fuhuo(e) {
        this.unschedule(this.updateTimer);
        var t = new cc.Event.EventCustom("fuHuo", !0);
        t.detail = e, this.node.dispatchEvent(t), this.node.active = !1;
    },
    normalBtnFuhuo: function normalBtnFuhuo() {
        var e = 25 * (this.fuhuoTimes + 1);
        if (Global.gold >= e) {
            this.unschedule(this.updateTimer);
            var t = new cc.Event.EventCustom("fuHuo", !0);
            this.node.dispatchEvent(t), this.node.active = !1, Global.operateGold(-e), this.gameSceneShowGold();
        } else Global.toast("金币不足，复活失败！");
    },
    videoFuhuoClick: function videoFuhuoClick() {
        var e = this,
            t = this;
        this.unschedule(this.updateTimer), Global.getisShowVideo2(Global.FHShareID) ? Global.showVideoAD(function () {
            var e = new cc.Event.EventCustom("fuHuo", !0);
            t.node.dispatchEvent(e), t.node.active = !1;
        }, "035", function () {
            Global.isOldPlayer() ? t.shareAndFuhuo() : t.schedule(e.updateTimer, 1);
        }) : this.shareAndFuhuo();
    },
    shareAndFuhuo: function shareAndFuhuo() {
        var e = this,
            t = this;
        Global.actionShare2(Global.FHShareID, function () {
            var e = new cc.Event.EventCustom("fuHuo", !0);
            t.node.dispatchEvent(e), t.node.active = !1;
        }, function () {
            t.schedule(e.updateTimer, 1);
        });
    },
    firstHuohuoPass: function firstHuohuoPass() {
        this.unschedule(this.updateTimer), this.showEnd(this._score, this._gold);
    },
    updateTimer: function updateTimer() {
        this.times--, this.firstFuhuo.getChildByName("timeSp").getChildByName("label").getComponent(cc.Label).string = this.times, this.getAudioManager().playTimes(), 0 == this.times && (this.unschedule(this.updateTimer), this.firstHuohuoPass());
    }
});

cc._RF.pop();
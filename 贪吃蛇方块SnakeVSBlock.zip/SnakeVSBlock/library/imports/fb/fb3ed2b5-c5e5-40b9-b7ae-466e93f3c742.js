"use strict";
cc._RF.push(module, 'fb3edK1xeVAubeuRm6T88dC', 'fcShop');
// src/fcShop.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        lblCount: cc.Label
    },
    onLoad: function onLoad() {
        this.lblCount.string = "福卡总额: " + Global.getHBCount();
    },
    dhClick: function dhClick(e, t) {
        Global.getHBCount() < parseInt(t) && Global.toast("福卡不足，兑换失败");
    },
    closeClick: function closeClick() {
        this.node.destroy();
    }
});

cc._RF.pop();
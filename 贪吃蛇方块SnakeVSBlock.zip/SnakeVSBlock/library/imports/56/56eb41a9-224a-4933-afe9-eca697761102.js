"use strict";
cc._RF.push(module, '56eb4GpIkpJM6/p7KaXdhEC', 'shootBall');
// src/shootBall.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {},
    update: function update(e) {
        this.node.y - this.node.height / 2 > this.node.parent.height / 2 ? this.removeSelf() : this.node.parent.getComponent("gameMatrix").isGamePause || (this.node.parent.getComponent("gameMatrix").isGameEnd ? this.removeSelf() : this.node.y = this.node.y + 1e3 * e);
    },
    removeSelf: function removeSelf() {
        cc.poolNode.shootBallPool.Push(this.node), this.node.parent.removeChild(this.node, !1);
    }
});

cc._RF.pop();
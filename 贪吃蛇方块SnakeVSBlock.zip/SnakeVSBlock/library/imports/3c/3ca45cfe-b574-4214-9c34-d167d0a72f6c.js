"use strict";
cc._RF.push(module, '3ca45z+tXRCFJw00WfQpy9s', 'bodyParticle');
// src/bodyParticle.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        isPlay: !1
    },
    play: function play() {
        this.isPlay = !0, this._tempTimes = 0, this.getComponent(cc.ParticleSystem).resetSystem();
    },
    update: function update(e) {
        this.isPlay && (this._tempTimes += e, this._tempTimes >= 2 && (this.isPlay = !1, this._tempTimes = 0, this.playEnd()));
    },
    playEnd: function playEnd() {
        this.node.parent && (this.node.parent.removeChild(this.node), cc.poolNode.bodyParticlePool.Push(this.node));
    }
});

cc._RF.pop();
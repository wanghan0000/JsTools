"use strict";
cc._RF.push(module, 'b32dcWfEpFDeYkn8JTenP89', 'global');
// src/global.js

"use strict";

var o = module.exports = {};
var t = module;

var i;

function n(e, t, o) {
    return t in e ? Object.defineProperty(e, t, {
        value: o,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = o, e;
}

window.Global = (n(i = {
    BarrierSpacing: {
        min: 8,
        max: 11
    },
    BarCount: {
        min: 5,
        max: 5
    },
    BlockCount: {
        min: 2,
        max: 5
    },
    FoodCount: {
        min: 3,
        max: 5
    },
    OneFoodNum: {
        min: 1,
        max: 5
    },
    StartBody: 5,
    eleHidePosY: 0,
    addSpeed: .1,
    maxSpeed: 11,
    invincibleSpeed: 14,
    goldLineSpeed: 14,
    iceSpeed: 4,
    deleteSnakeTime: .05,
    deleteMoveSpeed: 2,
    magnetTime: 8,
    magnetHeight: 400,
    shootTime: 8,
    shootGold: 25,
    shootInterval: .18,
    huDunTime: 8,
    huDunGold: 30,
    iceTime: 8,
    isNormal: !0,
    isGetConfig: !1,
    colorArr: [[80, 233, 255], [44, 155, 252], [131, 255, 24], [253, 182, 45], [253, 145, 45], [255, 76, 53]],
    firstLogin: !1,
    isMute: 0,
    historyScore: 0,
    weekScore: 0,
    gold: 0,
    skinData: {
        select: 1,
        unLockList: [1]
    },
    sceneData: {
        select: 1,
        unLockList: [1]
    },
    boxData: {
        kaiJuDaoJu: 0,
        qiDongBaoXiang: 0
    },
    mainBoxData: {
        ContentIndex: 0,
        btnContentIndex: 0
    },
    maxGroup: 2,
    wxGroupIds: [],
    maxCancel: [2, 3],
    cancelShare: [],
    videoTimes: [],
    yqMaxCount: 10,
    yqGold: 50,
    hxMaxCount: 10,
    hxGold: 25,
    VideoMaxCount: 5,
    videoGold: 50,
    adHeight: 200,
    iPhoneFullAddH: 15,
    bannerTime: 2e3,
    snakeBombColor: [cc.color(254, 212, 0, 255), cc.color(5, 195, 5, 255), cc.color(255, 156, 155, 255), cc.color(191, 144, 113, 255), cc.color(233, 223, 210, 255), cc.color(207, 37, 29, 255), cc.color(251, 2, 2, 255), cc.color(0, 159, 231, 255), cc.color(233, 87, 93, 255), cc.color(229, 160, 22, 255), cc.color(226, 226, 228, 255), cc.color(0, 159, 231, 255), cc.color(246, 94, 70, 255), cc.color(197, 22, 38, 255), cc.color(241, 241, 241, 255), cc.color(203, 203, 203, 255)],
    invincibleColor: cc.color(40, 40, 40, 255),
    skinGold: [200, 200, 200, 200, 200, 500, 500, 500, 500, 800, 800, 1e3, 1e3, 1e3, 1e3, 1e3],
    moreGameArry: [{
        minImg: "https://www.baidu.com/images/tcsdzfk/more/01.png",
        gameImg: "https://www.baidu.com/images/recommend/hlfds.png",
        first_appid: "wxa6316ab52368d323",
        first_path: "/pages/index/index",
        envVersion: "trial"
    }],
    Game_Version: "1.0.0.17",
    appname: "tcsdzfk",
    title: "经典魔性贪吃蛇玩法，快来激情碰撞吧~",
    imageUrl: "https://www.baidu.com/images/tcsdzfk/share/01.png",
    tongjiHost: "https://www.baidu.com/wxgame/data/share.php?game_id=101",
    host: "https://www.baidu.com",
    channel: "201",
    gameID: "101",
    appid: "wx7434802ee11d3722",
    passBtnShowTime: 2,
    getDialogID: "050",
    dailyShareID: "051",
    fkShareID: "048",
    fkVideoId: "049",
    unLockSkinBtnShareID: "052",
    unLockSkinBtnVideoID: "053",
    fhFreeGoldShareID: "054",
    useSkillNotGoldShareID: "056",
    doubleGetGoldShareID: "055",
    FHShareID: "010",
    sceneShareID: "008",
    useHDShareID: "011",
    useKJDJShareID: "013",
    openPropBXShareID: "015",
    getNormalTimeSkinID: "016",
    getSpecialTimeSkinID: "018",
    showFDLineCount: 20
}, "title", null), n(i, "imageUrl", null), n(i, "banerAd", "adunit-16e41c45c6ad23ed"), n(i, "initData", function () {
    if (!this.firstLogin) {
        this.firstLogin = !0, Global.eleHidePosY = -cc.director.getWinSize().height / 2 - 200, Global.isMute = parseInt(Global.getData("music", 0)), Global.historyScore = parseInt(Global.getData("historyScore", 0)), Global.weekScore = parseInt(Global.getData("weekScore", 0)), Global.gold = parseInt(Global.getData("gold", 25)), Global.appRunTimes = parseInt(Global.getData("appRunTimes", 0)), Global.appRunTimes++, Global.saveData("appRunTimes", Global.appRunTimes), Global.playGameTimes = parseInt(Global.getData("playGameTimes", 0)), Global._shareTimes = 5, Global.oldPlayerDays = 5, Global.hbswitch = 1, Global.adswitch = 0;
        var e = cc.view.getFrameSize();
        console.log("frameSize w" + e.width + ", h" + e.height), e.height / e.width <= 2 ? e.width <= 320 && (Global.isSmallPhone = !0) : (cc.sys.os == cc.sys.OS_IOS && (console.log("苹果全面屏"), Global.isiPhoneFull = !0, Global.iPhoneFullAddH = Global.iPhoneFullAddH / (e.width / 720), console.log("iPhoneFullAddH" + Global.iPhoneFullAddH)), Global.adHeight = 250), Global.bannerHeight = Global.adHeight, Global.getLoginDays(), Global.loadSkinData(), this.initGuide();
        var t = this.getData("loginDay", -1);
        t = parseInt(t), Global.firslogin = !1;
        var o = new Date().getDay();
        if (-1 == t ? Global.firslogin = !0 : t >= 0 && t != o && (Global.firslogin = !0), Global.firslogin) {
            this.saveData("loginDay", o);
            this.saveData("shareGroups", JSON.stringify([]));
            var i = [];
            Global.wxGroupIds = i, this.saveData("wxGroupIds", JSON.stringify(i));
            var n = {};
            Global.cancelShare = n, this.saveData("cancelShare", JSON.stringify(n));
            var a = {};
            Global.videoTimes = a, this.saveData("videoTimes", JSON.stringify(a));
            this.saveData("shareids", JSON.stringify([])), this.saveData("yaoqing", 0), this.saveData("huanxing", 0), this.saveData("videoCount", 0);
        } else {
            var s = Global.getData("wxGroupId", "");
            "" == s || (Global.wxGroupIds = JSON.parse(s));
        }
        Global.loginIn();
    }
}), n(i, "loginIn", function () {
    wx.login({
        fail: function fail() {
            console.log("login fail");
        },
        success: function success(e) {
            Global.getSession(e.code, function () {
                var e = wx.getLaunchOptionsSync();
                console.log("login getLaunchOptionsSync res=" + JSON.stringify(e)), Global.firslogin && Global.postUserData(e), Global.onShow(e);
            });
        },
        complete: function complete() {
            console.log("login complete");
        }
    });
}), n(i, "getRand", function (e, t) {
    return Math.floor(Math.random() * (t + 1 - e) + e);
}), n(i, "saveData", function (e, t) {
    cc.sys.localStorage.setItem(e, t);
}), n(i, "setData", function (e, t) {
    cc.sys.localStorage.setItem(e, t);
}), n(i, "getData", function (e, t) {
    var o = cc.sys.localStorage.getItem(e);
    return o || 0 === o ? o : t;
}), n(i, "setIsShowNormalGuide", function (e) {
    Global.isShowNormalGuide = e, this.saveData("normalGuide", e);
}), n(i, "setPlayGameTimes", function (e) {
    Global.playGameTimes = e, Global.saveData("playGameTimes", Global.playGameTimes);
}), n(i, "initGuide", function () {
    Global.isShowNormalGuide = parseInt(Global.getData("normalGuide", 0)), Global.playGameTimes > 0 && this.setIsShowNormalGuide(1);
    var e = this.getData("Guide", "");
    this.guideData = e ? JSON.parse(e) : {
        zdGuide: 0,
        ctGuide: 0,
        wdGuide: 0,
        xhGuide: 0,
        hdGuide: 0,
        cdGuide: 0
    };
}), n(i, "setGuide", function () {
    this.saveData("Guide", JSON.stringify(this.guideData));
}), n(i, "loadSkinData", function () {
    var e = this.getData("skinData", "");
    this.skinData = e ? JSON.parse(e) : {
        select: 1,
        unLockList: [1]
    }, e = this.getData("sceneData", ""), this.sceneData = e ? JSON.parse(e) : {
        select: 1,
        unLockList: [1]
    }, (e = this.getData("boxData", "")) ? (this.boxData = JSON.parse(e), this.boxData.kaiJuDaoJu = 0) : this.boxData = {
        kaiJuDaoJu: 0,
        qiDongBaoXiang: 0
    }, (e = this.getData("TimeSkin", "")) ? (this.TimeSkinData = JSON.parse(e), this.checkTimeSkin()) : this.TimeSkinData = [], Global.getIsCanShow(this.skinData.select) || Global.setSelectIndex(1), e = this.getData("mainBoxData", ""), this.mainBoxData = e ? JSON.parse(e) : {
        ContentIndex: 0,
        btnContentIndex: 0
    };
}), n(i, "unLockSkin", function (e) {
    this.skinData.unLockList.push(e), this.saveSkinData();
}), n(i, "unLockScene", function (e) {
    this.sceneData.unLockList.push(e), this.saveSceneData();
}), n(i, "setSelectIndex", function (e) {
    this.skinData.select = e, this.saveSkinData();
}), n(i, "setSceneSelectIndex", function (e) {
    this.sceneData.select = e, this.saveSceneData();
}), n(i, "getIsCanShow", function (e) {
    if (!Global.isNormal) return !0;
    for (var t = [6, 7, 8, 9, 12, 13, 14], o = 0; o < t.length; o++) {
        if (t[o] == e) return !1;
    }return !0;
}), n(i, "getIsUnLockSkin", function (e, t) {
    for (var o = 0; o < this.skinData.unLockList.length; o++) {
        if (this.skinData.unLockList[o] == e) return !0;
    }if (!t) {
        this.checkTimeSkin();
        for (var i = 0; i < Global.TimeSkinData.length; i++) {
            if (Global.TimeSkinData[i].index == e) return !0;
        }
    }
    return !1;
}), n(i, "getRandUnLockSkin", function () {
    for (var e = [], t = 1; t <= 16; t++) {
        !this.getIsUnLockSkin(t, !0) && Global.getIsCanShow(t) && e.push(t);
    }return e.length <= 0 ? 0 : e[Math.floor(Math.random() * e.length)];
}), n(i, "addTimeSkin", function (e) {
    for (var t = 0; t < Global.TimeSkinData.length; t++) {
        if (Global.TimeSkinData[t].index == e) return;
    }
    var o = new Date().getTime();
    o += 18e5, Global.TimeSkinData.push({
        index: e,
        time: o
    }), this.saveData("TimeSkin", JSON.stringify(Global.TimeSkinData));
}), n(i, "getTimeSkinTime", function (e) {
    for (var t = 0; t < Global.TimeSkinData.length; t++) {
        if (Global.TimeSkinData[t].index == e) {
            var o = new Date().getTime(),
                i = Global.TimeSkinData[t].time;
            return i <= o ? 1 : Math.floor((i - o) / 1e3);
        }
    }return 0;
}), n(i, "checkTimeSkin", function () {
    for (var e = [], t = new Date().getTime(), o = !1, i = 0; i < Global.TimeSkinData.length; i++) {
        t >= Global.TimeSkinData[i].time ? (Global.skinData.select == Global.TimeSkinData[i].index && Global.setSelectIndex(1), o = !0) : e.push(Global.TimeSkinData[i]);
    }Global.TimeSkinData = e, o && this.saveData("TimeSkin", JSON.stringify(Global.TimeSkinData));
}), n(i, "getIsUnLockScene", function (e) {
    for (var t = 0; t < this.sceneData.unLockList.length; t++) {
        if (this.sceneData.unLockList[t] == e) return !0;
    }return !1;
}), n(i, "saveSkinData", function () {
    this.saveData("skinData", JSON.stringify(this.skinData));
}), n(i, "saveSceneData", function () {
    this.saveData("sceneData", JSON.stringify(this.sceneData));
}), n(i, "saveBoxData", function () {
    this.saveData("boxData", JSON.stringify(this.boxData));
}), n(i, "saveMainBoxData", function () {
    this.saveData("mainBoxData", JSON.stringify(this.mainBoxData));
}), n(i, "operateGold", function (e) {
    Global.gold += e, this.saveData("gold", Global.gold);
}), n(i, "setMute", function (e) {
    Global.isMute != e && (Global.isMute = e, Global.saveData("music", Global.isMute));
}), n(i, "isSameWeek", function (e, t) {
    var o = parseInt(e / 864e5),
        i = parseInt(t / 864e5);
    return parseInt((o + 3) / 7) === parseInt((i + 3) / 7);
}), n(i, "saveHistoryScore", function (e) {
    this.historyScore < e && (this.historyScore = e, this.saveData("historyScore", Global.historyScore));
}), n(i, "setWeekScore", function (e) {
    var t = parseInt(Global.getData("last_save_time", 0)),
        o = 0;
    if (o = parseInt(wx.getPerformance().now() / 1e3), !1 === this.isSameWeek(t, o) && (Global.weekScore = 0), !(e <= Global.weekScore)) {
        Global.weekScore = e, Global.saveData("weekScore", Global.weekScore), Global.saveData("last_save_time", o);
        var i = new Array();
        i.push({
            key: "score",
            value: "" + Global.weekScore
        }), wx.setUserCloudStorage({
            KVDataList: i,
            success: function success() {}
        });
    }
}), n(i, "getIsFirstUseHD", function () {
    return parseInt(Global.getData("FirstUseHD", 0));
}), n(i, "setIsFirstUseHD", function () {
    Global.setData("FirstUseHD", 1);
}), n(i, "getIsFirstUseKJDJ", function () {
    return parseInt(Global.getData("FirstUseKJDJ", 0));
}), n(i, "setIsFirstUseKJDJ", function () {
    Global.setData("FirstUseKJDJ", 1);
}), n(i, "getBlockColor", function (e) {
    return Global.colorArr[e];
}), n(i, "getisShowhddj", function (e) {
    if (!(e <= 0)) return (e - 1) % 2 == 0;
}), n(i, "getisShowkjsdj", function (e) {
    return !!Global.isShowNormalGuide && !(e <= 1) && (e - 2) % 3 == 0;
}), n(i, "getisShowqpzbx", function (e) {
    return !!Global.qpzbx && !(e < Global.qpzbx.start) && (0 == Global.qpzbx.interval || (e - Global.qpzbx.start) % (Global.qpzbx.interval + 1) == 0);
}), n(i, "getisShowqpztcspf", function (e) {
    return !!Global.qpztcspf && !(e < Global.qpztcspf.start) && (0 == Global.qpztcspf.interval || (e - Global.qpztcspf.start) % (Global.qpztcspf.interval + 1) == 0);
}), n(i, "getisShowqpztcsxypf", function (e) {
    return !!Global.qpztcsxypf && !(e < Global.qpztcsxypf.start) && (0 == Global.qpztcsxypf.interval || (e - Global.qpztcsxypf.start) % (Global.qpztcsxypf.interval + 1) == 0);
}), n(i, "getisShowSkill", function (e) {
    return !(e <= 0) && e % 4 == 0;
}), n(i, "getIsShowGold", function (e) {
    return !(e <= 0) && e % 10 == 0;
}), n(i, "getIsShowQpdj", function (e) {
    return !(e <= 0) && (e - 1) % 5 == 0;
}), n(i, "alertDialog", function (e, t) {
    var o = !1;
    void 0 != t && (o = !0), wx.showModal({
        title: "",
        content: "" + e,
        showCancel: o,
        fail: function fail() {
            console.log("show alertDialog fail");
        },
        success: function success(e) {
            void 0 != t && t(e);
        }
    });
}), n(i, "isNormalVersion", function (e) {
    var t = !1;
    if (1 == e.length && 0 == parseInt(e)) return t;
    var o = Global.Game_Version;
    o = o.split(".").join("");
    var i = e;
    i = i.split(".").join("");
    var n = o.length - i.length;
    if (n > 0) for (var a = 0; a < n; a++) {
        i += "0";
    } else if (n < 0) for (var s = 0; s < Math.abs(n); s++) {
        o += "0";
    }return console.log("服务器" + i), console.log("本地" + o), parseInt(o) >= parseInt(i) && (t = !0), t;
}), n(i, "ShareAppMessage", function () {
    return Global.getShare(), {
        title: Global.title,
        imageUrl: Global.imageUrl,
        query: "channel=" + Global.channel,
        success: function success(e) {
            console.log("转发按钮 shareAppMessage sucesss=" + JSON.stringify(e)), void 0 != e.shareTickets ? Global.getTongJi("001", 2) : Global.getTongJi("001", 1);
        }
    };
}), n(i, "shareGameOnly", function (e, t, o, i) {
    var n = Global.title;
    o && (n = o);
    var a = Global.imageUrl;
    i && (a = i), wx.shareAppMessage({
        title: n,
        imageUrl: a,
        query: "channel=" + Global.channel,
        success: function success(o) {
            console.log("shareGameOnly sucesss=" + JSON.stringify(o)), void 0 == o.shareTickets ? Global.getTongJi(e, 1) : Global.getTongJi(e, 2), t && t(o);
        }
    });
}), n(i, "shareGame", function (e, t, o, i) {
    var n = cc.loader.getXMLHttpRequest(),
        a = this.getData("unqid", ""),
        s = this.title;
    o && (s = o);
    var l = this.imageUrl;
    i && (l = i), n.onreadystatechange = function () {
        if (4 == n.readyState && n.status >= 200 && n.status < 400) {
            var o = n.responseText,
                i = JSON.parse(o);
            console.log("ticket=" + i.ticket + " ,name=" + i.name);
            var c = i.ticket;
            wx.shareAppMessage({
                title: s,
                imageUrl: l,
                query: "ticket=" + c + "&name=gold&unqid=" + a + "&channel=" + Global.channel,
                success: function success(o) {
                    console.log("shareAppMessage sucesss=" + JSON.stringify(o)), void 0 == o.shareTickets ? Global.getTongJi(e, 1) : Global.getTongJi(e, 2), t && t(o);
                }
            });
        }
    };
    var c = "https://www.baidu.com/gameconf/" + this.appname + "/wechatShareDaoju/gold/";
    n.open("GET", c, !0), n.send();
}), n(i, "qiuChaoyue", function (e, t) {
    var o = [];
    o.push("我获得了" + t + "分，快来挑战我吧！"), o.push("哈哈，一不小心我获得了" + t + "分，只求一败！"), o.push("这个" + t + "分数，让我想起一句话“无敌是多么寂寞“");
    var i = Math.floor(3 * Math.random());
    Global.shareGameOnly(e, void 0, o[i], ["https://www.baidu.com/images/tcsdzfk/share/10.png", "https://www.baidu.com/images/tcsdzfk/share/11.png", "https://www.baidu.com/images/tcsdzfk/share/12.png"][i]);
}), n(i, "getShareDaoju", function (e) {
    var t = this.getData("shareids", "");
    t = "" == t ? [] : JSON.parse(t);
    var o = e.unqid,
        i = e.name,
        n = !1,
        a = this.getData("unqid", "");
    if (o != a) {
        for (var s = 0; s < t.length; s++) {
            if (o + i == t[s]) {
                n = !0;
                break;
            }
        }if (!n) switch (console.log("unqid + daoju" + o + "_" + i), t.push(o + i), this.saveData("shareids", JSON.stringify(t)), e.name) {
            case "yaoqing":
                var l = e.name;
                Global.appRunTimes > 1 && (l = "huanxing");
                var c = cc.loader.getXMLHttpRequest(),
                    h = "https://www.baidu.com/gameconf/" + this.appname + "/wechatGetDaoju/" + e.ticket + "/" + l + "/?unqid=" + a + "&ounqid=" + o;
                c.open("GET", h, !0), c.send();
                break;

            case "gold":
                var r = cc.loader.getXMLHttpRequest(),
                    d = "https://www.baidu.com/gameconf/" + this.appname + "/wechatGetDaoju/" + e.ticket + "/" + e.name + "/?unqid=" + a + "&ounqid=" + o;
                r.open("GET", d, !0), r.send();
                break;

            case "freeBody":
                var u = cc.loader.getXMLHttpRequest(),
                    g = "https://www.baidu.com/gameconf/" + this.appname + "/wechatGetDaoju/" + e.ticket + "/" + e.name + "/?unqid=" + a + "&ounqid=" + o;
                u.open("GET", g, !0), u.send();
        }
    }
}), n(i, "onShow", function (e) {
    if (console.log("onshow====" + JSON.stringify(e)), void 0 != e.query.ticket) {
        var t = cc.loader.getXMLHttpRequest();
        t.onreadystatechange = function () {
            if (4 == t.readyState && t.status >= 200 && t.status < 400) {
                var o = t.responseText,
                    i = JSON.parse(o);
                i.ok ? Global.getShareDaoju(e.query) : Global.toast("道具超时啦,再赠送一次吧!"), console.log("get daoju = " + JSON.stringify(i));
            }
        };
        var o = Global.getData("unqid", ""),
            i = "https://www.baidu.com/gameconf/" + this.appname + "/wechatGetDaoju/" + e.query.ticket + "/" + e.query.name + "/?unqid=" + o;
        t.open("GET", i, !0), t.send();
    }
    this.getShare();
}), n(i, "splitParamToObject", function (e) {
    var t = e.split(";");
    return 2 == t.length ? {
        start: parseInt(t[0]),
        interval: parseInt(t[1])
    } : null;
}), n(i, "getYaoqingCount", function () {
    return parseInt(Global.getData("yaoqing", 0));
}), n(i, "getHuanxingCount", function () {
    return parseInt(Global.getData("huanxing", 0));
}), n(i, "getVideoCount", function () {
    return parseInt(Global.getData("videoCount", 0));
}), n(i, "setVideoCount", function (e) {
    Global.saveData("videoCount", e);
}), n(i, "getShare", function () {
    var e = cc.loader.getXMLHttpRequest();
    e.onreadystatechange = function () {
        if (4 == e.readyState && e.status >= 200 && e.status < 400) {
            var t = e.responseText,
                o = JSON.parse(t);
            Global.title ? Global.getWxShareTitle(Global.isNormal) : (Global.title = o.title, Global.imageUrl = o.imageUrl), Global.ipKey = o.ipKey, console.log("jsonobj.yaoqing" + JSON.stringify(o.yaoqing)), console.log("jsonobj.huanxing" + JSON.stringify(o.huanxing)), Global.banerAd = o.banerAd, console.log("jsonobj.banerAd" + JSON.stringify(o.banerAd));
            var i = 0;
            if (o.yaoqing.length > 0) {
                var n = Global.getYaoqingCount();
                if (n >= Global.yqMaxCount) return;
                var a = o.yaoqing.length;
                n + o.yaoqing.length >= Global.yqMaxCount && (a = Global.yqMaxCount - n), Global.operateGold(a * Global.yqGold), i = a, Global.saveData("yaoqing", n + a);
            }
            var s = 0;
            if (o.huanxing.length > 0) {
                var l = Global.getHuanxingCount();
                if (l >= Global.hxMaxCount) return;
                var c = o.huanxing.length;
                l + o.huanxing.length >= Global.hxMaxCount && (c = Global.hxMaxCount - l), Global.operateGold(c * Global.hxGold), s = c, Global.saveData("huanxing", l + c);
            }
            if (i > 0 || s > 0) {
                var h = "成功";
                i > 0 && (h += "邀请" + i + "玩家，"), s > 0 && (h += "唤醒" + s + "玩家，"), h += "获得" + (i * Global.yqGold + s * Global.hxGold) + "金币", Global.toast(h);
            }
            if (o.gold.length > 0 && (Global.operateGold(25 * o.gold.length), 1 == o.gold.length ? Global.toast("成功邀请1位玩家进入游戏，奖励你25个金币") : Global.toast("成功邀请" + o.gold.length + "位玩家进入游戏，奖励你25x" + o.gold.length + "个金币")), !Global.isGetConfig) {
                if (Global._shareTimes = o.shareN, console.log("oldPlayerDays", JSON.stringify(o.oldUser)), Global.oldPlayerDays = o.oldUser, console.log("jsonobj.adswitch" + o.adswitch), Global.adswitch = o.adswitch, console.log("jsonobj.hbswitch" + o.hbswitch), Global.hbswitch = o.hbswitch, console.log("jsonobj.qpzbx" + o.qpzbx), Global.qpzbx = Global.splitParamToObject(o.qpzbx), console.log("jsonobj.qpztcspf" + o.qpztcspf), Global.qpztcspf = Global.splitParamToObject(o.qpztcspf), console.log("jsonobj.qpztcsxypf" + o.qpztcsxypf), Global.qpztcsxypf = Global.splitParamToObject(o.qpztcsxypf), console.log("jsonobj.bannerTime" + o.bannerTime), void 0 != o.bannerTime && (Global.bannerTime = o.bannerTime), Global.isTestVer = Global.isNormalVersion(o.normalVer), Global.normalCity = o.normalCity, "" == Global.getData("IPAddr", "") && Global.getIPAddr(o.ip), Global.isTestVer) Global.isNormal = !0, Global.isFinishGetIp = !0;else {
                    var r = o.normalCity;
                    if (Global.normalCity = o.normalCity, r.length > 0) {
                        if ("0" == r[0]) Global.isNormal = !0;else {
                            var d = Global.getData("IPAddr", "");
                            "" == d ? Global.getIPAddr(o.ip) : (console.log("read save=" + d + ",=" + JSON.stringify(d) + ", [0]" + d[0] + ",[1]=" + d[1]), Global.isNormal = Global.checkNormal(d));
                        }
                    } else Global.isNormal = !0;
                }
                Global.isGetConfig = !0;
            }
        }
    };
    var t = Global.getData("unqid", ""),
        o = "https://www.baidu.com/gameconf/" + this.appname + "/wechatShare/?unqid=" + t;
    e.open("GET", o, !0), e.send();
}), n(i, "checkNormal", function (e) {
    if (Global.isTestVer) return Global.isFinishGetIp = !0, !0;
    for (var t = !1, o = 0; o < this.normalCity.length; o++) {
        for (var i = this.normalCity[o], n = 0; n < e.length; n++) {
            var a = e[n];
            if (-1 != a.indexOf(i)) {
                t = !0, console.log(a + "包含" + i);
                break;
            }
            if (-1 != i.indexOf(a)) {
                t = !0, console.log(i + "包含" + a);
                break;
            }
        }
    }return Global.isFinishGetIp = !0, Global.getWxShareTitle(t), t;
}), n(i, "getWxShareTitle", function (e) {
    var t = "true";
    t = e ? "true" : "false";
    var o = cc.loader.getXMLHttpRequest(),
        i = Global.host + "/gameconf/" + Global.appid + "/wxShareTitle/" + t + "/";
    o.onreadystatechange = function () {
        if (4 == o.readyState && o.status >= 200 && o.status < 400) {
            var e = o.responseText,
                t = JSON.parse(e);
            console.log("getWxShareTitle=" + JSON.stringify(t)), Global.title = t.title, Global.imageUrl = t.imageUrl;
        }
    }, o.open("GET", i, !0), o.send();
}), n(i, "getIPAddr", function (e) {
    var t = cc.loader.getXMLHttpRequest(),
        o = "https://baidu.com/ip/ip2addr?ip=" + e + "&key=" + Global.ipKey;
    t.onreadystatechange = function () {
        if (4 == t.readyState && t.status >= 200 && t.status < 400) {
            var e = t.responseText,
                o = JSON.parse(e);
            if (console.log("getIPAddr=" + JSON.stringify(o)), "0" == o.error_code) {
                var i = o.result.area;
                Global.saveData("IPAddr", [i]), Global.isNormal = Global.checkNormal([i]);
            }
        }
    }, t.open("GET", o, !0), t.send();
}), n(i, "getSession", function (e, t) {
    var o = cc.loader.getXMLHttpRequest(),
        i = "https://www.baidu.com/gameconf/" + Global.appname + "/wechatAccessAPI/session/";
    o.onreadystatechange = function () {
        if (4 == o.readyState && o.status >= 200 && o.status < 400) {
            var e = o.responseText,
                i = JSON.parse(e);
            if (console.log("getSession=" + JSON.stringify(i)), "0" == i.code) {
                var n = i.data.session_key,
                    a = i.data.openid;
                Global.session = n, Global.openId = a, Global.saveData("unqid", Global.openId), void 0 != t && t();
            }
        }
    }, o.open("POST", i, !0);
    var n = JSON.stringify({
        js_code: e
    });
    console.log("body=" + n), o.send(n);
}), n(i, "addShareGroup", function (e) {
    var t = Global.getData("shareGroups", "");
    (t = "" == t ? [] : JSON.parse(t)).push(e), Global.saveData("shareGroups", JSON.stringify(t));
}), n(i, "isShowVideoAD", function (e, t) {
    return Global.wxGroupIds.length >= Global.maxGroup || Global.getCancelShare(e) >= Global.maxCancel[0] || Global.getVideoTimes(e) > 0 && (t && Global.setVideoTimes(e), !0);
}), n(i, "addwxGroupId", function (e) {
    var t = Global.getData("wxGroupId", "");
    t = "" == t ? [] : JSON.parse(t);
    for (var o = 0; o < t.length; o++) {
        if (e == t[o]) return;
    }t.push(e), Global.wxGroupIds = t, this.saveData("wxGroupId", JSON.stringify(t));
}), n(i, "addVideoTimes", function (e) {
    if (!Global.isNormal) {
        var t = this.getData("videoTimes", "");
        (t = "" == t ? {} : JSON.parse(t))[e] = Global.maxCancel[1] - 1, Global.videoTimes = t, this.saveData("videoTimes", JSON.stringify(t));
    }
}), n(i, "getVideoTimes", function (e) {
    var t = this.getData("videoTimes", "");
    return void 0 != (t = "" == t ? {} : JSON.parse(t))[e] ? t[e] : 0;
}), n(i, "setVideoTimes", function (e) {
    var t = this.getData("videoTimes", "");
    void 0 != (t = "" == t ? {} : JSON.parse(t))[e] ? t[e] -= 1 : t[e] = 0, Global.videoTimes = t, this.saveData("videoTimes", JSON.stringify(t));
}), n(i, "addCancelShare", function (e) {
    if (!Global.isNormal) {
        var t = this.getData("cancelShare", "");
        void 0 != (t = "" == t ? {} : JSON.parse(t))[e] ? t[e] += 1 : t[e] = 1, Global.cancelShare = t, this.saveData("cancelShare", JSON.stringify(t));
    }
}), n(i, "getCancelShare", function (e) {
    var t = this.getData("cancelShare", "");
    return void 0 != (t = "" == t ? {} : JSON.parse(t))[e] ? t[e] : 0;
}), n(i, "resetCancelShare", function (e) {
    var t = this.getData("cancelShare", "");
    (t = "" == t ? {} : JSON.parse(t))[e], t[e] = 0, Global.cancelShare = t, this.saveData("cancelShare", JSON.stringify(t));
}), n(i, "isHaveShareGroup", function (e) {
    var t = Global.getData("shareGroups", "");
    t = "" == t ? [] : JSON.parse(t);
    for (var o = !1, i = 0; i < t.length; i++) {
        if (e == t[i]) {
            o = !0;
            break;
        }
    }return o;
}), n(i, "getDecryptData", function (e, t, o, i) {
    var n = cc.loader.getXMLHttpRequest(),
        a = "https://www.baidu.com/gameconf/" + Global.appname + "/wechatAccessAPI/decrypt/";
    n.onreadystatechange = function () {
        if (4 == n.readyState && n.status >= 200 && n.status < 400) {
            var e = n.responseText,
                t = JSON.parse(e);
            if (console.log("getDecryptData=" + JSON.stringify(t)), "0" == t.code) {
                var a = !1,
                    s = t.data.openGId + o.djName;
                o.djName && (a = Global.isHaveShareGroup(s)), Global.resetCancelShare(o.shareID), a ? Global.alertDialog("同个群一天只能分享一次哦~", function (e) {
                    e.confirm ? Global.actionShare(o, i) : i({
                        confirm: !1
                    });
                }) : (Global.addwxGroupId(t.data.openGId), o.djName && Global.addShareGroup(s), void 0 != o.toast && Global.toast(o.toast), Global.getTongJi(o.shareID, 2), void 0 != i && i({
                    confirm: !0
                }));
            }
        }
    }, n.open("POST", a, !0);
    var s = JSON.stringify({
        sessionKey: Global.session,
        iv: t,
        encryptedData: e
    });
    console.log("body=" + s), n.send(s);
}), n(i, "checkShareGroup", function (e, t, o) {
    var i = this;
    wx.getShareInfo({
        shareTicket: e[0],
        success: function success(e) {
            i.getDecryptData(e.encryptedData, e.iv, t, o), console.log("getShareInfo sucess res=" + JSON.stringify(e));
        }
    });
}), n(i, "alertGameDialog", function (e) {
    wx.showModal({
        title: "温馨提示",
        content: "" + e,
        showCancel: !0,
        fail: function fail() {},
        success: function success(e) {
            e.confirm ? Global.actionShare(Global.shareobj, Global.callBack) : void 0 != Global.callBack && Global.callBack({
                confirm: !1
            });
        }
    });
}), n(i, "alertGameDialog2", function (e) {
    Global.getTongJi(Global.getDialogID, 2), wx.showModal({
        title: "领取奖励",
        content: "分享到微信群即可获得奖励，领取奖励吗？",
        cancelText: "放弃奖励",
        confirmText: "领取奖励",
        showCancel: !0,
        fail: function fail() {},
        success: function success(t) {
            t.confirm ? void 0 != e && e({
                confirm: !0
            }) : void 0 != e && e({
                confirm: !1
            });
        }
    });
}), n(i, "actionShare", function (e, t) {
    var o = e.query;
    o && 0 != o.length ? o += "&channel=" + Global.channel : o += "channel=" + Global.channel, Global.haveShare = !0, Global.callBack = t, Global.shareobj = e, Global.shareStartTime = new Date().getTime(), Global.shareCancel = !1, wx.shareAppMessage({
        title: e.title,
        imageUrl: e.imageUrl,
        query: o,
        fail: function fail() {},
        success: function success(e) {},
        cancel: function cancel() {
            Global.shareCancel = !0;
        }
    });
}), n(i, "actionShare2", function (e, t, o) {
    Global.actionShare({
        title: Global.title,
        imageUrl: Global.imageUrl,
        query: "",
        shareID: e
    }, function (i) {
        if (i.confirm) {
            if (Global.getIsMustFailed(e)) return void Global.alertGameDialog("分享失败，请分享到不同的群");
            t && t(null), Global.getTongJi(e, 2), Global.addShareTimes(e);
        } else o && o(null);
    });
}), n(i, "shareGame2", function (e, t) {
    var o = cc.loader.getXMLHttpRequest(),
        i = this.getData("unqid", ""),
        n = e.propName;
    o.onreadystatechange = function () {
        if (4 == o.readyState && o.status >= 200 && o.status < 400) {
            var a = o.responseText,
                s = JSON.parse(a).ticket;
            e.query = "ticket=" + s + "&name=" + n + "&unqid=" + i, Global.actionShare(e, t);
        }
    };
    var a = "https://www.baidu.com/gameconf/" + this.appname + "/wechatShareDaoju/" + n + "/";
    o.open("GET", a, !0), o.send();
}), n(i, "toast", function (e) {
    cc.loader.loadRes("toast/toast", function (t, o) {
        var i = cc.director.getScene().getChildByName("toastNode");
        i && i.destroy(), (i = cc.instantiate(o)).name = "toastNode";
        var n = i.getChildByName("text").getComponent(cc.Label);
        i.getComponent(cc.Widget).bottom = .5, n.string = e;
        var a = [],
            s = cc.fadeIn(.2),
            l = cc.fadeOut(.3),
            c = cc.delayTime(2),
            h = cc.removeSelf();
        a.push(s), a.push(c), a.push(l), a.push(h), i.runAction(cc.sequence(a)), i.zIndex = 1e4, cc.director.getScene().addChild(i);
    });
}), n(i, "getTongJi", function (e, t) {
    var o = cc.loader.getXMLHttpRequest();
    o.onreadystatechange = function () {
        if (4 == o.readyState && o.status >= 200 && o.status < 400) {
            var e = o.responseText;
            console.log("http getTongJi = " + e);
        }
    };
    var i = Global.tongjiHost + "&share_id=" + e + "&share_type=" + t;
    console.log("getTongyi url=" + i), o.open("GET", i, !0), o.send();
}), n(i, "gotoMiniGame", function () {
    var e = !1,
        t = wx.getSystemInfoSync();
    if (t) {
        var o = t.version.split(".");
        console.log("curent version = " + o);
        for (var i = [6, 6, 7], n = 0; n < o.length; n++) {
            if (parseInt(o[n]) > i[n]) {
                e = !0;
                break;
            }
            if (parseInt(o[n]) !== i[n]) {
                e = !1;
                break;
            }
            e = !0;
        }
    }
    var a = Global.moreGameArry[0];
    e ? wx.navigateToMiniProgram({
        appId: "wxa6316ab52368d323",
        path: " ?channel=" + Global.channel,
        extraData: {
            second_appid: a.second_appid,
            second_path: a.second_path,
            channel: Global.channel
        },
        envVersion: a.envVersion,
        success: function success() {},
        fail: function fail() {},
        complete: function complete() {}
    }) : wx.previewImage({
        urls: [a.gameImg],
        success: function success(e) {}
    });
}), n(i, "closeBanner", function () {
    void 0 != Global.bannerGame && Global.bannerGame.hide();
}), n(i, "showBannerId", function (e, t) {
    var o = Global.banerAd,
        i = new Date().getTime();
    if (i - Global.lastShowBannerTime < 1e3 * Global.bannerTime) Global.bannerGame && Global.bannerGame.show();else {
        console.log("刷新广告"), Global.lastShowBannerTime = i, Global.bannerType = e;
        var n = wx.getSystemInfoSync(),
            a = Global.adHeight;
        void 0 != this.bannerGame && (this.bannerGame.destroy(), this.bannerGame = void 0);
        var s = n.windowWidth;
        Global.isiPhoneFull || (s = .8 * n.windowWidth);
        var l = wx.createBannerAd({
            adUnitId: o,
            style: {
                left: 0,
                top: n.windowHeight - a,
                width: s
            }
        }),
            c = this;
        l.onError(function () {
            Global.lastShowBannerTime = 0, c.scheduleOnce(function () {
                c.showBannerId(1);
            }, 10), console.log("bannerAd 打开失败！");
        }), l.onResize(function (e) {
            l.style.left = (n.windowWidth - e.width) / 2;
            var t = n.windowWidth / 720,
                o = e.height,
                i = e.height;
            Global.isiPhoneFull && (i += 15), l.style.top = n.windowHeight - i, o = i / t, Global.bannerHeight = o + 40, console.log("game 广告size=" + JSON.stringify(e) + "resouH=" + o);
        }), l.show(), this.bannerGame = l;
    }
}), n(i, "showVideoAD", function (e, t, o) {
    Global.VideoCallBack = e, Global.VideoShareID = t, Global.VideoCancelBack = o, Global.showVideoADError = !1, Global.showLoadingDialog(), Global.videoAd || (Global.videoAd = wx.createRewardedVideoAd({
        adUnitId: "adunit-b89cdda9432a10f6"
    }), Global.videoAd.onClose(function (e) {
        var t = !1;
        (void 0 == e ? (void 0 != Global.VideoCallBack && Global.VideoCallBack(), Global.getTongJi(Global.VideoShareID, 1), t = !0) : e.isEnded && (Global.getTongJi(Global.VideoShareID, 1), void 0 != Global.VideoCallBack && Global.VideoCallBack(), t = !0), t || void 0 == Global.VideoCancelBack || Global.VideoCancelBack(), Global.isPlayVideoAD) && (Global.isPlayVideoAD = !1, cc.find("AudioManager").getComponent("AudioManager").playBgMusic());
    }), Global.videoAd.onError(function (e) {
        console.log(e), Global.showVideoADError = !0, void 0 != Global.VideoCancelBack && (Global.toast("打开视频广告失败!"), Global.VideoCancelBack());
    })), Global.videoAd.load().then(function () {
        Global.videoAd.show(), Global.closeLoadingDialog();
    }).catch(function (e) {
        console.log("video " + e.errMsg), Global.closeLoadingDialog(), Global.toast("打开视频广告失败!"), Global.showVideoADError = !0, void 0 != Global.VideoCancelBack && Global.VideoCancelBack();
    }), Global.isPlayVideoAD || cc.find("AudioManager").getComponent("AudioManager").stopAllAudio(), Global.isPlayVideoAD = !0;
}), n(i, "postUserData", function (e) {
    var t = "",
        o = "0";
    e.query && e.query.channel && (t = e.query.channel) == Global.channel && (o = "1"), e.referrerInfo && e.referrerInfo.extraData && (t = e.referrerInfo.extraData.channel || t);
    var i = Global.host + "/wxgame/data/userData.php?openid=" + Global.openId + "&channel=" + t + "&isSession=" + o + "&gameID=" + Global.gameID;
    console.log("post user data url =" + i);
    var n = cc.loader.getXMLHttpRequest();
    n.onreadystatechange = function () {
        if (4 == n.readyState && n.status >= 200 && n.status < 400) {
            var e = n.responseText;
            console.log("postUserData response = " + e);
        }
    }, n.open("GET", i, !0), n.send();
}), n(i, "goToFanJu", function () {
    var e = !1,
        t = wx.getSystemInfoSync();
    if (t) {
        var o = t.version.split(".");
        console.log("curent version = " + o);
        for (var i = [6, 6, 7], n = 0; n < o.length; n++) {
            if (parseInt(o[n]) > i[n]) {
                e = !0;
                break;
            }
            if (parseInt(o[n]) !== i[n]) {
                e = !1;
                break;
            }
            e = !0;
        }
    }
    e ? wx.navigateToMiniProgram({
        appId: "wx561fbf1eb92d5541",
        path: "",
        extraData: {},
        success: function success() {},
        fail: function fail() {},
        complete: function complete() {}
    }) : (console.log("========低于6.6.7显示大图扫描二维码======="), wx.previewImage({
        urls: [Global.host + "/images/recommend/big/02.png"],
        success: function success(e) {}
    }));
}), n(i, "curDaoName", function () {
    return "" + this._pad2(this.curDao + 1, 2);
}), n(i, "daoName", function (e) {
    return "" + this._pad2(e + 1, 2);
}), n(i, "_pad2", function (e, t) {
    return (e + "").length >= t ? "" + e : this._pad2("0" + e, t);
}), n(i, "btnAction", function (e) {
    if (e.active) {
        e.stopAllActions(), e.scale = 1;
        e.runAction(cc.repeatForever(cc.sequence(cc.scaleTo(.8, 1.1), cc.scaleTo(.8, 1))));
    }
}), n(i, "getIsShowVideo", function (e) {
    if (this.isNormal || this._shareTimes <= 0) return !0;
    var t = this.getData("shareTime", "");
    return console.log("shareTime" + t), "" != t && void 0 != (t = JSON.parse(t))[e] && (new Date().getTime() - t[e].startTime > 36e5 ? (t[e] = void 0, console.log("重置" + JSON.stringify(t)), this.saveData("shareTime", JSON.stringify(t)), !1) : !(t[e].times < this._shareTimes));
}), n(i, "getisShowVideo2", function (e) {
    var t = this.getIsShowVideo(e);
    return !t && this.isOldPlayer() && (t = !0), t;
}), n(i, "getShareTimes", function (e) {
    var t = this.getData("shareTime", "");
    return "" == t ? 0 : void 0 != (t = JSON.parse(t))[e] ? t[e].times : 0;
}), n(i, "addShareTimes", function (e) {
    if (!this.isNormal) {
        console.log("addShareTimes" + e);
        var t = this.getData("shareTime", "");
        if (void 0 != (t = "" == t ? {} : JSON.parse(t))[e]) t[e].times += 1;else {
            var o = new Date().getTime();
            t[e] = {
                times: 1,
                startTime: o
            };
        }
        this.saveData("shareTime", JSON.stringify(t));
    }
}), n(i, "getLoginDays", function () {
    Global.loginInDays = 1;
    var e = parseInt(this.getData("firstLoginTime", 0));
    0 == e && (e = new Date().getTime(), Global.setData("firstLoginTime", e));
    var t = Math.floor(e / 864e5),
        o = Math.floor(new Date().getTime() / 864e5);
    o > t && (Global.loginInDays += o - t), console.log("loginInDays " + Global.loginInDays);
}), n(i, "getIsMustFailed", function (e) {
    var t = this.getData("failedShareTime", "");
    console.log("failedShareTime" + t), t = "" == t ? {} : JSON.parse(t);
    var o = new Date().getTime();
    if (void 0 != t[e]) {
        if (o - t[e].startTime < 432e5) return !1;
    } else t[e] = {
        startTime: o
    };
    return t[e].startTime = o, this.setData("failedShareTime", JSON.stringify(t)), !0;
}), n(i, "showLoadingDialog", function () {
    wx.showLoading({
        title: "加载中...."
    });
}), n(i, "closeLoadingDialog", function () {
    wx.hideLoading();
}), n(i, "getIsShowStartFD", function () {
    return !!Global.canshowHB() && !Global.haveMaxHBCount() && (Global.appRunTimes - 1) % 2 == 0;
}), n(i, "isOldPlayer", function () {
    return (Global.loginInDays >= Global.oldPlayerDays || Global.showVideoADError) && !Global.isNormal;
}), n(i, "getRand", function (e, t) {
    return Math.floor(Math.random() * (t + 1 - e) + e);
}), n(i, "getHBCount", function () {
    return parseInt(Global.getData("HB_COUNT", "0"));
}), n(i, "setHbCount", function (e) {
    var t = this.getHBCount();
    (t += e) >= 1900 && (t = 1900), Global.setData("HB_COUNT", t);
}), n(i, "isFirstOpenGameHb", function () {
    return parseInt(Global.getData("FirstOpenGameHb", "0"));
}), n(i, "setIsFirstOpenGameHb", function () {
    Global.setData("FirstOpenGameHb", 1);
}), n(i, "getRandHbCount", function () {
    return this.getHBCount() <= 0 ? this.getRand(150, 250) : this.getHBCount() <= 1e3 ? this.getRand(10, 200) : this.getHBCount() <= 1500 ? Math.random() <= .7 ? this.getRand(1, 50) : this.getRand(50, 100) : this.getHBCount() <= 1800 ? Math.random() <= .8 ? this.getRand(1, 50) : this.getRand(50, 100) : 1;
}), n(i, "canshowHB", function () {
    return Global.hbswitch && !Global.isNormal;
}), n(i, "getDLQ", function () {
    return Global.getData("DLQ_FB", "");
}), n(i, "setDLQ", function (e) {
    Global.setData("DLQ_FB", e);
}), n(i, "haveMaxHBCount", function () {
    return !(this.getHBCount() < 1800);
}), i);

cc._RF.pop();
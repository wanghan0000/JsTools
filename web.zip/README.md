# Arco Design Pro

## 快速开始

```
// 初始化项目
npm install

// 开发模式
npm run start

// 构建
npm run build


```
打包更新说明
```
打包之前请先修改`package.json`文件中的版本号： `version`
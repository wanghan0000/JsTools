import './index.less';
import classNames from 'classnames';
import React, { memo } from 'react';
import BonusItem from '../BonusItem/BonusItem';
import ActivityItem from './ActivityItem/ActivityItem';
import { useActivityEntryPlus } from '@/store/home';
import useDialogManager from '@/utils/useDialogManager';
import { useTranslationPlus } from '@/Core/i18n/useTranslationPlus';
import { useLocation } from 'react-router';
import { useGlobalState, useMobileLeftSiderSwitch } from '@/store/commonStore';
import { useWsUpdateBouns } from '@/store/hallSocket';
import {useBeforeSetting} from "@/store/beforeSetting";

const Activity = (props) => {
  const { className, collapsed } = props;
  const prefixCls = 'activity';
  const { t } = useTranslationPlus('BonusView');
  const { data } = useActivityEntryPlus();
  const { farm, rebate, turntable } = data || {};
  const { openBetting, openFarm, openInviteElement,openInviteFriends, openTaskCenter, openWheel } = useDialogManager();
  const { pathname } = useLocation();
  const [drawerVisible, setDrawerVisible] = useMobileLeftSiderSwitch();
    const { data:sitting} = useBeforeSetting()

  return (
    <div className={classNames([`${prefixCls}`, className])}>
      <BonusItem className={`${prefixCls}-bonus`} isSelect={pathname === '/bonus'} />
      <div className={`${prefixCls}-items`}>
        {(
          <ActivityItem
            collapsed={collapsed}
            icon={<img src={require(`@/assets/image/bonus/jlzx_icon_rw.webp`)} />}
            title={t('TaskCenter')}
            className={'activity-item task'}
            onClick={() => {
              setDrawerVisible(false);
              openTaskCenter();
            }}
          />
        )}
        {rebate && turntable.isOpen && (
          <ActivityItem
            collapsed={collapsed}
            icon={<div className="image-span"></div>}
            title={t('LuckySpin')}
            className={'activity-item turntable'}
            onClick={() => {
              openWheel();
              setDrawerVisible(false);
            }}
          />
        )}

        {farm && farm.isOpen && (
          <ActivityItem
            collapsed={collapsed}
            icon={<img src={require(`@/assets/image/bonus/jlzx_icon_tree.webp`)} />}
            title={t('MoneyFarm')}
            className={'activity-item farm'}
            onClick={() => {
              openFarm();
              setDrawerVisible(false);
            }}
          />
        )}
        {turntable && rebate.isOpen && (
          <ActivityItem
            collapsed={collapsed}
            icon={<img src={require(`@/assets/image/home/pig_icon.png`)} />}
            title={t('RebateBet')}
            className={'activity-item rebate'}
            onClick={() => {
              openBetting();
              setDrawerVisible(false);
            }}
          />
        )}
      </div>
      <ActivityItem
        collapsed={collapsed}
        icon={<img src={require(`@/assets/image/home/iconjinbi.png`)} />}
        title={t('Invite')}
        className={'invate-friends'}
        onClick={() => {
            if(sitting && sitting.inviteSwitch){
                openInviteFriends()
            } else {
                openInviteElement();
            }
          setDrawerVisible(false);
        }}
      />
    </div>
  );
};
export default memo(Activity);

import './index.less'
import classNames from "classnames";
import React, { MouseEventHandler, ReactNode } from "react";

export interface ActivityItemProps {
    className?: string;
    title?: string;
    icon?: ReactNode;
    onClick?: MouseEventHandler<any> | undefined;
    collapsed?: boolean
}

const ActivityItem = (props: ActivityItemProps) => {
    const { className, title, icon, onClick ,collapsed} = props;
    const prefixCls = 'activity-menu-item';

    return (<div className={classNames([prefixCls, className , collapsed ? `${prefixCls}-collapsed` : ''])} onClick={onClick}>
        <div className={`${prefixCls}-item`}>
            <div className="item-left">
                {icon}
            </div>
            <div className={classNames(["item-right", collapsed ? 'collapsed' : ''])}>
                <p>{title}</p>
            </div>
        </div>
    </div>)
}

export default ActivityItem
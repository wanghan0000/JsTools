import './index.less';
import { Jlzx } from '@/assets/svg-icon';
import classNames from 'classnames';
import React from 'react';
import { Badge } from '@arco-design/web-react';
import { useTranslationPlus } from '@/Core/i18n/useTranslationPlus';
import { useNavigate } from 'react-router';
import { useGlobalState, useMobileLeftSiderSwitch } from '@/store/commonStore';
import useDialogManager from '@/utils/useDialogManager';
import { useActivityEntryPlus } from '@/store/home';

const BonusItem = (props) => {
  const { className, isSelect } = props;
  const prefixCls = 'bonus-menu-item';
  const { t } = useTranslationPlus('HomeView');
  const navigate = useNavigate();
  const { isLogin } = useGlobalState();
  const { openSignIn } = useDialogManager();
  const [drawerVisible, setDrawerVisible] = useMobileLeftSiderSwitch();

  const { data } = useActivityEntryPlus();

  return (
    <div
      className={classNames([prefixCls, className, isSelect ? `${prefixCls}-check` : ''])}
      onClick={() => {
        setDrawerVisible(false);
        if (isLogin) {
          navigate('/bonus');
        } else {
          openSignIn();
        }
      }}
    >
      {/* <div className={`${prefixCls}-item ${prefixCls}-tigger`}> */}
      <Badge count={data?.giftBagStatus ? 1 : 0} dot className={`${prefixCls}-item ${prefixCls}-tigger`}>
        <div className="item-left">{<Jlzx />}</div>
        <div className="item-right">
          <span>{t('Bonus')}</span>
        </div>
      </Badge>
      {/* </div> */}
    </div>
  );
};

export default BonusItem;

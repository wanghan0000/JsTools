import '@/style/global.less';
import '@/style/animation.less';
import React, { useEffect, useRef } from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import { SWRConfig } from 'swr';
import { setDialogRef } from './utils/useDialog';
import { register } from './serviceWorkerRegistration';
import EventMgr from './utils/EventMgr';
import { EventName } from './api/event/common';
import NiceModal from '@ebay/nice-modal-react'
import DialogPlus, { DialogPlusRef } from './componentsUI/Dialog/dialogPlus';
import { bindEnterKeyToButton, restrictTabToInputs } from './Core/utils';
import { sys } from './Core/utils/system';
import { AliveScope } from 'react-activation';

function Index() {
  /** 弹窗中心初始化 */
  const ref = useRef<DialogPlusRef>(null);
  useEffect(() => {
    setDialogRef(ref);
  }, []);

  useEffect(() => {
    sys.token = localStorage.getItem('authToken')
    /**删除html-loading */
    // const Loading = document.getElementById('Loading');
    // Loading.parentNode.removeChild(Loading)
    // setTimeout(() => {
    //   const elementLoading = document.getElementById('start-loading');
    //   document.body.removeChild(elementLoading);
    // }, 1000)

    /**前后台事件 */
    const handleVisiblity = () => {
      if (document.visibilityState == 'visible') {
        EventMgr.getInstance().dispatchEvent(EventName.EnterForeGround);
      } else {
        EventMgr.getInstance().dispatchEvent(EventName.EnterBackGround);
      }
    };
    const handleMouseEnter = () => {
      EventMgr.getInstance().dispatchEvent(EventName.EnterForeGround);
    };
    document.addEventListener('visibilitychange', handleVisiblity);
    document.addEventListener('mouseenter', handleMouseEnter);
    document.addEventListener('mousedown', handleMouseEnter);
    restrictTabToInputs()
    bindEnterKeyToButton()
    return () => {
      document.removeEventListener('visibilitychange', handleVisiblity);
      document.removeEventListener('mouseenter', handleMouseEnter);
      document.removeEventListener('mousedown', handleMouseEnter);
    };

  }, []);

  return (
    <BrowserRouter>
      <AliveScope>
        <SWRConfig
          value={{
            //默认缓存有效期
            dedupingInterval: 24 * 60 * 60 * 1000,
            //错误后自动请求间隔
            errorRetryInterval: 1000,
            //错误后自动重试次数
            errorRetryCount: 1,
            revalidateOnFocus: false,
            shouldRetryOnError: false,
          }}
        >
          <NiceModal.Provider>
            <DialogPlus ref={ref} />
            <App />
          </NiceModal.Provider>
        </SWRConfig>
      </AliveScope>
    </BrowserRouter>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<Index />);
if (!sys.isNative) {
  register();
}


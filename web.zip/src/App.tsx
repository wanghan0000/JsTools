import React, { useEffect, useState } from 'react';
import PageLayout from '@/layout';
import './Core/i18n';

import { useBeforeSetting } from './store/beforeSetting';
// import CommonEventCompoent from './components/commonEventCompoent/CommonEventCompoent';
// import WebSocketCompoent from './components/webSocket/WebSocketCompoent';
import { useGlobalState } from './store/commonStore';

import { useTranslation } from 'react-i18next';
import CommonEventCompoent from './components/commonEventCompoent/CommonEventCompoent';
import WebSocketCompoent from './components/webSocket/WebSocketCompoent';
import LoadingUI from './componentsUI/LoadingUI/LoadingUI';
import SwiperCore from 'swiper';
import { Virtual, Navigation, Pagination } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';
import { useWalletAll } from './store/walletStore';
SwiperCore.use([Virtual, Navigation, Pagination]);

/**进入界面之前需要的数据准备 */
const useAppEnterBefore = () => {
  const { error, data, mutate } = useBeforeSetting();
  const { mutate: walletMutate, isLoading: walletLoading } = useWalletAll(false);
  //const walletLoading = false;
  const { isLogin } = useGlobalState();
  const [loading, setLoading] = useState(true);

  const { ready } = useTranslation();
  useEffect(() => {
    if (isLogin) {
      walletMutate();
    }
  }, [isLogin]);

  useEffect(() => {
    if (!walletLoading && (data || error) && ready) {
      setLoading(false);
    }
  }, [walletLoading, data, ready, error]);

  const muateFunc = () => {
    setLoading(true);
    mutate();
  }

  return {
    loading,
    error,
    data,
    mutate: muateFunc,
  };
};


const App = () => {
  const { loading, error, data, mutate } = useAppEnterBefore();

  const removeLoading = ()=>{
    setTimeout(()=>{
      const Loading = document.getElementById('Loading');
      if(Loading) {
        Loading.parentNode.removeChild(Loading)
        const elementLoading = document.getElementById('start-loading');
        document.body.removeChild(elementLoading);
      }
    },500)
  }

  useEffect(() => {
    if (!loading && !error && data) {
      removeLoading()
    }else if(error) {
      removeLoading()
    }
  }, [loading, error, data])

  return (
    <>
      <LoadingUI
        isLoading={loading}
        error={error}
        dataList={data}
        retryFunc={mutate}
        style={{ height: '100vh' }}
        btnText={'Retry'}
        errorText={'Loading Error,Please Retry!'}
      >
        <PageLayout />
        {/**处理公共自定义事件中心 */}
        <CommonEventCompoent />
        {/**处理socket 断线及链接 */}
        <WebSocketCompoent />
      </LoadingUI>
    </>
  );
};
export default App;

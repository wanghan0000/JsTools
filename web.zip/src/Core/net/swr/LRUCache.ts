﻿
export interface LRUConfig {
    //缓存有效时间 0则永久缓存 默认值0  单位毫秒
    ttl?: number
}

export interface IFLRUCache {
    // 获取数据
    get: (key: string) => any;

    // 放入数据
    put: (key: string, value: any, config?: LRUConfig) => void;

    // 清理所有数据
    clearAll: () => void;

    // 清理指定数据
    clear: (key: string[] | string) => void;
}

export class LRUCache implements IFLRUCache {
    //缓存数据
    private cache: Map<any, any>;

    constructor() {
        this.cache = new Map()
    }
    get(key: string) {
        if (!this.cache.has(key)) {
            return undefined;
        }
        const entry = this.cache.get(key);
        const currentTime = new Date().getTime();
        if(currentTime - entry.timeStamp <= entry.ttl) {
            return entry.value;
        }
        this.cache.delete(key)
        return undefined;
    }
    put(key: string, value: any, config?: LRUConfig) {
        const currentTime = new Date().getTime();
        const entry = { value , timeStamp: currentTime, ttl: config?.ttl || 0}
        if(this.cache.has(key)) {
            this.cache.delete(key);
        }
        this.cache.set(key,entry)
    }
    clearAll() {
        this.cache.clear()
    }
    clear(key: string | string[]) {
        if(typeof key === 'string') {
            if(this.cache.has(key)){
                this.cache.delete(key)
            }
        }else if(Array.isArray(key)){
            for(let i = 0 ; i < key.length ; ++i) {
                this.clear(key[i]);
            }
        }
    }
}
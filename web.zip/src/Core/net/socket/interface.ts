export interface BaseWsData<T> {
    /**指令 */
    cmd: number;

    /**响应码 */
    code: number;

    /**数据包 */
    data: T;

    /**错误消息 */
    msg: string;
}
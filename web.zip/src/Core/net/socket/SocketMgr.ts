/* eslint-disable */
import { Lobby } from "@/proto/Lobby";
import { SocketDataTool, UnpackData } from "./SocketDataTool";
import { SocketPackTool } from "./SocketPackTool";
import { BaseWsData } from "./interface";

const HeartbeatInterval = 10;                // socket 心跳间隔时间
const HeartbeatTimeout = 120;                // socket 心跳超时时间
const HeartbeatCheckInterval = 10 * 1000;    // socket 心跳验证间隔时间

//是否加密
const IsEncode = false;

export class SocketMgr {
    private static instance: SocketMgr | undefined;

    private socket: WebSocket | undefined = undefined;
    private dataTool: SocketDataTool | undefined = undefined;

    // 外部处理回调
    public onOpenCallback: any | undefined = undefined;
    public onCloseCallback: any | undefined = undefined;
    public onErrorCallback: any | undefined = undefined;
    public onMessageCallback: any | undefined = undefined;
    public onSuccess: any | undefined = undefined;

    // socket心跳配置
    private heartbeatLastTS: number | undefined = undefined;                // socket 最后一次心跳时间
    private heartbeatTimerHandle: number | undefined = undefined;           // 心跳计时器句柄

    /**
     * 连接Socket: ws://127.0.0.1:8001
     *
     * @param ip
     * @param port
     */
    public static connect(ip: string,
        openCall?: any, closeCall?: any, errorCall?: any, messageCall?: any, success?: any): boolean {

        console.log("SocketMgr.connect", ip);
        if (SocketMgr.instance !== undefined) {
            console.log("Warn: SocketMgr.connect socket in connect !!!");
            return false;
        }

        const instance = new SocketMgr();
        const socket = instance.connectWebSocket(ip);
        if (undefined === socket) {
            return false;
        }

        SocketMgr.instance = instance;

        instance.socket = socket;
        // 增加回调
        instance.onOpenCallback = openCall;
        instance.onCloseCallback = closeCall;
        instance.onErrorCallback = errorCall;
        instance.onMessageCallback = messageCall;
        instance.onSuccess = success;
        // 增加数据包工具
        instance.dataTool = new SocketDataTool();

        return true;
    }

    /**
     * 关闭 socket
     */
    public static close(): void {
        let instance = SocketMgr.instance;
        if (undefined === instance) {
            return;
        }

        const onCloseCallback = instance.onCloseCallback;

        // 先清理回调
        instance.onOpenCallback = undefined;
        instance.onCloseCallback = undefined;
        instance.onErrorCallback = undefined;
        instance.onMessageCallback = undefined;

        if (instance.heartbeatTimerHandle !== undefined) {
            clearInterval(instance.heartbeatTimerHandle);
        }
        instance.heartbeatTimerHandle = undefined;
        if (instance !== undefined && instance.socket !== undefined) {
            instance.socket.close(1000, "Client active close !");
        }

        if (onCloseCallback !== undefined) {
            onCloseCallback();
        }
        SocketMgr.instance = undefined;
    }

    /**
     * socket 发送消息
     *
     * @param id
     * @param pack
     * @param bIsCheck
     */
    public static send(packetId: number, pack: any): void {
        const instance = SocketMgr.instance;
        if (undefined === instance) {
            console.log("Warn: SocketMgr.send: socket not connect, send failed !!!");
            return;
        }
        instance.sendPack(packetId, pack);
    }

    /**
     * 发送Ping
     */
    public static sendPing(): void {
        SocketMgr.send(Lobby.LobbyPacketID.PACKET_RQ_PING, {});
    }

    private connectWebSocket(host: string): WebSocket | undefined {
        // 创建 Socket
        try {
            const socket = new WebSocket(host);
            socket.binaryType = "arraybuffer"
            socket.onopen = this.onOpen.bind(this);
            socket.onclose = this.onClose.bind(this);
            socket.onerror = this.onError.bind(this);
            socket.onmessage = this.onMessage.bind(this);
            return socket;
        } catch (error: any) {
            console.log("Error: SocketMgr.connect socket create failed !!!");
            return undefined;
        }
    }

    private onOpen(event: Event): void {
        console.log("Info: SocketMgr socket onOpen !!!", event);

        this.startHeartCheck();

        if (this.onOpenCallback) {
            this.onOpenCallback();
        }
    }

    private onClose(event: CloseEvent): void {
        console.log("Warn: SocketMgr socket onClose !!!", event);

        SocketMgr.instance = undefined;

        if (this.heartbeatTimerHandle !== undefined) {
            clearInterval(this.heartbeatTimerHandle);
        }

        if (this.onCloseCallback !== undefined) {
            this.onCloseCallback();
        }
    }

    private onError(event: Event): void {
        console.log("Warn: SocketMgr socket onError !!!", event);
        SocketMgr.instance = undefined;

        if (this.heartbeatTimerHandle !== undefined) {
            clearInterval(this.heartbeatTimerHandle);
        }

        if (this.onErrorCallback !== undefined) {
            this.onErrorCallback();
        }
    }

    public static isConnection(): boolean {
        return !!SocketMgr.instance;
    }

    private onMessage(event: MessageEvent): void {
        //this.heartbeatLastTS = getTimeStamp();
        /**proto */
        if (this.dataTool !== undefined) {
            this.dataTool.recvData(event.data);
        }
        let unpackData: UnpackData | undefined;
        // 尝试解包
        for (let i = 0; i < 300; i++) {
            if (this.dataTool !== undefined) {
                unpackData = this.dataTool.unpack()
            }
            if (unpackData === undefined) {
                break;
            }
            this.onOneMessage(unpackData);
        }
    }

    private onOneMessage(unpackData: UnpackData): void {
        if (undefined === unpackData.pack) {
            return;
        }
        const unpackHandleFunc = SocketPackTool.getUnpackHandleFunc(unpackData.protobufId);
        if(unpackData.protobufId !== Lobby.LobbyPacketID.PACKET_RS_PING) {
            console.log('========socket receive!!!!!!=========')
            console.log(unpackData.protobufId,unpackData)
            console.log('========socket receive!!!!!!=========')
        }
        if (unpackHandleFunc !== undefined) {
            unpackHandleFunc.forEach((handleFunc, key) => {
                handleFunc(unpackData.pack, unpackData.code)
            })
        }
    }

    private sendPack(packetId: number, pack: any): void {
        /**proto */
        let data: ArrayBuffer | undefined;
        if (this.dataTool !== undefined) {
            const packFunc = SocketPackTool.getPackFunc(packetId);
            if (packFunc !== null && packFunc !== undefined) {
                data = this.dataTool.pack(packetId, packFunc.encode(pack).finish());
            }
        }
        if (this.socket !== undefined && data !== undefined) {
            this.socket.send(data);
        }
    }


    /**
     * socket 心跳验证
     */
    private startHeartCheck(): void {
        if (this.heartbeatTimerHandle !== undefined) {
            return;
        }

        this.heartbeatLastTS = getTimeStamp();
        this.heartbeatTimerHandle = window.setInterval(this.heartCheck.bind(this), HeartbeatCheckInterval);
    }

    private heartCheck(): void {
        if (undefined === SocketMgr.instance) {
            return;
        }

        const ts = getTimeStamp();
        let delayTime = 0
        if (this.heartbeatLastTS !== undefined) {
            delayTime = ts - this.heartbeatLastTS;
        }

        // 如果从后台切为前台， 则丢弃切入后台时间  todo
        // 如果距离上次心跳时间已经超时，则认为断网
        if (delayTime >= HeartbeatTimeout) {
            console.log("Warn: SocketMgr.heartCheck heartbeat timeout !!!");
            SocketMgr.close();
            return;
        }

        // // 如果可以再次心跳 todo
        if (delayTime >= HeartbeatInterval) {
            this.heartbeatLastTS = getTimeStamp();
            SocketMgr.sendPing();
        }
    }

}

function stringToUint8Array(str: string) {
    const arr = [];
    for (let i = 0; i < str.length; ++i) {
        arr.push(str.charCodeAt(i));
    }
    const tmpUnit8Array = new Uint8Array(arr);
    return tmpUnit8Array;
}

function getTimeStamp(): number {
    return Math.round(Date.now() / 1000);
}

/**注册心跳 */
SocketPackTool.register((data, code) => {
},
    Lobby.LobbyPacketID.PACKET_RS_PING,
    Lobby.Lobby.HeartBetRs, Symbol('ping')
)
/**注册心跳封包 */
SocketPackTool.registerPackFunc(
    Lobby.LobbyPacketID.PACKET_RQ_PING,
    Lobby.Lobby.HeartBetRq
)
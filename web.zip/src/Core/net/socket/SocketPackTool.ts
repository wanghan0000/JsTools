
/**
 * Socket 包处理工具.
 */
/* eslint-disable */

export class SocketPackTool {

    // 解包方法
    private static UnpackFuncMap: Map<number, any> = new Map<number, any>();

    // 解包回调新
    static UnpackHandleFuncSupMap: Map<number, Map<any, () => void>> = new Map<number, Map<any, () => void>>();

    //封包使用的方法
    private static packFunMap: Map<number, any> = new Map<number, any>();

    /**
     * 
     * 注册
     * 
     * @param id                    协议ID
     * @param UnpackFunc            协议数据解包方法  
     * @param UnpackHandleFunc      协议数据回调方法
     */
    public static register(UnpackHandleFunc: (data, code) => void, id: number, UnpackFunc: any = () => { }, target): void {
        if (undefined === UnpackFunc || undefined === UnpackHandleFunc || undefined === target) {
            console.log("Error: SocketPackHandleTool.registe: packetId %d must register UnpackFunc or UnpackHandleFunc !!!", id);
            return;
        }

        let arr;
        if (SocketPackTool.UnpackHandleFuncSupMap.has(id)) {
            arr = SocketPackTool.UnpackHandleFuncSupMap.get(id);
        } else {
            arr = new Map<any, (data, code) => void>();
            SocketPackTool.UnpackHandleFuncSupMap.set(id, arr)
        }

        if (arr.has(target)) {
            console.log("Warn: SocketPackHandleTool.registe: packetId %d target %d repeated register UnpackFunc or UnpackHandleFunc !!!", id, target);
        } else {
            arr.set(target, UnpackHandleFunc)
        }

        if (!SocketPackTool.UnpackFuncMap.has(id)) {
            SocketPackTool.UnpackFuncMap.set(id, UnpackFunc);
        }
    }

    /**
    * 在游戏中，进入游戏要进行消息的注册，在退出游戏的时候要取消注册
    * @param id 
    */
    public static unregister(id: number, target?): void {
        if (!SocketPackTool.UnpackHandleFuncSupMap.has(id)) {
            console.log("warn:SocketPackHandleTool.unregister packetId %d has been ungister or  %d has neer been registered!", id, id);
            return;
        }


        if (!SocketPackTool.UnpackHandleFuncSupMap.has(id)) {
            console.log("warn:SocketPackHandleTool.unregister packetId %d has been ungister or  %d has neer been registered!", id, id);
            return;
        }
        if (!target) {
            SocketPackTool.UnpackHandleFuncSupMap.delete(id);
        } else {
            const maps = SocketPackTool.UnpackHandleFuncSupMap.get(id);
            if (maps.has(target)) {
                maps.delete(target);
            }
        }
    }

    /**
     * 注册封包使用的静态类
     * @param packFunc 封包静态类
     * @param id 包ID
     */
    public static registerPackFunc(id: number, packFunc: any = () => { }): void {
        if (undefined == packFunc) {
            console.log("Error:Socket registerPackFunc %d must register packFunc", id);
            return;
        }
        if (SocketPackTool.packFunMap.has(id)) {
            return
        }
        SocketPackTool.packFunMap.set(id, packFunc);
    }

    /**封包方法 */
    public static getPackFunc(id: number): any {
        if (!SocketPackTool.packFunMap.has(id)) {
            console.log(`Error:SocketPackTool没有找到${id}对应的消息注册`);
            return null;
        }
        return SocketPackTool.packFunMap.get(id);
    }


    /**解包方法 */
    public static getUnpackFunc(id: number): any {
        if (!SocketPackTool.UnpackFuncMap.has(id)) {
            console.log("Error: SocketPackHandleTool.getUnpackFunc: packetId %d not register UnpackFunc !!!", id);
            return undefined;
        }

        return SocketPackTool.UnpackFuncMap.get(id);
    }

    public static getUnpackHandleFunc(id: number): Map<any, (data, code) => void> | undefined {
        if (!SocketPackTool.UnpackHandleFuncSupMap.has(Number(id))) {
            console.log("Error: SocketPackHandleTool.getUnpackHandleFunc: packetId %d not register UnpackHandleFunc !!!", id);
            return undefined;
        }

        return SocketPackTool.UnpackHandleFuncSupMap.get(Number(id));
    }
}
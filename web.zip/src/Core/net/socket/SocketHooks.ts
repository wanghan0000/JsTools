import TimerTask from '@/Core/utils/TimerTask';
import { useCallback, useEffect, useRef, useState } from 'react';
import { SocketMgr } from './SocketMgr';
import { SocketPackTool } from './SocketPackTool';

export interface WSOptions {
  /**超时时间 默认值10s*/
  timeout?: number;
  /**超时回调 */
  timeOutCallback?: () => void;
}

/**只收推送消息 */
export const useWs = <T>(rspId: number, decode: any, getCache = true) => {
  const [data, setData] = useState<T>();
  const [error, setError] = useState<{ code?: number } | undefined>();
  const [target] = useState(Symbol());

  useEffect(() => {
    if (getCache) {
      setData(WsDataCenter.getInstance().getDataByPacktId(rspId, target));
    }
  }, []);
  useEffect(() => {
    SocketPackTool.register(
      function (data: T, code): void {
        if (code === 200) {
          WsDataCenter.getInstance().setData(rspId, data, target);
          setData(data || ({} as T));
          setError(undefined);
        } else {
          WsDataCenter.getInstance().setData(rspId, null, target);
          setError({ code: code });
        }
      },
      rspId,
      decode,
      target
    );
    return () => {
      SocketPackTool.unregister(rspId, target);
      WsDataCenter.getInstance().clearByPacktId(rspId, target);
    };
  }, []);
  return {
    data,
    error,
  };
};

/**收发 */
export const useWsMutation = <T, R>(rspId: number, sendId: number, decode: any, encode: any) => {
  const { data, error } = useWs<T>(rspId, decode);
  const [isLoading, setIsLoading] = useState(false);
  const promiseRef = useRef<any>({});

  const timeTask = useRef<TimerTask>(new TimerTask());

  const trigger: (pack: R, options?: WSOptions) => Promise<T> = useCallback((pack: R, options?: WSOptions) => {
    const { timeout = 10 * 1000, timeOutCallback } = options || {};
    timeTask.current.stop();
    timeTask.current
      .wait(timeout)
      .do(() => {
        timeOutCallback && timeOutCallback();
      })
      .excute();
    return new Promise((res, reject) => {
      promiseRef.current.reslove = res;
      promiseRef.current.reject = reject;
      setIsLoading(true);
      console.log('========socket send!!!!!!=========')
      console.log(sendId,pack)
      SocketMgr.send(sendId, pack);
      console.log('========socket send!!!!!!=========')
    });
  }, []);

  useEffect(() => {
    if (data) {
      promiseRef.current && promiseRef.current?.reslove?.(data);
      setIsLoading(false);
      timeTask.current.stop();
    }
  }, [data]);
  useEffect(() => {
    if (error) {
      setIsLoading(false);
      promiseRef.current && promiseRef.current?.reject?.(error);
      timeTask.current.stop();
    }
  }, [error]);

  useEffect(() => {
    SocketPackTool.registerPackFunc(
      sendId,
      encode,
    )
    return () => {
      timeTask.current?.stop();
    };
  }, []);
  return {
    data,
    isLoading,
    trigger,
    error,
  };
};

export class WsDataCenter {
  private cache: Map<number, Map<any, any>> = new Map<number, Map<any, any>>();

  private static instance: WsDataCenter;

  static getInstance(): WsDataCenter {
    if (!this.instance) {
      this.instance = new WsDataCenter();
    }
    return this.instance;
  }

  getDataByPacktId(packtId: number, target) {
    if (this.cache.has(packtId)) {
      const maps = this.cache.get(packtId);
      if (maps?.has(target)) {
        return maps.get(target);
      } else {
        if (maps?.size > 0) {
          const values = maps.values();
          return values.next().value;
        }
      }
    }
  }

  setData(packtId: number, data: any, target) {
    if (this.cache.has(packtId)) {
      let maps = this.cache.get(packtId);
      if (!maps) {
        maps = new Map<any, any>();
        this.cache.set(packtId, maps);
      }
      maps.set(target, data);
    } else {
      const maps = new Map<any, any>();
      maps.set(target, data);
      this.cache.set(packtId, maps);
    }
  }

  clearByPacktId(packetId: number, target: any) {
    if (this.cache.has(packetId)) {
      const maps = this.cache.get(packetId);
      if (maps?.has(target)) {
        maps.delete(target);
      }
      if (maps?.size === 0) {
        this.cache.delete(packetId);
      }
    }
  }
}

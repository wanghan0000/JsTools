// 原创游戏列表 -【id 对应 游戏页面路由key】
export const originalArr = {
  '10000': 'limbo',
  '10001': 'wheel',
};

export const langArrayDev = [
  {
    id: '3',
    lang: 'en_US',
  },
  {
    id: '4',
    lang: 'pt_BR',
  },
  {
    id: '1',
    lang: 'zh_CN',
  },
  {
    id: '2',
    lang: 'zh_TW',
  },
];

export const langArrayPro = [
  {
    id: '3',
    lang: 'en_US',
  },
  {
    id: '4',
    lang: 'pt_BR',
  },
]


export const langArray = (process.env.REACT_APP_BUILD === 'developmenet' ? langArrayDev : langArrayPro);

export const defaultLang = window.localStorage.getItem('i18nextLng') ||  process.env.REACT_APP_LANG_DEFAULT;
export const themeArray = ['Light', 'Dark'];

export const LoadingBackground = "data:image/webp;base64,UklGRtAFAABXRUJQVlA4WAoAAAAQAAAAFwEAOwEAQUxQSDQBAAAFHyAQIPi/FKIjIgIPshuKrdvqkOAHPzWCRiHQxbi7rbQgBUdt7yOi/xPwAQYGwTUo6lwdEhI8nsa4QRrozQRHLqPPvNFNIUV0V0Z0c5K9BGD1EvBHMkCaKXNbViP5IqSNbiZWo95c+Y31Ss4GsgFd2WrUmKvkldFrfibq+btj/ZIHEr38pdFlHpCxQC5Rw290MU8H0krfnOjiByT6+Q8f65Rsyqol5w4poecNaafbQZrof//999+/OAVNfDtBOz9vQUk/eFIN3ZR0Qn/2jH7zgIwu880JWvnpsEVwHTXmjS/ygFiXfGn0mk9E+qFvzqg3P2O98iVZWY1coYtgA344pBd6GSurl6u5maCNf5XUQHdlBM2cfCQDkHoozM0Io9sE3VRQ1DcVXKxP3niA3QQN/CYfB1ZQOCB2BAAAcCcAnQEqGAE8AT6dTqBOIhRUEBR8WAnEs7dwdtt7tMbkd5XnkAPUCsv6BfyaoHgH6o506f5/u78gC3PkNTvqoeUnUNTM/WJ75gU/RVIX+9DV7sqbfJ19TOO53tioT08QfJ6m3I2PwdZiiIvHR5rYyiV6C2PmLhr/t9oS1KRCzn+NwovYjb9n5+NpyfZZ6+jonTEM4gWVYOAJQMaIw9kyFhit8hqcqjR8GygZS+7hlu2WQcHyc6fnfyP/783v2EVjwsvLZx+LaWnrJb3C6pMdSKHOQxValKkjxnAA9+ZaiqpmXl6j3TqizV7gdFUkJAdbn/UkcB30kcVgx/dSSL3IMDQb5f4E+LtOY4bu5AVWPoPV/SweXIHLYLYvxd5cTfwHSvTQLLOnrKXXEGzvSDENSpm/bjY66jnG2uoanZeDqgI/9EYAAP7GxavyvJVMYj/ZjMkg42SY6+Ue34kmKDF2+wsB7Oc4xjYN68BRRDV/H20DFS67BBb4BDafSAfye6jebHr3KP7eszNTlXiy8+QKchO0Cy12vNBe69WvyafSy9A4+nVgfoioeKBvDGal0eXtHJX1oYjdF9qFDpJMoFUhzVmmUMcwWj9LKHFMBk0M236rXZvCmMyCFR/OmoyTKHwkNmJkE40P5AdcSnfadPpUTA+pN/+tzrvmel8/6xMhGy3+tXfislEUeATTe/3wXAnrcAJN9KObS5chM4cPju47Mz/0kTNWFRFHMGcMz4k7vl9jldmNiktUibj1XBoCFazy4ePpbueyEd9g4OjE7NW3u/1r5bfPPp99t2Dcjr7oeYH/dHq6DQAeIQ/giwPRe9LQIKvhbh8wZMa9DGFjupNlPWVOnybQPBP4Vm1lYFm6RRF9q6XIJrHu5FWkM8r69SKIf1UcT4uDMnUfKNO+SuxdXihzGFkSWaoKDMqreWC/A9QYP+NoqDDmosV3dCip9Nig2rVhMEngtLMwHSLQzs9Fxp26Kw3TvIbNuS/v9UYkia22po1RbGu1ynK0pHjB4Al1qGTNq/jA5W8vB1oC9goccBS1zXHq+EisILoB2No3W5HnDyD/f83+yjn9Gycog5mVMqyrCSqaQaNGJAya/Sv+3FW4AI6NZGA8/j4u1Obb5YrAkJvIncjaHn90pjGz+lZqZ0AatwTgdqLkZ6T0ud99dgejkMMnGyrrHM97Bf76pQYtoiKBupdIChIQgJ+XgzJg9v/5YaX5woBGMV7zYd490897YIYvS9htl514KBwDIyD9KgisoLeQGU/Qn1JukritpMJKnwOaQ3+LRPUVdY9Qtr9IRjSGMhjqwxAZ4hVADPIhYPlJOnOLO2npq37rlhAlbiIBcDIZtBXvI5T1BaThtd60fnynQhHu4ButaGKKAeOVD1SRWRSGZRkULtBwfweie2gmAcOn4KgCiL0SAJavybuOyrPtgpExS2omAeX+qe5glDIi+afWY9R7LNWdphgnBk5xDuCqcL1e3CbqqvSBdzax76yqOFqHC4+FHdiuF4b7vzlAAAA="
import { useTranslation } from "react-i18next";

export const useTranslationPlus = (prefix?) => {
    const { t: trans, i18n } = useTranslation();
    const t = (key: string, options?: any): any => {
        if (key?.includes('.')) {
            return trans(key, options)
        }
        const index = prefix ? prefix + '.' + key : key
        return trans(index, options)
    }
    return {
        t,
        i18n
    }
}
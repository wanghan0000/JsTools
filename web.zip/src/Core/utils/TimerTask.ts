export default class TimerTask {

  private tasks: any[] = [];
  private timerId;
  private generator: Generator = null;
  do(func: () => any) {
    this.tasks.push(func)
    return this;
  }

  wait(timeout) {
    this.tasks.push(timeout)
    return this;
  }

  excute() {
    // try {
    //   this.tasks.forEach(async (v) => {
    //     if (typeof (v) === 'function') {
    //       v()
    //     } else if (typeof (v) === 'number') {
    //       await new Promise((res) => {
    //         this.timerId = setTimeout(() => {
    //           res(true)
    //         }, v)
    //       })
    //     }
    //   })
    // } catch (error) { }
    this.generator = this._taskGenerator()
    this.generator.next()
  }

  stop() {
    this.tasks.length = 0;
    if (this.timerId) {
      clearTimeout(this.timerId)
      this.timerId = undefined;
    }
    this.generator?.return('');
    this.generator = null;
  }

  * _taskGenerator() {
    try {
      for (let i = 0; i < this.tasks.length; ++i) {
        const task = this.tasks[i];
        const type = typeof (task)
        if (type === 'function') {
          yield (() => {
            task()
            this?.generator?.next()
          })()
        } else if (type === 'number') {
          yield (() => {
            return new Promise((res) => {
              this.timerId = setTimeout(() => {
                res(true)
                this?.generator?.next()
              }, task);
            })
          })()
        } else {
          throw console.error('is not a timertask');
        }
      }
    } catch (error) {
      
    }
  }
}

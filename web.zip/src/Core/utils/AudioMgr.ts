/**
 * 音频管理器
 */
export default class AudioMgr {

    private static instance: AudioMgr;
    public static getInstance(): AudioMgr {
        if (!this.instance) {
            this.instance = new AudioMgr()
        }
        return this.instance;
    }

    private music: HTMLAudioElement;

    //private sound: HTMLAudioElement;

    /**浏览器默认是否支持播放 */
    private static canPlay: boolean;

    private curMusicPath: string;

    constructor() {
        window.addEventListener('mousedown', this.onMouseDown.bind(this))
    }

    private onMouseDown() {
        if (!AudioMgr.canPlay && this.curMusicPath) {
            //如果有背景音乐 那么就播放
            this.playMusic(this.curMusicPath, true)
        }
    }

    /**播放背景音乐 只能存在一个*/
    playMusic(path: string, forceUpdate?: boolean) {
        if (!forceUpdate && path === this.curMusicPath) {
            return
        }
        this.curMusicPath = path;
        this.music = new Audio(path)
        this.music.loop = true;
        this.music.autoplay = true;
        const promise = this.music.play()
        if (!promise !== undefined) {
            promise.then(() => {
                AudioMgr.canPlay = true;
                console.log("=============AudioMgr================")
                console.log("自动播放背景音乐成功", path)
                console.log("=============AudioMgr================")
                window.removeEventListener('mousedown', this.onMouseDown)
            }).catch(() => {
                AudioMgr.canPlay = false;
                console.log("=============AudioMgr================")
                console.error("自动播放背景音乐失败", path)
                console.log("=============AudioMgr================")
            })
        }
    }

    /**播放音效 可以存在多个*/
    playSound(path: string) {
        const sound = new Audio(path)
        sound.autoplay = true;
        const promise = sound.play()
        if (!promise !== undefined) {
            promise.then(() => {
                AudioMgr.canPlay = true;
                window.removeEventListener('mousedown', this.onMouseDown)
            }).catch(() => {
                AudioMgr.canPlay = false;
            })
        }
    }

    /**关闭音乐 */
    stopMusic(){
        if(this.music){
            this.music.pause()
            this.music = null;
            this.curMusicPath = ''
        }
    }
}
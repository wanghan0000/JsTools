import BIG from '@/libs/bigmin.js';

import USDT_PATH from '@/assets/image/wallet/wallet_usdt.webp';
import BRL_PATH from '@/assets/image/wallet/wallet_brl.webp';
import USD_PATH from '@/assets/image/wallet/wallet_usd.webp';
import FUN_PATH from '@/assets/image/wallet/wallet_fun.webp';
import LOCK_FUN_PATH from '@/assets/image/wallet/wallet_fun_lock.webp';
import { CurrencyType } from '@/api/proto/IFCommon';

/**默认货币类型 */
export const DefaultCurrencyType = 'BRL';
/**基础数据单元 */
const BaseAmountUnit = new BIG(10000000000);
/**用于数据千分位分割 */
const AmountReg = /(\d)(?=(\d{3})+\.)/g;

export const CurrencyImage = {
  BRL: BRL_PATH,
  USDT: USDT_PATH,
  USD: USD_PATH,
  FUN: FUN_PATH,
  LOCK_FUN: LOCK_FUN_PATH,
};
export interface CurrencyExtra {
  currencyType: CurrencyType;
}

export const toLocaleString = (num: string | number): any => {
  if (window.defaultLang === 'pt_BR') {
    return Number(num).toLocaleString('pt-BR', {
      minimumFractionDigits: 2,
      useGrouping: false
    })
  } else {
    return num;
  }
}

/**科学计数转换 */
export const transferToNumber = (num: string | number): string => {
  if (isNaN(Number(num))) {
    return num + '';
  }
  num = num + '';
  num = parseFloat(num);
  const eformat = num.toExponential();
  const tmpArray: any = eformat.match(/\d(?:\.(\d*))?e([+-]\d+)/);
  return toLocaleString(Number(num.toFixed(Math.max(0, (tmpArray[1] || '').length - tmpArray[2]))));
};

/**金额乘数转换 用于向服务器提交货币数据*/
export const AmountMultiplierConversion = (amount: string | number, extra: CurrencyExtra): number => {
  const { currencyType } = extra || {};
  const rate = window.currencyPrecision?.[currencyType];
  const tAmount = Number(amount);
  if (!isNaN(tAmount)) {
    if (rate) {
      const retAmount = new BIG(tAmount).times(new BIG(rate));
      return Number(retAmount.toString());
    } else {
      const retAmount = new BIG(tAmount).times(BaseAmountUnit);
      console.error('没有匹配到对应精度！！！！！！！！！！！！！！！');
      return Number(retAmount.toString());
    }
  }
  return tAmount;
};

/**金额除数转换 用于解析服务器金额转换为正常数据*/
export const AmountDivisorConversion = (amount: string | number, extra: CurrencyExtra): number => {
  const { currencyType } = extra || {};
  const rate = window.currencyPrecision?.[currencyType];
  const tAmount = Number(amount);
  if (!isNaN(tAmount)) {
    if (tAmount == 0) {
      return 0;
    }
    if (rate) {
      const retAmount = new BIG(tAmount).div(new BIG(rate));
      return Number(retAmount.toFixed(9, 0));
    } else {
      const retAmount = new BIG(tAmount).div(BaseAmountUnit);
      console.error('没有匹配到对应精度！！！！！！！！！！！！！！！');
      return Number(retAmount.toFixed(9, 0));
    }
  }
  return tAmount;
};

export const numberTimes = (num1: number, num2: number, fixed = 9) => {
  const tnum1 = new BIG(num1).times(BaseAmountUnit);
  const tnum2 = new BIG(num2).times(BaseAmountUnit);
  return Number(tnum1.times(tnum2).div(BaseAmountUnit).div(BaseAmountUnit).toFixed(fixed, 0));
};

export const numberDivisor = (num1: number, num2: number, fixed = 9) => {
  const tnum1 = new BIG(num1);
  const tnum2 = new BIG(num2);
  if (num1 == 0 || num2 == 0) {
    return tnum2.toFixed(fixed, 0);
  }
  return Number(tnum1.div(tnum2).toFixed(fixed, 0));
};

/**
 * 处理数据有效位
 * @param num 数据
 * @param valid 有效位
 */
export const dealNumberValid = (num, valid = 9): string => {
  const tNum = Number(num);
  if (!isNaN(tNum)) {
    const bigNum = new BIG(num);
    const bigStr = transferToNumber(bigNum.toString());
    const hasDot = bigStr.includes('.');
    const strLength = bigStr.length;
    hasDot && (valid += 1);
    let retValue = bigStr;
    if (strLength <= valid) {
      if (hasDot) {
        retValue = bigStr + '0000000000000000000'.substring(0, valid - strLength);
      } else {
        if (valid === strLength) {
          retValue = bigStr + '0000000000000000000'.substring(0, valid - strLength);
        } else {
          retValue = bigStr + '.' + '0000000000000000000'.substring(0, valid - strLength);
        }
      }
    } else {
      if (hasDot) {
        const dotIndex = retValue.indexOf('.');
        if (dotIndex >= valid - 1) {
          return bigStr.substring(0, dotIndex);
        } else {
          return bigStr.substring(0, valid);
        }
      }
    }
    return retValue;
  }
  return num + '';
};

/**
 * 数据小数位保留
 * @param num
 * @param fixed 需要保留的小数位
 */
export const numberFixed = (num, fixed = 2): string => {
  const tNum = Number(num);
  if (!isNaN(tNum)) {
    const bigNum = new BIG(num);
    const fixedNum = bigNum.toFixed(fixed, 0);
    return toLocaleString(fixedNum)
  }
  return num;
};

/**
 * 金额显示有效位9位
 * @param amount
 * @returns
 */
export const dealAmount9Valid = (amount: string | number, extra: CurrencyExtra): string => {
  amount = AmountDivisorConversion(amount, extra);
  //amount = dealNumberValid(amount, 9);
  amount = numberFixed(amount, 2);
  return amount;
};
/**
 * 金额显示 传参位数
 * @param amount
 * @returns
 */
export const dealAmountAnyValid = (amount: string | number, len: number, extra: CurrencyExtra): string => {
  amount = AmountDivisorConversion(amount, extra);
  //amount = dealNumberValid(amount, len);
  amount = numberFixed(amount, 2);
  return amount;
};
/**
 * 金额显示2位小数处理
 */
export const dealAmount2Fiexd = (amount: string | number, extra: CurrencyExtra): string => {
  amount = AmountDivisorConversion(amount, extra);
  amount = numberFixed(amount, 2);
  return amount;
};
/**
 * 金额缩小10个0显示，无小数处理
 */
export const dealAmount0Fiexd = (amount: string | number, extra: CurrencyExtra): number => {
  amount = AmountDivisorConversion(amount, extra);
  amount = numberFixed(amount, 0);
  return Number(amount);
};
/**
 * 金额显示2位小数且带千分位处理
 */
export const dealAmountSegmentationAnd2Fixed = (amount: string | number, extra: CurrencyExtra): string => {
  amount = AmountDivisorConversion(amount, extra);
  amount = numberFixed(amount, 2);
  amount = amount.replace(AmountReg, '$1,');
  return amount;
};

/**
 * 金额带货币类型处理
 */
export const dealAmount9ValidCurrency = (amount: string | number, extra: CurrencyExtra): string => {
  const { currencyType } = extra || {};
  amount = dealAmount9Valid(amount, extra);
  const type = currencyType || DefaultCurrencyType;
  return type + ' ' + amount;
};

/**
 * 金额带货币显示2位小数处理
 */
export const dealAmount2FiexdCurrency = (amount: string | number, extra: CurrencyExtra): string => {
  const { currencyType } = extra || {};
  amount = AmountDivisorConversion(amount, extra);
  amount = numberFixed(amount, 2);
  const type = currencyType || DefaultCurrencyType;
  return type + ' ' + amount;
};

/**
 * 金额显示2位小数且带千分位处理
 */
export const dealAmountSegmentationAnd2FixedCurrency = (amount: string | number, extra: CurrencyExtra): string => {
  const { currencyType } = extra || {};
  amount = AmountDivisorConversion(amount, extra);
  amount = numberFixed(amount, 2);
  amount = amount.replace(AmountReg, '$1,');
  const type = currencyType || DefaultCurrencyType;
  return type + ' ' + amount;
};

export const getCurrencyImagePath = (type: string) => {
  return CurrencyImage[type];
};

/**
 * 汇率换算
 */
export const exchangeRateConversion =
  (source: { amount: string | number, currency: string },
    targetCurrency: string,
    rate: number) => {
    let newValue = Number(source?.amount) * rate;
    const sourcePrecision = window.currencyPrecision?.[source?.currency] || 0;
    const targetPrecision = window.currencyPrecision?.[targetCurrency] || 1;
    let deltaPrecision = sourcePrecision / targetPrecision;
    if (deltaPrecision > 0) {
      newValue = newValue / deltaPrecision;
    } else {
      deltaPrecision = targetPrecision / sourcePrecision;
      newValue = newValue * deltaPrecision;
    }
    return newValue;
  }
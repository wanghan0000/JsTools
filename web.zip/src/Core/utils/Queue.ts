// function Queue() {
//     this.items = [];
// }


// Queue.prototype.equeue = function (element) {
//     this.items.push(element)
// }

// Queue.prototype.dequeue = function () {
//     return this.items.shift()
// }

// Queue.prototype.isEmpty = function() {
//     return this.items.length === 0;
// }

// Queue.prototype.size = function() {
//     return this.items.length;
// }

// Queue.prototype.clear = function() {
//     this.items.length = 0;
// }

class Queue {
    items: any[] = [];

    equeue(element) {
        this.items.push(element)
    }

    dequeue() {
        return this.items.shift()
    }

    isEmpty() {
        return this.items.length === 0;
    }

    size() {
        return this.items.length;
    }

    clear() {
        this.items.length = 0;
    }
}


export default Queue
/* eslint-disable */

import moment from "moment";

const InitLog = ()=>{
    if(process.env.REACT_APP_ENV.toString() == 'production'){
      console.log=()=>{}
    }
}
  
InitLog()

export function getTimestamp() {
  return Math.floor(Date.parse(new Date().toString()) / 1000);
}

export const getResetTime = (countdown) => {
  const ResetTime = `${countdown.hours < 10 ? '0' + countdown.hours : countdown.hours}:${
    countdown.minutes < 10 ? '0' + countdown.minutes : countdown.minutes
  }:${countdown.seconds < 10 ? '0' + countdown.seconds : countdown.seconds}`;

  return ResetTime;
};

export const calcResetTime = (current) => {
  const hours = parseInt(((current / (60 * 60)) % 24) + '');
  const minutes = parseInt(((current / 60) % 60) + '');
  const seconds = parseInt((current % 60) + '');
  const t1 = getResetTime({ hours, minutes, seconds });
  return t1;
};

export const timestampToDate = (time) => {
  moment.locale('pt-br')
  return moment(time).format('l') + ' ' + moment(time).format('LTS'); 
};

export const timeStampToDateDay = (time) => {
  moment.locale('pt-br')
  return moment(time).format('LTS'); 
};

export const covertTranslationImagePath = (path: any) => {
  return window.cdnUrl + (window.defaultLang || 'pt_BR') + '/' + path + '.webp';
};

export const FromValidate = (form) => {
  return function (keys?: string[]): Promise<any> {
    return new Promise((resolve, reject) => {
      if (keys) {
        form
          .validate(keys)
          .then((v: any) => {
            resolve(v);
          })
          .catch(() => {
            reject();
          });
      } else {
        form
          .validate()
          .then((v: any) => {
            resolve(v);
          })
          .catch(() => {
            reject();
          });
      }
    });
  };
};

/**
 * 防抖函数
 * @param fn  目标函数
 * @param delay  延迟时间
 */

export function debounce(func, delay = 500) {
  let timeId;
  return function (...args) {
    clearTimeout(timeId);
    timeId = setTimeout(() => {
      func.apply(this, args);
    }, delay);
  };
}

/**键盘tab只能选中输入框 */
export function restrictTabToInputs() {
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Tab') return;
    e.preventDefault();
    //获取所有输入框元素
    const inputElements = document.querySelectorAll('input');
    const currnetIndex = Array.from(inputElements).findIndex((input) => input === document.activeElement);
    const nextIndex = (currnetIndex + 1) % inputElements.length;
    (inputElements?.[nextIndex] as HTMLElement)?.focus();
  });
}
/**键盘enter可以直接触发事件 */
export const BindEnterId = 'btn-bindEnterKey';
export function bindEnterKeyToButton() {
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    //获取所有输入框元素
    const button = document.getElementById(BindEnterId);
    button?.click();
  });
}

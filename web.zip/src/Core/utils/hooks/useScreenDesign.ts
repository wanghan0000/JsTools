import {useEffect, useState} from "react"

export enum screenType {
	"mobile" = "sm",
	"ipad" = "md",
	"smallPc" = "lg",
	"middlePc" = "xl",
	"bigPc" = "xxl",
}
const condition = {
	"sm":{min:0,max:621},
	"md":{min:621,max:768},
	"lg":{min:768,max:992},
	"xl":{min:992,max:1200},
	"xxl":{min:1200,max:1600},
}
type SymbolStr = '>=' | '<='

/**
 * 使用方法：
 * import  useScreenDesign,{screenType} from "@/Core/utils/hooks/useScreenDesign";
 *
 * const isMobile = useScreenDesign();
 * const isIpad = useScreenDesign(screenType.ipad);
 */
const useScreenDesign = (type?:screenType, symbolStr?: SymbolStr, cb?:any)=> {
	if(!type) type = screenType.mobile;
	let curCondition = condition[type];
	if(!curCondition) curCondition = condition["mobile"];

	const curConditionTemp = condition[type];

	if(symbolStr){
		if(symbolStr === '<=') {
			curConditionTemp.min = 0
		}else if(symbolStr === '>='){
			curConditionTemp.max = 3600
		}
	}
	curCondition = curConditionTemp;
	const _isMobile = navigator.userAgent.match(/(iPad)|(iPhone)|(iPod)|(android)|(webOS)/i) != null;
	const initStatus = _isMobile ? _isMobile : window.innerWidth > curCondition.min && window.innerWidth < curCondition.max;
    const [isScreen,setIsScreen] = useState(initStatus)

	useEffect(() => {
		function handleResize() {
			cb && cb(isScreen)
			setIsScreen(window.innerWidth > curCondition.min && window.innerWidth < curCondition.max)
		}
		window.addEventListener('resize', handleResize)
		return () => window.removeEventListener('resize', handleResize)
	}, [])
	return _isMobile ? _isMobile : isScreen;
}

export default useScreenDesign

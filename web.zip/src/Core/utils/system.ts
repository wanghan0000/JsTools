export class sys {
  static get pwa(): boolean {
    sys._init();
    return sys._pwa;
  }
  /** Indicate the running os name */
  static get os(): OSType {
    sys._init();
    return sys._os;
  }
  /** Is native ? This is set to be true in jsb auto. */
  static get isNative(): boolean {
    sys._init();
    return sys._isNative;
  }
  /**是否是手机移动端 */
  static get isMobile(): boolean {
    sys._init();
    return sys._isMobile;
  }
  /**设备类型 1ios-h5 2Android-h5 3pc 4ios-app 5android-app*/
  static get device(): number {
    sys._init();
    return sys._device;
  }
  /**渠道挂靠id */
  static get pid(): string {
    sys._init();
    return sys._pid;
  }
  /**下级代理挂靠id */
  static get inviteCode(): string {
    sys._init();
    return sys._inviteCode;
  }
  /**是否是debug */
  static get isDebug(): boolean {
    return process.env.REACT_APP_BUILD?.toString() != 'production';
  }
  /**获取facebook fbc*/
  static get fbc(): any {
    return sys._fbc;
  }
  /**获取facebook fbq*/
  static get fbq(): any {
    return sys._fbp;
  }
  /**设备UID */
  static get equipmentUid(){
    sys._init();
    return sys._equipmentUid;
  }
  /**打开连接 */
  static openUrl(url: string): WindowProxy | null {
    if (!sys.callNative('webViewJumpUrl', url)) {
      //网页
      if (sys.os === 'IOS') {
        if (url) {
          window.open(url, '_blank');
        } else {
          return window.open('', '_blank');
        }
      } else {
        window.open(url, '_blank');
      }
    }
  }
  /**添加到桌面 */
  public static addToHomePWA(callback) {
    if (sys.os === 'IOS') {
      window.location.href = '/desktop.mobileconfig';
      callback(false);
    } else {
      const installApp = async () => {
        const promptEvent = window.addToHome.pwaEvent;
        if (promptEvent) {
          promptEvent.prompt();
          const { outcome } = await promptEvent.userChoice;
          if (outcome === 'accepted') {
            window.addToHome.pwaEvent = null;
            sys._pwa = false;
            callback && callback(true);
          }
        } else {
          callback && callback(false);
        }
      };
      installApp();
    }
  }
  /**原生Google登录 */
  static nativeGoogleLogin(): void {
    if (!sys.isNative) {
      return;
    }
    sys.callNative('webViewGoogleLogin');
  }
  /**原生facebook登录 */
  static nativeFacebookLogin(): void {
    if (!sys.isNative) {
      return;
    }
    sys.callNative('webViewFacebookLogin');
  }
  /**原生更新 */
  static nativeUpdateApp(): void {
    if (!sys.isNative) {
      return;
    }
    sys.callNative('webViewUpdateApp');
  }

  /**事件埋点 */
  static analytics(params: Analytics) {
    if (process.env.REACT_APP_ENV?.toString() != 'production') {
      return;
    }
    const { eventName, category, label, userId } = params;
    /**首充特殊处理 */
    if (eventName === 'recharge' && userId) {
      const purchase = localStorage.getItem('purchase' + userId);
      if (!purchase) {
        sys.callNative('trackEvent', 'purchase', category, label);
        sys.pixelTrack({ ...params, eventName: 'purchase' });
      }
    }
    sys.callNative('trackEvent', eventName, category, label);
    sys.pixelTrack(params);
  }



  /**初始化系统变量 */
  public static initSystem() {
    const { userAgent = '' } = window.navigator;
    const matchPlats = [
      {
        native: true,
        os: 'ANDROID',
        rules: [
          '360shouji',
          'honor_cn',
          'huawei_cn',
          'lenovo',
          'letv',
          'meizu',
          'motorola',
          'nokia',
          'oneplus',
          'oppo_cn',
          'realme_cn',
          'samsung',
          'smartisan',
          'vivo',
          'xiaomi',
          'zte',
        ],
        isMobile: true,
        device: 2,
      },
      { native: false, os: 'ANDROID', rules: ['Android'], isMobile: true, device: 2 },
      { native: false, os: 'IOS', rules: ['iPhone', 'iPad', 'iPod'], isMobile: true, device: 1 },
      { native: false, os: 'WINDOWS', rules: ['Win32', 'Win64', 'Windows', 'WinCE'], isMobile: false, device: 3 },
      { native: false, os: 'IOS', rules: ['Macintosh', 'MacIntel', 'MacPPC', 'Mac68K'], isMobile: false, device: 1 },
    ];

    let result = {
      native: false,
      os: 'UNKNOWN',
      isMobile: false,
      device: 3,
    };

    for (let i = 0; i < matchPlats.length; ++i) {
      const item = matchPlats[i];
      let flag = false;
      for (let j = 0; j < item.rules.length; ++j) {
        if (userAgent.indexOf(item.rules[j]) !== -1) {
          flag = true;
          break;
        }
      }
      if (flag) {
        result = item;
        break;
      }
    }

    if (!result.native) {
      result.native = /Webview/.test(userAgent);
    }

    sys._isNative = result.native;
    sys._os = result.os as OSType;
    sys._isMobile = result.isMobile;
    if(result.native) {
      if(sys._os === 'IOS') {
        sys._device = 4;
      }else {
        sys._device = 5;
      }
    }else{
      sys._device = result.device;
    }
  }

  private static _isNative: boolean;
  private static _os: OSType;
  private static _isMobile: boolean;
  private static _device: number;
  private static _isInit = false;
  private static _pid: string;
  private static _inviteCode: string;
  private static _pwa: boolean;
  private static _fbc: any;  
  private static _fbp: any;
  private static _token: any;
  private static _equipmentUid: any;

  public static get token() {
    return sys._token;
  }
  public static set token(token) {
    sys._token = token;
  }

  private static _init() {
    if (this._isInit) {
      return;
    }
    this._pwa = !!window.addToHome?.supportPwa;
    if (!this._pwa) {
      Object.defineProperty(window.addToHome, 'supportPwa', {
        set: function (val) {
          if (window.matchMedia('(display-mode: standalone)').matches) {
            console.log('在pwa里面');
          } else {
            console.log('没有在pwa里面');
            sys._pwa = true;
          }
        },
        enumerable: true,
        configurable: true,
      });
    }
    sys.initSystem();
    this._isInit = true;
    sys._pid = getUrlParam('pid') || localStorage.getItem('pid') || '0';
    sys._inviteCode = getUrlParam('rid') || localStorage.getItem('rid');
    const fbq = sys.getcookie('fbq');
    if(fbq) {
      sys._fbp = fbq;
    }else {
      sys._fbp = getUrlParam('fbq');
    }
    const fbc = sys.getcookie('fbc');
    if(fbc) {
      sys._fbc = fbc;
    }else {
      sys._fbc = getUrlParam('fbc');
    }
    const PNAME_MAP = [
      { key: 'Facebook Installs', value: '0' },
      { key: 'TT', value: '0' },
      { key: 'Instagram Installs', value: '0' },
      { key: 'Off-Facebook Installs', value: '0' },
      { key: 'Facebook Messenger Installs', value: '0' },
      { key: 'kwai', value: '0' },
    ];
    if (sys._pid === '0') {
      for (let i = 0; i < PNAME_MAP.length; ++i) {
        if (getUrlParam(PNAME_MAP[i].key)) {
          sys._pid = PNAME_MAP[i].value;
          break;
        }
      }
    }
    localStorage.setItem('pid', sys._pid);
    if (sys._inviteCode) {
      localStorage.setItem('rid', sys._inviteCode);
    }

    if(sys._isNative) {
       // 获取原生设备ID
       sys._equipmentUid = sys.callNative('webViewEquipmentUid');
    }else {
       import(/* webpackChunkName: 'fingerprintjs', webpackPrefetch: true */'@fingerprintjs/fingerprintjs').then((module)=>{
          const Fingerprintjs = module.default;
          Fingerprintjs.load().then((fp)=>{
             fp.get().then(({ visitorId })=>{
                sys._equipmentUid = visitorId;
             })
          })
       })
    }
  }

  private static callNative(method: string, ...params: string[]): boolean {
    if (window.jsCallNative && window.jsCallNative[method]) {
      window.jsCallNative[method](params?.[0] || '', params?.[1] || '', params?.[2] || '');
      return true;
    } else if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers[method]) {
      window.webkit.messageHandlers[method]['postMessage'](params?.[0] || '', params?.[1] || '', params?.[2] || '');
      return true;
    }
    return false;
  }
  /**像素统计 */
  private static pixelTrack(params: Analytics): void {
    sys.pixelKuaishou(params.eventName);
    sys.pixelFacebook(params.eventName);
    sys.pixelTiktok(params.eventName);
    sys.pixelBemob(params.eventName);
    sys.pixelGoogle(params);
  }
  private static pixelKuaishou(eventName: AnalyticsEventName): void {
    if (!window.kwaiq || !window.kwaiId) {
      return;
    }
    if (eventName === 'purchase') {
      window.kwaiq.instance(window.kwaiId).track(eventName);
    } else if (eventName === 'complete_registration') {
      window.kwaiq.instance(window.kwaiId).track('completeRegistration');
    } else if (eventName === 'firstInApp') {
      window.kwaiq.instance(window.kwaiId).track('contentView');
    }
  }
  private static pixelFacebook(eventName: AnalyticsEventName): void {
    if (!window.fBId || !window.fbq) {
      return;
    }
    if (eventName === 'purchase') {
      window.fbq('trackCustom', 'firstDeposit');
      window.fbq('track', 'Purchase');
    } else if (eventName === 'complete_registration') {
      window.fbq('track', 'CompleteRegistration');
    } else if (eventName === 'Login') {
      window.fbq('trackCustom', 'Login');
    } else if (eventName === 'download') {
      window.fbq('trackCustom', 'Download');
    }
  }
  private static pixelTiktok(eventName: AnalyticsEventName): void {
    if (!window.ttkid || !window.ttq) {
      return;
    }
    if (eventName === 'purchase') {
      window.ttq.track('Purchase');
    } else if (eventName === 'complete_registration') {
      window.ttq.track('CompleteRegistration');
    } else if (eventName === 'Login') {
      window.ttq.track('Login');
    } else if (eventName === 'download') {
      window.ttq.track('Download');
    }
  }
  private static pixelBemob(eventName: AnalyticsEventName): void {
    if (!window.bemob) {
      return;
    }
    if (eventName === 'purchase') {
      window.bemob.track('Firstdeposit');
    } else if (eventName === 'complete_registration') {
      window.bemob.track('CompleteRegistration');
    } else if (eventName === 'Login') {
      window.bemob.track('Login');
    }
  }
  private static pixelGoogle(params: Analytics): void {
    if (!window.gtag) {
      return;
    }
    const { eventName, label, category } = params;
    if (eventName === 'purchase') {
      window.gtag('event', 'purchase', {
        currency: 'BRL',
        transaction_id: label,
        value: 0,
      });
    } else {
      window.gtag('event', eventName, {
        event_category: category || '操作事件',
        event_label: label,
        debug_mode: true,
      });
    }
  }

  private static getcookie(objname) {
    const arrstr = document.cookie.split("; ");
    for (let i = 0; i < arrstr.length; i++) {
      const temp = arrstr[i].split("=");
      if (temp[0] == objname) return unescape(temp[1]);
    }
  }

}

export function getUrlParam(name) {
  const reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)');
  const r = window.location.search.substring(1).match(reg);
  if (r != null) {
    return decodeURI(r[2]);
  } else {
    return null;
  }
}

export function parseQueryString(queryString) {
  const params = {};
  const keyValuePairs = queryString.split('&');

  for(const pair of keyValuePairs) {
    const [key, value] = pair.split('=');
    if(key && value) {
      params[key] = decodeURIComponent(value);
    }
  }
  return params;
}

export type OSType = 'IOS' | 'ANDROID' | 'WINDOWS' | 'UNKNOWN';

export type AnalyticsEventName =
  /**首充 */
  | 'purchase'
  /**注册成功 */
  | 'complete_registration'
  /**登录 */
  | 'Login'
  /**下载 */
  | 'download'
  /**第一次进入应用 */
  | 'firstInApp'
  /**充值 */
  | 'recharge';

export interface Analytics {
  eventName: AnalyticsEventName;
  category?: string;
  label?: string;
  userId?: string;
}

window.luckybetSys = sys;

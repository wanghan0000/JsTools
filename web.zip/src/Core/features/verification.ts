export const FORMAT_REG = {
	USDT_ERC20: '^(0[xX])[A-Za-z0-9]{32}$',
	USDT_TRC20: '^[T][A-Za-z0-9]{33}$',
	USERNAME: '^[a-zA-Z][a-zA-Z0-9_]{5,19}$',
	LOGIN_USERNAME: '^[a-zA-Z0-9_]{6,20}$',
	PASSWORD: '.{6,20}$',
	IMAGE_VERIFY_CODE: '.{2,5}$',
	ACCOUNT_LOGIN_USERNAME: '[a-zA-Z0-9_\s]{6,20}$',
	VERIFY_CODE: '^[A-Za-z0-9]{5}$',
	PHONE: '^\\+55\\s[1-9]{2}\\s9[0-9]{8}$',
	PHONEBX: '^[1-9]{2}[9]{1}[0-9]{8}$',
	SMS_CODE: '^[0-9]{6}$',
	EMAIL: '^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$',
	PIX_NAME: '^[a-zA-Z·\u00B5-\u00FF\\s]{3,100}$',
	PIX_ACCOUNT: '^[a-zA-Z0-9@.]{3,50}$',
	INVITE_CODE: "^[0-9]{5,15}$"
};
//验证不能以0开头得数字
export const isIntNum = (str: string) => {
    //  const is=	str.replace(/[^1-9]{0,1}( \d*(?:\.\d{0,2})?).*$/g,'$1');
	const reg = new RegExp('^[1-9]|[0-9]{8}$');
	return reg.test(str);
};

//验证是否数字
export const isNum = (str: string) => {
	const reg = new RegExp('^[0-9]*$');
	return reg.test(str);
};

//至少N位数字
export const isNumLessN = (str: string, n: number) => {
	const reg = new RegExp('^d{' + n.toString() + ',}$');
	return reg.test(str);
};

//N位数字
export const isNumN = (str: string, n: number) => {
	const reg = new RegExp('^d{' + n.toString() + '}$');
	return reg.test(str);
};

//M-N位数字
export const isNumMN = (str: string, m: number, n: number) => {
	const reg = new RegExp('^d{' + m.toString() + ',' + n.toString() + '}$');
	return reg.test(str);
};

//数字和26个英文字母组成
export const isLettersNum = (str: string) => {
	const reg = new RegExp('^[A-Za-z0-9]+$');
	return reg.test(str);
};

//图片验证码
export const isVerifyCode = (str: string) => {
	const reg = new RegExp(FORMAT_REG.VERIFY_CODE);
	return reg.test(str);
};

//USDT_TRC20地址
export const isUSDT_TRC20 = (str: string) => {
	const reg = new RegExp(FORMAT_REG.USDT_TRC20);
	return reg.test(str);
};
//USDT_ERC20地址
export const isUSDT_ERC20 = (str: string) => {
	const reg = new RegExp(FORMAT_REG.USDT_ERC20);
	return reg.test(str);
};

// 账号登录-用户名输入框校验 数字和26个英文字母组成 也可输入手机号
export const isLettersAccountLogin = (str: string) => {
	const reg = new RegExp(FORMAT_REG.ACCOUNT_LOGIN_USERNAME);
	return reg.test(str);
};

//登录-用户名输入框校验 数字和26个英文字母组成
export const isLettersNumAccountNameLogin = (str: string) => {
	const reg = new RegExp(FORMAT_REG.LOGIN_USERNAME);
	return reg.test(str);
};

//数字和26个英文字母组成
export const isLettersNumAccountName = (str: string) => {
	const reg = new RegExp(FORMAT_REG.USERNAME);
	return reg.test(str);
};

//邀请码
export const isInviteCode = (str: string) => {
	const reg = new RegExp(FORMAT_REG.INVITE_CODE);
	return str == "" || reg.test(str);
};

//巴西手机号
export const isPhone = (str: string) => {
	const reg = new RegExp(FORMAT_REG.PHONE);
	return reg.test(str);
};
//巴西手机号
export const isPhoneBX = (str: string) => {
	const reg = new RegExp(FORMAT_REG.PHONEBX);
	return reg.test(str);
};
//手机验证码
export const isSMSCode = (str: string) => {
	const reg = new RegExp(FORMAT_REG.SMS_CODE);
	return reg.test(str);
};

//Email验证
export const isEmail = (str: string) => {
	const reg = new RegExp(FORMAT_REG.EMAIL);
	return reg.test(str) && str.length <= 100;
};

//PIX
export const isPIX = (str: string) => {
	const reg = new RegExp(FORMAT_REG.PIX_ACCOUNT);
	return reg.test(str);
};


//PIX CPF verify
export const isCPF = (cpf: string) => {
	if (!cpf) return false;
	cpf = cpf.replaceAll('.','').replaceAll('-','');
	cpf = cpf.replace(/[^\d]+/g, '');
	// Elimina CPFs invalidos conhecidos
	if (
		cpf.length != 11 ||
		cpf == '00000000000' ||
		cpf == '11111111111' ||
		cpf == '22222222222' ||
		cpf == '33333333333' ||
		cpf == '44444444444' ||
		cpf == '55555555555' ||
		cpf == '66666666666' ||
		cpf == '77777777777' ||
		cpf == '88888888888' ||
		cpf == '99999999999'
	)
		return false;
	// Valida 1o digito
	let add = 0;
	for (let i = 0; i < 9; i++) add += parseInt(cpf.charAt(i)) * (10 - i);
	let rev = 11 - (add % 11);
	if (rev == 10 || rev == 11) rev = 0;
	if (rev != parseInt(cpf.charAt(9))) return false;
	// Valida 2o digito
	add = 0;
	for (let i = 0; i < 10; i++) add += parseInt(cpf.charAt(i)) * (11 - i);
	rev = 11 - (add % 11);
	if (rev == 10 || rev == 11) rev = 0;
	if (rev != parseInt(cpf.charAt(10))) return false;
	return true;
};

//PIX Full Name
export const isPIXFullName = (str: string) => {
	const reg = new RegExp(FORMAT_REG.PIX_NAME);
	return reg.test(str);
};
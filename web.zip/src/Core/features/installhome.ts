
export const checkCanInstall = ( callback : ()=> void) =>{
	window.addEventListener('beforeinstallprompt',(event)=> {
		event.preventDefault();
		window.deferredPrompt = event;
		callback()
	});
}


export const installApp = async ( callback : (installed : boolean)=> void) =>{
	const promptEvent = window.deferredPrompt
	if( promptEvent ){
		promptEvent.prompt();
		const { outcome } = await promptEvent.userChoice;
		if( outcome === 'accepted'){
			window.deferredPrompt = null;
			callback(true);
		}
	}else{
		callback(false);
	}
}

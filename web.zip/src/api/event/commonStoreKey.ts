export enum StoryKey {
    //当前货币类型
    CurrentCurrencyType = 'CurrentCurrencyType',
    /**切换原创控制台操控面板 */
    ChangeGamePanel = 'ChangeGamePanel',
    /**原创游戏投注返回刷新货币 */
    GameOriginalBetBack = 'GameOriginalBetBack',
    /**原创游戏进入游戏数据 */
    GameOriginalEnterGameData = 'GameOriginalEnterGameData',
    /**切换投注表单索引 */
    ChangeBetTab = 'ChangeBetTab',
    /**玩家投注 */
    PlayerBetsKey = 'PlayerBetsKey',
    /**打开搜索 */
    OpenSearchKey = 'OpenSearchKey',
    /**关闭搜索 */
    CloseSearchKey = 'CloseSearchKey',
    /**打开通知**/
    OpenNoticeKey = 'OpenNoticeKey',
    /**通知同步store**/
    GlobalNoticeKey = 'GlobalNoticeKey',
    /**刷新奖励中心**/
    GlobalRefreshBonus = 'GlobalRefreshBonus',
    /**刷新转盘**/
    GlobalRefreshSpin = 'GlobalRefreshSpin',
    /**转盘倒计时**/
    GlobalResetTimerSpin = 'GlobalResetTimerSpin',
    /**切换登录注册 */
    GlobalChangeLoginRegister = 'GlobalChangeLoginRegister',
    /**下载导航栏*/
    GlobalDownLoadBarStatus = 'GlobalDownLoadBarStatus',
    /**多语言配置 */
    GlobalLang = 'GlobalLang',
    /**主题配置 */
    GlobalTheme = 'GlobalTheme',
    /**token */
    GlobalToken = 'GlobalToken',
    /**tokenTime */
    GlobalTokenTime = 'GlobalTokenTime',
    /**是否登录 */
    GlobalLogin = 'GlobalLogin',
    /**服务器setting配置 */
    GlobalUserInfo = 'GlobalUserInfo',
    /**左侧菜单栏开关 */
    GlobalMobileLeftSiderSwitch = 'GlobalMobileLeftSiderSwitch',
    /**header高度 */
    GlobalHeaderHeight = 'GlobalHeaderHeight',
    /**刷新弹窗 */
    GlobalRefreshDialog = 'GlobalRefreshDialog',
    /**钱包刷新 */
    GlobalWalletAllPlus = 'GlobalWalletAllPlus',
    /**打开手机端mobile抽屉*/
    GlobalGameMobileDraw = 'GlobalGameMobileDraw',
    /**打开红包雨 */
    GlobalOpenRedPack = 'GlobalOpenRedPack'
}

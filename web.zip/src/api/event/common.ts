
export enum EventName {
    /**进入前台 */
    EnterForeGround = 'EnterForeGround',
    /**进入后台 */
    EnterBackGround = 'EnterBackGround',

    /**打开顶部搜索栏**/
    CLIENT_OPEN_SEARCH = 'CLIENT_OPEN_SEARCH',
    /**打开顶部搜索栏**/
    CLIENT_CLOSE_SEARCH = 'CLIENT_CLOSE_SEARCH',
    /**turn or false 状态切换**/
    CLIENT_CHANGE_STATUS = 'CLIENT_CHANGE_STATUS',
    /**打开右侧通知栏**/
    CLIENT_OPEN_NOTICE = 'CLIENT_OPEN_NOTICE',

    /**socket断线重连成功 */
    SocketRetrySuccess = 'SocketRetrySuccess',

    /**401退出Login */
    LOGIN_OUT_401 = 'LOGIN_OUT_401',

    /**111停服 */
    STOP_SERVER_111 = 'STOP_SERVER_111',

    /**错误弹窗 */
    ERROR_POP_DIALOG = 'ERROR_POP_DIALOG'
}

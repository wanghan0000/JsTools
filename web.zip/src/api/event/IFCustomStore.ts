import { CurrencyType } from "../proto/IFCommon";

export interface GameOriginalBetBack {
    /**赢取金额 */
    winAmount: number,
    /**玩家当前余额 */
    playerAmount: number,
    /**当前币种 */
    currencyType: CurrencyType,
}
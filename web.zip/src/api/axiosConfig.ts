import { AxiosTypes, ResponseTypes } from '@/Core/net/axios/index.inter';
import { ERROR_CODE, PopupDialog } from './errorCode';
// import { Md5 } from 'ts-md5';
import EventMgr from '@/utils/EventMgr';
import { EventName } from './event/common';

let serverTimeStamp;
/**获取服务器时间戳 */
export const getServerTimeStamp = () => {
  return serverTimeStamp;
}

export const getApiSign = (params) => {
  const pobj = params ? params : {};
  // const sortedKeys = Object.entries(pobj).sort((a, b) => {
  //   return a[0].localeCompare(b[0]);
  // });
  // let signStr = '';
  // sortedKeys.forEach((item) => {
  //   if (item[1] !== '') {
  //     if (Array.isArray(item[1])) {
  //       signStr += item[0] + '=[' + item[1] + ']&';
  //     } else {
  //       signStr += item[0] + '=' + item[1] + '&';
  //     }
  //   }
  // });
  //signStr = Md5.hashStr(signStr + 'key=xxxxxxxxxxxxxxxxxxx').toUpperCase();
  //Object.assign(pobj,{ 'sign':signStr})
  return pobj;
};

export const config = {
  domainName: process.env.REACT_APP_MAIN_API,
  timeout: 15000,
};

export const onDynamicHeader = () => {
  const token = localStorage.getItem('authToken') || '';
  const headers = {
    lang: `${localStorage.getItem('i18nextLng')}`,
    channel: process.env.REACT_APP_CHANNEL,
    Authorization: `${token ? `Bearer ${token}` : ''}`,
  };
  return headers;
};

export const onHandleResponseData = <T>(response: AxiosTypes<ResponseTypes<T>>) => {
  return new Promise<any>((resolve, reject) => {
    const data = response.data;
    if(response?.['headers']?.['date']){
      serverTimeStamp = response['headers']['date']
    }
    if (PopupDialog.includes(data?.code)) {
      EventMgr.getInstance().dispatchEvent(EventName.ERROR_POP_DIALOG, response);
    }

    if (data.code != '200') {
      if (data.code) {
        if (data.code === '111') {
          EventMgr.getInstance().dispatchEvent(EventName.STOP_SERVER_111);
        }

        if (data.code == '401') {
          EventMgr.getInstance().dispatchEvent(EventName.LOGIN_OUT_401);
        }

        const errorCode = data.code;
        data.code = dealDataErrorCode(data.code);
        reject({ ...data, errorCode });
      } else {
        reject({ code: 'ERROR_DATA' });
      }
    } else {
      resolve(data.data === null || data.data === undefined ? {} : data.data);
    }
  });
};
const dealDataErrorCode = (code) => {
  if (ERROR_CODE.includes(`ERROR_${code}`)) {
    return `ERROR_${code}`;
  } else {
    return 'ERROR_999';
  }
};

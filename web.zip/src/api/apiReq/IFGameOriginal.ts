export interface IFBetInfoReq {
    /**	投注ID */
    betId: string,
    /**游戏ID */
    gameId: number,
    /**平台 */
    platformCode: string,
    /**投注时间 */
    betTime: number

}

export interface IFUPdateSeedsReq {
    /**当前使用种子 */
    currentSeed: string,
    /**随机数 */
    nonce: number
    /**游戏id */
    gameId: number
}
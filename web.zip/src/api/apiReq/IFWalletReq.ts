/* eslint-disable @typescript-eslint/no-empty-interface */
/* 
     * 玩家钱包初始化请求参数
     */
export interface IFInitWalletReq{}
/* 
     * 钱包切换请求参数
     */
export interface IFInitWalletSwitchReq{
    
     /* 
       * 钱包币种
       */
     currencyType?:string
  }

/* --------------------------------------------------------------初始化 充值 */
 /* 
* 初始化:加密货币（充值）：请求参数 
*/
export interface IFInitWalletRechargeCryptoReq {
   /* 
     * 钱包币种
     */
   currencyType?:string
    /* 
     * 设备类型(1:ios, 2:android, 3:双端)
     */
   device?:number
}
 /* 
* 初始化:法币支付（充值）：请求参数
*/
export interface IFInitWalletRechargeFlatReq{
   /* 
     * 钱包币种
     */
   currencyType?:string
    /* 
     * 设备类型(1:ios, 2:android, 3:双端)
     */
   device?:number
}


 
/* 
     * 充值:加密货币进行请求参数
     */
export interface IFWalletRechargeCryptoReq{
     /* 
      * 钱包币种
      */
     currencyType?:string
     /* 
      * 充值金额	
      */
     money?:number
    /* 
      * 支付类型码
      */
    payCode?:string
 }

/* 
     充值:法币进行充值请求参数
     */
export interface IFWalletRechargeFlatReq{
     /* 
      * 钱包币种
      */
     currencyType?:string
     /* 
      * 充值金额	
      */
     money?:number
    /* 
      * 支付类型码
      */
    payCode?:string
 }

/* --------------------------------------------------------------提现 */
 
  /* 
* 提现初始化请求参数 :加密货币（提现）
*/
export interface IFInitWalletWithdrawCryptoReq {
     /* 
       * 钱包币种
       */
     currencyType?:string
    /* 
     * 设备类型(1:ios, 2:android, 3:双端)
     */
    device?:number
  }
   /* 
  * 提现初始化请求参数:法币支付（提现）
  */
  export interface IFInitWalletWithdrawFlatReq{
     /* 
       * 钱包币种
       */
     currencyType?:string
     /* 
     * 设备类型(1:ios, 2:android, 3:双端)
     */
   device?:number
  }



  /*-----------------------------------------------------提现（请求）参数- */
   /* 
     加密货币提现请求参数
     */
export interface IFWalletWithdrawCryptoReq{
   /* 
      * 提款地址
      */
   address?:string
   /* 
    * 币种	
    */
   currencyType?:string
   /* 
      * 充值金额	
      */
   money?:number
   /* 
     * 网络类型
     */
   networkType?:string
 }

   /* 
     法币提现请求参数
     */
     export interface IFWalletWithdrawFlatReq{
         
          /* 
             * 代付商户需要的账户相关参数，json格式，具体字段以商户需要为准
             */
          accountInfo?:string
          /* 
           * 币种	
           */
          currencyType?:string
          /* 
             * 金额	
             */
          money?:number
          /* 
            * 商户ID
            */
          merchantId?:string
        }

   /*-----------------------------------------------------兑换货币请求内容- */
         /* 
          * 兑换钱包，两种币种互转
     */
export interface IFWalletExchangeReq{
     /* 
      * 钱包币种（原钱包）
      */
     sourceCurrencyType?:string
     /* 
      * 	钱包币种（目标钱包）
      */
     targetCurrencyType?:string
     /* 
             * 兑换金额 （原钱包）	
             */
     sourceMoney?:number
     /* 
       * 兑换金额 （目标钱包）
       */
     targetMoney?:number
   
 }



 /* 
     查询汇率：指定货币的配置汇率
     */
export interface IFWalletRateReq{
     /* 
      * 商户ID
      */
     baseCurrency?:string
     /* 
      * 商户名称	
      */
     targetCurrency?:string
   
 }

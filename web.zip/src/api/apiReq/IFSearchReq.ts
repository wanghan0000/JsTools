
export interface IFSearchReq {
    /**
     * 搜索关键字
     */
    keyword: string,

}

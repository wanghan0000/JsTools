export interface IFForgetPasswordReq {
  /**
   * 国码
   */
  countryCode: number;
  /**
   * 手机号码
   */
  mobile: string;
  /**
   * 发送类型
   */
  sendType: string;
  /**
   * 短信验证码
   */
  smsCode: string;
}

export interface IFForgetSetPasswordReq {
  /**
   * 国码
   */
  countryCode?: number;
  /**
   * 手机号码
   */
  mobile?: string;
  /**
   * 再次输入
   */
  newAgain?: string;
  /**
   * 新密码
   */
  newPwd?: string;
  /**
   * 短信验证码
   */
  smsCode?: string;

  /* 邮箱 */
  email?: string;

  /* 类型 */
  type?: string;
  /* 验证码 */
  emailCode?: string;
}

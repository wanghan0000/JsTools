export interface IFEnterGameReq {
    //设备
    device:string,
    //游戏ID
    gameId:number,
    //钱包币种
    walletCurrency:string,
    //平台
    webPlatform:string,
    //游戏币种
    currencyType?: string
}

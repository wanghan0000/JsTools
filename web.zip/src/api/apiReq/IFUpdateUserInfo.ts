
export interface IFUpdateUserInfo {
    /**
    * 国码
    */
    countryCode?: number,
    /**
     * 邮箱
     */
    email?: string
    /**
    * 手机号
    */
    mobile?: string
    /**
     * 短信验证码
     */
    smsCode?:string
    /**
     * 邮件验证码
     */
     emailCode?:string
         /**
     * 发送验证码业务类型
     */
     type?:string
     
}


export interface IFUpdateUserPassword {
    /**
    * 确认新密码
    */
    newAgain?: string,
    /**
     * 新密码
     */
    newPwd?: string
    /**
    * 旧密码
    */
    oldPwd?: string
}
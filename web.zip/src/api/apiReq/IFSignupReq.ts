
export interface IFSignupBase {
    /**
    * 图形验证码
    */
    code?: string,
    /**
     * 图形验证码uuid
     */
    uuid?: string
    /**
    * 代理挂靠id
    */
    pid?: string
    /**
     * 渠道
     */
    channle?: string
    /**
    * 邀请码  玩家rid
    */
    inviteCode?: string
    /**
    * 注册类型
    */
    type: string,

    /**
     * facebook cookie 用于服务器事件埋点
     */
    fbc?: any,
    fbp?: any,
    /**设备类型 1ios-h5 2Android-h5 3pc 4ios-app 5android-app*/
    device: number
}

export interface IFSignupAccountReq extends IFSignupBase {
    /**
     * 用户名 账号注册需要填写
     */
    username: string,
    /**
     * 账号注册需要填写
     */
    password: string,
}

export interface IFSignupPhoneReq extends IFSignupBase {
    /**
     * 手机号码
     */
    mobile: string,
    /**
     * 短信验证码
     */
    smsCode: string
    /**
     * 国码
     */
    countryCode: number,
    /**
     * 密码
     */
    password: string,
}
export interface IFSignupEmailReq extends IFSignupBase {
    /**
     * 邮箱验证码
     */
    emailCode: string,
    /**
      * 密码
      */
    password: string,

    /**
     * 用户名
     */
    username: string
}



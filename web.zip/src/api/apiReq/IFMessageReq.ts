export interface IFMessageReq {
    //
    isAsc?:string,
    //
    orderByColumn?: string,
    //当前记录起始索引
    pageNum?:number,
    //页码
    pageSize?:number,
    //
    reasonable?:boolean,
}

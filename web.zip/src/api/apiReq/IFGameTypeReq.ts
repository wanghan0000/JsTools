//platformCode 和 gameType 不能同时为空）
export interface IFGameTypeReq {
  /**
   * 页码（默认1）
   */
  page: number;
  /**
   * 查询条数（默认40）
   */
  pageSize: number;

  /**
   * 搜索关键字  游戏分类为 1区块链 ，2 棋牌，4 老虎机 ，5 捕鱼，6体育，7电竞  时必传  8原创
   */
  gameType?: number;
  /**
   * 平台code
   */
  platformCode?: number;
  /**
   * 排序方式 0 默认 1 A-Z 2 Z-A
   */
  isAzSort?: number;

  /* 过滤 */
  platformCodes?: string[];
}

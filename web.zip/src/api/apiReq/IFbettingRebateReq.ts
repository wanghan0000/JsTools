export interface IPropsReq {
  /* 活动ID */
  activityId: string | number;
}

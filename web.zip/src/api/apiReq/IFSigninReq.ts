
export interface IFSigninBase {
    /**
    * 图形验证码
    */
    code?: string,
    /**
     * 图形验证码uuid
     */
    uuid?: string
    /**
    * 代理挂靠id
    */
    pid?: string
    /**
     * 邀请码  玩家rid
     */
    inviteCode?: string
    /**
     * 渠道
     */
    channle?: string
    /**
     * google验证码
     */
    googleAuthCode?: string
    /**
     * 登录类型
     */
    loginType?: number
}

export interface IFSigninAccountReq extends  IFSigninBase {
    /**
     * 用户名 账号注册需要填写
     */
    username: string,
    /**
     * 账号注册需要填写
     */
    password: string,
}

export interface IFSigninPhoneReq extends IFSigninBase {
    /**
     * 手机号码
     */
    mobile?: string,
    /**
     * 短信验证码
     */
    smsCode?: string
    /**
     * 国码
     */
    countryCode: number,
    /**
     * 密码
     */
    password: string,
    /**
     * 用户名
     */
    username?: string
}


export interface IFThirdSignupReq extends IFSigninBase {
    /**
     * google token
     */
    googleCode: string,
    /**
     * window.location.origin
     */
    googleUri: string,
    /**
     * 三方登录验证
     */
    thirdSign?: string,
    /**
     * 登录平台
     */
    os:string
}



export interface IFSendSMSCodeReq {
    /**
    * 手机号码
    */
    mobile: string,
    /**
     * 注册场景
     */
    type: string
    /**
    * 国码
    */
    countryCode: string
}

export interface IFSendEmailCodeReq {
    /**
     * 邮箱
     */
    email: string
    /**
    * 注册场景
    */
    type: string
}
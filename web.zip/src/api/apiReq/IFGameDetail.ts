export interface IFGameDetailReq {
    /**游戏ID */
    gameId: number,
}
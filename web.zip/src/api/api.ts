/*
 * @Author: ilal 1
 * @Date: 2023-05-10 14:34:18
 * @LastEditors: ilal 1
 * @LastEditTime: 2023-05-13 17:51:35
 * @FilePath: \web 2.0\src\api\api.ts
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import { BaseAxios } from '@/Core/net/axios';
import qs from 'qs';
import { config, getApiSign, onDynamicHeader, onHandleResponseData } from './axiosConfig';
import useSWR from 'swr';
import useSWRMutation from 'swr/mutation';
import { useGlobalState } from '@/store/commonStore';
import { langArray } from '@/Core/default';
import i18n from '@/Core/i18n';

const axios = new BaseAxios({
  requestConfig: config,
  onDynamicHeader: onDynamicHeader,
  onHandleResponseData: onHandleResponseData,
  handleSign: getApiSign,
});

const handlerLang = (settingInfo) => {
  const langInfo = settingInfo?.languageConfig?.language.split(',');
  const newlangArr = langArray.filter((item) => langInfo?.includes(item.id));
  const defaultLang = newlangArr.filter((item) => item.id === String(settingInfo?.languageConfig?.default_language))[0];
  const newLangarrMap = newlangArr.map((i) => i.lang);
  window.newLangarrMap = newLangarrMap;
  /* 有默认语言 */
  if (defaultLang) {
    /* 第一次进网站的语言 */
    if (localStorage.getItem('i18nextLng') === 'fallbackLng') {
      i18n.init({
        fallbackLng: defaultLang ? defaultLang?.lang : newLangarrMap[0],
      });
      localStorage.setItem('i18nextLng', defaultLang ? defaultLang?.lang : newLangarrMap[0]);
      i18n.changeLanguage(defaultLang ? defaultLang?.lang : newLangarrMap[0]);
      window.defaultLang = defaultLang.lang;
    } else {
      const currentLang = localStorage.getItem('i18nextLng');
      const filterLang = newlangArr.findIndex((v) => v.lang === currentLang);
      /* 判断当前是否支持该语言 */
      if (filterLang !== -1) {
        i18n.init({
          fallbackLng: currentLang,
        });
        localStorage.setItem('i18nextLng', currentLang);
        i18n.changeLanguage(currentLang);
        window.defaultLang = currentLang;
      } else {
        i18n.init({
          fallbackLng: defaultLang ? defaultLang?.lang : newLangarrMap[0],
        });
        localStorage.setItem('i18nextLng', defaultLang ? defaultLang?.lang : newLangarrMap[0]);
        i18n.changeLanguage(defaultLang ? defaultLang?.lang : newLangarrMap[0]);
        window.defaultLang = defaultLang.lang;
      }
    }
  } else {
    i18n.init({
      fallbackLng: newLangarrMap[0],
    });
    window.defaultLang = newLangarrMap[0];
    localStorage.setItem('i18nextLng', newLangarrMap[0]);
    i18n.changeLanguage(newLangarrMap[0]);
  }
};

export const fetcher = <T>(API: any, { arg }: any): Promise<T> => {
  const { formData = false } = API;
  let params = arg;
  if (formData) {
    params = new URLSearchParams(qs.stringify(arg));
  }
  return axios.request<T | any>(API, params).then((res) => {
    if (API.path.includes('api/index/setting') && res) {
      window.cdnUrl = res?.cdnUrl;
      window.currencyPrecision = res?.currencyPrecision;
      handlerLang(res);
    }
    return res;
  });
};

export interface SWROptions {
  //缓存有效期
  dedupingInterval?: number;
  onSuccess?: (data, key, config) => void;
  /**当节点挂载的时候是否自动请求 */
  revalidateOnMount?: boolean;
}

export interface APIConfig {
  path: string;
  type?: string;
  needLogin?: boolean;
  formData?: boolean;
  baseURL?: string;
}

export const useAPI = <T, P>(API: APIConfig, args?: P, options?: SWROptions) => {
  const params = { arg: args };
  const { needLogin } = API;
  const { isLogin } = useGlobalState();
  const { revalidateOnMount = true } = options || {};

  const { data, isLoading, isValidating, error, mutate } = useSWR<T>(
    (needLogin ? isLogin : true) ? [API, params] : null,
    <T>([API, arg]) => fetcher<T>(API, { ...params }),
    { ...options, revalidateOnMount }
  );

  const revalidate = (data?: any, options?: { revalidate?: boolean }) => {
    mutate(data, options);
  };
  return { data, isLoading, isValidating, error, mutate, revalidate };
};

export const useAPIMutation = <T, P>(API: APIConfig, options?) => {
  return useSWRMutation(
    API,
    (API, arg: { arg: P }) => {
      return fetcher<T>(API, { ...arg });
    },
    options
  );
};

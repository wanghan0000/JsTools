import { CurrencyType } from "../proto/IFCommon"

export interface IFturntablesItems {
  //	奖励编号
  award?: number
   //	数量（金额）
   num?: number
   //	币种
   currency?: CurrencyType
}

export interface IFturntables {

  //	是否开启
  isOpen?: boolean
   //	倒计时时间错
  resetTime?:string
  //	转盘类型
  type?: number
   //	开启等级
   vipLevel?: number
   //	转盘名称
   name?: string
   //奖励信息
   items?:IFturntablesItems[]
}


/**
 *获取转盘信息
 */
export interface IFWheelInfoRsp {/**
* 	用户剩余次数
*/
   remainingTimes?: number
  /**
    * 	转盘列表信息
    */
   turntables?: IFturntables[]
  /**
   * 	用户当前所属转盘(空的情况代表用户没有达到开启转盘等级)
   */
   userCurrentTurntable?: number

 
}

/**
 * 抽奖结果
 */
export interface IFWheelResultRsp {
  /**
 * 奖励编号
 */
   award?: number;
   /**
 * 奖励剩余次数
 */
    remainingTimes?: number;
     /**
 * 转盘倒计时：string类型的时间戳格式
 */
    resetTime?:string

    //中奖币种
    currency?:CurrencyType  

    //中奖金额
    amount?:number  

}
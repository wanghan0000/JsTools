export interface IFActivityDetail {
    /**
     * 支付宝账号
     */
    activityType:number ,
    /**
     * 支付宝名字
     */
    id:number,
    /**
     * 是否弹出
     */
    isPop: number,
    /**
     * 跳转
     */
    jumpTo: string,
    /**
     * 跳转类型
     */
    jumpType: number,
    /**
     * 图片地址
     */
    pic: string,
    /**
     * 
     */
    popPic: string,
    /**
     * 弹出类型
     */
    popType: string,
    /**
     * 规则
     */
    rule: string,
    /**
     * 排序
     */
    sort: number,
    /**
     * 标题
     */
    titleL: string
    /**
     * 类型
     */
    type: number
}


/**登录弹窗数据 */
export interface LoginPopInfo {
    /**活动开始时间 */
    beginTime?: number
    /**活动创建时间 */
    createTime?: number
    /**活动结束时间 */
    endTime?: number
    /**活动内容 */
    content?: string
    /**活动id */
    id: number
    /**活动排序sort */
    sort?: number
    /**活动状态status */
    status?: number
    /**活动标题 */
    title: string
    /**更新时间 */
    updateTime: number
}
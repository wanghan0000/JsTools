export interface IFEmpty{
    
} 
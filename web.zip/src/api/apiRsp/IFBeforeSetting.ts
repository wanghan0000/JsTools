type FlagType = 'open' | 'close' | '';
export interface IFBeforeSetting {
  /**
   * 账号登录开关
   */
  accountLogonFlag: FlagType;
  /**
   * 账号注册开关
   */
  accountRegisterFlag: FlagType;
  /**
   * 邮箱登录开关
   */
  emailLogonFlag: FlagType;
  /**
   * 邮箱注册开关
   */
  emailRegisterFlag: FlagType;
  /**
   * Android 下载地址
   */
  androidDown: string;
  /**
   * cdn
   */
  cdnUrl: string;
  /**
   * 客服
   */
  customer: string;
  /**
   * ios下载
   */
  iosDown: string;
  /**
   * ios超级签下载
   */
  iosSuperSignDown: string;
  /**
   * 登录图形验证码开关
   * 手机索引：0  邮箱索引：1  用户名索引：2
   * 0关闭 1开启
   */
  logVCode: number[];
  /**
   * 手机号登录开关
   */
  phoneLogonFlag: FlagType;
  /**
   * 手机号注册开关
   */
  phoneRegisterFlag: FlagType;
  /**
   * 注册图形验证码开关
   */
  regVCode: number[];
  /**
   * 小飞机客服链接
   */
  telegram: string | null;
  /**
   * whatsapp客服链接
   */
  whatsapp: string | null;
  /**
   * 客服连接
   */
  facebook: string | null;
  /**
   * 停服信息
   */
  wnoticeVO: {
    noticeComment: string;
  } | null;

  /**
   * token地址
   */
  wsAddr: string;

  /* 全民代理 */

  agentSwitch: string;

  /**国码 */
  countryCodes: number[];

  /* 多语言配置 */
  languageConfig: any;

  /* telegramChannel */

  telegramChannel: string | null;

  /* telegramGroup */
  telegramGroup: string | null;

  facebookChannel: string | null;

  telegramLogin: string[] | null;

  appVersion: string;

  /**fun支持平台 */
  plats4FUN: string[];

  lockCurrency: string;

  //是否开启邀请活动
  inviteSwitch: boolean;
}

export interface Airpay {
  /**
   * 支付宝账号
   */
  zfbAccount: string | null;
  /**
   * 支付宝名字
   */
  zfbAccountName: string | null;
}

export interface Bank {
  /**
   * 银行卡账号
   */
  bankAccount: string | null;
  /**
   * 银行卡账号名字
   */
  bankAccountName: string | null;
  /**
   * 银行卡名字
   */
  bankName: string;
}

export interface Pix {
  /**
   * pix账号
   */
  pixAccount: string | null;
  pixCpf: string | null;
  pixFullName: string | null;
  pixType: string | null;
}

export interface Usdt {
  walletAddress: string;
}

export interface CloudPayMobile {
  cloudPayMobile: string;
}

export interface WalletInfo {
  /**
   * 支付宝
   */
  airpay: Airpay;
  /**
   * 银行卡
   */
  bank: Bank;
  /**
   * pix
   */
  pix: Pix;
  /**
   * usdt
   */
  usdt: Usdt;
  /**
   * 云支付
   */
  yunzf: CloudPayMobile;
}

export interface IFUserInfo {
  /**
   * 余额
   */
  balance?: number;
  /**
   * 钱包绑定详情
   */
  bind?: WalletInfo;
  /**
   * 国码
   */
  countryCode?: string;
  /**
   * 电子邮件
   */
  email?: string;
  /**
   * 电话号码
   */
  mobile?: string;
  /**
   * 昵称
   */
  nickName?: string;
  /**
   * 设置密码 1 已设置 other 未设置
   */
  setPwd?: number;
  /**
   * 用户Id
   */
  userId?: number;
  /**
   * 用户名
   */
  userName?: string;
  /**
   * 是否有首充
   */
  isFirstRecharge?: boolean;
  /**
   * 是否绑定邮箱
   */
  emailStatus?: boolean;
  /**
   * 是否绑定google邮箱
   */
  setGoogleAuth?: boolean;
  /* 是否可以修改邮箱 */
  isUserNameEdit?: any;
}

export interface IFSigninRsp {
  userId: number;
  /**
   * token
   */
  token: string;
  /**
   * 用户信息
   */
  userInfo: IFUserInfo;
}

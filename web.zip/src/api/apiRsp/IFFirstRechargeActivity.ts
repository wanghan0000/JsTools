/* 首充活动 */

import { CurrencyType } from '../proto/IFCommon';

export interface IFfirstRechargeActivity {
  currentTimes: number;
  endTime: string;
  rebateRate: number;
  timesRuleList: {
    items: {
      rebateRate: number;
      rechargeAmount: number;
      rechargeAmountCurrencyType: CurrencyType;
    }[];
    limitRebateAmount: number;
    limitRebateAmountCurrencyType: CurrencyType;
    maxRebateRate: number;
    times: number;
  }[];
}

/* 首充活动详情 */

export interface IFfirstRechargeActivityDetail {
  items: {
    rebateRate: number;
    rechargeAmount: number;
    rechargeAmountCurrencyType: CurrencyType;
  }[];
  limitRebateAmount: number;
  limitRebateAmountCurrencyType: CurrencyType;
  maxRebateRate: number;
  times: number;
}

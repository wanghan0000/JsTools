import { CurrencyType } from '../proto/IFCommon';

export interface InviteDetailItem {
  /**id */
  id: number,
  /**打码倍数 */
  betTimes: number,
  /**邀请人数 */
  rebateRatio: number,
  /**奖励金额 */
  rechargeAmount: number,


  /**自定义 */
  min: number,
  max: number,
  currency: string;
}

// 邀请好友
export interface IFInviteData {
  awardMoney: number;
  awardMoneyCurrencyType: CurrencyType;
  inviteCode: string;
  inviteNum: number;
  inviteUrl: string;
  rebateMoney: number;
  rebateMoneyCurrencyType: CurrencyType;
  showAward: number;
  showAwardCurrencyType: CurrencyType;
  showRebate: number;
  total: number;


  totalCurrencyType: CurrencyType;

  inviteGiftConfig: {
    inviteDetailList:InviteDetailItem[];
    /**最低投注额 */
    minBetAmount: number,
    /**最低充值金额额 */
    minRechargeAmount: number,
    /**返利币种 */
    rebateCurrencyType: string,
    /**充值币种 */
    rechargeCurrencyType: string
  }
  
}

/* 仪表盘 邀请码列表 */
export interface IFInvitesCode {
  createTime: string;
  inviteCode: string;
  inviteNum: number;
  inviteUrl: string;
  showRebate: number;
  total: number;
}

/* 仪表盘 佣金奖励领取历史记录 */

export interface IFSearchInviteRewardHistory {
  pageInfo: {
    records: {
      currencyType: any;
      receivedMoney: any;
      receivedMoneyCurrencyType: CurrencyType;
      createTime: string;
      receivedStatus: any;
    }[];
    total: number;
  };
}

/* 仪表盘 佣金奖励列表 */
export interface IFRebateList {
  rebates: {
    records: {
      currencyType: any;
      total: number;
      totalCurrencyType: CurrencyType;
      rebateMoney: any;
      rebateMoneyCurrencyType: CurrencyType;
      receiveFlag: any;
      receiveFlagCurrencyType: CurrencyType;
    }[];
    total: number;
  };
  receivedRebateMoney: number;
  currencyType: CurrencyType;
}

/* 仪表盘 好友管理列表 */
export interface IFfriendList {
  directInviteNum: any;
  indirectInviteNum: any;
  inviteNum: any;
  page: {
    current: number;
    o: any;
    records: {
      userName: string;
      betSum: number;
      betSumCurrencyType: string;
      total: number;
      totalCurrencyType: string;
      teamCount: any;
      registerDate: any;
      inviteCode: any;
      status: any;
    }[];
    size: number;
    total: number;
  };
}

/* 仪表盘 邀请奖励列表 */

export interface IFInvitesAward {
  awards: {
    current: number;
    o: any;
    records: {
      userName: string;
      userVipLevel: any;
      total: any;
      totalCurrencyType: CurrencyType;
      registerTime: any;
      inviteCode: any;
      loginStatus: any;
    }[];
    size: number;
    total: number;
  }[];
  awardMoney: number;
  awardMoneyCurrencyType: CurrencyType;
  lockedAwardMoney: number;
  lockedAwardMoneyCurrencyType: CurrencyType;
  receivedAwardMoney: number;
  receivedAwardMoneyCurrencyType: CurrencyType;
}

/* 会员基本信息 */
export interface IFinviteInfoData {
  awardMoney: number;
  awardMoneyCurrency: string;
  inviteCode: string;
  inviteNum: number;
  inviteUrl: string;
  rebateMoney: number;
  rebateMoneyCurrency: string;
  showAward: number;
  showRebate: number;
  total: number;
  awardMoneyCurrencyType: CurrencyType;
  rebateMoneyCurrencyType: CurrencyType;
  showAwardCurrencyType: CurrencyType;
  totalCurrencyType: CurrencyType;
}

/* 全民代理基本信息 */

export interface IFinviteInfoDataProxy {
  awardMoney: number;
  awardMoneyCurrencyType: CurrencyType;
  directInviteNum: number;
  indirectInviteNum: number;
  inviteCode: string;
  inviteRebateMoney: number;
  inviteRebateMoneyCurrencyType: CurrencyType;
  inviteUrl: string;
  rebateAwardMoney: number;
  rebateAwardMoneyCurrencyType: CurrencyType;
  rebateMoney: number;
  rebateMoneyCurrencyType: CurrencyType;
  showAward: number;
  showAwardCurrencyType: CurrencyType;
  showRebate: number;
}

/* 邀请好友规则 */

export interface IFInviteAwardRule {
  levels: {
    betSum: number;
    level: number;
    rankId: number;
    unlockMoney: number;
    currencyType: CurrencyType;
  }[];
  total: number;
  // 币种
  currencyType: CurrencyType;
}

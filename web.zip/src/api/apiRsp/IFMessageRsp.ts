export interface noticeItem {
    //id
    id:number;
    //标题
    title:string;
    //是否已读
    alreadyRead:boolean;
    //内容
    content:string;
    //时间
    sendTime:string;
}
export interface IFMessageCountRsp {
    //已读邮件数
    read:number;
    //未读邮件数
    unread:number
}
export interface IFMessageRsp {
    //消息列表
    records:Array<noticeItem>;
    //总数
    total:number
}


export interface IFSearchRsp{
    //进入游戏金币最低限制
    goldRequire: number;
    //平台游戏id
    id: number;
    //游戏名
    name: string;
    //平台编码: at, tg, tg
    platformCode: string;
    //平台ID
    platformId: number;
    //平台名称: AT平台, PB平台, IM平台
    platformName: string;
    //状态 1 正常 ，2下架 ，3 维护 4 敬请期待
    status: number;
    //游戏分类 0 全部， 1区块链 ，2 对战场 ，3百人场，4 老虎机 ，5 捕鱼
    type: Array<string>;
}

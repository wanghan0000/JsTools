import { ReactNode } from "react"
import { CurrencyType } from "../proto/IFCommon"

/**
 *玩家VIP等级信息
 */
export interface IFVipInfoRsp {/**
* 	用户ID
*/
  usrId?: string
  /**
    * 	用户名字
    */
  userName?: string
  /**
   * 	用户当前等级
   */
  level: number
  /**
   * 	用户开启VIP客服等级
   */
   lockLevel: number
   /**
   * 	vip客服链接
   */
    customerServerUrl: string
  /**
   * 		当前等级总经验
   */
  levelTotalExp: number
  /**
 * 下一等级
 */
  nextLevel: number
  /**
   * 	下一等级总经验
   */
  nextLevelTotalExp: number
  /**
* 	当前段位ID
*/
  rankId: number
  /**
   * 	当前段位名称
   */
  rankTitle: string
  /**
* 	用户当前总经验
*/
  totalExp: number
  rankSrc?: ReactNode

  currencyType: CurrencyType
}

interface IFBenefits {
  rankSrc?: ReactNode
  //	奖励编号 (1:晋级礼金 2：每日转盘 3：周奖励 4:月奖励 5:投注返利 6：金币农场 7：神秘宝箱 
  benefitId?:number
  //	奖励信息
  benefitName?: string
  //	奖励开启等级
  startLevel?: number
}
/**
 * 段位信息
 */
export interface IFVipRanksRsp {
  /**
 * 段位ID 
 */
  rankId: number;
  /**
   * 	段位名称
   */
  rankTitle: string;
  /**
  * 等级范围（取段位最小等级和最大等级）：[1, 10] 
  */
  levelRange: number[];
  /**
   * 		等级范围内的奖励内容
   */
  benefits: IFBenefits[];

  rankSrc?: ReactNode
  
}
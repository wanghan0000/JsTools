import { CurrencyType } from '../proto/IFCommon';

export interface IFWalletRsp {
  all: IFInitWalletRsp[],
  swap: IFInitWalletRsp[],
  flat: IFInitWalletRsp[],
  crypto: IFInitWalletRsp[]
}
/*
 * 响应内容：玩家钱包初始化
 */
export interface IFInitWalletRsp {
  /*
   * 钱包余额(单位: 元 * 100 000)
   */
  balance?: number;
  /*
   * 钱包币种
   */
  currencyType?: CurrencyType;
  /*
   * 是否默认币种：true为是；false或空值为非默认币种
   */
  defaultCurrency?: boolean | null;
  /**
   * 币种币种大类：1 加密货币 2 法币
   */
  currencyCategory?: number;

  /**游戏余额 */
  gameBalance?: number;

  /**锁定币 */
  lockMoney?: number | null;

  /**自定义字段 */
  allBalance?: number;

  /* 是否是平台币 */
  isPlatform?: boolean;
}
/*
 *响应内容： 钱包切换
 */

/* 
/*--------------------------------------------------------------充值（初始化）响应内容- */
export interface IFpayParams {
  /*
   * 定额 ： 1-定额 2-非定额
   */
  decide?: number;

  /*
   * 档位（定额面值 如50、100、200）
   */
  gears?: string[];
  /*
   * 最大充值金额
   */
  max?: number;
  /*
   * 最小充值金额
   */
  min?: number;

  /*
   * 支付类型码
   */
  payCode?: string;
  /*
   * 支付类型名称
   */
  payName?: string;
  /*
   * 自定义面值带返利比例类型
   */
  custGears?: { gear: string; rate: number; rebateRate: any }[];
  limitRebateAmount?: any;
  limitRebateAmountCurrencyType?: any;
  rebateRuleItems?: any;
  rebateRuleItemsNew?: any;
  /**
 * 自定义返利规则明细
 */
  accountRebateRule?: IFRebateRule[];
  /**自定义转换汇率 */
  currencyRateInfo?: {
    baseRate: IFExchangeRate;
    rates: IFExchangeRate[]
  }
}

export interface IFrebateRuleItems {
  //返利比例（%）
  rebateRate?: number;
  //	充值金额
  rechargeAmount?: string;
}
/*
 * 充值初始化响应内容-：加密货币支付（充值）
 */
export interface IFInitWalletRechargeCryptoRsp {
  /*
   * 定额 ： 1-定额 2-非定额
   */
  decide?: number;

  /*
   * 档位（定额面值 如50、100、200）
   */
  gears?: string[];
  /*
   * 最大充值金额
   */
  max?: number;
  /*
   * 最小充值金额
   */
  min?: number;
  /*
   * 支付类型码
   */
  payCode?: string;
  /*
   * 自定义面值带返利比例类型
   */
  custGears?: { gear: string; rate: number; rebateRate?: any }[];
  /*
   * 自定义返利规则明细
   */
  rebateRuleItems?: IFrebateRuleItems[];
  limitRebateAmount?: any;
  limitRebateAmountCurrencyType?: any;
}
export interface IFRebateRule {
  //返利比例（%）
  rebateRate: number;
  //充值币种,
  rechargeCurrencyType: string;
  //最低充值金额满足条件
  minRechargeAmount: number;
  //返利币种
  rebateCurrencyType: string
}
export interface IFExchangeRate {
  //货币类型
  currencyType: string;
  //{'usd': '0.20000', 'usdt':'0.20000'}
  rate: any;
}
/*
 * 充值初始化响应内容：法币支付（充值）
 */
export interface IFInitWalletRechargeFlatRsp {
  payParams?: IFpayParams[];
  rebateRuleItems?: IFrebateRuleItems[];
  limitRebateAmount?: any;
  limitRebateAmountCurrencyType?: any;
  //返利规则
  accountRebateRule: IFRebateRule[];
  //返利汇率
  currencyRateInfo: {
    baseRate: IFExchangeRate;
    rates: IFExchangeRate[]
  }
}

/*-----------------------------------------------------充值（请求）响应内容- */
/*
 *充值响应内容： 加密货币充值
 */
export interface IFWalletRechargeCryptoRsp {
  /*
   * 加密货币支付URL
   */
  payUrl?: string;
}
/*
 *充值响应内容： 法币充值
 */
export interface IFWalletRechargeFlatRsp {
  /*
   * 法币支付URL
   */
  payUrl?: string;
}

/*-----------------------------------------------------提现（初始化）响应内容- */

/*
 * 提现初始化响应内容:加密货币进行提现响应内容
 */
export interface IFInitWalletWithdrawCryptoRsp {
  /*
   * 行政费
   */
  adminFee?: number;
  /*
   * 加密货币网络类型
   */
  networkType?: string;

  /*
   * 单次提现最高金额
   */
  singleMaximumCoin?: number;
  /*
   * 单次提现最低金额
   */
  singleMinimumCoin?: number;
  /*
   * 提现手续费比例：百分数
   */
  withdrawalCommission?: number;
}

/* 
    提现初始化响应内容:法币进行提现请求参数
    */
export interface IFInitWalletWithdrawFlatRsp {
  /*
   * 行政费
   */
  adminFee?: number;
  /*
   * 商户ID
   */
  merchantId?: string;
  /*
   * 商户名称
   */
  merchantName?: number;
  /*
   * 下拉字段对应的选项值，key为商户对接参数字段名，value是可支持的选项值(以,分割)，如：{"accountType","CPF,EMAIL,PHONE"}
   */
  options?: {
    accountType?: string;
  };
  /*
   * 单次提现最高金额
   */
  singleMaximumCoin?: number;
  /*
   * 单次提现最低金额
   */
  singleMinimumCoin?: number;
  /*
   * 提现手续费比例：百分数
   */
  withdrawalCommission?: number;
}

/*-----------------------------------------------------提现（请求）响应内容- */
/* 
     提现请求响应内容：加密货币（无）
     */
export interface IFWalletWithdrawCryptoRsp {
  googleAuth?: any;
}
/* 
提现请求响应内容：法币（无）
*/
export interface IFWalletWithdrawFlatRsp {
  googleAuth?: any;
}
/*-----------------------------------------------------兑换货币响应内容- */
/*
 * 兑换钱包响应内容，两种币种互转
 */
// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface IFWalletExchangeRsp { }
/* 
查询汇率响应内容：指定货币的配置汇率
*/
export interface IFWalletRateRsp {
  rate?: string;
}

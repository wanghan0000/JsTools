import { CurrencyType } from '../proto/IFCommon';

export interface IFTaskItem {
  /** */
  award: number;
  awardCurrencyType: CurrencyType;
  /** */
  betAlready: any | null;
  betAlreadyCurrencyType: CurrencyType;
  endTime: string;
  game: number;
  gameId: number;
  gameName: any | null;
  getTime: any | null;
  isReset: number;
  money: number;
  moneyCurrencyType: CurrencyType;
  platformCode: any | null;
  stopTime: any | null;
  taskId: number | null;
  taskPeriod: string;
  taskStatus: number;
  taskType: number;
  webUserVipAwardId: any | null;
  currencyType: CurrencyType;
}

export interface IFDailytaskPack {
  /** */
  dailyRemainTimes: number;

  /** */
  dailyResetTime: string;

  /** */
  dailyTasks: IFTaskItem[];

  weeklyRemainTimes: number;
  weeklyResetTime: string;
  weeklyTasks: IFTaskItem[];
}

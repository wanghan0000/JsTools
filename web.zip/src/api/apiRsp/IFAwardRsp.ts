import { CurrencyType } from '../proto/IFCommon';

export interface IFAwardTotalInfoRsp {
  //待解锁
  lockMoney: number;
  //累计领取奖励总额
  totalReceiveAward: number;
  //已解锁
  unlockMoney: number;
  //货币类型
  currencyType: CurrencyType;
}

export interface IFAwardListRsp {
  //已领取金额
  amount: number;
  //奖励类型名称
  awardType: string;
  //单位
  currency: CurrencyType;
}

export interface IFMyAwardListRsp {
  //金币农场
  farmAwardResBody: IFFarmAwardItem;
  //幸运转盘
  turntableResBody: IFTurnAwardItem;
  //任务中心
  jobCenterResBody: IFJobAwardItem;
  //月奖励
  monthAwardResBody: IFMonthAwardItem;
  //投注返利
  rebateAwardResBody: IFRebateAwardItem;
  //周奖励
  weekAwardResBody: IFWeekAwardItem;
}

//金币农场
export interface IFFarmAwardItem {
  //可领取金额
  awardAmount: number;
  //领奖状态
  awardStatus: number;
  //奖励类型
  awardType: number;
  //奖励名称
  benefitName: string;
  //截止时间
  stopTime: string;
  //参与等级
  lockLevel: number;
  //是否开启(0 关闭 1开启)
  open: number;
  // 货币类型
  awardAmountCurrencyType: CurrencyType;
}

//任务中心
export interface IFJobAwardItem {
  //奖励类型
  awardType: number;
  //奖励名称
  benefitName: string;
  //累计奖励
  sumAward: string;
  //领奖状态(1 可领取 2 不可领取)
  awardStatus: number;
  //货币类型
  currency: CurrencyType;
}

//月奖励
export interface IFMonthAwardItem {
  //奖励记录Id
  awardId: number;
  //领奖状态
  awardStatus: number;
  //奖励类型
  awardType: number;
  //奖励名称
  benefitName: string;
  //投注目标
  betTarget: number;
  //当前有效投注额
  totalBetValid: number;
  //参与等级
  lockLevel: number;
  //是否开启(0 关闭 1开启)
  open: number;
  //币种
  currency: CurrencyType;
}

//投注返利
export interface IFRebateAwardItem {
  //可领取金额
  awardAmount: number;
  //领奖状态
  awardStatus: number;
  //奖励类型
  awardType: number;
  //奖励名称
  benefitName: string;
  //截止时间
  stopTime: string;
  //参与等级
  lockLevel: number;
  //是否开启(0 关闭 1开启)
  open: number;
  //货币类型
  currency: CurrencyType;
}

//幸运转盘
export interface IFTurnAwardItem {
  //领奖状态(1 可领取 2 不可领取 3 锁定)
  awardStatus: number;
  //奖励类型
  awardType: number;
  //奖励名称
  benefitName: string;
  //截止时间
  stopTime: string;
  //幸运转盘次数
  turntableNum: number;
  //参与等级
  lockLevel: number;
  //是否开启(0 关闭 1开启)
  open: number;
  //货币类型
  currency: CurrencyType;
}

//周奖励
export interface IFWeekAwardItem {
  //奖励记录Id
  awardId: number;
  //领取状态(1 可领取 2 不可领取 3 锁定)
  awardStatus: number;
  //奖励类型
  awardType: number;
  //奖励名称
  benefitName: string;
  //投注目标
  betTarget: number;
  //当前有效投注额
  totalBetValid: number;
  //参与等级
  lockLevel: number;
  //是否开启(0 关闭 1开启)
  open: number;
  //货币类型
  currency: CurrencyType;
}

//特殊奖励列表
export interface IFSpecialAwardListRsp {
  //可领取金额
  awardAmount: number;
  //	奖励记录Id
  awardId: number;
  //领取状态(1 可领取 2 不可领取 3 锁定)
  awardStatus: number;
  //奖励类型
  awardType: number;
  //奖励名称
  benefitName: string;
  //备注信息
  remark: string;
  //单位
  currency: CurrencyType;
}

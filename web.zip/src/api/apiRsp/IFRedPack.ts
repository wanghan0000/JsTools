﻿export interface IFRedPackConfig {
    /**
     * 玩家当前充值
     */
    playerPayCnt: number
    /**
     * 最小充值
     */
    rechargeMin: number
    /**
     * 服务器当前时间
     */
    lastmodifyTime: number
    /**
     * 红包持续时间
     */
    redRainTime: number
    /**
     * 临近发放红包开始时间
     */
    nexttime: number
    /**
     * 临近发放红包结束时间
     */
    nextendtime: number
    /**
     * 该用户是否满足活动
     */
    isEnoughActivity?: boolean
}
import { CurrencyType } from "../proto/IFCommon"

export interface IFBetInfo {
    /**注单号 */
    betId: number,
    /**玩家ID */
    userId: string,
    /**玩家名称 */
    userName: string,
    /**投注时间(格式: 时间戳)*/
    betTime: number,
    /**结算时间(格式: 时间戳) */
    settleTime: number,
    /**投注金額 */
    betAmount: number,
    /**投注赔率 */
    payout: number,
    /**投注结果 */
    betResult: number,
    /**游戏ID */
    gameId: string,
    /**游戏名称 */
    gameName: string,
    /**游戏Icon */
    gameIcon: string,
    /**服务端Hash */
    serverSeedHash: string,
    /**服务端种子 */
    serverSeed: string,
    /**客户端种子 */
    clientSeed: string,
    /**随机数 */
    nonce: string,
    /**开奖结果 */
    calResult: number,
    /**损益，赢了就是正负，输了就是负值  */
    settle: number,
    /**货币类型 */
    currencyType:CurrencyType
    /**赢取金额 */
    winAmount: number
    /**平台名字 */
    platformName: string
}


export interface IFSeedsInfo {
    /**服务端种子 */
    serverSeed: string,
    /**clientSeed */
    clientSeed: string,
    /**nonce */
    nonce: number
}

export interface IFNextSeeds {
    /**当前使用种子 */
    currentSeed: IFSeedsInfo,
    /**新的种子 */
    newSeed: IFSeedsInfo
}

export interface IFUPdateSeeds {
    /**当前使用种子 */
    currentSeed: IFSeedsInfo
}
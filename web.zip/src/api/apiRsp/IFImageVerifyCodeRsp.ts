/**
 * 图形验证码
 */
export interface IFImageVerifyCodeRsp {
    /**
     * 图形验证码图片 
     */
    img: string
    /**
     * 验证uid
     */
    uuid: string
}
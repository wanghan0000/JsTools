import { CurrencyType } from '../proto/IFCommon';

export interface IFGameList {
  //游戏列表
  gameList: Array<IFGameItem>;
  //总数
  totalNum: number;
}

export interface IFGameItem {
  //进入游戏金币最低限制
  goldRequire: number;
  //平台游戏id
  id: number;
  //游戏名
  name: string;
  //平台编码: at, tg, tg
  platformCode: string;
  //平台ID
  platformId: number;
  //平台名称: AT平台, PB平台, IM平台
  platformName: string;
  //状态 1 正常 ，2下架 ，3 维护 4 敬请期待
  status: number;
  //游戏分类 0 全部， 1区块链 ，2 对战场 ，3百人场，4 老虎机 ，5 捕鱼
  type: Array<string>;
}

export interface IFPlatform {
  //平台ID
  id: number;
  //平台编码: at, tg, tg
  platformCode: string;
  //平台名称: AT平台, PB平台, IM平台
  title: string;
  //直接跳游戏
  gameInfo: IFGameItem;
}

export interface IFHomeRsp {
  //对战场游戏
  battlefieldList: IFGameList;
  //区块链游戏
  blockChainList: IFGameList;
  //电竞游戏
  esportList: IFGameList;
  //收藏游戏
  favoriteList: IFGameList;
  //捕鱼游戏
  fishingList: IFGameList;
  //热门游戏
  hotList: IFGameList;
  //百人场游戏
  multiList: IFGameList;
  //原创游戏
  originalList: IFGameList;
  //游戏平台
  platforms: Array<IFPlatform>;
  //最近游戏
  playedList: IFGameList;
  //推荐游戏
  recommendList: IFGameList;
  //老虎机游戏
  slotsList: IFGameList;
  //体育游戏
  sportList: IFGameList;
  //棋牌游戏
  chessList: IFGameList;
  //捕鱼
  happyFishingList: IFGameList;
  // 视讯
  videoList: IFGameList;
}

export interface IFBanner {
  //ID
  id?: number;
  //url
  pic?: string;
  //名称
  title?: string;
  //跳转类型
  jump_type?: number;
  //跳转游戏id
  jump_to?: number;
  //跳转参数
  params?: string;
}

export interface IFBigWins {
  //币种
  currency: CurrencyType;
  //	游戏Id
  gameId: number;
  //	平台编码
  platformCode: string;
  //游戏名称
  gameName: string;
  //派奖金额
  settle: string;
  //中奖时间
  time: string;
  //中奖用户
  user: string;
}

export interface IFEntryItem {
  //是否有奖励领取
  isAward: boolean;
  //是否开启
  isOpen: boolean;
}

export interface IFActivityEntry {
  //金钱农场
  farm: IFEntryItem;
  //投注返利
  rebate: IFEntryItem;
  //任务中心
  taskCenter: IFEntryItem;
  //幸运转盘
  turntable: IFEntryItem;
  // 是否有奖励领取
  giftBagStatus: boolean;
}

export interface IFMarquee {
  //id
  id: number;
  //开始时间
  start: number;
  //结束时间
  end: number;
  //类型
  type: string;
  //内容
  content: string;
}

export interface IPropsRsp {
  /* 结束时间 */
  activityEndTime: string;
  /* 开始时间 */
  activityStartTime: string;
  /* 活动类型 */
  activityType: string | number;
  /* iD */
  id: string | number;
  /* 图片链接 */
  pic: string;
  /* 活动标题 */
  title: string;
  /* 活动内容 */
  rule: string;
}

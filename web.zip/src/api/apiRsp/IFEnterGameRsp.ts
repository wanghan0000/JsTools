export interface IFEnterGameRsp {
    //游戏ID
    currentGameId:number;
    //游戏名
    currentGameName:string;
    //游戏地址
    gameUrl:string;
}

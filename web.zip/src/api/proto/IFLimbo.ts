import { CurrencyType } from "./IFCommon";


/**投注结果 */
export interface IFLimboRecordRsp {
    /**记录id */
    betId: number;
    /**投注赔率 */
    payout: number;
    /**投注结果 */
    betResult: number;
    /**投注时间(格式: 时间戳) */
    betTime: string;
    /**结算时间(格式: 时间戳) */
    settleTime: string;
    /**赢取金额 */
    winAmount: number;
    /**用户金额 */
    playerAmount: number;
    /**币种 */
    currencyType: CurrencyType;
}


export interface IFLimboLimit {
     /**币种 */
     currencyType: CurrencyType;
     /**最大投注 */
     maxBetAmount: number,
     /**最小投注 */
     minBetAmount: number,
     /**限红 */
     maxBetResult: number
}
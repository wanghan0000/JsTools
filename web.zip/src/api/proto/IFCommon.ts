/* eslint-disable @typescript-eslint/no-empty-interface */
import { TradeModeCode } from './TradeModeCode';



/**币种类型 */
export type CurrencyType = 'BRL' | 'USDT' | 'IWD' | 'LOCK_IWD' | 'FUN' | 'LOCK_FUN' | string;
/**
 * 充值余额更新
 */
export interface IFRechargeRsp {
  /**交易方式 */
  tradeModeCode: TradeModeCode;
  /**币种类型 */
  currencyType: CurrencyType;
  /**变化金额 */
  money: string;
}

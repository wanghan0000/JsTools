export type TradeModeCode = 
'CASHBACK' |          //提现退回
'MANUALLYPAY' |       //人工充值（线下）
'ACTIVITY' |          // TODO 产品：此账变类型废弃
'COMPENSATIONS' |     //兑换补单（线下）
'AGENTPAY' |          //代理充值
'OTHERPAY' |          //其它（线下）
'BROKERAGE' |         //佣金
'GMCOST'   |          //GM 下分
'GMPAY' |             //GM 上分
'PAYERRCOMP' |        //线上掉单（补单）
'GMARTIFICIAL' |      //GM 人工存入
'WITHDRAWCOST' |      //提现金额
'CHECKIN' |           //活动签到
'RECHARGE' |          //充值
'WITHDRAW' |          //提现
'GAMESETTLE' |        //游戏损益
'REBATE' |            //洗码
'TRANSIN' |           //游戏上分
'TRANSOUT' |          //游戏下分
'ADVANCEMONEY' |      //VIP晋级奖励
'MONTHMONEY' |        //VIP月奖金
'MAILSEND' |          //邮件发送
'AUTO_RECEIVE' |      //自动领取洗码
'MANUAL_RECEIVE' |    //手动领取投注返利
'AUTO_PULL_ORDER' |   //自动从三方拉取注单
'BANKCAR_WITHDRAW' |  //银行卡提现
'ZFB_WITHDRAW' |      //支付宝提现
'USDT_WITHDRAW' |     //USDT提现
'PIX_WITHDRAW' |      //PIX提现
'YZF_WITHDRAW' |      //云支付提现
'GAME_BET' |          //投注
'GAME_WIN' |          //派彩
'VIP_TURNTABLE_AWARD'|//幸运转盘
'VIP_WEEK_AWARD' |    //周奖励
'VIP_FARM_AWARD' |    //金币农场
'VIP_TREASURE_AWARD' |//神秘宝箱
'VIP_TASK_CENTER' |   //任务中心
'VIP_ACTIVITY_AWARD' |//活动奖励
'VIP_REISSUE_AWARD' | //活动补发
'CONSUME' |           //消耗
'ACQUIRE' |           //获得
'RECHARGE_VIP_PAY' |  //VIP支付
'RECHARGE_ZFB' |      //支付宝充值
'RECHARGE_ALIPAYSCAN' | //支付宝扫码
'RECHARGE_WECHATPAY' |  //微信支付
'RECHARGE_WECHATSCAN' | //微信扫码
'RECHARGE_QQWALLET' |   //QQ钱包
'RECHARGE_YZF' |        //云支付充值
'RECHARGE_SZRMB' |      //数字人民币
'RECHARGE_TOPAY' |      //Topay支付
'RECHARGE_YLZF' |       //银联支付
'RECHARGE_WXDAER' |     //微信大额
'RECHARGE_WXDINGER' |   //微信定额
'RECHARGE_WXXE' |       //微信小额
'RECHARGE_PIX' |        //PIX充值
'RECHARGE_USDT' |       //USDT充值
'RECHARGE_PIX_QUOTA' |  //PIX定额支付
'RECHARGE_ZFBDINGER' |  //支付宝定额
'RECHARGE_ZFBXE' |      //支付宝小额
'RECHARGE_ZFBDAER' |    //支付宝大额
'RECHARGE_VIPUSDT' |    //VIP支付USDT
'RECHARGE_ZFBYS' |      //支付宝原生
'RECHARGE_YZFZL' |       //云支付直连
'FIRST_RECHARGE_REBATE'  //充值返利活动














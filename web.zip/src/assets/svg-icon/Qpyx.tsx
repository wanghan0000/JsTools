import * as React from 'react';
import type { SVGProps } from 'react';

const SvgQpyx = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={23} height={21} viewBox="0 0 48 48" {...props} fill={'currentColor'} fillRule={'evenodd'}>
    <path d="M41.3 33.107c-4.748 5.156-12.222 3.282-15.266-.464-3.2 3.589-10.518 5.619-15.266.464-6.006-6.521-.463-13.179-.463-13.179L26.03 3.939v-.014l.007.007.007-.007v.014l15.721 15.989s5.544 6.658-.465 13.179Zm-4.628-9.414L26.037 12.875 15.4 23.694s-2.444 2.612 0 5.177a4.558 4.558 0 0 0 5.554.941l5.076-5.162v-.015l.007.007.007-.007v.015l5.077 5.163a4.557 4.557 0 0 0 5.554-.941c2.444-2.567-.001-5.178-.001-5.178Zm-2.76 19.769H18.176l7.868-8Z" />
  </svg>
);

export default SvgQpyx;

import * as React from 'react';
import Bonus from "@/assets/image/icon/bonus.svg";

const IconBonusSvg = (props) => (
	<Bonus className={"arco-icon"} style={{fontSize:'16px'}} />
);

export default IconBonusSvg;

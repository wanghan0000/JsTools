import * as React from 'react';
import type { SVGProps } from 'react';

const SvgRmyxsvg = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={23} height={21} viewBox="0 0 48 48" {...props} fill={"currentColor"} fillRule={"evenodd"}>
    <path
      d="M20.8 46.612S7.314 41.137 7.6 31.3s8.251-16.07 10.033-17.954 5.956-6.265 2.112-10.561c0 0 6.612-.369 9.328 3.253a9.7 9.7 0 0 1 1.762 9.421c-1.44 4.811 1.5 6.908 1.5 6.908s3.97-1.979 2.612-8.491a25.414 25.414 0 0 1 6.445 16.369c.058 9.866-13.2 16.37-13.2 16.37a2.536 2.536 0 0 1 .528-3.168c1.245-1.345 3.991-3.733 2.64-8.449-1.309-4.569-7.028-5.145-4.224-10.033 0 0-9.855 5.367-10.033 10.561s2 6.49 3.168 7.921a3.6 3.6 0 0 1 .529 3.165Z"
    />
  </svg>
);

export default SvgRmyxsvg;

import * as React from 'react';
import type { SVGProps } from 'react';

const SvgMemu1 = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} viewBox="0 0 48 48" {...props} fill={"#d0d0d0"} fillRule={"evenodd"}>
    <path
      d="M8.18 8.64H38.9v3.84H8.18V8.64Zm0 13.44H29.3v3.84H8.18v-3.84Zm0 13.44H38.9v3.84H8.18v-3.84ZM31.219 24l9.6-5.759v11.52Z"
    />
  </svg>
);

export default SvgMemu1;

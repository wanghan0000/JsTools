import * as React from 'react';
import type { SVGProps } from 'react';

const SvgArrow3 = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={76} height={76} {...props} fill={"#FFF"} fillRule={"evenodd"}>
    <path
      d="m479.171 206.992 12.658 13.608 3.165 3.4-3.165 3.4-12.658 13.606-3.165-3.4L488.664 224l-12.658-13.606Z"
      transform="translate(-447 -184)"
    />
  </svg>
);

export default SvgArrow3;

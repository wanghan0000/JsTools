import * as React from 'react';
import type { SVGProps } from 'react';
const SvgDelete = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={20.031} height={19} {...props}>
    <path
      d="M11.825 11.3 29.29 28.229a1.019 1.019 0 0 1 0 1.473 1.1 1.1 0 0 1-1.519 0L10.307 12.77a1.019 1.019 0 0 1 0-1.472 1.1 1.1 0 0 1 1.518.002Zm16.375.123-17.225 16.7a1 1 0 0 0 0 1.452 1.083 1.083 0 0 0 1.5 0l17.225-16.7a1 1 0 0 0 0-1.452 1.083 1.083 0 0 0-1.5 0Z"
      style={{
        fill: 'currentColor',
        fillRule: 'evenodd',
      }}
      transform="translate(-10 -11)"
    />
  </svg>
);
export default SvgDelete;

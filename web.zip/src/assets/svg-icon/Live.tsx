import * as React from 'react';
import type { SVGProps } from 'react';
const SvgLive = (props: SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={23}
    height={21}
    viewBox="0 0 317 317"
    {...props}
    fill={'currentColor'}
    fillRule={'evenodd'}
    stroke={'transparent'}
    className={'cus-svg'}
  >
    <path
      d="m310.451 264.223-63.561-47.847v33.75a14.109 14.109 0 0 1-14.123 14.1H20.586a14.11 14.11 0 0 1-14.124-14.1V66.859a14.113 14.113 0 0 1 14.124-14.1h212.181a14.112 14.112 0 0 1 14.123 14.1v33.753l63.561-47.853v211.464ZM79.7 157.831v73.546l126.479-73.546L79.7 84.282v73.549Z"
    />
  </svg>
);
export default SvgLive;

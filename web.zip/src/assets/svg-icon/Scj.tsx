import * as React from 'react';
import type { SVGProps } from 'react';

const SvgScj = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={23} height={21} viewBox="0 0 48 48" {...props} fill={"currentColor"} fillRule={"evenodd"}>
    <path
      d="M40.819 26.532v16.209L24.5 36.662 8.18 42.741V9.449a3.166 3.166 0 0 1 3.154-3.179h26.344a3.167 3.167 0 0 1 3.154 3.179Zm-12.71-8.916-3.835-7.035-3.834 7.035-7.8 1.515L18.07 25l-.985 7.971 7.189-3.411 7.19 3.411L30.479 25l5.428-5.864Z"
    />
  </svg>
);

export default SvgScj;

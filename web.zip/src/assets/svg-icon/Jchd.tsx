import * as React from 'react';
import type { SVGProps } from 'react';

const SvgJchd = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={23} height={21} viewBox="0 0 48 48" {...props} fill={"currentColor"} fillRule={"evenodd"}>
      <path id="形状_2372_拷贝" data-name="形状 2372 拷贝" className="cls-1"
            d="M36.2,28.589l0.831-4.154s5.71-1.972,4.984-9.969H37.866S40.58,27.787,26.236,34.4c0,0,2.476,7.214,8.646,7.476v2.492H12.943V41.881c6.17-.262,8.646-7.476,8.646-7.476C7.244,27.787,9.959,14.467,9.959,14.467H5.805c-0.726,8,4.984,9.969,4.984,9.969l0.831,4.154C-0.525,23.133,2.482,11.144,2.482,11.144H9.959V7.821H37.866v3.323h7.476S48.35,23.133,36.2,28.589ZM23.722,11.975L26.3,16.626l5.252,1L27.9,21.5l0.664,5.27L23.722,24.52,18.88,26.775l0.664-5.27-3.656-3.876,5.252-1,2.582-4.651"/>
  </svg>
);

export default SvgJchd;

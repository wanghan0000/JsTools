import * as React from 'react';
import type { SVGProps } from 'react';

const SvgVip = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={23} height={21} viewBox="0 0 48 48" {...props} fill={"currentColor"} fillRule={"evenodd"}>
    <path
      d="M11.1 6.23 2.192 21.625 24.069 43.5l21.066-21.875L37.033 6.23H11.1Zm.81 12.153h6.49l5.672 6.482 6.482-6.482h5.672L24.069 31.348Z"
    />
  </svg>
);

export default SvgVip;

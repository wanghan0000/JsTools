import * as React from 'react';
import { SVGProps } from 'react';

const SvgLoginIconGoogle = (props: SVGProps<SVGSVGElement>) => (
	<svg
		xmlns='http://www.w3.org/2000/svg'
		xmlnsXlink='http://www.w3.org/1999/xlink'
		viewBox='0 0 40 40'
		// style={{
		// 	enableBackground: 'new 0 0 40 40',
		// }}
		xmlSpace='preserve'
		width='1em'
		height='1em'
		className='svg-icon'
		{...props}>
		<image
			style={{
				overflow: 'visible',
			}}
			width={40}
			height={40}
			xlinkHref='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAEyklEQVRYhc2YeWwUVRzHP3PsWbct WkqkHG04WwFFLolFCF4I/IExIUFTEU8wmOCtiSbFA4z/EBJNQOUPYozcicGgQSKYYFoLhQZoy1Eh Uizbbrs9aHeXnc48M1tAWnZnZ5dY95tMsjP7e+/3ee/93m9+8xBCmNc4IcROIUS7+P9lMuwQQowx 2SQhxFigChhCZikIzDABdwFPZRjcde0wATuB7MzguUUdJqDIMKh+kjOIJa7U2+2g90wdWk01Wv1J jJZmRE83yDKSLxtl+AgcxffgmDoTZVRhWv2nvcTRQ/sJ79mGVnfKlr2zdB7epWWoJZP/W0DDf5nu jeuJHqlMydF1eZ5cStYra0C1t3gpAWrVVXSVv4MIh9KC6/MISsFocr/6DsnpTGpuOwb1o5V0vPc6 kmSkD2dKgOvRJ5AUxZa5rRk0An6CzyzBtJREfEB13ETU4knIeUPBMND/bkQ7cRyj+XI/O9/7H+F6 eIHd4dibwa7ytxBISKK3b41ukmPqdLxlL+GYMjXOyAyuHtxP98bPEKEQvg/X4Zr7iG047MygVrmP tuc/Rx0aAZcORh+gEBJZz76Ad/nLSZ2IpkZ6L13EMfPBlOBsAYraQrq/VQj9OBIpS0POjSJ0mTuW r8BTtjJlh6nK8k0igr9hdDTiW3Ge7NW15nDQ/V6cYyYMChzJYlC0/oAIK/Q2yXjmtaKO6KHr62K8 q94eFDiSLbF+dC6isyKWGsxLydcwQuNQZp9N2GGwR7CrSov9lqWEZjek6ZDjlXh6tiPu/9YzeLXx 2jD6Lr3ZiVxUaumw7Ypge4WWnGyAEgFaVzN6uP+9IkAtsmzisJd/bSsjyi3JIhSsARVPv1szWcvh BssmZkxZKk7EWyU6yxiU3KMQkUs37h1KFK39d+JHS5+GZEksvE+NOR24SRRZoiFgUNfYfxSqxTRZ A/qmYXRU4EAHVefPaA6rWkr4IHCah4ZOjNsmzyfx5kJXwj43HIhS/5eOuA4lYFhuYkLLJZbzl+CQ ozG4vaFCHm9dRI2Wx6YTm62aJdSViODnY9q/cNc04e40AcmdA84iPumYRllwPgYSY9QOGtou8sXx 71MG/PgnDSNy6/M5JYkXMukuPjzqGzb0TGK00k2+HKYXOVYobD27m02nttmG+3IfVNcZGOpNO0JA tkdiztjEuSkpYOnI+SzOH4ZbGOgDSq0ttbt49dBaqppPJmxf1VLDyoNr2Vl/FCXiRhJuuFb0Srrg xcdclmnGVsEaCLezeO8qhOiNlyViKsoewb15ExnmzUNg0NQToLbtHBc6/Qi1FaGE8Phfw+NfBgoI qYuxIx1ses6ToMcUAE1Vt9Wycn85yGl8BAoFoVzBcDbhCi4hq/FdfFlutq6WyE684VMDNHUsUMcb h9fRczUysLC2ITOadHT3WYZHFrJ5wXoKcpK/yFL+7PSHAnx6ZDOV/ppUCWMqLZhC+Yw15LjsHQel /eH+66U/2H5uH8daam3Z359fwrLxi5hXMCslP7d9eHSm/QJHWk5QHzxPMNKJLPUtm0Bwl3sIxXcW MT1/MuNzB/noY7CU8adbJmBXBnAkUqcJeCAz2WL6xYxBs26qMEuDDAC6We3ATHMGTwMPAHvMiigD wEyG3cAsoOEfGFlrgMOl96AAAAAASUVORK5CYII='
		/>
	</svg>
);

export default SvgLoginIconGoogle;

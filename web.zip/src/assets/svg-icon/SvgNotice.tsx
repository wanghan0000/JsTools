import * as React from 'react';
import type { SVGProps } from 'react';

const SvgNotice = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} viewBox="0 0 48 48" {...props} fill={"currentColor"} fillRule={"evenodd"}>
    <path id="tz" className="cls-1"
          d="M37.328,36.338H10.679a3.009,3.009,0,0,1,0-6.018h0.43v-8.6a12.889,12.889,0,0,1,8.608-12.15,4.288,4.288,0,0,1,8.574,0A12.889,12.889,0,0,1,36.9,21.724v8.6h0.43A3.009,3.009,0,0,1,37.328,36.338ZM24,44.39A7.735,7.735,0,0,1,16.288,38.6H31.719A7.928,7.928,0,0,1,24,44.39Z"/>
  </svg>
);

export default SvgNotice;

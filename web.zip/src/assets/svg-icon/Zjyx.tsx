import * as React from 'react';
import type { SVGProps } from 'react';

const SvgZjyx = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={23} height={21} viewBox="0 0 48 48" {...props} fill={"currentColor"} fillRule={"evenodd"}>
    <path
      d="M25.818 43.883a19.576 19.576 0 0 1-13.554-5.443l2.725-4.36a14.654 14.654 0 1 0-3.683-11.822h4.683l-6.881 9.83-6.881-9.83h4.032a19.659 19.659 0 1 1 19.559 21.625Zm8.152-14.5L31.3 32.27l-6.567-6.08h-.881v-11.8h3.932v9.262Z"
    />
  </svg>
);

export default SvgZjyx;

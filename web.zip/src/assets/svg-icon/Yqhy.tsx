import * as React from 'react';
import type { SVGProps } from 'react';

const SvgYqhy = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} viewBox="0 0 48 48" {...props} fill={"#67707b"} fillRule={"evenodd"}>
    <path
      d="m43.785 37.146-8.084-6.1v4.3a1.8 1.8 0 0 1-1.8 1.8H6.916a1.8 1.8 0 0 1-1.8-1.8V12a1.8 1.8 0 0 1 1.8-1.8H33.9a1.8 1.8 0 0 1 1.8 1.8v4.3l8.084-6.1v26.946ZM14.434 23.588v9.372l16.087-9.372-16.087-9.372v9.373Z"
    />
  </svg>
);

export default SvgYqhy;

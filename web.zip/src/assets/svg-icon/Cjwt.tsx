import * as React from 'react';
import type { SVGProps } from 'react';

const SvgCjwt = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} viewBox="0 0 48 48" {...props} fill={"#67707b"} fillRule={"evenodd"}>
    <path
      d="M24 44.2A19.2 19.2 0 1 1 43.2 25 19.2 19.2 0 0 1 24 44.2Zm-7.68-17.839s2.914-6.1 6.875-6.943 7.343 1.416 5.347 6.171a95.494 95.494 0 0 1-4.583 9.257 5.425 5.425 0 0 0 5.347-3.086s1.724 3.195-3.819 5.4-9.178 1.011-7.639-2.314 5.347-11.571 5.347-11.571a13.649 13.649 0 0 0-6.875 3.086ZM28.838 11.55a3.55 3.55 0 1 1-3.512 3.55 3.531 3.531 0 0 1 3.512-3.55Z"
    />
  </svg>
);

export default SvgCjwt;

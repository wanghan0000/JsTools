import * as React from 'react';
import type { SVGProps } from 'react';
const SvgTelegram = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="23" height="21" viewBox="0 0 124 124" {...props}>
    <path
      data-name="\u5F62\u72B6 883"
      d="m509.108 727.124-80.808 32.67s-9.041 2.842 0 8.6l15.474 6.878a10.868 10.868 0 0 0 6.878 0l42.985-29.23s4.182-1.352 0 3.439l-27.511 27.511s-2.783 3.137 0 5.158l34.389 24.072s5.306 1.259 6.877-3.44l10.317-70.495s1.838-8.587-8.601-5.163Z"
      transform="translate(-411 -701)"
      style={{
        fill: 'currentColor',
        fillRule: 'evenodd',
      }}
    />
  </svg>
);
export default SvgTelegram;

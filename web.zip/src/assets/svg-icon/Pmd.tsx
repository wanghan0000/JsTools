import * as React from 'react';
import type { SVGProps } from 'react';

const SvgPmd = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} viewBox="0 0 48 48" {...props} fill={"#67707b"} fillRule={"evenodd"}>
    <path
      d="M32.617 32.679v-15.36a7.68 7.68 0 1 1 0 15.36Zm-21.134 0a5.76 5.76 0 0 1-5.76-5.76V23.08a5.76 5.76 0 0 1 5.76-5.76h3.461L28.773 5.8v38.394L14.947 32.68h-3.464Z"
    />
  </svg>
);

export default SvgPmd;

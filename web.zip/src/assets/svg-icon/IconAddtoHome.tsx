﻿import * as React from 'react';

const IconAddtoHome = (props) => (
	<svg
		xmlns='http://www.w3.org/2000/svg'
		width='20px'
		height='20px'
		viewBox='0 0 76 76'
		className='svg-icon'
		{...props}>
		<path
			data-name='\u5706\u89D2\u77E9\u5F62 670'
			d='M66.362 1687.33h-6.536v18.06a3.626 3.626 0 0 1-3.638 3.61H19.812a3.626 3.626 0 0 1-3.638-3.61v-18.06H9.638a3.612 3.612 0 0 1-2.367-6.36l28.362-24.14a3.656 3.656 0 0 1 4.735 0l28.362 24.14a3.612 3.612 0 0 1-2.368 6.36Zm-17.449-3.62h-7.275v-7.22a3.638 3.638 0 0 0-7.275 0v7.22h-7.276a3.615 3.615 0 1 0 0 7.23h7.275v7.22a3.638 3.638 0 0 0 7.275 0v-7.22h7.275a3.615 3.615 0 1 0 .001-7.23Z'
			transform='translate(0 -1646)'
			style={{
				fill: 'currentColor',
				fillRule: 'evenodd',
			}}
		/>
	</svg>
);

export default IconAddtoHome;
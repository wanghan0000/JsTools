import * as React from 'react';
import type { SVGProps } from 'react';

const SvgMemu2 = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} viewBox="0 0 48 48" {...props}  fill={"#d0d0d0"} fillRule={"evenodd"}>
    <path
      d="M8.189 8.64h30.72v3.84H8.189V8.64Zm0 13.44h21.12v3.84H8.189v-3.84Zm0 13.44h30.72v3.84H8.189v-3.84ZM40.916 24l-9.6-5.609v11.22Z"
    />
  </svg>
);

export default SvgMemu2;

import * as React from 'react';
import type { SVGProps } from 'react';

const SvgDt = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} viewBox="0 0 48 48" {...props} fill={"currentColor"} fillRule={"evenodd"}>
    <path
      d="M41.357 38.381c0 1.524-1.626 2.622-3.165 2.622h-7.963V30.452a2.343 2.343 0 0 0-2.343-2.343h-7.028a2.343 2.343 0 0 0-2.343 2.343V41h-8.184c-1.538 0-3.046-2.163-3.046-3.687V26.669c0-4.693-.342-7.43 2.13-9.583 6.118-4.949 13.034-10.618 13.034-10.618a2.805 2.805 0 0 1 3.627 0s6.991 5.478 13.153 10.617c2.662 2.265 2.115 4.723 2.129 9.583.02 6.997-.001 11.713-.001 11.713Z"
    />
  </svg>
);

export default SvgDt;

import * as React from 'react';
import type { SVGProps } from 'react';

const SvgDc = (props: SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={18}
    height={18}
    viewBox="0 0 48 48"
    {...props}
    fill={'currentColor'}
    fillRule={'evenodd'}
    stroke={'transparent'}
    className={'cus-svg'}
  >
    <path d="m45.147 11.614-6.108 28.809a2.505 2.505 0 0 1-2.971 1.931l-18.388-3.9a2.507 2.507 0 0 1-1.932-2.972l6.107-28.806a2.507 2.507 0 0 1 2.973-1.932l18.388 3.9a2.506 2.506 0 0 1 1.931 2.97Zm-12.355 2.57s-9.371 2.665-11.292 8.688 5.871 5.249 5.871 5.249a20.682 20.682 0 0 1-3.429 5.15l8.787 1.987s-1.9-4.1-1.581-6.109c0 0 5.082 3.771 7.344-1.65s-5.699-13.315-5.699-13.315Zm-19.38 24.983c1.979.847 1.909.717 3.776 1.511l-4.339.91A2.342 2.342 0 0 1 9.96 39.97L2.492 13.487A2.343 2.343 0 0 1 4.11 10.6L18.7 6.69c-.852 3.051-2.34 10.01-6.043 27.945 0 0-1.039 3.765.755 4.532Z" />
  </svg>
);

export default SvgDc;

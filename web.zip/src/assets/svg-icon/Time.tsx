import * as React from 'react';
import type { SVGProps } from 'react';

const SvgTime = (props: SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 48 48"  fill={"#67707b"} fillRule={"evenodd"}>
        <path id="time" className="cls-1"
              d="M24.013,42.835A18.763,18.763,0,1,1,42.776,24.073,18.763,18.763,0,0,1,24.013,42.835ZM25.89,24.526V14.692H20.261V26.6l-0.363.488,0.363,0.27v0.471h0.634l9.542,7.1L33.8,30.406Z"/>
    </svg>
);

export default SvgTime;

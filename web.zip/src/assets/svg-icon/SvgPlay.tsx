import * as React from 'react';
import type { SVGProps } from 'react';

const SvgPlay = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="57" height="57" viewBox="0 0 57 57" {...props} fill={"#FFFFFF"} fillRule={"evenodd"}>
      <path id="敬请期待_拷贝_3" data-name="敬请期待 拷贝 3" className="cls-1"
            d="M28.028,56.057A28.028,28.028,0,1,1,56.057,28.028,28.029,28.029,0,0,1,28.028,56.057Zm0-3.78A24.248,24.248,0,1,1,52.277,28.029,24.248,24.248,0,0,1,28.028,52.277Z"/>
      <path id="三角形_1911_拷贝" data-name="三角形 1911 拷贝" className="cls-1"
            d="M40.34,25.853a2,2,0,0,1,0,3.431L22.029,40.257A2,2,0,0,1,19,38.542V16.6a2,2,0,0,1,3.028-1.716Z"/>

  </svg>
);

export default SvgPlay;

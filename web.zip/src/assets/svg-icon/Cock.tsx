import * as React from 'react';
import type { SVGProps } from 'react';

const SvgCock = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} viewBox="0 0 48 48" {...props} fill={"#67707b"} fillRule={"evenodd"}>
      <path id="cock" className="cls-1"
      d="M36.749,42.352H11.019a1.838,1.838,0,0,1-1.838-1.838V23.973a1.838,1.838,0,0,1,1.838-1.838h1.838V16.621a11.027,11.027,0,1,1,22.055,0v5.514h1.838a1.838,1.838,0,0,1,1.838,1.838V40.514A1.838,1.838,0,0,1,36.749,42.352ZM22.046,35a1.838,1.838,0,0,0,3.676,0V29.486a1.838,1.838,0,0,0-3.676,0V35ZM29.39,16.594a5.506,5.506,0,1,0-11.011,0v5.541H29.39V16.594Z"/>
  </svg>
);

export default SvgCock;

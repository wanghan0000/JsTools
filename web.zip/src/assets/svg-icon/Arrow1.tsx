import * as React from 'react';
import type { SVGProps } from 'react';

const SvgArrow1 = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={76} height={76} {...props} fill={"#FFF"} fillRule={"evenodd"}>
    <path
      d="m501.82 126.587-13.456 12.826-3.364 3.206-3.364-3.206-13.457-12.826 3.364-3.206L485 136.206l13.456-12.825Z"
      transform="translate(-447 -92)"
    />
  </svg>
);

export default SvgArrow1;

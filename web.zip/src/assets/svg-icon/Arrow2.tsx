import * as React from 'react';
import type { SVGProps } from 'react';

const SvgArrow2 = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} viewBox="0 0 48 48" {...props} fill={"#FFF"} fillRule={"evenodd"}>
    <path
      d="m19.437 11.394 10.126 10.885L32.1 25l-2.532 2.721-10.131 10.886-2.537-2.722L27.032 25 16.9 14.115Z"
    />
  </svg>
);

export default SvgArrow2;

import * as React from 'react';
import { SVGProps } from 'react';

const SvgLoginIconFacebook = (props: SVGProps<SVGSVGElement>) => (
	<svg
		xmlns='http://www.w3.org/2000/svg'
		xmlnsXlink='http://www.w3.org/1999/xlink'
		viewBox='0 0 40 40'
		// style={{
		// 	enableBackground: 'new 0 0 40 40',
		// }}
		xmlSpace='preserve'
		width='1em'
		height='1em'
		className='svg-icon'
		{...props}>
		<image
			style={{
				overflow: 'visible',
			}}
			width={40}
			height={40}
			xlinkHref='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAADsUlEQVRYhe2Yz28bRRTHPzO767Xj 2M4PJWkFLZCiFA6pVFAFSIUDP2+VkKjEgVMPCIkLEuVIUGmFhJC48idw6AUESMAJIRUq9YA4gPiR EqAF5LRK4h+xvWvvTDVrJ8TxujVeuzVSvpJtaWbf24/nzXvzdsXM6xdRieCAtNU54DEgy51VAfhG SbHk+I0rNmn/Hon4Ds3kHQbb0hywIJU+EdjWMRst3oGRgdupKeAtCTw6OkwdOm4DmdtxJwHUlaYe aJTWCAFSCKQASwosM9CpnD1UKAFKw/WiB76ClE0uaZGUFo0QVuG1oKfG7BBU63YfQwM0NytVG2wW fR5emOD5xVmeODTBTNrBsQSNQOMHCj/Q/LRa4bWPfqXiK1KOHD6ggVsv+3h1xXsnD3P6yYM3vf6h uzO88ckyxZom5bTPDRzQ7KSqH+DVAs6/fIQXjsze0ubqhheGVkZsQxllEAtQCAprNV596mBPcLfS wAGLXoPspMubz9zbs81dOTf8VbpzbuAhrpbrPH10lrnxRNdrfl+r8se6h23Ki4R8qR6OOxExHnyS BJrF/eNdp5c+X+HdL1bwTR2UIgyh2RYTKZt0QrJ7EQcPKGF6zImc+jG/ydnPLps0ZzLthImhW4ll FBHh4ZQZu8vOXr5WDav3VCaBFXlwdGrgSUKXzU4rlAZQ7z4ubqLYKyi2vvTOgWiFOSCbl4idDnR0 eIkDKForkt+omS7g34lrFTaqjUibTT+AfIW1bKK9KrsW+3IuQcTS9w0YaE2joXjpkf3syzSdG/eb ZZ/j87lImwfnxnjlxP0kktZ292JKzdWCx6c/XMe1Jbubmr4BGwpKXsCZ5+aZn072ZGPKzwcvPtAx /uXPa3x48W/cyU4/fSdJuJ2EYLXk9+tiW5eulECpjtWLBbil3vOxu/4x/WIXDaXM/Ff9uV4zx0qk Vd+AOqx3evugj6O/Ch7Y0fWp7yQxJ0HSkZz/Ps/h2TSqVSJML3j0QIaFmbEOGxPKC78VsG3ZPIMl lL2A1bJPKhmN0jegKQ8Z1+L0x8thg7C9G1crnDm1yNKz93XYXFgpcPL9S5BJNP9hq0pPZV1yrh2W roEBhkgapsedtgedtboik4h2m7QtmEiSHXfCPxjKPNUJEQkXC3BLMjxf2wYiywWtpzzCHrD56cl/ XMBhaw8wrvYA42oPMK7+F4ClEeDopqIB/HY02UJ9LYUUbwMbIwCzW+vAOTuoBr9IVx4zL6yBx4Hu 7y1uj8rAVwLOBnD5BuV9IaPbVIuTAAAAAElFTkSuQmCC'
		/>
	</svg>
);

export default SvgLoginIconFacebook;

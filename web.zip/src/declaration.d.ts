declare module '*.svg' {
  const content: React.FunctionComponent<React.SVGAttributes<SVGElement>>;
  export default content;
}

declare module '*.less' {
  const classes: { [className: string]: string };
  export default classes;
}

declare module '*.mp3' {
  const value: string;
  export default value;
}

declare module '*/settings.json' {
  const value: {
    colorWeek: boolean;
    navbar: boolean;
    menu: boolean;
    footer: boolean;
    themeColor: string;
    menuWidth: number;
  };

  export default value;
}

declare module '*.png' {
  const value: string;
  export default value;
}

type FaceBookTrigger = 'track';
/**
 * 首充  登录 完成注册  添加cart 下载
 */
type FaceBookPushType = 'firstDeposit' | 'Login' | 'completeRegistration' | 'addToCart' | 'download';

interface kwaiqObject {
  track: (eventName: string) => void;
}

interface Window {
  //native谷歌登录
  nativeGoogleLogin: {
    authCode: string;
    errorCode: string;
    thirdSign: string;
  };

  //native脸书登录
  nativeFBLogin: {
    authCode: string;
    errorCode: string;
    thirdSign: string;
  };

  /**青雀埋点 channel[快手]*/
  kwaiq: {
    instance: (pixelId: string) => kwaiqObject;
  };
  kwaiId: string;
  /**facebook埋点 */
  fbq: (type: string, eventName: string) => void;
  fBId: string;
  /**tiktok抖音埋点 */
  ttq: {
    track: (eventName: string) => void;
  };
  ttkid: string;
  /**bemob 埋点 */
  bemob: {
    track: (eventName: string) => void;
  };
  /**google 埋点 */
  gtag(trigger: string, eventName: string, params: any);

  //ios
  webkit: {
    messageHandle;
    messageHandlers: {
      webViewGoogleLogin: {
        postMessage: (v:string) => void;
      };
      webViewFacebookLogin: {
        postMessage: (v:string) => void;
      };
      webViewUpdateApp: {
        postMessage: (v:string) => void;
      }
      webViewJumpUrl: {
        postMessage: (url: string) => void;
      };
    };
  };

  //android
  jsCallNative: {
     webViewGoogleLogin(): void;
     webViewFacebookLogin(): void;
     webViewUpdateApp():void;
     webViewJumpUrl(url: string);
  };

  cdnUrl: string;

  //pwa事件
  deferredPrompt: any;

  //货币精度
  currencyPrecision: any;

  //多语言
  newLangarrMap: any;

  defaultLang: any;

  newLangarrMap: any;

  LiveChatWidget: any;

  //zInstall
  cjqInstall: any;

  //pwa事件
  addToHome: {
    supportPwa: any;
    pwaEvent: any;
  };

  luckybetSys: any;
}

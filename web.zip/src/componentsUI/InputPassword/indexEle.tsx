import { styled } from 'styled-components';

export const Container = styled.div`
  position: relative;

  .icon {
    position: absolute;
    top: 50%;
    right: 10px;
    transform: translateY(-50%);
    width: 20px;
    height: 20px;
    cursor: pointer;
    color: var(--color-text-2);
  }
`;

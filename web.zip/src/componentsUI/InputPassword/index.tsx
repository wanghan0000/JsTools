import '../Input/index.less';
import { Input } from '@arco-design/web-react';
import { InputPasswordProps } from '@arco-design/web-react/es/Input';
import React, { FC, useState } from 'react';
import useScreenDesign, { screenType } from '@/Core/utils/hooks/useScreenDesign';
import { Container } from './indexEle';
import { IconEye, IconEyeInvisible } from '@arco-design/web-react/icon';

const InputPasswordUI: FC<InputPasswordProps> = (props) => {
  const mobile = useScreenDesign(screenType.mobile);
  const [status, setStatus] = useState(false);
  return (
    <Container>
      <Input
        type={status ? 'text' : 'password'}
        {...props}
        autoComplete={'new-password'}
        size={mobile ? 'small' : 'default'}
        className={'arco-mt2-input-ui'}
      ></Input>
      {!status ? (
        <IconEyeInvisible className="icon" onClick={() => setStatus(!status)} />
      ) : (
        <IconEye className="icon" onClick={() => setStatus(!status)} />
      )}
    </Container>
  );
};

export default InputPasswordUI;

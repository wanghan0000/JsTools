import React from 'react';
import {
  FacebookShareButton,
  FacebookIcon,
  TwitterShareButton,
  TwitterIcon,
  WhatsappShareButton,
  WhatsappIcon,
  TelegramShareButton,
  TelegramIcon,
} from 'react-share';
import { ShareContainer } from './indexEle';

const ShareElement = () => {
  return (
    <ShareContainer>
      <FacebookShareButton quote="" hashtag="" title="Facebook" url="https://www.facebook.com">
        <FacebookIcon borderRadius={50} size={54} />
      </FacebookShareButton>
      <TwitterShareButton title="Twitter" url="https://twitter.com">
        <TwitterIcon borderRadius={50} size={54} />
      </TwitterShareButton>
      <WhatsappShareButton title="Whatsapp" url="https://web.whatsapp.com">
        <WhatsappIcon borderRadius={50} size={54} />
      </WhatsappShareButton>
      <TelegramShareButton title="Telegram" url="https://telegram.me">
        <TelegramIcon borderRadius={50} size={54} />
      </TelegramShareButton>
    </ShareContainer>
  );
};

export default ShareElement;

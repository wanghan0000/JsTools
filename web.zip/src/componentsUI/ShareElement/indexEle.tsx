import { styled } from 'styled-components';

export const ShareContainer = styled.div`
  width: 100%;
  display: flex;
  justify-content: center;
  column-gap: 15px;
`;

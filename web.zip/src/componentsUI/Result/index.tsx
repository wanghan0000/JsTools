import { useTranslationPlus } from '@/Core/i18n/useTranslationPlus';
import { Button, Result, ResultProps } from '@arco-design/web-react';
import React, { FC, useMemo } from 'react';
import './index.less'
import omit from '@/Core/utils/omit';
export interface ResultUIProps extends ResultProps {
  errorCode?:string;
  retryFunc?:()=>void;
  btnText?:string;
  cusFunc?:()=>void;
  errorText?:string;
}


const ResultUI: FC<ResultUIProps> = (props) => {
  const { t:t2 } = useTranslationPlus('HomeView');
  const { t } = useTranslationPlus();
  const {errorCode,status,retryFunc,btnText,cusFunc , errorText} =props
  const other = useMemo(()=>{
    return omit(props,['errorCode','retryFunc','btnText','cusFunc','errorText'])
  },[props]) 
  return <Result 
  {...other}
  className={'pt-web-result'}
  title={errorText ? errorText : t(`${errorCode}`)}
                  extra={
                    <>
                     {btnText && <Button key='again' onClick={()=>{cusFunc ? cusFunc?.() : retryFunc?.()}}> {btnText }</Button>}
                     {!btnText  && retryFunc && <Button key='again' onClick={(e)=>{
                        retryFunc()
                     }}> {btnText ? btnText : t2( 'Again')}</Button>}
                    </>
                  }
                  status={status}
          
  />;
};

export default React.memo(ResultUI);

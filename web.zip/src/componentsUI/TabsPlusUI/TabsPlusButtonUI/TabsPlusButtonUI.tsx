import './index.less'
import classNames from "classnames"
import React, { CSSProperties, ForwardRefExoticComponent, ReactNode, useContext, useEffect, useRef } from "react"
import { TabsPlusContext } from "../TabsPlusUI"
export interface TabsPlusButtonUIProps {
    className?: string,
    index: any,
    title?: string | ReactNode,
    style?: CSSProperties | undefined;
    type?: 'default' | 'primary';
}


const TabsPlusButtonUI = (props: TabsPlusButtonUIProps, ref: React.MutableRefObject<any>) => {
    const { className, index, title ,style ,type = 'default'  } = props
    const context = useContext(TabsPlusContext)
    const prefixCls = 'tabs-plus-button-ui'

    const classnames = classNames([
        prefixCls,
        context.index === index ? `${prefixCls}-select` : '',
        `${prefixCls}-${context.model}`,
        `${prefixCls}-${type}`,
        className
    ])

    const refSelf = useRef(null);
 
    useEffect(()=>{
        const refT = ref || refSelf;
        if(refT?.current && context.model === 'auto') {
            context.onInit(refT)
        }
    },[])

    return (<div ref={ref || refSelf} className={classnames}
        style={{ ...style, marginLeft: context.interval, marginRight: context.interval }}
        onClick={() => context.onSelect(index)}
    >
        <div className={`${prefixCls}-title`}>{title}</div>
    </div>)
}

export type TabsPlusButtonType = ForwardRefExoticComponent<TabsPlusButtonUIProps> & {
    isTabsPlusButton: boolean;
}

export const TabsPlusButtonRef: TabsPlusButtonType = React.forwardRef(TabsPlusButtonUI) as TabsPlusButtonType;

TabsPlusButtonRef.displayName = 'TabsPlusButtonUI'
TabsPlusButtonRef.isTabsPlusButton = true;

export default TabsPlusButtonRef
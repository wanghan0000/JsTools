import './index.less'
import React, { CSSProperties, PropsWithChildren, ReactElement, useEffect, useRef, useState } from "react";
import classNames from 'classnames';
import { TabsPlusButtonType, TabsPlusButtonUIProps } from './TabsPlusButtonUI/TabsPlusButtonUI';

const getHeadChildren = (props: any) => {
    const { children } = props;
    const headChildren = [];
    React.Children.forEach(children, (child: ReactElement) => {
        if (child && child.type && (child as ReactElement<TabsPlusButtonUIProps, TabsPlusButtonType>).type.isTabsPlusButton) {
            headChildren.push(child);
        }
    });
    return headChildren as ReactElement<TabsPlusButtonUIProps, TabsPlusButtonType>[];
};

export type ModelType = 'fill-width' | 'auto'

export interface IFTabsPlusContext {
    index?: any;
    interval?: number;
    onSelect?: (index: number) => void;
    model?: ModelType;
    onInit?: (ref: any) => void;
    disabled?: boolean
}

export const TabsPlusContext = React.createContext<IFTabsPlusContext>({
    index: 0
})

export interface TabsPlusUIProps {
    className?: string
    model?: ModelType,
    value?: any,
    defaultValue?: any,
    interval?: number
    onSelect?: (index: any) => void;
    style?: CSSProperties | undefined;
    disabled?: boolean
}

const TabsPlusUI = (props: PropsWithChildren<TabsPlusUIProps>) => {
    const { className, model = 'fill-width', defaultValue = 0, onSelect, interval, style = {}, disabled , value} = props;
    const prefixCls = 'tabs-plus-ui'
    const ref = useRef(null)
    const allWidthRef = useRef([]);
    const headChildren = getHeadChildren(props)
    const [currentIndex, setCurrentIndex] = useState<number>(defaultValue)

    useEffect(()=>{
        handleClick(defaultValue,false)
    },[defaultValue])

    useEffect(()=>{
        if(typeof(value) !== 'undefined' && value !== null){
            handleClick(value)
        }
    },[value])

    const handleClick = (index, isTrigger = true) => {
        if (disabled) {
            return
        }
        setCurrentIndex(index)
        if(isTrigger){
            onSelect && onSelect(index)
        }
        if (model === 'auto') {
            
            let allWidth = 0;
            let currentWidth = 0;
            let offsetx = 0;
            const half = ref.current.clientWidth / 2;
            for (let i = 0; i < allWidthRef.current.length; ++i) {
                allWidth += allWidthRef.current[i].current.clientWidth;
                if (i < index) {
                    currentWidth += allWidthRef.current[i].current.clientWidth;
                } else if (i === index) {
                    currentWidth += allWidthRef.current[i].current.clientWidth / 2;
                }
            }
            if (index > 0) {
                currentWidth += ((interval * 2) * (index - 1))
            }

            if (index === 0) {
                offsetx = 0;
            } else if (index === allWidthRef.current?.length - 1) {
                offsetx = allWidth - half;
            } else {
                if (currentWidth < half) {
                    offsetx = 0
                } else if (currentWidth > half) {
                    offsetx = currentWidth - half;
                    if (offsetx > allWidth - half * 2) {
                        offsetx = allWidth - half * 2;
                    }
                }
            }
            ref.current.scrollTo({left: offsetx, behavior: 'smooth'})
        }
    }

    const onInit = (ref) => {
        allWidthRef.current.push(ref);
    }

    const headContext: IFTabsPlusContext = {
        index: currentIndex,
        onSelect: handleClick,
        interval: interval,
        model: model,
        onInit: onInit,
        disabled: disabled
    }

    return (
        <div
            className={classNames([className, prefixCls, `${prefixCls}-${model}`])} style={style} ref={ref}>
            <TabsPlusContext.Provider
                value={{ ...headContext }}
            >
                {
                    headChildren
                }


            </TabsPlusContext.Provider>
        </div>)
}



export default TabsPlusUI


import React, { Component } from 'react';

export type InputModeTypes =
  | 'verbatim'
  | 'latin'
  | 'latin-name'
  | 'latin-prose'
  | 'full-width-latin'
  | 'kana'
  | 'kana-name'
  | 'katakana'
  | 'numeric'
  | 'tel'
  | 'email'
  | 'url';

export interface ReactCodeInputProps {
  // 类型
  type?: 'text' | 'number' | 'password' | 'tel';
  // 允许输入的字符数
  fields?: number;
  // 占位符
  placeholder?: string;
  // 设置输入的字段值
  value?: string;
  // 值发生变化时回调
  onChange?: (value: string) => void;
  // 组件名称
  name: string;
  // 触摸
  touch?: (name: string) => void;
  // 清除已触摸
  untouch?: (name: string) => void;
  // 添加类名
  className?: string;
  // 设置数据是否有效
  isValid?: boolean;
  // 是否禁用
  disabled?: boolean;
  // 样式
  style?: React.CSSProperties;
  // 输入样式
  inputStyle?: React.CSSProperties;
  // 如果prop为false isValid设置每个输入字段的样式
  inputStyleInvalid?: React.CSSProperties;
  // 是否自动聚焦
  autoFocus?: boolean;

  forceUppercase?: boolean;

  // 在按键下过滤字符
  filterKeyCodes?: Array<number>;
  // 过滤字符，默认值['-','.']
  filterChars?: Array<string>;
  // 过滤器白名单 filterChars 如果充当黑名单，则false  true充当白名单； 默认：false
  filterCharsIsWhitelist?: boolean;
  // prop指定检查元素值的正则表达式
  pattern?: string;
  // 动态键盘设备上的浏览器要显示哪个键盘
  inputMode: InputModeTypes;
  //  输入字段是否启用自动完成
  autoComplete?: string;
}

declare class ReactCodeInput extends Component<ReactCodeInputProps, any> {
  constructor(props: ReactCodeInputProps);
}

export default ReactCodeInput;

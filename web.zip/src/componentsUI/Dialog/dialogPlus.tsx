import './index.less';
import Portal from '@arco-design/web-react/es/Portal';
import classNames from 'classnames';
import React, { forwardRef, ReactNode, useContext, useEffect, useImperativeHandle, useRef, useState } from 'react';
import { CSSTransition } from 'react-transition-group';
import useScreenDesign, { screenType } from '@/Core/utils/hooks/useScreenDesign';
import { debounce } from '@/Core/utils';
import { sys } from '@/Core/utils/system';
import { useGlobalOpenSearch, useMobileLeftSiderSwitch, useRefreshDialog } from '@/store/commonStore';
export interface DialogPagePlusProps {
  children?: ReactNode | any;
  props?: any;
  key?: string,
  lazyCompoent?: any;
}

export interface DialogLoadLazyProps {
  key: string,
  props?: any
}

export interface DialogPlusRef {
  push: (params: DialogPagePlusProps) => void;
  pop: () => void;
  closeAll: () => void;
  replace: (path: any, params: DialogLoadLazyProps) => void;
  pushLoadLazy: (path: any, params: DialogLoadLazyProps) => void;
}

export type DialogPlusState = 'NONE' | 'PUSH' | 'POP' | 'CLOSEALl' | 'REPLACE' | 'CLOSESELEF';

export interface IFDialogPlusContext {
  closeSelf?: (key: string) => void;
  showBtnBack?: (key: string) => boolean;
  closeAll?: () => void;
  pop?: () => void;
  push?: (params: DialogPagePlusProps) => void;
  replace?: (path: any, params: DialogLoadLazyProps) => void;
  enableKey: string;
  closeByNames?: (key: string[]) => void;
  stopClose?: () => void;
  useActiveEffect?: (effect: ()=>void,name:string)=>void;
}

export const DialogPlusContext = React.createContext<IFDialogPlusContext>({
  enableKey: '',
});

export function useDialogPlus() {
  const context = useContext(DialogPlusContext);
  return {
    closeSelf: context.closeSelf,
    showBtnBack: context.showBtnBack,
    closeAll: context.closeAll,
    pop: context.pop,
    push: context.push,
    replace: context.replace,
    enableKey: context.enableKey,
    closeByNames: context.closeByNames,
    stopClose: context.stopClose,
    useActiveEffect: context.useActiveEffect
  };
}

function DialogPlus(props, ref) {
  const getPopupContainer = () => document.body;
  const [visible, setVisible] = useState<boolean>(false);
  const prefixCls = 'dialog-plus';
  const mobile = useScreenDesign(screenType.mobile);
  const stateRef = useRef<DialogPlusState>('NONE');
  const [update, setUpdate] = useState<any>({});
  const pageRef = useRef<DialogPagePlusProps[]>([]);
  const maskClipRef = useRef<any>(null);
  const backGroundRef = useRef<any>(null);
  const [refreshDialog] = useRefreshDialog();
  const [drawerVisible, setDrawerVisible] = useMobileLeftSiderSwitch()
  const [searchVisible, setSearchVisible] = useGlobalOpenSearch();
  const [topKey, setTopkey] = useState<string>('');

  const push = (params: DialogPagePlusProps) => {
    // if (pageRef.current.length) {
    //   for (let i = 0; i < pageRef.current.length; ++i) {
    //     if (pageRef.current[i].children['key'] === params.children['key']) {
    //       return;
    //     }
    //   }
    // }
    isFristRef.current = false;
    stateRef.current = 'PUSH';
    pageRef.current.push(params);
    setUpdate({});
    setVisible(true);
    setTopkey(params.children['key']);
  };

  const pushLoadLazy = (path: any, params: DialogLoadLazyProps) => {
    isFristRef.current = false;
    maskClipRef.current.style.transitionDuration = '0.5s';
    //const compoents = lazyLoad(() => import(`${path}`))
    if(!pageRef.current.length && mobile){
      backGroundRef.current.style.transition = `all 0s`;
      backGroundRef.current.style.left = window.innerWidth + 'px'; 
    }
    stateRef.current = 'PUSH';
    pageRef.current.push({ lazyCompoent: path , props: params.props || {} , key:params.key});
    setUpdate({});
    setVisible(true);
    setTopkey(params.key);
  }

  const pop = () => {
    if (!pageRef.current?.length) {
      return;
    }
    stateRef.current = 'POP';
    setUpdate({});
    backGroundRef.current.style.zIndex = 'unset';
  };

  const closeAll = () => {
    stateRef.current = 'CLOSEALl';
    setUpdate({});
  };

  const replace = (path: any, params: DialogLoadLazyProps) => {
    isFristRef.current = false;
    maskClipRef.current.style.transitionDuration = '0.5s';

    stateRef.current = 'REPLACE';
    //pageRef.current.push(params);
    pageRef.current.push({ lazyCompoent: path , props: params.props || {} , key:params.key});
    setUpdate({});
    setVisible(true);
    setTopkey(params.key);
  };

  const handleMobileEnter = () => {
    if (sys.os === 'IOS' && sys.isMobile && pageRef.current.length) {
      document.body.style.overflow = 'hidden';
      document.body.style.overflowY = 'hidden';
    }
  };

  const handleMobileExit = () => {
    if (sys.os === 'IOS' && sys.isMobile) {
      document.body.style.overflow = '';
      document.body.style.overflowY = 'auto';
    }
  };

  const isFristRef = useRef(null);
  useImperativeHandle<DialogPlusRef, any>(ref, () => {
    return {
      push,
      pop,
      closeAll,
      replace,
      pushLoadLazy
    };
  });

  const handleMaskAnimationEnd = () => {
    const state = stateRef.current;
    if (state === 'REPLACE' && pageRef.current.length > 1) {
      pageRef.current.splice(pageRef.current.length - 1, 1);
      setUpdate({});
    } else if (state === 'POP') {
      pageRef.current.pop();
      setUpdate({ remove: true });   
      setTopkey(pageRef.current[pageRef.current.length - 1]?.children?.['key']);
      activityEffectRef.current?.[pageRef.current[pageRef.current.length - 1]?.children?.['key']]?.()
    } else if (state === 'CLOSEALl') {
      pageRef.current.length = 0;
      setUpdate({ remove: true });
      setTopkey(pageRef.current[pageRef.current.length - 1]?.children?.['key']);
    }

    stateRef.current = 'NONE';
    maskClipRef.current.removeEventListener('transitionend', handleMaskAnimationEnd);
  };

  /**处理弹窗状态 */
  const handleDialogState = () => {
    maskClipRef.current.removeEventListener('transitionend', handleMaskAnimationEnd);
    const elements = document.getElementsByClassName('dialog-plus-page');
    const element = elements.item(elements.length - 1) as HTMLElement;
    if (stateRef.current === 'CLOSESELEF') {
      stateRef.current = 'NONE';
      return;
    }

    if (!mobile) {
      if ((stateRef.current === 'PUSH' && elements.length === 1) || (stateRef.current === 'REPLACE' && elements.length === 1)) {
        if (document.body.clientHeight > 500) {
          //maskClipRef.current.style.transitionDuration = '0s';
          maskClipRef.current.style.width = element.clientWidth + 'px';
          maskClipRef.current.style.height = element.clientHeight + 'px';
          maskClipRef.current.style.marginTop = -element.clientHeight / 2 + 'px';
          maskClipRef.current.style.marginLeft = -element.clientWidth / 2 + 'px';
          handleMaskAnimationEnd();
          //maskClipRef.current.addEventListener('transitionend', handleMaskAnimationEnd)
        } else {
          stateRef.current = 'NONE';
        }
        element.style.transform = `translateX(0)`;
      } else if ((stateRef.current === 'POP' && elements.length === 1) || (stateRef.current === 'CLOSEALl' && elements.length)) {
        // maskClipRef.current.style.width = '0px';
        // maskClipRef.current.style.height = '0px';
        // maskClipRef.current.style.marginTop = '0px';
        // maskClipRef.current.style.marginLeft = '0px';
        //maskClipRef.current.addEventListener('transitionend', handleMaskAnimationEnd)

        setVisible(false);
      }
    } else {
      if ((stateRef.current === 'PUSH' && elements.length === 1) || (stateRef.current === 'REPLACE' && elements.length === 1)) {
        backGroundRef.current.style.transition = `all 0.25s`;
        backGroundRef.current.style.left = '0px'; 
        if(element.className.includes('dialog-plus-loading')){
          element.style.transition = `all 0.25s`;
          isFristRef.current = true;
          if(mobile){
            element.style.width = '100vw';
            element.style.height = '100vh';
          }
        }else if(isFristRef.current){
          element.style.transition = `all 0s`;
        }else {
          element.style.transition = `all 0.25s`;
        }
        element.style.transform = `translate3d(${0}px,0px,0px)`;
        const handleElement = () => {
          stateRef.current = 'NONE';
          element.removeEventListener('transitionend', handleElement);
          handleMobileEnter();
        };
        element.addEventListener('transitionend', handleElement);
      } else if ((stateRef.current === 'POP' && elements.length === 1) || (stateRef.current === 'CLOSEALl' && elements.length)) {
        if (stateRef.current === 'CLOSEALl') {
          for (let i = 0; i < elements.length - 1; ++i) {
            const e = elements.item(i) as HTMLElement;
            e.style.display = 'none';
          }
        }
        element.style.transition = `all 0.25s`;
        element.style.transform = `translate3d(${element.clientWidth}px,0px,0px)`;
        const handleElement = () => {
          if (stateRef.current === 'CLOSEALl') {
            pageRef.current.length = 0;
          } else {
            pageRef.current.pop();
          }
          setTopkey(pageRef.current[pageRef.current.length - 1]?.children?.['key']);
          activityEffectRef.current?.[pageRef.current[pageRef.current.length - 1]?.children?.['key']]?.()
          element.removeEventListener('transitionend', handleElement);
          stateRef.current = 'NONE';
          setUpdate({ remove: true });
        };
        element.addEventListener('transitionend', handleElement);
        setVisible(false);
        handleMobileExit();
      }
    }

    if ((stateRef.current === 'PUSH' && elements.length > 1) || (stateRef.current === 'REPLACE' && elements.length > 1)) {


      //console.log("===========",element.clientWidth)
      //if(!element.className.includes('dialog-plus-loading')) {
        if(!mobile){
          maskClipRef.current.style.transitionDuration = '0.3s';
          maskClipRef.current.style.width = element.clientWidth + 'px';
          maskClipRef.current.style.height = element.clientHeight + 'px';
          maskClipRef.current.style.marginTop = -element.clientHeight / 2 + 'px';
          maskClipRef.current.style.marginLeft = -element.clientWidth / 2 + 'px';
        }

      //}

      //右进
      //element.style.transition = `all 0.25s`;

      
      if(element.className.includes('dialog-plus-loading')){
        if(mobile){
          backGroundRef.current.style.transition = `all 0s`;
          backGroundRef.current.style.left = window.innerWidth + 'px'; 
          backGroundRef.current.style.zIndex = '1';
          backGroundRef.current.style.transition = `all 0.25s`;
          backGroundRef.current.style.left = '0px';
        }
        element.style.transition = `all 0.25s`;
        if(mobile){
          isFristRef.current = Date.now();
          element.style.zIndex = '2';
        }
        if(mobile){
          element.style.width = '100vw';
          element.style.height = '100vh';
        }
      }else if(isFristRef.current){
        const delay = (Date.now() - isFristRef.current) / 1000;
        if(delay < 0.1){
          element.style.transition = `all 0.25s`;
        }else {
          element.style.transition = `all 0s`;
        }      
        backGroundRef.current.style.zIndex = '-1';
      }else {
        element.style.transition = `all 0.25s`;
      }
      element.style.transform = `translate3d(${0}px,0px,0px)`;
      const handleElement = () => {
        maskClipRef.current.style.height = element.clientHeight + 'px';
        if (stateRef.current === 'REPLACE' && pageRef.current.length > 1) {
          pageRef.current.splice(pageRef.current.length - 2, 1);
          setUpdate({});
        }
        stateRef.current = 'NONE';
        element.removeEventListener('transitionend', handleElement);
      };
      element.addEventListener('transitionend', handleElement);
    } else if (stateRef.current === 'POP' && elements.length > 1) {
      //左出
      const element2 = elements.item(elements.length - 2) as HTMLElement;

      if (element2) {
        maskClipRef.current.style.transitionDuration = '0.3s';
        maskClipRef.current.style.width = element2.clientWidth + 'px';
        maskClipRef.current.style.height = element2.clientHeight + 'px';
        maskClipRef.current.style.marginTop = -element2.clientHeight / 2 + 'px';
        maskClipRef.current.style.marginLeft = -element2.clientWidth / 2 + 'px';
      }

      element.style.transition = `all 0.25s`;
      element.style.transform = `translate3d(${element.clientWidth}px,0px,0px)`;
      activityEffectRef.current?.[pageRef.current[pageRef.current.length - 2]?.['key']]?.()
      const handleElement = () => {
        //maskClipRef.current.style.height = element2.clientHeight + 'px';
        stateRef.current = 'NONE';
        pageRef.current.pop();
        element.removeEventListener('transitionend', handleElement);
        setUpdate({ remove: true });
        setTopkey(pageRef.current[pageRef.current.length - 1]?.['key']);
      };
      element.addEventListener('transitionend', handleElement);
    }
  };

  useEffect(() => {
    if (maskClipRef.current) {
      setTimeout(() => {
        handleDialogState();
      }, 0);
    }
  }, [update,refreshDialog]);

  useEffect(()=>{
    if(refreshDialog) {
      if(stateRef.current !== 'REPLACE') {
        stateRef.current = 'PUSH';
      }
      //setUpdate({})
    }
  },[refreshDialog])

  useEffect(() => {
    if (maskClipRef.current) {
      if (mobile) {
        maskClipRef.current.style.width = '100%';
        maskClipRef.current.style.height = '100%';
        maskClipRef.current.style.marginTop = '0px';
        maskClipRef.current.style.marginLeft = '0px';
        handleMobileEnter();
      } else {
        const elements = document.getElementsByClassName('dialog-plus-page');
        const element = elements.item(elements.length - 1) as HTMLElement;
        if (element) {
          handleMobileExit();
          setTimeout(() => {
            maskClipRef.current.style.marginTop = '0px';
            maskClipRef.current.style.marginLeft = '0px';
            maskClipRef.current.style.width = '0px';
            maskClipRef.current.style.height = '0px';
            stateRef.current = 'PUSH';
            setUpdate({});
          }, 400);
        }
      }
    }
  }, [mobile]);

  const handleColseSlef = (key?: string) => {
    for (let i = 0; i < pageRef.current.length; ++i) {
      if (pageRef.current[i]?.children?.['key'] === key || pageRef.current[i]?.key === key) {
        if (i === pageRef.current.length - 1) {
          if (pageRef.current[i]['dialogFlag']) {
            return;
          }
          pageRef.current[i]['dialogFlag'] = "destory"
          pop();
        } else {
          pageRef.current.splice(i, 1);
          stateRef.current = 'CLOSESELEF';
          setUpdate({ remove: true });
        }
        return;
      }
    }
  };

  const handleColseByNames = (keys: string[]) => {
    if (pageRef.current.length < keys.length) {
      return
    }
    if (keys.length === pageRef.current.length) {
      closeAll()
      return
    }
    if (keys.length < 2) {
      handleColseSlef(keys[0])
      return
    }
    let flagRemoveTop = false;
    const topKey = pageRef.current[pageRef.current.length - 1]['key'];
    keys.forEach((key: string) => {
      for (let i = 0; i < pageRef.current.length; ++i) {
        if (pageRef.current[i]?.children?.['key'] === key || pageRef.current[i]?.key === key) {
          if (topKey === key) {
            flagRemoveTop = true;
          } else {
            pageRef.current.splice(i, 1);
          }

          return
        }
      }
    })
    if (flagRemoveTop) {
      pop()
    } else {
      stateRef.current = 'CLOSESELEF';
      setUpdate({ remove: true });
    }
  }

  const hadnleShowBtnBack = (key?: string) => {
    if (pageRef.current.length <= 1 || (pageRef.current.length === 2 && stateRef.current === 'REPLACE')) {
      return false;
    }
    for (let i = 0; i < pageRef.current.length; ++i) {
      if (pageRef.current[i]?.children?.['key'] === key || pageRef.current[i]?.key === key) {
        return true;
      }
    }
    return false;
  };

  const handleWindowResize = debounce(() => {
    //console.log('刷新了===========')
    if (pageRef.current.length) {
      stateRef.current = 'PUSH';
      setUpdate({});
    }
  }, 400);
  const updateWindowResize = () => {
    handleWindowResize();
  };
  useEffect(() => {
    window.removeEventListener('resize', updateWindowResize);
    window.addEventListener('resize', updateWindowResize);

    return () => {
      window.removeEventListener('resize', updateWindowResize);
    };
  }, [drawerVisible]);

  useEffect(() => {
    const nativeClickBack = () => {
      if (drawerVisible) {
        setDrawerVisible(false)
      } else if (pageRef.current.length) {
        pop()
      } else if (searchVisible) {
        setSearchVisible(false)
      } else {
        window.history.back();
      }
    }
    document.removeEventListener("nativeClickBack", nativeClickBack)
    document.addEventListener('nativeClickBack', nativeClickBack);
    return () => {
      document.removeEventListener("nativeClickBack", nativeClickBack)
    }
  }, [drawerVisible, searchVisible])

  // useEffect(() => {
  //   if (!drawerVisible && !searchVisible && !pageRef.current.length) {
  //     return
  //   }

  //   if (stateRef.current !== 'PUSH' && pageRef.current.length != 0) {
  //     return
  //   }

  //   const goBack = () => {
  //     if (drawerVisible) {
  //       setDrawerVisible(false)
  //     } else if (pageRef.current.length) {
  //       pop()
  //     } else if (searchVisible) {
  //       setSearchVisible(false)
  //     }
  //   }
  //   history.pushState(null, '', document.URL);
  //   //window.removeEventListener("popstate",goBack)
  //   window.addEventListener('popstate', goBack)
  //   return () => {
  //     window.removeEventListener("popstate", goBack)
  //   }
  // }, [drawerVisible, searchVisible, update])

  const clickBackgroundRef = useRef(false)
  function stopClose() {
    clickBackgroundRef.current = true;
  }
  const activityEffectRef = useRef<any>()
  function useActiveEffect (effect,name){
    if(!activityEffectRef.current) {
      activityEffectRef.current = {}
    }
    activityEffectRef.current[name] = effect
  }

  const passedContext: IFDialogPlusContext = {
    closeSelf: handleColseSlef,
    showBtnBack: hadnleShowBtnBack,
    closeAll: closeAll,
    pop: pop,
    push: push,
    replace: replace,
    enableKey: topKey,
    closeByNames: handleColseByNames,
    stopClose: stopClose,
    useActiveEffect: useActiveEffect
  };



  useEffect(() => {
    if (!visible && maskClipRef.current) {
      maskClipRef.current.style.transitionDuration = '0s';
      maskClipRef.current.style.width = '0px';
      maskClipRef.current.style.height = '0px';
      maskClipRef.current.style.marginTop = '0px';
      maskClipRef.current.style.marginLeft = '0px';
      pageRef.current.length = 0;
    }
    if (!visible) {
      isFristRef.current = false;
      setTimeout(() => {
        if (sys.os === 'IOS' && sys.isMobile) {
          document.body.style.overflow = '';
          document.body.style.overflowY = 'auto';
        }
      }, 400);
      if(backGroundRef.current) {
        backGroundRef.current.style.zIndex = 'unset';
      }

    }
  }, [visible]);

  return (
    <Portal visible={visible} forceRender={true} getContainer={getPopupContainer}>
      <CSSTransition
        in={visible}
        timeout={400}
        appear
        mountOnEnter={false}
        classNames="fadedialog"
        unmountOnExit={false}
        onEnter={(e) => {
          e.style.display = 'block';
        }}
        onExited={(e) => {
          e.style.display = 'none';
          handleMaskAnimationEnd();
        }}
      >
        <div aria-hidden className={`${prefixCls} ${prefixCls}-mask`} onMouseUp={() => {
          setTimeout(() => {
            clickBackgroundRef.current = false;
          }, 16);
        }} onClick={() => {
          if (!clickBackgroundRef.current) {
            pop()
          }
        }}>
          <DialogPlusContext.Provider value={passedContext}>
            <div className={classNames([`${prefixCls}-clip-mask`])} ref={maskClipRef}>
             <div className='dialog-background' ref={backGroundRef}></div>
              {pageRef.current?.map((v) => {
                if(v.key) {
                  return <v.lazyCompoent key={v.key} {...v.props} />
                }else {
                  return v?.children;
                }
              })}
            </div>
          </DialogPlusContext.Provider>
        </div>
      </CSSTransition>
    </Portal>
  );
}
export default forwardRef(DialogPlus);

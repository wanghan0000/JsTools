import './index.less';
import classNames from 'classnames';
import React, { CSSProperties, PropsWithChildren, useEffect, useState } from 'react';
import SpinUI from '../Spin';
import ResultUI from '../Result';
import EmptyUI from '../Empty';
import mobilePath from '@/components/LogoUI/assets/pc_logo.png';
export interface LoadingSuperPlusUIProps {
  loading?: boolean;
  error?: any;
  dataList?: any;
  retryFunc?: () => void;
  className?: string;
  style?: CSSProperties | undefined;
  delayTime?: number;
  btnText?: string;
  cusFunc?: () => void;
  showLogo?: boolean;
  extraStyle?: any;
}

type LoadinState = 'Loading' | 'Error' | 'Empty' | 'Done';

const LoadingSuperPlusUI = (props: PropsWithChildren<LoadingSuperPlusUIProps>) => {
  const { loading, error, dataList, retryFunc, className, style, children, delayTime = 150, btnText, cusFunc, showLogo, extraStyle } = props;
  const prefixCls = 'loading-super-plus-ui';

  const [state, setState] = useState<LoadinState>('Loading');

  useEffect(() => {
    if (typeof loading === 'undefined') {
      setState('Done');
    }
  }, []);

  useEffect(() => {
    if (!loading && error) {
      setState('Error');
    }
  }, [error, loading]);

  useEffect(() => {
    if (!loading && !error && dataList && Object.keys(dataList ?? [])?.length === 0) {
      setState('Empty');
    }
  }, [dataList]);

  useEffect(() => {
    let timer;
    if (typeof loading !== 'undefined' && !error && Object.keys(dataList ?? [])?.length > 0 && !loading) {
      timer = setTimeout(() => {
        setState('Done');
      }, delayTime);
    } else if (loading) {
      setState('Loading');
    }
    return () => {
      timer && clearTimeout(timer);
    };
  }, [loading, dataList]);
  return (
    <>
      {state !== 'Done' && (
        <div className={classNames([`${prefixCls}`, className])} style={style}>
          {showLogo
            ? state === 'Loading' && (
                <div style={{ display: 'flex', justifyContent: 'center', flexDirection: 'column', marginBottom: 100 }}>
                  <div>
                    <img src={mobilePath} />
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'center', marginTop: 20 }}>
                    <SpinUI className={`${prefixCls}-spin-ui`} dot block loading={true} />
                  </div>
                </div>
              )
            : state === 'Loading' && <SpinUI className={classNames([`${prefixCls}-spin-ui`, extraStyle])} dot block loading={true} />}
          {state === 'Error' && <ResultUI status={'error'} errorCode={error?.code} retryFunc={retryFunc} cusFunc={cusFunc} btnText={btnText} />}
          {state === 'Empty' && <EmptyUI showIcon={false} description={'NoData'} />}
        </div>
      )}
      <div className={classNames([className, `${prefixCls}-content`, state === 'Done' ? `${prefixCls}-loaded` : `${prefixCls}-other`])}>
        {!loading && children}
      </div>
    </>
  );
};

export default LoadingSuperPlusUI;

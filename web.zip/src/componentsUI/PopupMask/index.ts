import './style/index.less'
import PopupMask from './popupMask';

export default PopupMask;
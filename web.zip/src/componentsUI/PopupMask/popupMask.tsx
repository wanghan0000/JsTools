import Portal from '@arco-design/web-react/es/Portal';
import classNames from 'classnames';
import React, {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';
import { CSSTransition } from 'react-transition-group';

function PopupMask(props) {
  const getPopupContainer = () => document.body;
  const {children , visible} = props;
  const prefixCls = 'jokerma-popup';

  const wrapperRef = useRef(null);


  return (
    <Portal visible={visible} forceRender={true} getContainer={getPopupContainer} >
      <div  >
        <CSSTransition
          in={visible}
          timeout={400}
          appear
          mountOnEnter={false}
          classNames="fadeModal"
          unmountOnExit={false}
          onEnter={(e) => {
            e.style.display = 'block';
          }}
          onExited={(e) => {
            e.style.display = 'none';
          }}
        >
          <div aria-hidden className={`${prefixCls}-mask`} />
        </CSSTransition>
        {<div
          role="popup"
          aria-modal="true"
          ref={wrapperRef}
          className={classNames(`${prefixCls}-wrapper`, `${prefixCls}-wrapper-align-center`)}
        >
          <div className={classNames([`${prefixCls} ${prefixCls}-content`])}>
              {children}
          </div>
        </div>}
      </div>
    </Portal>
  );
}


export default PopupMask;

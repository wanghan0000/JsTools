﻿import React, { CSSProperties } from 'react'
import SpinUI from '../Spin';
import ResultUI from '../Result';
import EmptyUI from '../Empty';
import './loadingUI.less'

type Props = {
    isLoading?: boolean;
    error?: any;
    dataList?: any;
    retryFunc?: () => void;
    children?: any;
    animationCls?: any;
    btnText?: any;
    errorText?: any;
    style?: CSSProperties
}

export default function LoadingUI(pros: Props) {
    const { isLoading, error, dataList, retryFunc, children  ,animationCls , btnText ,errorText , style} = pros;
    return (
        <>
            {
                isLoading && <div 
                className={animationCls + ' web-loading-state-ui'}
                style={style}>
                    <SpinUI dot block loading={true} />
                </div>
            }
            {
                !isLoading && error && <div className='web-loading-state-ui' style={style}>
                    <ResultUI status='error' errorCode={error?.code} retryFunc={retryFunc} btnText={btnText} errorText={errorText}/>
                </div>
            }
            {

                !isLoading && !error && (Object.keys(dataList ?? [])?.length === 0) ? <div 
                className='web-loading-state-ui'
                style={style}>
                    <EmptyUI showIcon={false} description={'NoData'} />
                </div> : !isLoading && !error && children
            }

        </>
    )
}
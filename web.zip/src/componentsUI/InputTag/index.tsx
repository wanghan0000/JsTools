import { InputTag, InputTagProps } from "@arco-design/web-react";
import React, { FC,ReactNode } from "react";

type Iprops = InputTagProps & {
    size?:string
}

const InputTagUI: FC<Iprops> = (props) => {


    return (
        <InputTag  {...props} >
        </InputTag>
    )
}

export default InputTagUI;
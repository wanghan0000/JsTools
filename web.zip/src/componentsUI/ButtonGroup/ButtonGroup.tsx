import { Button, Radio, RadioProps } from "@arco-design/web-react"
import classNames from "classnames";
import React from "react"
import ButtonUI from "../Button";

const RadioGroup = Radio.Group;

export const ButtonGroupItem = (props: RadioProps) => {
    const {value,className} = props;
    return (
        <Radio {...props}
        className={classNames([className,'arco-mt2-button-group-item'])}
        >
            {
                ({checked}) => {
                    return (
                        <ButtonUI tabIndex={-1} key={value} className={checked? 'is-cheked' : 'no-checked'} >
                            {value}
                        </ButtonUI>
                    )
                }
            }
        </Radio>
    )
}

const ButtonGroup = (props) => {
    const { className } = props;
    return (<RadioGroup
        {...props}
        className={classNames([className,'arco-mt2-button-group'])}
    >
    </RadioGroup>)
}

export default ButtonGroup
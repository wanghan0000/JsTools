

import { Space,Typography ,Avatar} from '@arco-design/web-react';
import React, { useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { IconApps, IconUser } from '@arco-design/web-react/icon';

import   './index.less'
import InputTagUI from '@/componentsUI/InputTag';

const ReadIpt = (props) => {

    const {tit,readOnly,rangeAmount}=props
    const p={...props}
    delete p.rangeAmount
    props={...p}
    return (
            <dl className='wallet-read-dl'>
                <dt  className='wallet-dt'>{tit}</dt>
                  <dd>{rangeAmount}</dd>
                <dd  className='wallet-dd'>
                         <InputTagUI readOnly={readOnly} {...props} > </InputTagUI>
                </dd>
            </dl>
    );
};

export default ReadIpt;



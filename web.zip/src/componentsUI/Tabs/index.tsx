/*
 * @Author: ilal 1
 * @Date: 2023-05-09 19:08:48
 * @LastEditors: ilal 1
 * @LastEditTime: 2023-05-10 14:57:18
 * @FilePath: \web 2.0\src\componentsUI\Tabs\index.tsx
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import React, { FC } from 'react';
import { Tabs, TabsProps } from '@arco-design/web-react';
import styles from './index.module.less';
//继承类型
type Iprops = TabsProps & {
  active?: boolean;
  data?: any;
  childrenTabs?: any;
  activeTab?: string;
  activeTab2?: string;
  onChangeTab?: (key: string) => void;
  onChangeTab2?: (key: string) => void;
  onClickTab?: (key: string) => void;
  type?: string;
};

const TabsUI: FC<Iprops> = (props) => {
  //继承属性，自定义逻辑
  const {
    data,
    childrenTabs,
    activeTab,
    onChangeTab,
    activeTab2,
    onChangeTab2,
    onClickTab,
    type,
  } = props;
  const renderChildrenTabs = () => {
    return (
      <div>
        <Tabs
          className={styles['tabsContainer-tab']}
          size="large"
          activeTab={activeTab2}
          onChange={onChangeTab2}
          style={{ width: '100%' }}
        >
          {childrenTabs.map((item, index) => {
            return (
              <Tabs.TabPane key={index} title={item.name}>
                {props.children}
              </Tabs.TabPane>
            );
          })}
        </Tabs>
      </div>
    );
  };
  return (
    <div>
      <Tabs
        className={styles['tabsContainer']}
        size="large"
        activeTab={activeTab}
        onChange={onChangeTab}
        onClickTab={onClickTab}
        type={type}
      >
        {data.map((item, index) => {
          return (
            <Tabs.TabPane key={index} title={item.name}>
              {childrenTabs! ? renderChildrenTabs() : props.children}
            </Tabs.TabPane>
          );
        })}
      </Tabs>
    </div>
  );
};
export default TabsUI;

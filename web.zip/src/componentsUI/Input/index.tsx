import './index.less'
import omit from "@/Core/utils/omit";
import { Input, InputProps, Trigger } from "@arco-design/web-react";
import React, { FC, forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react";
import classNames from 'classnames';
import useScreenDesign, { screenType } from '@/Core/utils/hooks/useScreenDesign';

export interface InputPlusProps extends InputProps {
    onBlur?: () => void;
    onFocus?: () => void;
    initFocus?: boolean;
    dataList?: string[];
    onClickDropData?: (v: string)=>void;
    triggerDisabled?: boolean
}

const InputUI = (props , ref) => {
    const { onBlur, onFocus, className, initFocus, dataList = [] , onClickDropData ,triggerDisabled} = props;
    const other = omit(props, ['onBlur', 'onFocus', 'initFocus' , 'dataList' , 'onClickDropData' , 'triggerDisabled'])
    const mobile = useScreenDesign(screenType.mobile)
    const input = useRef(null)
    const [focus,setFocus] = useState(false);
    useEffect(() => {
        if (input.current && initFocus) {
            input.current.focus();
        }
    }, [input])

    const triggreBlur = ()=> {
        if(input.current){
            input.current.blur()
            console.log(triggerRef.current)
            //triggerRef.current.onBlur()
        }
    }
    const triggerFocus = () => {
        if(input.current){
            input.current.focus()
            console.log(triggerRef.current)
            //triggerRef.current.onFocus()
        }
    }

    useImperativeHandle(ref,()=>{
        return {
            triggreBlur,
            triggerFocus
        }
    })

    const triggerRef = useRef(null);
    
    return (
        <Trigger
            disabled={triggerDisabled}
            popup={() => (<div></div>)}
            trigger={'focus'}
            onVisibleChange={(visible) => {
                console.log('=======',visible)
                if (!visible) {
                    setFocus(false)
                    onBlur && onBlur()
                } else {
                    setFocus(true)
                    onFocus && onFocus()
                }
            }}
            ref={triggerRef}
        >
            <Input
                {...other}
                ref={input}
                size={mobile ? 'small' : 'default'}
                className={classNames(['arco-mt2-input-ui', className])}
            >
            </Input>
            {!!dataList?.length && focus && <div className='input-ui-data-list'>
                {
                    dataList.map((v, i) => {

                        return v?.length <= 47 ? <div key={i + ''} 
                        onClick={()=>{onClickDropData && onClickDropData(v)}}
                        >
                            {v}
                        </div> : <div key={i + ''}
                        onClick={()=>{onClickDropData && onClickDropData(v)}}
                        >
                            <span className='r'>{v.slice(0,40)}</span>
                            <span className='l'>{v.slice(40)}</span>
                        </div>
                    })
                }
            </div>}
        </Trigger>

    )
}

export default forwardRef(InputUI);
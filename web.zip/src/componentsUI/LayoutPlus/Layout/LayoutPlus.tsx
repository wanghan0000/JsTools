import React, { PropsWithChildren, ReactNode, forwardRef, useEffect, useRef, useState } from "react";

export interface LayoutPlusProps {
    header?: ReactNode;
    className?: string;
}

const LayoutPlus = (props: PropsWithChildren<LayoutPlusProps> , ref) => {

    const [marginBottom, setMarginBottom] = useState(0);
    const headref = useRef(null)

    useEffect(() => {
        const element = headref.current;
        if (element) {
            setMarginBottom(element.clientHeight)
        }
        const resizeObserver = new ResizeObserver(() => {
            setMarginBottom(element.clientHeight)
        })
        resizeObserver.observe(element)
        return () => {
            resizeObserver.disconnect()
        }
    }, [])

    return (<div style={{ overflow: 'hidden', height: '100%' }} className={props?.className}>
        <div ref={headref}>
            {props?.header}
        </div>
        <div style={{
            overflowY: 'auto',
            overscrollBehavior: 'contain',
            height: '100%',
            overflowX: 'hidden'
        }} ref={ref}>
            <div style={{ marginBottom: marginBottom }}>
                {props?.children}
            </div>

        </div>
    </div>)
}


export default forwardRef(LayoutPlus)
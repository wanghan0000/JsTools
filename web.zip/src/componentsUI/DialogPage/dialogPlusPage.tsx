import './index.less';
import classNames from 'classnames';
import React, { PropsWithChildren, ReactNode, CSSProperties, useState, useEffect } from 'react';
import DialogPlusHead from './DialogDefaultHead/dialogPlusHead';
import SpinUI from '../Spin';
import ResultUI from '../Result';
import EmptyUI from '../Empty';
import { useDialogPlus } from '../Dialog/dialogPlus';

export interface DialogPlusPageProps {
  className?: string;
  /**必传 用于关闭指定弹窗标识*/
  dialogName: string;

  header?: ReactNode;

  title?: string;

  style?: any;

  /**固定头部  */
  fixedHeader?: ReactNode;

  isLoading?: boolean;
  error?: any;
  dataList?: any;
  retryFunc?: () => void;
  childrenStyle?: CSSProperties;
  delayTime?: number;
  dialogScrollId?: any;

  /**是否隐藏关闭按钮 */
  isHideClose?: boolean;
}

const DialogPlusPage = (props: PropsWithChildren<DialogPlusPageProps>) => {
  const {
    children,
    dialogName,
    header,
    title,
    className,
    style,
    fixedHeader,
    dialogScrollId,
    isLoading,
    error,
    dataList,
    retryFunc,
    childrenStyle,
    delayTime = 300,
    isHideClose,
  } = props;
  const prefixCls = 'dialog-plus-page';

  const showHead = typeof header === 'undefined';
  const [delayLoading, setDelayLoading] = useState<boolean>(true);
  const { stopClose } = useDialogPlus()
  useEffect(() => {
    if (typeof isLoading === 'undefined') {
      setDelayLoading(false);
    }
  }, []);

  useEffect(() => {
    let timer;
    if (typeof isLoading !== 'undefined') {
      if (!isLoading) {
        timer = setTimeout(() => {
          setDelayLoading(false);
        }, delayTime);
      } else {
        setDelayLoading(true);
      }
    }
    return () => {
      timer && clearTimeout(timer);
    };
  }, [isLoading, error, dataList]);

  return (
    <div style={style} className={classNames([prefixCls, className])} onMouseDown={(e)=>{
      stopClose()
    }} onClick={(e)=>{
      e.preventDefault()
      e.stopPropagation()
    }}>
      {showHead ? <DialogPlusHead dialogName={dialogName} title={title} isHideClose={isHideClose} /> : header}

      {delayLoading && (
        <div className={classNames([`${prefixCls}-loading`])}>
          <SpinUI className={`${prefixCls}-spin-ui`} dot block loading={delayLoading} />
        </div>
      )}
      {!delayLoading && error && (
        <div className={`${prefixCls}-loading`}>
          <ResultUI errorCode={error?.code} retryFunc={retryFunc} />
        </div>
      )}
      {!delayLoading && !error && !isLoading && Object.keys(dataList ?? [])?.length === 0 && typeof isLoading !== 'undefined' && (
        <div className={`${prefixCls}-loading`}>
          <EmptyUI showIcon={false} description={'NoData'} />
        </div>
      )}

      {fixedHeader && (
        <div
          className={classNames([
            `${prefixCls}-fixed-header`,
            (!delayLoading && !error && Object.keys(dataList ?? [])?.length > 0) || typeof isLoading === 'undefined'
              ? `${prefixCls}-fixed-header-loaded`
              : '',
          ])}
        >
          {fixedHeader}
        </div>
      )}
      <div
        className={classNames([
          `${prefixCls}-scorllview`,
          (!delayLoading && !error && Object.keys(dataList ?? [])?.length > 0) || typeof isLoading === 'undefined'
            ? `${prefixCls}-scorllview-loaded`
            : '',
        ])}
        style={childrenStyle}
        id={dialogScrollId}
      >
        {children}
      </div>
    </div>
  );
};

export default DialogPlusPage;

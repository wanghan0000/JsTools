import { useDialogPlus } from '@/componentsUI/Dialog/dialogPlus';
import { IconClose, IconLeft } from '@arco-design/web-react/icon';
import classNames from 'classnames';
import React, { CSSProperties, ReactNode, useEffect, useState } from 'react';
import './index.less'

export interface DialogPlusHeadProps {
    className?: string | string[];
    /**
     *@zh 标题
     */
    title?: string | ReactNode;

    style?: CSSProperties;

    styleTitle?: CSSProperties;

    styleIcon?: CSSProperties;

    /**必传 用于关闭指定弹窗标识*/
    dialogName: string;

    /**是否隐藏关闭按钮 */
    isHideClose?: boolean
}

const DialogPlusHead = (props: DialogPlusHeadProps) => {
    const { className, title = 'title', style, styleTitle, styleIcon, dialogName , isHideClose} = props;
    const prefixCls = 'dialog-plus-head';
    const [btnBack, setBtnBack] = useState<boolean>(false)
    const { showBtnBack , closeAll , closeSelf} = useDialogPlus()

    useEffect(() => {
        setBtnBack(showBtnBack(dialogName))
    }, [])
    return (
        <>
            {btnBack && <button className={
                classNames([
                    `${prefixCls}-back`,
                    `${prefixCls}-button`
                ])
            }
                onClick={()=>{
                    closeSelf(dialogName)
                }}
            >
                <IconLeft style={styleIcon} className={'svg-icon'} />
            </button>}
            <div 
            style={style}
            className={
                classNames([
                    `${prefixCls}`,
                    btnBack ? `${prefixCls}-hasback` : '',
                    className
                ])
            }>
                <div className={`${prefixCls}-title`} style={styleTitle}>{title}</div>
            </div>
            {!isHideClose && <button className={
                classNames([
                    `${prefixCls}-close-icon`,
                    `${prefixCls}-button`
                ])
            }
                onClick={()=>{
                    closeAll()
                }}
            >
                <IconClose style={styleIcon} className={'svg-icon'} />
            </button>}
        </>
    );
};

export default DialogPlusHead;

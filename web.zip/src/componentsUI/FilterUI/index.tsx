import './index.less';
import SelectUI from '@/componentsUI/Select';
import { Divider, Select } from '@arco-design/web-react';
import React, { useEffect, useRef, useState } from 'react';
import classNames from 'classnames';
import { useFilterMenu } from '@/store/FliterUI';
import { useTranslationPlus } from '@/Core/i18n/useTranslationPlus';
import useScreenDesign from '@/Core/utils/hooks/useScreenDesign';

interface Props {
  className?: string;
  onChange?: (v?: any, op?: any) => void;
  gameType: number;
}

const SortUI = (props: Props) => {
  const { className, onChange, gameType } = props;
  const { t } = useTranslationPlus('FilterItem');
  const filterUIRef = useRef(null);
  const [values, setValues] = useState([]);
  const { data, revalidate, isLoading, error } = useFilterMenu({ gameType });
  const isMobile = useScreenDesign();
  return (
    <div ref={filterUIRef} className={classNames([`filter-ui-complete`, className])}>
      {!isMobile && (
        <div className={'l'}>
          <p>{t('filter')}</p>
        </div>
      )}

      <SelectUI
        loading={isLoading}
        disabled={isLoading}
        className={'selectUI'}
        onChange={(value, options) => {
          if (value || options) {
            setValues(value);
            onChange(value, options);
          }
        }}
        allowClear
        value={values}
        mode="multiple"
        maxTagCount={0}
        placeholder={t('placeholder')}
        getPopupContainer={() => filterUIRef?.current}
        renderFormat={(op, value) => {
          return op ? <span>{op.value}</span> : <>{value}</>;
        }}
        dropdownRender={(menu) => (
          <div className="dropdownRender">
            <div className="headerTile">
              <span
                className="text"
                onClick={() => {
                  setValues([]);
                  onChange([]);
                }}
              >
                {t('ClearAll')}
              </span>
            </div>
            <Divider className="Divider" />
            {menu}
          </div>
        )}
        showSearch={false}
      >
        {data?.map((item) => {
          return (
            <Select.Option key={item.platformCode} value={item.platformCode}>
              <div className="formatItem">
                <div className="left">{item.platformName}</div>
                <div className="right">{item.total}</div>
              </div>
            </Select.Option>
          );
        })}
      </SelectUI>
    </div>
  );
};

export default SortUI;

import './index.less'
import React, { FC, ReactNode } from "react";
import { Select, SelectProps } from "@arco-design/web-react";
import useScreenDesign from "@/Core/utils/hooks/useScreenDesign";
import omit from "@/Core/utils/omit";
import classNames from "classnames";


export interface SelectUIProps extends SelectProps {
  addAfter?: ReactNode;
}

const SelectUI = (props: SelectUIProps) => {
  const { addAfter, addBefore, className } = props;
  const mobile = useScreenDesign()
  const other = omit(props, ['addAfter'])
  const prefixCls = 'select-ui'
  return (
    <Select {...other} size={mobile ? 'small' : 'default'}
      addBefore={
        addBefore ? addBefore : addAfter
      }
      className={classNames([`${prefixCls}`, className, addAfter ? `${prefixCls}-add-after` : ''])}
    ></Select>
  )

}
export default SelectUI;

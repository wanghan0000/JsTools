import React from 'react';
import { Container } from './indexEle';
import { Breadcrumb } from '@arco-design/web-react';
import { useLocation, useNavigate, useParams } from 'react-router';
import { IconRight } from '@arco-design/web-react/icon';
import { useTranslationPlus } from '@/Core/i18n/useTranslationPlus';

const BreadcrumbItem = Breadcrumb.Item;

const BreadcrumbUI = () => {
  const { pathname, state } = useLocation();
  const params: any = useParams();
  const { t } = useTranslationPlus('HomeView');
  const navigate = useNavigate();

  const routesMap = {
    '/originalList': t('Original'),
    '/recommendList': t('Recommend'),
    '/slotList': t('Slot'),
    '/tableList': t('Table'),
    '/hotList': t('Hot'),
    '/favoriteList': t('Favorite'),
    '/playedList': t('Played'),
    '/sportsIm': t('SportIm'),
    '/sportsPb': t('SportPb'),
    ['/platformList/' + params?.platformCode]: state?.title,
    '/Activity': t('Activity'),
    '/NationalProxy': t('Affiliate'),
    '/InviteDashBoard': t('Affiliate'),
    '/bonus': t('Bonus'),
    '/fishing': t('Fishing'),
    '/videoConferencing': t('VideoConferencing'),
    '/bingo': t('Bingo'),
  };

  const callback = () => {
    navigate('/home');
  };

  return (
    <Container>
      <Breadcrumb style={{ display: !!routesMap[pathname] ? 'block' : 'none' }} separator={<IconRight />}>
        <BreadcrumbItem className="callback" onClick={callback}>
          {t('tabHome')}
        </BreadcrumbItem>
        <BreadcrumbItem>{routesMap[pathname]}</BreadcrumbItem>
      </Breadcrumb>
    </Container>
  );
};

export default BreadcrumbUI;

import { styled } from 'styled-components';

export const Container = styled.div`
  display: flex;
  align-items: center;
  .arco-breadcrumb {
    @media screen and (max-width: 621px) {
      font-size: 12px;
    }
    background: var(--color-bg-1);
    padding-left:14px;
    padding-right:14px;
    padding-top:8px;
    padding-bottom:8px;
    border-radius:2px;
    font-size: 14px;
  }
  .arco-breadcrumb-item {
    padding: 0;
  }
  .arco-breadcrumb-item-separator {
    line-height: 0;
  }
  .callback {
    cursor: pointer;
    &:hover {
      color: var(--color-text-1);
    }
  }
`;

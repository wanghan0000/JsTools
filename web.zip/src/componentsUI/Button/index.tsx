import './style/index.less';
import React, { FC, forwardRef, ReactNode, CSSProperties } from 'react';
import { Button, ButtonProps, Space } from '@arco-design/web-react';
import useScreenDesign, { screenType } from '@/Core/utils/hooks/useScreenDesign';
import classNames from 'classnames';
import omit from '@/Core/utils/omit';

//继承类型
type Iprops = ButtonProps & {
  buttonColor?: 'link-6' | 'secondary' | 'white' | 'blue-1';
};

const ButtonUI: FC<Iprops> = (props) => {
  //继承属性，自定义逻辑
  const { buttonColor, className, style, loading } = props;
  const mobile = useScreenDesign(screenType.mobile);
  const prefix = 'buttonui';
  const other = omit(props, ['buttonColor']);
  return (
    <Button
      loading={loading}
      style={style}
      {...other}
      size={mobile ? 'small' : 'default'}
      className={classNames([className, `${prefix}-${buttonColor}`])}
    ></Button>
  );
};
export default ButtonUI;

import React, {FC, forwardRef, PropsWithChildren, PropsWithoutRef, useImperativeHandle, useRef, useState} from "react";
import {  Space } from "@arco-design/web-react";
import {Tag,TagProps} from '@arco-design/web-react'

// //继承类型
// type Iprops = TagProps & {
//     ishow?:any
// };

type closeStatue = 'hover' | 'default'

 interface Iprops extends  TagProps {
    showClose?:boolean
 }


const TagUI:FC<Iprops>= (props:Iprops)=>{
    //继承属性，自定义逻辑
    const [showClose,setShowClose] = useState(false);

    const onMouseOver = () => {
        if(props.showClose) return;
        setShowClose(true)
    }
    const onMouseLeave = () => {
        if(props.showClose) return;
        setShowClose(false)
    }

    return (
           <Tag style={{cursor:'pointer'}}  {...props} closable={showClose} onMouseOver={onMouseOver} onMouseLeave={onMouseLeave}>
               {props.children}
           </Tag>
    )

}
export default TagUI;

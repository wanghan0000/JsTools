import { Spin, SpinProps } from '@arco-design/web-react';
import React, { FC } from 'react';

export interface SpinUIProps extends SpinProps {
  isShow?: string;
}

const SpinUI: FC<SpinUIProps> = (props) => {
  return <Spin {...props}></Spin>;
};

export default SpinUI;

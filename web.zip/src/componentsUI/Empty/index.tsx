import { Empty, EmptyProps } from '@arco-design/web-react';
import React, { FC } from 'react';
import { IconEmpty, IconExclamation } from '@arco-design/web-react/icon';

import styles from './styles/index.module.less';

import { useTranslationPlus } from '@/Core/i18n/useTranslationPlus';
export interface EmptyUIProps extends EmptyProps {
  //根据swr的各种状态,展示各种状态空组件
  showIcon?: boolean;
  bkground?: string;
  description?: string;
}
const EmptyUI: FC<EmptyUIProps> = (props) => {
  const { t } = useTranslationPlus('HomeView');
  const { showIcon, bkground, description } = props;
  const p = { ...props };
  delete p?.showIcon;
  delete p?.bkground;
  delete p?.description;
  props = { ...p };
  return (
    <Empty
      description={t(description)}
      icon={
        true && (
          <div className={styles['emptyIcon']} style={{ background: bkground }}>
            {<IconEmpty style={{ width: '1em', height: '1em' }} />}
          </div>
        )
      }
      {...props}
    />
  );
};

export default EmptyUI;

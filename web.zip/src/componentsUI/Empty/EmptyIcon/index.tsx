


import {IconExclamation,IconProps} from '@arco-design/web-react/icon';
import React, { FC } from 'react';

export interface IconExclamationUIProps extends IconProps {
  //根据swr的各种状态,展示各种状态空组件
  isStatus?:string
}

const IconExclamationUI: FC<IconExclamationUIProps> = (props) => {
  return <IconExclamation {...props} />;
};

export default IconExclamationUI;

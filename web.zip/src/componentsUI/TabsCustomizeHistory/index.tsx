/**
 * Description
 * @param {any} activeKey:string
 * @returns {ReactElement}
 */
import { Tabs, TabsProps } from '@arco-design/web-react';
import TabHeader from '@arco-design/web-react/es/Tabs/tab-header';
import React, { FC, ReactElement, ReactNode, memo } from 'react';
import './index.less';

const styles = 'ilal-TabsCustomize-history';

type TabTitleInfo = {
  key?: string | number;
  isActive?: boolean;
  disabled?: boolean;
  editable?: boolean;
};

interface IProps {
  activeTab: string;
  options: {
    title: string;
    active?: string | number;
  }[];
  children?: ReactElement[] | ReactElement;
  onChange?: (activeKey: string) => void;
  onClickTab?: (activeKey: string) => void;
  type?: string;
  renderTabHeader?: (tabProps?: TabsProps, DefaultTabHeader?: typeof TabHeader) => ReactElement;
  renderTabTitle?: (tabTile: ReactNode, info: TabTitleInfo) => ReactNode;
  destroyOnHide?: boolean;
}

const TabUI: FC<IProps & TabsProps> = memo((props): React.ReactElement => {
  const { children, activeTab, options, onChange, onClickTab, type, renderTabHeader, renderTabTitle, destroyOnHide } = props;

  return (
    <Tabs
      renderTabTitle={renderTabTitle}
      renderTabHeader={renderTabHeader}
      type={type}
      onChange={onChange}
      onClickTab={onClickTab}
      activeTab={activeTab}
      className={`${styles}-tabs`}
      destroyOnHide={true}
    >
      {options.map(({ title, active }, key) => {
        return (
          <Tabs.TabPane destroyOnHide={destroyOnHide} key={active} title={title}>
            {Array.isArray(children) ? children[active] : typeof children === 'object' && children !== null ? children : null}
          </Tabs.TabPane>
        );
      })}
    </Tabs>
  );
});

export default TabUI;

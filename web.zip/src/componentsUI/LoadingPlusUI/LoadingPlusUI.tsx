import './index.less'
import React, { CSSProperties, PropsWithChildren, useEffect, useState } from "react";
import classNames from 'classnames';
import SpinUI from '../Spin';
import ResultUI from '../Result';
import EmptyUI from '../Empty';

export interface LoadingPlusUIProps {
    loading?: boolean;
    error?: any;
    dataList?: any;
    retryFunc?: () => void;
    className?: string;
    style?: CSSProperties | undefined;
    delayTime?: number;
    btnText?: string;
    cusFunc?: () => void;
}

const LoadingPlusUI = (props: PropsWithChildren<LoadingPlusUIProps>) => {
    const { loading, error, dataList, retryFunc, className, style, children, delayTime = 300 * 1 ,btnText ,cusFunc} = props;
    const prefixCls = 'loading-plus-ui'
    const [delayLoading, setDelayLoading] = useState<boolean>(true)
    const [isHide,setIsHide] = useState<boolean>(false)
    useEffect(() => {
        if (!loading && !delayTime) {
            setDelayLoading(false)
        }
    }, [loading, error, dataList])

    useEffect(() => {
        let timer;
        if (delayLoading && !loading) {
            timer = setTimeout(() => {
                setDelayLoading(false)
                timer = setTimeout(() => {
                    setIsHide(true)
                }, 300);
            }, delayTime)
        }
        return () => {
            timer && clearTimeout(timer)
        }
    }, [delayLoading,loading])

    return (
        <>
            {
                !isHide && <div className={
                    classNames([
                        className,
                        prefixCls,
                        (!delayLoading) ? `${prefixCls}-loaded` : `${prefixCls}-loading`,
                        !loading ? `${prefixCls}-data-loaded` : ''
                    ])
                }
                style={style}
                >
                    <div className={
                        classNames([
                            `${prefixCls}-content`
                        ])
                    }
                    >
                        <SpinUI className={`${prefixCls}-spin-ui`} dot block loading={loading} />
                    </div>
                </div>

            }
            {
                (!loading && error) && <div className={
                    classNames([
                        className,
                        prefixCls,
                        `${prefixCls}-error`
                    ])
                }
                    style={style}
                >
                    <ResultUI errorCode={error?.code} retryFunc={retryFunc} cusFunc={cusFunc} btnText={btnText} />
                </div>
            }
            {
                (!loading && !error && (Object.keys(dataList ?? [])?.length === 0)) && <div className={
                    classNames([
                        className,
                        prefixCls,
                        `${prefixCls}-empty`
                    ])
                }
                    style={style}
                >
                    <EmptyUI showIcon={false} description={'NoData'} />
                </div>
            }
            {
                (!loading && !error && (Object.keys(dataList ?? [])?.length > 0)) && children

            }
        </>
    )
}

export default LoadingPlusUI
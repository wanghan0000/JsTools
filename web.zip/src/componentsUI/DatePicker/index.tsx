import React from "react";
import { DatePicker, DatePickerProps } from "@arco-design/web-react";
import useScreenDesign, { screenType } from "@/Core/utils/hooks/useScreenDesign";

const DatePickerUI = (props: DatePickerProps) => {
    //继承属性，自定义逻辑
    const mobile = useScreenDesign(screenType.mobile)
    return (
        <DatePicker size={mobile ? 'small' : 'default'} {...props} ></DatePicker>
    )

}
export default DatePickerUI;
import React from 'react';
import "./index.less"
import pcPath from './assets/pc_logo.png'
import mobilePath from './assets/mobile_logo.png'
import useScreenDesign from '@/Core/utils/hooks/useScreenDesign';
/**
 * 作者: nick
 * 时间: 2023/6/9
 * 说明: 组件logo
 */

export interface LogoUIProps {
    showBig?: boolean;
}

const LogoUI = ({showBig}: LogoUIProps) => {
    const isMobile = useScreenDesign();
    return (
        <div className={"logo-ui"}>
            <img src={showBig ? pcPath : (isMobile ? mobilePath : pcPath)} alt="" />
        </div>
    )
};

export default LogoUI;

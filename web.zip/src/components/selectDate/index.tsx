import './selectStyle.less';

import { Select } from '@arco-design/web-react';
import React, { FC, ReactElement, memo, CSSProperties } from 'react';
const styles = 'ilal-myselect';

interface IOptions {
  options: {
    id: number;
    value: string;
  }[];
  handlerValue?: (id?: number) => any;
  value?: number | string;
  dropdownMenuClassName?: string;
  dropdownMenuStyle?: CSSProperties;
  getPopupContainer?: (node: HTMLElement) => Element;
}

const Option = Select.Option;

const SelectDate: FC<IOptions> = memo(
  ({ options, handlerValue, value, dropdownMenuClassName, dropdownMenuStyle, getPopupContainer }): ReactElement => {
    const onChange = (value) => {
      handlerValue(value);
    };
    return (
      <Select
        dropdownMenuClassName={dropdownMenuClassName}
        dropdownMenuStyle={dropdownMenuStyle}
        className={`${styles}-MYselect`}
        value={value}
        onChange={onChange}
        getPopupContainer={getPopupContainer}
        triggerProps={{
          autoAlignPopupWidth: false,
          autoAlignPopupMinWidth: true,
        }}
      >
        {options.map(({ id, value }) => (
          <Option key={id} value={id}>
            {value}
          </Option>
        ))}
      </Select>
    );
  }
);

export default SelectDate;

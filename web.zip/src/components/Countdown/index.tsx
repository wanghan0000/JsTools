import React, { useState, useEffect, CSSProperties } from 'react';
import moment from 'moment';
import { useTranslationPlus } from '@/Core/i18n/useTranslationPlus';

interface IProps {
  startTime?: number;
  endTime: number;
  onCountdownEnd?: () => void;
  onChange?: (timeLeft: number, percentage: number) => void;
  className?: string;
  style?: CSSProperties;
  format?: string;
  getCountdownText?: (CountdownObj) => void;
}

const Countdown: React.FC<IProps> = ({
  startTime = 0,
  endTime,
  getCountdownText,
  onCountdownEnd,
  onChange,
  className,
  style,
  format,
}): React.ReactElement => {
  const [timeLeft, setTimeLeft] = useState(Math.max(endTime - startTime, 0));
  const { t } = useTranslationPlus('FORMATTIME');

  useEffect(() => {
    if (timeLeft <= 0) {
      if (onCountdownEnd) {
        onCountdownEnd();
      }
      if (onChange) {
        onChange(0, 100);
      }
      return;
    }
    const totalTime = endTime - startTime;
    const percentage = ((totalTime - timeLeft) / totalTime) * 100;
    if (onChange) {
      onChange(timeLeft, percentage);
    }

    const timerId = setTimeout(() => {
      setTimeLeft(timeLeft - 1000);
    }, 1000);

    return () => clearTimeout(timerId);
  }, [timeLeft, onCountdownEnd]);

  useEffect(() => {
    setTimeLeft(Math.max(endTime - startTime, 0));
  }, [startTime, endTime]);

  const formatTime = (time, format = undefined) => {
    const timeDiff = moment.duration(time);
    const years = timeDiff.years().toString().padStart(2, '0');
    const months = timeDiff.months().toString().padStart(2, '0');
    const days = timeDiff.days().toString().padStart(2, '0');
    const hours = timeDiff.hours().toString().padStart(2, '0');
    const minutes = timeDiff.minutes().toString().padStart(2, '0');
    const seconds = timeDiff.seconds().toString().padStart(2, '0');

    const CountdownObj = {
      years: Number(years),
      months: Number(months),
      days: Number(days),
      hours: Number(hours),
      minutes: Number(minutes),
      seconds: Number(seconds),
    };
    if (getCountdownText) {
      getCountdownText(CountdownObj);
    }

    if (format === 'YYYY-MM-DD HH:mm:ss') {
      return `${years}-${months}-${days} ${hours}:${minutes}:${seconds}`;
    } else if (format === 'YYYY-MM-DD') {
      return `${years}-${months}-${days}`;
    } else if (format === 'DD HH:mm:ss') {
      return `${days}: ${hours}:${minutes}:${seconds}`;
    } else if (format === `${t('day')} HH:mm:ss`) {
      return `${days}${t('day')} ${hours}:${minutes}:${seconds}`;
    } else if (format === 'HH:mm:ss') {
      return `${hours}:${minutes}:${seconds}`;
    } else if (format === 'mm:ss') {
      return `${minutes}:${seconds}`;
    } else if (format === 'HH:mm') {
      return `${hours}:${minutes}`;
    } else if (format === 'MM-DD') {
      return `${months}-${days}`;
    } else if (format === 'YYYY') {
      return `${years}`;
    } else if (format === 'MM') {
      return `${months}`;
    } else if (format === 'DD') {
      return `${days}`;
    } else if (format === 'ss') {
      return `${seconds}`;
    } else if (format === 'mm') {
      return `${minutes}`;
    } else if (format === 'HH') {
      return `${hours}`;
    } else {
      return `${hours}:${minutes}:${seconds}`;
    }
  };
  return (
    <div className={className} style={style}>
      {formatTime(timeLeft, format)}
    </div>
  );
};

export default Countdown;

import classNames from 'classnames';
import React, { PropsWithChildren } from 'react';
import './index.less';
/**页面内容最大宽度样式 */
export const STYLE_PAGE_MAX_CONTAINER = 'page-max-container';
export interface Props {
  className?: string;
  style?: any;
}

const PageMaxContainer = (props: PropsWithChildren<Props>) => {
  const { className, children, style } = props;
  return (
    <div style={style} className={classNames([STYLE_PAGE_MAX_CONTAINER, 'page-max-container-transition-animation', className])}>
      {children}
    </div>
  );
};

export default React.memo(PageMaxContainer) ;

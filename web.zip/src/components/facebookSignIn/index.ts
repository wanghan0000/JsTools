import './style/index.less'
import FacebookSignIn from './facebookSignIn'

export default FacebookSignIn;
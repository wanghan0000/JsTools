import { Button } from '@arco-design/web-react';
import { useEffect, useState } from 'react';
import React from 'react';
import { useTranslation } from 'react-i18next';
import useDialog from '@/utils/useDialog';
import FacebookLogin from '@greatsumini/react-facebook-login';
import { useFaceBookSignin } from '@/store/signin';
import { LoginIconFacebook } from '@/assets/svg-icon';
import { sys } from '@/Core/utils/system';
type ThirdSignStatus = '' | 'loading' | 'success' | 'error';

const FacebookSignIn = (props) => {
    const { className } = props
    const [isLoading, setIsLoading] = useState<boolean>(true)
    const [thirdBtnStatus, setThirdLoginBtnStatus] = useState<ThirdSignStatus>('')
    const { t } = useTranslation();
    const { trigger } = useFaceBookSignin();
    const { pop } = useDialog()

    const signin = async (token) => {
        const nativeSigin = window.nativeFBLogin;
        try {
            await trigger({
                googleCode: token,
                googleUri: window.location.origin,
                thirdSign: nativeSigin.thirdSign,
                os: sys.os,
                inviteCode: sys.inviteCode,
                pid: sys.pid,
                channle: '0',
                loginType: undefined
            })
            pop()
        } catch (error) {
            console.warn(error)
        }
        setThirdLoginBtnStatus('')
    }

    // 成功后回调
    const handleSuccess = async (res: any) => {
        console.log('facebook res >> ', res)
        setIsLoading(true)
        signin(res.accessToken)
        setIsLoading(false)
    }

    // 失败后回调
    const handleFail = (error: any) => {
        setIsLoading(false)
        console.log('facebook error >>', error)
    }

    const clickSignin = (triggerLogin) => {
        const native = sys.isNative
        if (native) {
            sys.nativeFacebookLogin()
        } else {
            triggerLogin()
            setThirdLoginBtnStatus('loading')
        }
    }

    useEffect(() => {
       try {
        const nativeSigin = window.nativeFBLogin;
        Object.defineProperty(nativeSigin, 'authCode', {
            set: function (val) {
                if (val) {
                    signin(val)
                } else {
                    setThirdLoginBtnStatus('error')
                }
            },
            enumerable: true,
            configurable: true
        })
       } catch (error) {
        console.error('facebook登录报错');
       }
    }, [window])

    return (
        <FacebookLogin
            appId={`${process.env.REACT_APP_FACEBOOK_APPID}`}
            onSuccess={handleSuccess}
            onFail={handleFail}
            render={({ onClick }) => (
                <Button
                    className={className}
                    icon={<LoginIconFacebook></LoginIconFacebook>}
                    type={'outline'}
                    onClick={() => {
                        clickSignin(onClick)
                    }}
                    disabled={isLoading || thirdBtnStatus !== ''}
                >
                    {t('Facebook')}
                </Button>
            )}
        />
    )

}

export default FacebookSignIn;
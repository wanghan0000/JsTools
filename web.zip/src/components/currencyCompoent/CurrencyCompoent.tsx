import { dealAmount2Fiexd, dealAmount9Valid, dealAmountSegmentationAnd2Fixed, getCurrencyImagePath } from '@/Core/utils/currencyDealCenter';
import React from 'react';
import { CurrencyCompoentProps, FormatAmountType } from './interface';

import { Space } from '@arco-design/web-react';

const CurrencyCompoent = (props: CurrencyCompoentProps) => {
  const {
    currencyType,
    amount,
    showIcon = true,
    showUnit = true,
    type = 'SegmentationAndFixed2',
    iconPosition = 'lt',
    unitPosition = 'lt',
    className,
    style,
    styleIcon,
  } = props;
  const dealAmount = (type: FormatAmountType, amount) => {
    let ret = amount;
    if (type === 'valid9') {
      ret = dealAmount9Valid(amount, {
        currencyType: currencyType,
      });
    } else if (type === 'fixed2') {
      ret = dealAmount2Fiexd(amount, {
        currencyType: currencyType,
      });
    } else if (type === 'SegmentationAndFixed2') {
      ret = dealAmountSegmentationAnd2Fixed(amount, {
        currencyType: currencyType,
      });
    }
    return ret;
  };

  return (
    <>
      {iconPosition === 'lt' && unitPosition === 'lt' && (
        <Space direction={'horizontal'} className={['currency-compoent', className]} style={style}>
          {showIcon && (
            <div className="icon">
              <img style={styleIcon} src={getCurrencyImagePath(currencyType)} />
            </div>
          )}
          {showUnit && <div className="unit">{currencyType}</div>}
          {amount !== null && amount !== undefined && <div className="amount">{dealAmount(type, amount)}</div>}
        </Space>
      )}
      {iconPosition === 'lt' && unitPosition === 'rt' && (
        <Space direction={'horizontal'} className={['currency-compoent', className]} style={style}>
          {showIcon && (
            <div className="icon">
              <img style={styleIcon} src={getCurrencyImagePath(currencyType)} />
            </div>
          )}
          {amount !== null && amount !== undefined && <div className="amount">{dealAmount(type, amount)}</div>}
          {showUnit && <div className="unit">{currencyType}</div>}
        </Space>
      )}
      {iconPosition === 'rt' && unitPosition === 'rt' && (
        <Space direction={'horizontal'} className={['currency-compoent', className]} style={style}>
          {amount !== null && amount !== undefined && <div className="amount">{dealAmount(type, amount)}</div>}
          {showUnit && <div className="unit">{currencyType}</div>}
          {showIcon && (
            <div className="icon">
              <img style={styleIcon} src={getCurrencyImagePath(currencyType)} />
            </div>
          )}
        </Space>
      )}
      {iconPosition === 'rt' && unitPosition === 'lt' && (
        <Space direction={'horizontal'} className={['currency-compoent', className]} style={style}>
          {showUnit && <div className="unit">{currencyType}</div>}
          {amount !== null && amount !== undefined && <div className="amount">{dealAmount(type, amount)}</div>}
          {showIcon && (
            <div className="icon">
              <img style={styleIcon} src={getCurrencyImagePath(currencyType)} />
            </div>
          )}
        </Space>
      )}
    </>
  );
};

export default CurrencyCompoent;

import { CurrencyType } from "@/api/proto/IFCommon";

/**展示有效位9位 */ /**展示保留2位小数 */ /**展示千分位分割且保留2位小数 */
export type FormatAmountType = 'valid9' | 'fixed2' | 'SegmentationAndFixed2';

export interface CurrencyCompoentProps {
  className?: string | undefined;
  /**货币类型 */
  currencyType?: CurrencyType;
  /**货币金额 */
  amount?: string | number;
  /**是否展示货币Icon 默认展示 */
  showIcon?: boolean;
  /**是否展示货币单位 默认展示*/
  showUnit?: boolean;
  /**数据格式化类型 默认 展示千分位分割且保留2位小数*/
  type?: FormatAmountType;
  /**货币Icon 在金额的左侧还是右侧*/
  iconPosition?: 'lt' | 'rt';
  /**货币单位在 金额的左侧还是右侧 */
  unitPosition?: 'lt' | 'rt';
  /**币种 */
  decide?: number;
  style?: any;
  styleIcon?: any;
}

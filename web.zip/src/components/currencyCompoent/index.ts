import './style/index.less'
import CurrencyCompoent from './CurrencyCompoent'

export default CurrencyCompoent
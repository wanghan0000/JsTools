
export interface IInputWithdrawAmountProps{
    title?:string
    descMin?:string
/**
     * 初始化加密货币数据
     */
 min?: number,
 /**
* 初始化法币数据
*/
max?:number ,
balance?:number,
errorMsg?:string,
onTrigger?:()=>void,
 /**
     * none 时 则不校验 
     * 默认值 VerifyRule.rule1
     */
  rule?:VerifyRule | 'none'
}

export interface IInputWithdrawAmountRef{
    value?:number
           /**
     * 校验状态 false 失败 true 成功
     */
    status: ()=>boolean ;
}
/**
 * 校验规则
 */
 export enum VerifyRule {
    /**
     * 规则1 校验
     */
    rule1 = '^[1-9][0-9_]{1,9}$'
}
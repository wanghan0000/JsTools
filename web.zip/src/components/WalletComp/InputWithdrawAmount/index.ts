import './style/index.less'
import InputWithdrawAmount from  "./InputWithdrawAmount";
export default InputWithdrawAmount
import React, { useState, useEffect } from "react"
import { Button,Space } from "@arco-design/web-react"
import InputUI from "@/componentsUI/Input"
import { useTranslationPlus } from "@/Core/i18n/useTranslationPlus"
import classNames from "classnames"

const ButtonGroup = (props: {ts:any, onClickMin: () => void; onClick25: any; onClick50: any; onClickMax: any; isChecked }) => {
  const {
    ts,
    isChecked,
    onClickMin,
    onClick25,
    onClick50,
    onClickMax,
  } = props
  return (
    <Space>

      <Button className={classNames([isChecked == 1 ? 'isChecked' : ''], 'amountBtn')} onClick={onClickMin}>{ts('Min')}</Button>
      <Button className={classNames([isChecked == 2 ? 'isChecked' : ''], 'amountBtn')} onClick={onClick25}>25%</Button>
      <Button className={classNames([isChecked == 3 ? 'isChecked' : ''], 'amountBtn')} onClick={onClick50}>50%</Button>
      <Button className={classNames([isChecked == 4 ? 'isChecked' : ''], 'amountBtn')} onClick={onClickMax}>{ts('Max')}</Button>
    </Space>
  )
}

const InputWithdrawAmount = (props) => {
  const prefixCls = 'fym-InputWithdrawAmount'
  const { balance, min: minAmount, max: maxAmount, value,onChange } = props
  const { t } = useTranslationPlus('Wallet');
  const [inputValue, setInputValue] = useState('')
  const [isChecked, setIsChecked] = useState(0);
  useEffect(() => {
    if(isChecked>0){
     
      setIsChecked(isChecked)
     
    }
  }, [isChecked])

  useEffect(()=>{
    if(!value){
      setIsChecked(0)
      setInputValue('')
    }
  },[value])
 
  const onInputChange = (v) => {
    const valueNum = Number(v);
    if (isNaN(valueNum)) {
      return v
    }
    let amValue=''
    const b=Number(balance)
    const m=Number(maxAmount)
    if(b<m){
      if (valueNum<b  ) {
        amValue=v
    
      }else{//最大：balance
        amValue=balance
     
      }
    }else{//balance > maxAmount
      if (valueNum<m ) {
        amValue=v
      }else{
        amValue=maxAmount
      }
    }
    setInputValue(Number(amValue)?.toFixed(0)+'')
    onChange &&  onChange(amValue)
  }

  const formatRateValue=(rate)=>{
    const b=Number(balance)
    const m=Number(maxAmount)
    let result:any=0
    if (b<m) {
      result=b * rate
    }else{
      result=m * rate
    }
    result = result.toFixed(2);
    setInputValue(result+'')
    onChange &&  onChange(result)
  }

  const onClickMin = () => {
    setIsChecked(1)
    const b=Number(balance)
    const m=Number(minAmount)
    let ipt=0
    if(b<m){
      ipt=b
    }else{//balance > minAmount
      ipt=m
    }
    setInputValue(ipt+'')
    onChange &&  onChange(ipt)
  }
  const onClick25 = () => {
    setIsChecked(2)
    formatRateValue(0.25)
  }
  const onClick50 = () => {
    setIsChecked(3)
    formatRateValue(0.5)
  }
  const onClickMax = () => {
    setIsChecked(4)
    formatRateValue(1)
  }
  return (
    <div className={prefixCls}>
     <InputUI
          className={`${prefixCls}-amount`}
          value={inputValue}
          maxLength={10}
          onChange={(v) => { 
            onInputChange(v) }}
          suffix={
            <ButtonGroup
              ts={t}
              isChecked={isChecked}
              onClickMin={onClickMin}
              onClick25={onClick25}
              onClick50={onClick50}
              onClickMax={onClickMax}
            />
          }
        />
    </div>
  )
}
export default InputWithdrawAmount
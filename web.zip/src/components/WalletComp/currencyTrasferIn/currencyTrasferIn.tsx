
import React from "react";
import { Select, Typography } from "@arco-design/web-react";
// import SelectCurrency from "@/components/WalletComp/ExchangeComp/SelectCurrency";
import classNames from "classnames";
import { useTranslationPlus } from "@/Core/i18n/useTranslationPlus";
import { dealAmount2Fiexd, getCurrencyImagePath } from "@/Core/utils/currencyDealCenter";
import InputUI from "@/componentsUI/Input";
import SelectUI from "@/componentsUI/Select";
const CurrencyTransferIn = (props) => {
  const prefixCls = 'fym-CurrencyTransferIn';
  const { className, title, options = [], value, onChange, suffix} = props;
  const { t } = useTranslationPlus('Wallet');
  const getMaxByCurrencyType = (currencyType) => {
    for (const iterator of options) {
      if (iterator.currencyType === currencyType) {
        return dealAmount2Fiexd(iterator.balance,{
          currencyType: iterator.currencyType
        })
      }
    }
  }

  const formatValue = (v): string => {
    const max = getMaxByCurrencyType(value?.select)
    if (isNaN(Number(v))) {
      return value?.transfer
    }
    const num = Number(v);
    if (num > Number(max)) {
      return max + '';
    }
    return v;
  }

  const onChangeValue = (v: { transfer: any; select: any; changeFrom: any; }) => {
    const { transfer,select,changeFrom } = v;
    const i=options?.findIndex(item=>{
      if(item?.currencyType==select){
          return true
      }
    })
    onChange && onChange({ ...options[i], transfer:formatValue(transfer),select:select ,changeFrom })
  }

  return (
    <div  className={classNames([prefixCls,className])}>
      {!!title &&
        <Typography.Text > {t(title)} </Typography.Text>}

      <div className={`${prefixCls}-input`}>
      <InputUI
          readOnly={true}
            value={value?.transfer}
            onChange={(v) => { onChangeValue({ ...value, transfer: v ,changeFrom:1}) }}
            addBefore={
                <SelectUI className={`${prefixCls}-select`}
                  getPopupContainer={Trigger=>Trigger.parentElement}
                  value={value?.select}
                    onChange={(v) => {
                      onChangeValue({ ...value, select: v,changeFrom:0 })
                }}>
                  {
                    options.map((item, index) => {
                      return <Select.Option className={`${prefixCls}-option`} 
                      key={index} value={item.currencyType} >
                        <div className={`${prefixCls}-currencyType`}>
                          <div className="left">
                            <img src={getCurrencyImagePath(item?.currencyType)} />
                            <span> {item.currencyType}</span>
                          </div>
                        </div>
                      </Select.Option>
                    })
                  }
                </SelectUI>
            }
            suffix={suffix}
          />
      </div>
      {/* {Number(value) === 0 && 
        <Typography.Text className={`${prefixCls}-error`}>{t('Wrong Amount')}</Typography.Text>
      } */}
    </div>
  )
}

export default CurrencyTransferIn
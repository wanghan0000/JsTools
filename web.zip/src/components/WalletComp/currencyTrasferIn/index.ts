import './style/index.less'
import  currencyTrasferIn from './currencyTrasferIn'
export default currencyTrasferIn

import {IFInitWalletRsp} from '@/api/apiRsp/IFWalletRsp'
import { ReactNode } from 'react';
export interface ICurrencyTrasferInProps {

    
    className?: string ;
    title?:string; 
    list?:IFInitWalletRsp[];
    value?:any;
    //max?:string;
    //defaultType?:string;
    //onChangeDefaultType?:(v:string)=>void;
    onChange?:(v:any)=>void;

    suffix?: ReactNode;

    onChangePlus?:(v:any)=>void;
}


export interface ICurrencyTrasferInRef {
        /**
     * 数据
     */
         value: string;
           /**
     * 校验状态 false 失败 true 成功
     */
    status: ()=>boolean;
}



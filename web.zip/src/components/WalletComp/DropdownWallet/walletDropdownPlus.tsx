import { IFInitWalletRsp } from "@/api/apiRsp/IFWalletRsp";
import { GameOriginalBetBack } from "@/api/event/IFCustomStore";
import { Qb } from "@/assets/svg-icon";
import CurrencyCompoent from "@/components/currencyCompoent";
import ButtonUI from "@/componentsUI/Button";
import SelectUI from "@/componentsUI/Select";
import { useTranslationPlus } from "@/Core/i18n/useTranslationPlus";
import { useGlobalCurrentWallet, useGlobalWalletStore, useUpdateGlobalOriginalBalance } from "@/store/commonStore";
import { useWalletAll, useWalletSwitch } from "@/store/walletStore";
import useDialogManager from "@/utils/useDialogManager";
import { Select } from "@arco-design/web-react";
import { IconDown, IconLock } from "@arco-design/web-react/icon";
import classNames from "classnames";
import React, { useEffect, useRef, useState } from "react";
import { CSSTransition } from 'react-transition-group';
const WalletDropdownPlus = () => {

    const prefixCls = 'wallet-drop-down'
    const { t } = useTranslationPlus('Wallet');
    const { openWallet, openIWDunlock } = useDialogManager();

    /**监听钱包刷新 */
    //const { data: updateBanblce } = useWsUpdateBanblce()
    const [gameBetData] = useUpdateGlobalOriginalBalance()
    /**获取钱包源数据 */
    const { data, mutate } = useWalletAll(false)//初始化钱包：取数
    const { all: walletAllOriginal} =  data || {}
    const [globalWallet,setGlobalWallet] = useGlobalWalletStore()
    /**所有钱包展示数据 */
    // const [walletAll, setWalletAll] = useState<IFInitWalletRsp[]>([])
    /**钱包是否初始化 */
    //const [isInit, setIsInit] = useState(false)
    const initRef = useRef<boolean>(false)
    /**当前展示钱包数据 */
    const [currentWallet, setCurrentWallet] = useState<IFInitWalletRsp>();
    /**当前使用的钱包 */
    const [currentWalletGlobal, setCurrentWalletGlobal] = useGlobalCurrentWallet()
    const { trigger } = useWalletSwitch() //切换钱包

    const [gameWin, setGameWin] = useState(false)
    const [tempData, setTempData] = useState<GameOriginalBetBack>();
    useEffect(() => {
        if (currentWalletGlobal) {
            if (currentWalletGlobal?.currencyType === currentWallet?.currencyType) {
                setCurrentWallet(currentWalletGlobal)
            }
        }
    }, [currentWalletGlobal])

    useEffect(() => {
        if (gameBetData && gameBetData?.winAmount > 0) {
            setGameWin(true)
            setTempData(gameBetData)
            setTimeout(() => {
                setGameWin(false)
            }, 300)
        }
    }, [gameBetData])

    useEffect(() => {
        if (walletAllOriginal) {
            let tWallet;
            if (!initRef.current) {
                initRef.current = true
                //初始化 选出默认的钱包
                walletAllOriginal.forEach((v) => {
                    if (v.defaultCurrency) {
                        tWallet = v;
                    }
                })
                !tWallet && (tWallet = walletAllOriginal[0])
            } else {
                //后续改变的
                walletAllOriginal.forEach((v) => {
                    if (v.currencyType === currentWallet.currencyType) {
                        tWallet = v;
                    }
                })
            }
            setCurrentWallet(tWallet)
            setCurrentWalletGlobal(tWallet)
            // setWalletAll([...walletAllOriginal])
           // setGlobalWallet([...walletAllOriginal])
        } else {

        }
    }, [walletAllOriginal])

    useEffect(()=>{
        if(data) {
            setGlobalWallet({...data})
        }
    },[data])

    const onChangeWallet = async (item: IFInitWalletRsp) => {
        setCurrentWallet(item)
        setCurrentWalletGlobal(item)
        await trigger({ currencyType: item.currencyType }).then(
            (res) => { console.log(res) }
        ).catch((err) => { console.log(err) })
    }

    return (<div className={prefixCls}>
        <SelectUI
            className={`${prefixCls}-select`}
            style={{ minWidth: 150 }}
            addAfter={<ButtonUI
                className={`${prefixCls}-btn`}
                icon={<Qb />}
                type={'primary'}
                onClick={() => {
                    openWallet()
                }}
            >{t('Wallet')}</ButtonUI>}
            value={currentWallet?.currencyType}
            onVisibleChange={(visible) => {
                if (visible) {
                    mutate()
                }
            }}
            getPopupContainer={Trigger => Trigger.parentElement}
            renderFormat={() => {
                return <div className={`${prefixCls}-render`}>
                    {currentWallet ?
                        <>
                            <div className={`${prefixCls}-top`}>
                                <CurrencyCompoent currencyType={currentWallet?.currencyType} />
                                <IconDown className={`down-icon`} />
                            </div>
                            <div className={`${prefixCls}-amount`}>
                                <CurrencyCompoent amount={currentWallet?.allBalance} type={'valid9'} showIcon={false} showUnit={false} currencyType={currentWallet.currencyType} />
                            </div>
                        </> : <>Loading</>
                    }
                </div>
            }}
        >
            {
                globalWallet?.all?.map((v, index) => {
                    return <Select.Option value={v.currencyType} key={index} onClick={
                        () => onChangeWallet(v)
                    }>
                        <div className={`${prefixCls}-options`}>
                            <CurrencyCompoent currencyType={v.currencyType} />
                            <div className={`${prefixCls}-empty`}></div>
                            <div>

                                <div className={classNames([`${prefixCls}-select-amount`,
                                v.lockMoney ? '' : `${prefixCls}-no-lock-money`
                                ])} onClick={v.lockMoney ? openIWDunlock : null}>
                                    <div style={{ display: 'flex' }}>
                                        <IconLock style={{ opacity: 0 }} />
                                        <CurrencyCompoent amount={v.allBalance} showIcon={false} showUnit={false} type={'valid9'} currencyType={v.currencyType} />
                                    </div>
                                    {v.lockMoney && <div style={{ display: 'flex' }} className={`${prefixCls}-lock`}>
                                        <IconLock />
                                        <CurrencyCompoent amount={v.lockMoney} showIcon={false} showUnit={false} type={'valid9'} currencyType={v.currencyType} />
                                    </div>}
                                </div>
                            </div>

                        </div>
                    </Select.Option>
                })
            }

        </SelectUI>
        <CSSTransition
            in={gameWin}
            timeout={500}
            mountOnEnter={true}
            classNames="win-amount-csst"
            unmountOnExit={true}
        >
            <div className="game-win-amount">+
                <CurrencyCompoent type='valid9'
                    showUnit={false}
                    showIcon={false}
                    currencyType={tempData?.currencyType}
                    amount={tempData?.winAmount} />
            </div>

        </CSSTransition>
    </div>)
}


export default WalletDropdownPlus
import React from 'react'
import { Select } from "@arco-design/web-react"
import SelectUI from '@/componentsUI/Select'

const SelectNetwork=(props)=>{
    const prefixCls='fym-selectNetwork'
    const Option =Select.Option
const {options = [],onChange}=props

    return(
        <div className={prefixCls} >
            <SelectUI size='large' className={`${prefixCls}-select`} 
            getPopupContainer={Trigger=>Trigger.parentElement}
            value={props?.value?.networkType }    onChange={(v2)=>{
               
                const index = options.findIndex((v)=>{
                    if(v.networkType === v2){
                        return true;
                    }
                })
                onChange({...options[index],index:index})
            }} >
                {
                    options?.map((item,index)=>{
                       return <Option key={index} value={item.networkType}>
                             <span>{item.networkType}</span>
                        </Option>
                    })
                }
               
            </SelectUI>
        </div>
    )
}
export default  SelectNetwork

interface INetworkData{
    networkType?:string
  }
export interface ISelectNetworkProps{
    networkData?:INetworkData[]
    title?:string
    onSwithNetwork?:(index)=>void
} 

export interface ISelectNetworkRef{
    networkItem?:string
          /**
     * 校验状态 false 失败 true 成功
     */
           status: ()=>boolean;
}
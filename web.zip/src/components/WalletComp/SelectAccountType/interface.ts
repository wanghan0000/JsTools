

export interface ISelectAccountTypeProps{
    title?:string
    accountTypeData?:string[]
    onSwithAccountType?:(index)=>void
} 

export interface ISelectAccountTypeRef{
    value?:string
}
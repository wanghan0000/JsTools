import './style/index.less'
import SelectAccountType from './SelectAccountType'
export  default SelectAccountType
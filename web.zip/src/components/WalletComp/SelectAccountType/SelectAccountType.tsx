import React from 'react'
import { Select, Typography } from "@arco-design/web-react"
import SelectUI from '@/componentsUI/Select'
const SelectAccountType = (props) => {
    const prefixCls = 'fym-selectAccountType'
    const Option = Select.Option
    const { accountTypeData, onChange } = props
    const onChangeFunc = (ctype, e) => {
        const key = e._index
        onChange({ ctype: ctype, index: key })//执行回调
    }
    return (
        <div className={prefixCls} >
            <SelectUI className={`${prefixCls}-select`}
                getPopupContainer={Trigger => Trigger.parentElement}
                value={props?.value?.ctype} onChange={onChangeFunc} style={{ width: '200px' }}>
                {
                    accountTypeData?.length > 0 &&
                    accountTypeData?.map((item, i) => {
                        return <Option key={i} value={item}>
                            <Typography.Text>{item}</Typography.Text>
                        </Option>
                    })
                }
            </SelectUI>
        </div>
    )
}
export default SelectAccountType
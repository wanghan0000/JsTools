import {IFInitWalletRsp} from '@/api/apiRsp/IFWalletRsp'
export interface ICurrencyTransferOutProps {

  
    
    // className?: string ;
    // /**
    //  * none 时 则隐藏title
    //  * 默认值 I18Key.key1
    //  */
    // title?:string | 'none',

    // maxAmount?:number | 'none'
    
    // /**
    //  * 是否禁用输入
    //  */
    // disabled?: boolean,
    // rate?:string
    // onTrigger?:(index)=>void,
    // onTriggerMax?:(value)=>void


    className?: string ;
    title?:string; 
    list?:IFInitWalletRsp[];
    value?:any;
    max?:string;
    defaultType?:string;
    onBlur?:(v:string)=>void;
    //onChangeDefaultType?:(v:string)=>void;
    onChange?:(v:any)=>void;

    onChangePlus?:(v:any)=>void;
}


export interface ICurrencyTransferOutRef {
        /**
     * 数据
     */
         value: string;
           /**
     * 校验状态 false 失败 true 成功
     */
    status: ()=>boolean;
    currencyIndex?:number
}



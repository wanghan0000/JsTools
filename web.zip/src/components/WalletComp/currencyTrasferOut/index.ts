import './style/index.less'
import  currencyTransferOut from './currencyTrasferOut'
export default currencyTransferOut
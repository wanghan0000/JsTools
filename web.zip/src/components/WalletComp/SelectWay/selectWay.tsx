import React, { Select } from '@arco-design/web-react';
import { useTranslationPlus } from '@/Core/i18n/useTranslationPlus';
import SelectUI from '@/componentsUI/Select';

const SelectWay = (props) => {
  const prefixCls = 'fym-SelectWay';
  const { options = [], onChange } = props;
  const { t } = useTranslationPlus('Wallet');

  return (
    <div className={prefixCls}>
      <SelectUI
        size="large"
        className={`${prefixCls}-select`}
        getPopupContainer={(Trigger) => Trigger.parentElement}
        value={props?.value?.merchantName}
        onChange={(v2) => {
          const index = options.findIndex((v) => {
            if (v.merchantId === v2) {
              return true;
            }
          });
          onChange({ ...options[index], index: index });
        }}
      >
        {options?.map((item, index) => {
          return (
            <Select.Option key={index} value={item.merchantId}>
              <span> {item.merchantName}</span>
            </Select.Option>
          );
        })}
      </SelectUI>
    </div>
  );
};

export default SelectWay;

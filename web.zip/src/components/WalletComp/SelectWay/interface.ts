
interface IcurrencyData{
  icon?:any
  payCode?:string
  payName?:string
}
export interface IselectWayProps {
    className?: string;
    /**
     * none 时 则隐藏title
     * 默认值 I18Key.key1
     */
    title?: string | 'none',
    currencyData?:IcurrencyData[]
    onTrigger?:(index)=>void
}

export interface ISelectWayRef {
      /**
     * 商户名称
     */
       value: string;
        /**
     * 商户ID
     */
       valueCode?:string
}



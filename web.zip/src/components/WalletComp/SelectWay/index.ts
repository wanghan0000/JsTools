import './style/index.less'
import  selectWay from './selectWay'
export default selectWay
import { styled } from 'styled-components';

export const MyAvatar = styled.div`
  display: inline-block;
  position: relative;
  text-align: center;
  &::before {
    content: 'V${(props) => props['data-level']}';
    width: 30px;
    height: 12px;
    background-color: #a0bfee;
    position: absolute;
    bottom: 0px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 1;
    font-size: 12px;
    line-height: 12px;
    color: var(--color-text-1);
  }
`;

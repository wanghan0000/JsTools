import { Avatar } from '@arco-design/web-react';
import React, { memo, useEffect, useState } from 'react';
import './style/user-drop-list.less';
import DroplistElement from './droplist/index';
import { Transition } from 'react-transition-group';
import './style/transition.less';

import user from './droplist/img/user.webp';
import useScreenDesign from '@/Core/utils/hooks/useScreenDesign';
import { useVipInfo } from '@/store/PersonalCenter';
import { MyAvatar } from './userDropListEle';

/* 个人信息菜单样式 */
const duration = 300;
const defaultStyle = {
  transition: `all ${duration}ms ease-in-out`,
  opacity: 0,
};

const transitionStyles = {
  entering: { opacity: 1 },
  entered: { opacity: 1 },
  exiting: { opacity: 0 },
  exited: { opacity: 0 },
};

const UserDropList = () => {
  const [visible, setVisible] = useState(false);
  const isMobile = useScreenDesign();
  const { data } = useVipInfo(false);

  const handleMouseEnter = () => {
    setVisible(true);
  };

  const handleMouseLeave = () => {
    setVisible(false);
  };

  const changeVisible = (event) => {
    event.stopPropagation();
    setVisible(!visible);
  };

  const handleColes = () => {
    setVisible(false);
  };

  return (
    <>
      {isMobile ? (
        <div style={{ height: '100%', display: 'flex', alignItems: 'center' }} onClick={changeVisible}>
          <MyAvatar data-level={data?.level}>
            <Avatar style={{ cursor: 'pointer' }}>
              <img alt={''} src={user} />
            </Avatar>
          </MyAvatar>
        </div>
      ) : (
        <div style={{ height: '100%', display: 'flex', alignItems: 'center' }} onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
          <MyAvatar data-level={data?.level}>
            <Avatar style={{ cursor: 'pointer' }}>
              <img alt={''} src={user} />
            </Avatar>
          </MyAvatar>
        </div>
      )}

      <div className="mobile-shadow" onClick={changeVisible} style={{ display: isMobile && visible ? 'block' : 'none' }}></div>
      <Transition in={visible} timeout={duration} unmountOnExit>
        {(state) => (
          <div
            className="userDropContainer"
            style={{ ...defaultStyle, ...transitionStyles[state] }}
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
          >
            <DroplistElement handleColes={handleColes}></DroplistElement>
          </div>
        )}
      </Transition>
    </>
  );
};

export default memo(UserDropList);

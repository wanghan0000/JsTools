import React, { memo, useEffect, useState } from 'react';
import { Badge } from '@arco-design/web-react';
import useDialogManager from '@/utils/useDialogManager';
import UserDropList from '@/components/NavBar/userDropList';
import ButtonUI from '@/componentsUI/Button';
import useScreenDesign from '@/Core/utils/hooks/useScreenDesign';
import { Dc, Jlzx } from '@/assets/svg-icon';
import cs from 'classnames';
import './style/navbar.less';
import { useLocation, useNavigate } from 'react-router';
import { useGlobalOpenNotice, useGlobalState } from '@/store/commonStore';
import { useWsUpdateEmail } from '@/store/hallSocket';
import { useMessageCount } from '@/store/message';
import { useTranslationPlus } from '@/Core/i18n/useTranslationPlus';
import LogoUI from '@/components/LogoUI';
import SvgNotice from '@/assets/svg-icon/SvgNotice';
import SearchInput from '@/components/searchInput';
import WalletDropdownPlus from '@/components/WalletComp/DropdownWallet';
import DownLoadAppBar from '@/pages/home/components/downloadAppBar/DownLoadAppBar';
import { useBeforeSetting } from '@/store/beforeSetting';
import PageMaxContainer from '../pageMaxContainer/PageMaxContainer';
import { useActivityEntryPlus } from '@/store/home';

function Navbar() {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const { t } = useTranslationPlus('HomeView');
  const { t: tO } = useTranslationPlus();
  const { isLogin } = useGlobalState();
  const isMobile = useScreenDesign();
  const [openNotice, setOpenNotice] = useGlobalOpenNotice();
  const { isDownload } = useBeforeSetting();
  const { data: countData, mutate: countMutate } = useMessageCount();
  //socket 通知消息
  const { data } = useWsUpdateEmail();
  const { openSignUp, openSignIn } = useDialogManager();
 
  const [bonusState, setBonusState] = useState(false);

  const { data:activityData } = useActivityEntryPlus();
  function signUp() {
    openSignUp();
  }
  function toHome() {
    navigate('/home');
  }
  function handleClickMessage() {
    setOpenNotice(!openNotice);
  }
  useEffect(() => {
    countMutate();
  }, [data]);

  useEffect(() => {
    if (pathname.includes('bonus')) {
      setBonusState(isMobile);
    } else {
      setBonusState(false);
    }
  }, [pathname, isMobile]);

  return (
    <div className={'navbar'}>
      {isDownload && <DownLoadAppBar className={'navbar-download-bar'}></DownLoadAppBar>}
      <PageMaxContainer className="header-wrapper-container">
        <div className={'header-wrapper'}>
          <div className={'navbar-content'}>
            <div className={'left'}>
              {isMobile && (
                <div onClick={toHome}>
                  <LogoUI />
                </div>
              )}
              <div className={cs(isMobile && 'hidden', 'navbar-left')}>
                <ButtonUI icon={<Dc className={'arco-icon'} />} onClick={() => toHome()} className={cs('home-btn')}>
                  {t('Home')}
                </ButtonUI>
              </div>
            </div>

            <ul className={'right'}>
              {isLogin && (
                <li>
                  <WalletDropdownPlus />
                </li>
              )}
              {!isLogin && (
                <li>
                  <ButtonUI type="default" loading={false} loadingFixedWidth={false} className={'login-btn'} onClick={() => openSignIn()}>
                    {tO('Signin.Login')}
                  </ButtonUI>
                </li>
              )}
              {!isLogin && (
                <li>
                  <ButtonUI
                    type="primary"
                    loading={false}
                    loadingFixedWidth={false}
                    className={'login-btn'}
                    onClick={() => {
                      signUp();
                    }}
                  >
                    {tO('Signup.Signup')}
                  </ButtonUI>
                </li>
              )}
              {!isMobile && isLogin && (
                <li>
                  <SearchInput />
                </li>
              )}
              {isMobile && isLogin && (
                <li>
                  <Badge count={activityData?.giftBagStatus ? 1 : 0} dot>
                    <ButtonUI className={'message-tag navbar-bouns'} onClick={() => navigate('bonus')}>
                      <Jlzx className={bonusState ? 'check-bonus' : 'no-check-bonus'} />
                    </ButtonUI>
                  </Badge>
                </li>
              )}
              {!isMobile && isLogin && (
                <li>
                  <Badge count={countData?.unread || 0} className={'message-badge'}>
                    <ButtonUI size={'large'} type={'text'} className={'message-tag'} onClick={handleClickMessage}>
                      <SvgNotice />
                    </ButtonUI>
                  </Badge>
                </li>
              )}
              {isLogin && (
                <li>
                  <UserDropList />
                </li>
              )}
            </ul>
          </div>
        </div>
      </PageMaxContainer>
    </div>
  );
}

export default memo(Navbar);

import { IconClose } from '@arco-design/web-react/icon';
import { styled } from 'styled-components';

export const BubbleCardContainer = styled.div`
  width: 100%;
  height: 100%;
  background-color: var(--color-bg-2);
  border-radius: 5px;
  box-sizing: border-box;
  box-shadow: 0 0 10px 1px rgba(0, 0, 0, 0.5);
  display: flex;
  flex-direction: column;
  border-radius: 2px;
  /* @media screen and (max-width: 621px) {
    right: 0;
    top: 50px;
    width: 100vw;
    height: 80vh;
  } */
`;

export const MyIconClose = styled(IconClose)`
  display: none;
  @media screen and (max-width: 621px) {
    display: block;
    position: absolute;
    top: 10px;
    right: 10px;
    font-size: 20px;
    cursor: pointer;
  }
`;

export const Header = styled.div`
  text-align: center;
  margin-top: 17px;
`;
export const MyAvatar = styled.div`
  display: inline-block;
  margin-bottom: 15px;
  position: relative;
  text-align: center;
  &::before {
    content: 'V${(props) => props['data-level']}';
    width: 30px;
    height: 15px;
    background-color: #a0bfee;
    position: absolute;
    bottom: -10px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 1;
    font-size: 12px;
    line-height: 15px;
    color: var(--color-text-1);
  }
`;
export const Name = styled.div`
  color: var(--color-text-1);
  font-size: 18px;
  font-weight: bold;
`;

export const UserId = styled.div`
  font-size: 14px;
  color: var(--color-text-2);
  user-select: text;
  cursor: pointer;
`;
export const VIP = styled.div`
  font-size: 12px;
  display: flex;
  justify-content: space-between;
  color: var(--color-text-1);
  cursor: pointer;
  box-sizing: border-box;
  padding: 0 16px;
  margin-top: 22px;
  .exp {
    color: var(--color-text-6coin);
  }
  @media screen and (max-width: 621px) {
    margin-top: 5px;
  }
`;
export const Main = styled.div`
  font-size: 14px;
  flex: 1;
  background-color: var(--color-bg-5);
`;

export const ScheduleBox = styled.div`
  height: 40px;
  background-color: var(--color-bg-4);
  padding: 0 18px;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: start;
  border-radius: 2px;

  @media screen and (max-height: 600px) {
    height: 30px;
  }
`;
export const Schedule = styled.div`
  width: 100%;
  height: 10px;
  border-radius: 5px;
  overflow: hidden;
  background-color: var(--color-bg-10);
  position: relative;
  margin-right: 5px;
  &::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    height: 10px;
    width: ${(props) => props['data-num']}%;
    background-color: var(--color-text-6coin);
  }
`;
export const ScheduleText = styled.div`
  font-size: 12px;
  color: var(--color-text-2);
`;

export const MainItem = styled.div`
  width: 100%;
  height: 100%;
  border-radius: 5px;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
`;
export const MenuItem = styled.div`
  width: 100%;
  height: 50px;
  display: flex;
  justify-content: start;
  align-items: center;
  cursor: pointer;
  color: var(--color-text-2);
  box-sizing: border-box;
  padding-left: 30px;
  font-size: 14px;
  &:hover {
    color: var(--color-text-1);
    background-color: var(--color-bg-10);
    transition: all 0.2s ease-in-out;
  }
  :nth-child(1) {
    width: 18px;
    height: 18px;
  }
  :nth-child(2) {
    margin-left: 32px;
  }
  @media screen and (max-height: 650px) {
    height: 45px;
  }
  @media screen and (max-height: 600px) {
    height: 40px;
  }
`;

export const LogOut = styled.div`
  height: 57px;
  background-color: var(--color-bg-5);
  border-top: 1px solid var(--color-border-1);
  box-sizing: border-box;
  padding-left: 30px;
  display: flex;
  align-items: center;
  color: var(--color-text-2);
  font-size: 14px;
  cursor: pointer;
  :nth-child(2) {
    margin-left: 32px;
  }
  &:hover {
    color: var(--color-text-1);
    background-color: var(--color-bg-10);
    transition: all 0.2s ease-in-out;
  }
  /* box-sizing: border-box;
  padding: 0 10px;
  margin-top: 20px;
  display: grid;
  grid-template-columns: 30px 1fr;
  align-items: center;
  cursor: pointer;
  &:hover {
    color: var(--color-text-1);
  } */

  @media screen and (max-height: 600px) {
    height: 40px;
  }
`;

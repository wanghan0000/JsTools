import React from 'react';
import useDialogManager from '@/utils/useDialogManager';
import {
  BubbleCardContainer,
  Header,
  MyAvatar,
  Name,
  VIP,
  Main,
  ScheduleBox,
  ScheduleText,
  Schedule,
  MainItem,
  LogOut,
  MenuItem,
  UserId,
} from './indexElement';
import { Avatar, Message } from '@arco-design/web-react';
import { IconSettings } from '@arco-design/web-react/icon';
import { useVipInfo } from '@/store/PersonalCenter';

import Svg2 from './svg-icons/Lsjl';
import Svg3 from './svg-icons/Qb';
import Svg5 from './svg-icons/Tc';
import Svg6 from './svg-icons/Vip';
import Svg7 from './svg-icons/Yqhy';

import { useNavigate } from 'react-router';
import { useTranslationPlus } from '@/Core/i18n/useTranslationPlus';
import { AmountDivisorConversion, dealAmount0Fiexd, numberFixed } from '@/Core/utils/currencyDealCenter';

import user from './img/user.webp';
import copy from 'copy-to-clipboard';
import { debounce } from '@/Core/utils';
import { useGlobalState } from '@/store/commonStore';
import { useSignOut } from '@/store/signin';
import { Yaoqing } from '@/assets/svg-icon';

type IProps = {
  handleColes?: () => void;
};
const Droplist = ({ handleColes }: IProps) => {
  const { openVip, openWallet, openHistoryElement, openInviteElement } = useDialogManager();
  const { t } = useTranslationPlus('droplist');
  const { t: tt } = useTranslationPlus('GoogleSecurity');
  const navigate = useNavigate();
  const { data } = useVipInfo();

  const { trigger } = useSignOut();
  const { setToken, setTokenTime } = useGlobalState();

  const handleClickVip = () => {
    openVip();
  };
  const handleClickWallet = () => {
    openWallet();
  };
  const handleClickRecords = () => {
    openHistoryElement();
  };

  const handleClickInvite = () => {
    openInviteElement();
  };

  const handleFirends = () => {
    navigate('/NationalProxy');
    handleColes();
  };

  const useClickLogout = () => {
    trigger('');
    setToken('');
    setTokenTime('');
    navigate('/');
  };

  // 安全中心
  const ClickGlobalSettings = () => {
    navigate('/globalSettings/0');
    handleColes();
  };

  const calcCurrentProGress = () => {
    /*  进度=当前已获得 /  （下一等级总经验-当前等级总经验）
     *达到到当前等级后 后台需把已获得经验清空
         如：
    */
    const levelTotalExp = AmountDivisorConversion(data?.levelTotalExp, {
      currencyType: data?.currencyType,
    }); //当前等级经验
    const totalExp = AmountDivisorConversion(data?.totalExp, {
      currencyType: data?.currencyType,
    }); //当前已获得经验
    const nextLevelTotalExp = AmountDivisorConversion(data?.nextLevelTotalExp, {
      currencyType: data?.currencyType,
    }); //下一等级需要经验
    const per = (totalExp / (nextLevelTotalExp - levelTotalExp)) * 100;
    // return parseFloat(numberFixed(per > 100 ? 100 : per, 0)?.replace(',', '.')); //兼容服务端数据错误，百分比》100%
    return Math.round(per > 100 ? 100 : per);
  };

  /* 复制回调 */
  const handlerCopy = debounce(() => {
    if (copy(data?.usrId)) {
      Message.success(t('Affiliate.INVITE-1'));
    }
  });

  // useEffect(() => {
  //   revalidate();
  // }, []);

  return (
    <BubbleCardContainer>
      {/* <MyIconClose onClick={handleColes}></MyIconClose> */}
      <Header>
        <MyAvatar data-level={data?.level}>
          <Avatar>
            <img alt={''} src={user} />
          </Avatar>
        </MyAvatar>
        <Name>{data?.userName || ''}</Name>
        <UserId onClick={handlerCopy}>
          {tt('User ID')}:{data?.usrId}
        </UserId>
        <VIP onClick={openVip}>
          <span>VIP{data?.level || 0}</span>
          <span>
            <span className="exp">
              {AmountDivisorConversion(data?.nextLevelTotalExp || 0, {
                currencyType: data?.currencyType,
              }) -
                AmountDivisorConversion(data?.levelTotalExp || 0, {
                  currencyType: data?.currencyType,
                }) -
                AmountDivisorConversion(data?.totalExp || 0, {
                  currencyType: data?.currencyType,
                })}
            </span>
            {t('DROPLIST-8')}
            {data?.nextLevel || 0}
          </span>
        </VIP>
      </Header>
      <Main>
        {/* 进度条 */}
        <ScheduleBox>
          <Schedule data-num={calcCurrentProGress() || 0}></Schedule>
          <ScheduleText>{calcCurrentProGress() || 0}%</ScheduleText>
        </ScheduleBox>
        {/* 钱包、历史记录 */}
        <MainItem>
          <MenuItem onClick={handleClickWallet}>
            <Svg3 />
            <span>{t('DROPLIST-1')}</span>
          </MenuItem>
          <MenuItem onClick={handleClickRecords}>
            <Svg2 />
            <span>{t('DROPLIST-2')}</span>
          </MenuItem>
          <MenuItem onClick={handleFirends}>
            <Yaoqing />
            <span>{t('DROPLIST-5')}</span>
          </MenuItem>
          <MenuItem onClick={handleClickVip}>
            <Svg6 />
            <span>{t('DROPLIST-3')}</span>
          </MenuItem>
          <MenuItem onClick={handleClickInvite}>
            <Svg7 />
            <span>{t('DROPLIST-4')}</span>
          </MenuItem>
          <MenuItem onClick={ClickGlobalSettings}>
            <IconSettings />
            <span>{tt('Global Settings')}</span>
          </MenuItem>
        </MainItem>
      </Main>
      <LogOut onClick={useClickLogout}>
        <Svg5 />
        <span>{t('DROPLIST-7')}</span>
      </LogOut>
    </BubbleCardContainer>
  );
};

export default Droplist;

import * as React from 'react';
import type { SVGProps } from 'react';
const SvgTc = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} viewBox="0 0 48 48" {...props}>
    <path
      d="M38.6 7.493H11.423v6.588l3.294-1.647V9.963h15.647l-8.235 4.118v20.588h-7.412V32.2l-3.294-1.647v6.588h10.706V42.9L38.6 34.669V7.493ZM16.364 24.787v4.941L4.012 21.8l12.352-6.9v4.941h4.941v4.941h-4.941Z"
      data-name="\u7BAD\u5934 10 1"
      style={{
        fill: 'currentColor',
				fillRule: 'evenodd',
      }}
    />
  </svg>
);
export default SvgTc;

import * as React from 'react';
import type { SVGProps } from 'react';
const SvgQb = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} viewBox="0 0 48 48" {...props}>
    <path
      d="M28.91 26.5a6.016 6.016 0 0 0 5.87 6.154h4.7v4.923A1.2 1.2 0 0 1 38.3 38.8H8.953a1.2 1.2 0 0 1-1.174-1.231V15.42a1.2 1.2 0 0 1 1.174-1.231H38.3a1.2 1.2 0 0 1 1.174 1.231v4.923h-4.7A6.017 6.017 0 0 0 28.91 26.5Zm-9.978-14.157h18.783l-1.761-4.308s-.223-1.372-2.348-.616-14.674 4.924-14.674 4.924ZM34.78 22.8h6.457v7.385H34.78a3.7 3.7 0 0 1 0-7.385Zm.445 2.1a1.743 1.743 0 1 1-1.6 1.738 1.673 1.673 0 0 1 1.6-1.738Z"
      style={{
        fill: 'currentColor',
				fillRule: 'evenodd',
      }}
    />
  </svg>
);
export default SvgQb;

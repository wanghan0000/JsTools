import * as React from 'react';
import type { SVGProps } from 'react';
const SvgVip = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={18} height={18} viewBox="0 0 48 48" {...props}>
    <path
      d="m13.123 9.335-7.931 13.7L24.659 42.5l18.746-19.466-7.21-13.7H13.123Zm.721 10.815h5.768l5.047 5.768 5.768-5.768h5.047L24.659 31.686Z"
      style={{
      	fill: 'currentColor',
				fillRule: 'evenodd',
      }}
    />
  </svg>
);
export default SvgVip;

﻿import ActivityPopup from '@/pages/activityPopup';
import { useActivityList } from '@/store/activityList';
import NiceModal from '@ebay/nice-modal-react';
import React, { useEffect } from 'react'



function HomeActivity() {
    const { popList, trigger } = useActivityList(false);
    useEffect(() => {
        setTimeout(()=>{
            trigger({ needLogin: 0 }).then();
        },100)
    }, []);
    useEffect(() => {
        if (popList?.length) {
            NiceModal.show(ActivityPopup, { popList: popList });
        }
    }, [popList]);
    return (
        <></>
    )
}

export default React.memo(HomeActivity)
import React, { Fragment, useRef, CSSProperties } from 'react';
import Draggable from 'react-draggable';

interface Props {
  // children?: React.ReactElement | any;
  style?: CSSProperties;
  onStart?: () => void;
  onStop?: () => void;
  className?: string;
  onDrag?: (e) => void;
  children?: any;
}

const DraggableUI: React.FC<Props> = ({ style, children, onStart, onStop, className, onDrag }: any) => {
  const nodeRef = useRef(null);
  const dragHandlers = { onStart, onStop, nodeRef, onDrag };

  return (
    <Fragment>
      <Draggable {...dragHandlers}>
        <div style={style} ref={nodeRef} className={className}>
          {children}
        </div>
      </Draggable>
    </Fragment>
  );
};

export default DraggableUI;

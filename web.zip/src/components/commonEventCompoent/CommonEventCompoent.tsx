import { EventName } from '@/api/event/common';
import NiceModal from '@ebay/nice-modal-react';
import StopService from '@/pages/stopService';
import { useBeforeSetting } from '@/store/beforeSetting';
import EventMgr from '@/utils/EventMgr';
import useDialog from '@/utils/useDialog';
import React, { memo, useEffect, useLayoutEffect, useRef } from 'react';
import UpdateBanblce from '../webSocket/updateBanblce/UpdateBanblce';
import { useWsError, useWsLoginOut, useWsOpenWallet, useWsRefreshSettings } from '@/store/hallSocket';
import changeTheme from '@/utils/changeTheme';
import { useGlobalState, useGlobalTheme } from '@/store/commonStore';
import { useLocation, useNavigate, useNavigationType, useParams } from 'react-router';
import { getTimestamp } from '@/Core/utils';
import { useExitGame } from '@/store/game';
import { useVipInfo } from '@/store/PersonalCenter';
import { useUserInfo } from '@/store/userInfo';
import { useGetLoginSpecialActivityData } from '@/store/loginSpecialActivity';
import { sys } from '@/Core/utils/system';
import { useTranslationPlus } from '@/Core/i18n/useTranslationPlus';
import { Notification } from '@arco-design/web-react';
import ButtonUI from '@/componentsUI/Button';
import useDialogManager from '@/utils/useDialogManager';
import CommonPopup from '@/pages/commonPopup';
import { createBrowserRouter } from 'react-router-dom';
const routesMap = {};

const CommonEventCompoent = () => {
  const navigate = useNavigate();
  const { token, tokenTime, setToken, setTokenTime, isLogin } = useGlobalState();
  const { close } = useDialog();
  const { data, mutate } = useBeforeSetting();
  const { t } = useTranslationPlus();
  useWsRefreshSettings();
  const { data: insufficientBalanceData } = useWsOpenWallet();
  useWsLoginOut();
  useWsError();
  const { theme } = useGlobalTheme();
  const loginOutRef = useRef<boolean>();
  const { openWallet } = useDialogManager();

  /**处理401|登出 */
  const handleLoginout401 = () => {
    if (isLogin && !loginOutRef.current) {
      loginOutRef.current = true;
      setToken('');
      setTokenTime('');
      close();
      navigate('/home');
    }
  };

  useEffect(() => {
    isLogin && (loginOutRef.current = false);
  }, [isLogin]);

  /**处理停服 */
  const handleStopServer = () => {
    mutate();
  };

  /**处理错误弹窗 */
  const handleErrorPop = (response: any) => {
    console.log(response);
  };

  useEffect(() => {
    if (data && data.wnoticeVO) {
      NiceModal.show(StopService);
    }
    if (data && data.appVersion && data.appVersion > process.env.REACT_APP_VERSION) {
      const id = `${Date.now()}`;
      setTimeout(() => {
        Notification.info({
          id,
          title: t('UPDATE_WEBSITE_TITLE'),
          content: t('UPDATE_WEBSITE_CONTENT'),
          duration: 0,
          btn: (
            <span>
              <ButtonUI
                type="primary"
                onClick={() => {
                  if (sys.isNative) {
                    sys.nativeUpdateApp();
                    Notification.remove(id);
                  } else {
                    window.location.reload();
                  }
                }}
                style={{ margin: `0 12px`, height: 30, lineHeight: '30px' }}
              >
                {t('UPDATE_NOW')}
              </ButtonUI>
            </span>
          ),
        });
      }, 1000);
    }
  }, [data]);

  /**统一处理登录刷新数据 */
  const { revalidate } = useVipInfo(false);
  const { revalidate: revalidateUserInfo, data: userInfo } = useUserInfo();
  const { revalidate: revalidateSpecialActivityData } = useGetLoginSpecialActivityData();

  useEffect(() => {
    if (isLogin) {
      revalidate();
      //revalidateAmount()
      revalidateUserInfo();
      revalidateSpecialActivityData();
    }
  }, [isLogin]);

  useEffect(() => {
    EventMgr.getInstance().removeByEvent(EventName.LOGIN_OUT_401);
    EventMgr.getInstance().removeByEvent(EventName.STOP_SERVER_111);
    EventMgr.getInstance().removeByEvent(EventName.ERROR_POP_DIALOG);

    EventMgr.getInstance().addEventListener(EventName.LOGIN_OUT_401, handleLoginout401, this);
    EventMgr.getInstance().addEventListener(EventName.STOP_SERVER_111, handleStopServer, this);
    EventMgr.getInstance().addEventListener(EventName.ERROR_POP_DIALOG, handleErrorPop, this);

    return () => {
      EventMgr.getInstance().removeByEvent(EventName.LOGIN_OUT_401);
      EventMgr.getInstance().removeByEvent(EventName.STOP_SERVER_111);
      EventMgr.getInstance().removeByEvent(EventName.ERROR_POP_DIALOG);
    };
  }, [isLogin]);

  useEffect(() => {
    changeTheme(theme);
  }, [theme]);

  //useVipInfo();
  useEffect(() => {
    const checkToken = () => {
      if (!token || token.length < 5) {
        return false;
      }
      const delta = getTimestamp() - Number(tokenTime);
      if (delta > 0 && delta < 86400) {
        return true;
      } else {
        return false;
      }
    };

    if (!checkToken()) {
      setToken('');
      setTokenTime('');
    }

    window.addEventListener('message', (event) => {
      if (event.data === 'openOwnerWallet') {
        openWallet({ isHideClose: true });
      }
    });
  }, []);

  useEffect(() => {
    if (insufficientBalanceData) {
      NiceModal.show(CommonPopup, {
        ontentText: t('Wallet.InsufficientBalance'),
        rightBtnText: t('GameOriginal.Confirm'),
        leftBtnText: t('GameOriginal.Cancle'),
        leftCallback: ({ remove }) => {
          remove();
        },
        rightCallback: ({ remove }) => {
          remove();
          openWallet({ isHideClose: true });
        },
      });
    }
  }, [insufficientBalanceData]);

  //退出游戏
  const { exitTrigger } = useExitGame();
  const { pathname } = useLocation();

  const firstEnterAppRef = useRef(null);

  
  useEffect(() => {
    if (!firstEnterAppRef.current && isLogin && pathname && !pathname.includes('game')) {
      firstEnterAppRef.current = true;
      exitTrigger({});
    }
  }, [isLogin, pathname]);

  const types = useNavigationType()
  useLayoutEffect(() => {
    if(types === 'PUSH') {
      document.documentElement.scrollTop = 0;
    }
  }, [types,pathname]);

  return (
    <>
      {/**处理ws金额推送 */}
      <UpdateBanblce />
    </>
  );
};

export default memo(CommonEventCompoent);

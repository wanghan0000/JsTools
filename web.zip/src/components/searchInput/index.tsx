import React, { FC } from 'react';
import './styles/index.less';
import { IconSearch } from '@arco-design/web-react/icon';
import { useGlobalOpenSearch } from '@/store/commonStore';
import { useTranslationPlus } from '@/Core/i18n/useTranslationPlus';
/**
 * 作者: nick
 * 时间: 2023/5/27
 * 说明: 组件index
 */

interface IProps {
  title?: string;
  bgColor?: string;
}

const SearchInput: FC<IProps> = (Props) => {
  const [data, setOpenSearch] = useGlobalOpenSearch();
  const { t } = useTranslationPlus('HomeView');
  function handleClickMessage() {
    if (data) {
      setOpenSearch(false);
    } else {
      setOpenSearch(true);
    }
  }

  return (
    <div className={'tag-search-input-view'} style={{ backgroundColor: Props.bgColor }}>
      <div className={'tag-search-input-content'} onClick={handleClickMessage}>
        <IconSearch className={'tag-search-input-icon'} />
        <span className={'tag-search-input-tip'}>{t('SearchInput')}</span>
      </div>
    </div>
  );
};

export default SearchInput;

import './index.less';
import React, { memo, FC, useEffect, useState } from 'react';
import SpinUI, { SpinUIProps } from '../../componentsUI/Spin';
import ResultUI, { ResultUIProps } from '../../componentsUI/Result';
import EmptyUI, { EmptyUIProps } from '../../componentsUI/Empty';
import classNames from 'classnames';
export interface LoadingProps extends SpinUIProps, ResultUIProps, EmptyUIProps {
  loading?: boolean;
  error?: any | undefined;
  delay?: number;
  showIcon?: boolean;
  dataList?: any;
  isFloat?: boolean;
  retryFunc?: () => void;
  btnText?:string;
  cusFunc?:()=>void;
  emptyStyle?: any;
}

const LoadingUI: FC<LoadingProps> = (props) => {
  const [statusMsg, setStatusMsg] = useState<statusInfo>(null);
  type statusInfo = 'success' | 'error' | 'info' | 'warning' | '404' | '403' | '500' | null;
  useEffect(() => {
    //    if (!error?.code)  return
    switch (error?.code) {
      case 'ERROR_NETWORK':
        setStatusMsg('error');
        break;
      case 'ERROR_NODATA':
        setStatusMsg('info');
        break;
      default:
        setStatusMsg('warning');
        break;
    }
  }, []);

  const { loading, delay, tip, style , emptyStyle } = props; //spin属性

  const { dataList, retryFunc, error, showIcon, description,cusFunc,btnText } = props;
  const [successCssName, setSuccessCssName] = useState('');
  useEffect(() => {
    if (!loading && !error?.code) {
      setSuccessCssName('loading-complete');
    } else {
      setSuccessCssName('');
    }
  }, [loading, error]);

  return (
    <>
      {loading && (
        <div className={classNames(['loadingComp', successCssName])} style={style}>
          <SpinUI dot block loading={loading} delay={delay} tip={tip}></SpinUI>
        </div>
      )}
      <>
        {(( Object.keys(dataList ?? [])?.length > 0 && !loading && !error)) && props.children}
        {error && !loading && <ResultUI errorCode={error?.code} retryFunc={retryFunc} status={statusMsg} cusFunc={cusFunc} btnText={btnText} />}
        {!error?.code && Object.keys(dataList ?? [])?.length == 0 && !loading && (
          <EmptyUI style={emptyStyle} showIcon={showIcon} description={description} />
        )}
      </>
    </>
  );
};
LoadingUI.defaultProps = {
  loading: true,
  dot: true,
  block: true,
  tip: '',
  isFloat: false,
  description: 'NoData',

};

export default memo(LoadingUI);

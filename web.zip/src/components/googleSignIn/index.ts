import './style/index.less'
import GoogleSignIn from './googleSignIn'

export default GoogleSignIn;
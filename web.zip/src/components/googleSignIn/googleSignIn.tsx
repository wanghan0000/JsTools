import { Button } from '@arco-design/web-react';
import { useGoogleLogin } from '@react-oauth/google';
import { GoogleOAuthProvider } from '@react-oauth/google';
import { useEffect, useState } from 'react';
import React from 'react';
import { useTranslation } from 'react-i18next';
import useDialog from '@/utils/useDialog';
import { useGoogleSignin } from '@/store/signin';
import { LoginIconGoogle } from '@/assets/svg-icon';
import classNames from 'classnames';
import { sys } from '@/Core/utils/system';
const clientId = '1029089519139-i2urvcn0o3unjosnr5bdtkt0jjv0rola.apps.googleusercontent.com';

type ThirdSignStatus = '' | 'loading' | 'success' | 'error';

const GoogleComponet = (props) => {
  const prefixCls = 'google';
  const { isLoading, className } = props;
  const { i18n, t } = useTranslation();
  const { trigger } = useGoogleSignin();
  const { pop } = useDialog();
  const [thirdBtnStatus, setThirdLoginBtnStatus] = useState<ThirdSignStatus>('');

  const signin = async (token) => {
    const nativeSigin = window.nativeGoogleLogin;
    try {
      await trigger({
        googleCode: token,
        googleUri: window.location.origin,
        thirdSign: nativeSigin.thirdSign,
        os: sys.os,
        inviteCode: sys.inviteCode,
        pid: sys.pid,
        channle: '0',
        loginType: undefined,
      });
      pop();
    } catch (error) {
      console.warn(error);
    }
    setThirdLoginBtnStatus('');
  };

  const login = useGoogleLogin({
    onSuccess: (tokenResponse) => {
      signin(tokenResponse.access_token);
    },
    onError: (e) => console.log(e),
  });

  const clickSignin = () => {
    const native = sys.isNative;
    if (native) {
      sys.nativeGoogleLogin();
    } else {
      login();
      setThirdLoginBtnStatus('loading');
    }
  };

  useEffect(() => {
    try {
      const nativeSigin = window.nativeGoogleLogin;
      Object.defineProperty(nativeSigin, 'authCode', {
        set: function (val) {
          if (val) {
            signin(val);
          } else {
            setThirdLoginBtnStatus('error');
          }
        },
        enumerable: true,
        configurable: true,
      });
    } catch (error) {
      console.error('google登录报错');
    }
  }, [window]);

  return (
    <Button
      className={classNames([className])}
      icon={<LoginIconGoogle></LoginIconGoogle>}
      type={'outline'}
      onClick={() => {
        clickSignin();
      }}
      disabled={isLoading || thirdBtnStatus !== ''}
    >
      {t('Google')}
    </Button>
  );
};

const GoogleSignIn = (props: any) => {
  const { className } = props;
  const [isLoading, setIsLoading] = useState<boolean>(true);

  return (
    <GoogleOAuthProvider
      clientId={clientId}
      onScriptLoadSuccess={() => setIsLoading(false)}
      onScriptLoadError={() => console.warn('google script loadError')}
    >
      <GoogleComponet isLoading={isLoading} className={className}></GoogleComponet>
    </GoogleOAuthProvider>
  );
};

export default GoogleSignIn;

import React, { memo, useEffect, useState } from 'react';
import cs from 'classnames'
// import srCoin from '@/assets/coin.png';
import styles from './style/index.module.less';

export interface UseCssLotteryProps {
  data: Array<[]>;
}

const CssLottery = ({ data }) => {
  const CIRCLE_ANGLE = 360;
  const BIGSIZE = 24;
  let gift_id = 0;
  const average = CIRCLE_ANGLE / data.length; //60
  const half = average / 2; //30
  // // 记录每个奖的位置
  const [angleList, setAngleList] = useState([])
  //奖品列表
  const [prizeList, setPrizeList] = useState([])

  //为了防止重复点击
  const [isRotating, setIsRotating] = useState(false)
  // let rotateAngle = 0;

  const [rotateAngle, setRotateAngle] = useState(-half)

  useEffect(() => {
    formatPrizeList(data); //有样式的奖品列表
  }, []);

  //每个奖增加style
  const formatPrizeList = (list) => {
    // 计算单个奖项所占的角度
    // const average = CIRCLE_ANGLE / l; //60
    // const half = average / 2; //30
    // setRotateAngle(-half)
    // 循环计算给每个奖项添加style属性
    list.forEach((item, i) => {
      // 每个奖项旋转的位置为 当前 i * 平均值 + 平均值 / 2
      const angle = -(i * average + half);
      // 记录每个奖项的角度范围
      angleList.push(angle);
    });
    setAngleList(angleList);
    setPrizeList(list);
  }

  //抽奖
  const prizeRoll = () => {
    if (isRotating) return false;
    if (!isNaN(gift_id)) {//没有指定，采取默认中奖id
      gift_id = Math.floor(1 + Math.random() * prizeList.length);
    }

  
    prizeList.forEach((item, i) => {
      if (item.id == gift_id) {
        rotating(i);
        return
      }
    });

  };
  //转盘转动角度
  const rotating = (i) => {
    setIsRotating(true)
    const config = {
      duration: 5000,
      circle: 8,
      mode: "ease-in-out"
    }
    // 计算角度=初始角度+多旋转的圈数+奖项的角度
    const angle = rotateAngle + config.circle * CIRCLE_ANGLE + angleList[i] - (rotateAngle % CIRCLE_ANGLE);

    setRotateAngle(angle)
    // 旋转结束后，允许再次触发
    setTimeout(() => {
      setIsRotating(false)
      console.log('旋转结束')
    }, config.duration + Math.random());
    console.log('旋转s-->' + (config.duration + Math.random() * 1000 >> 0))
  }

  const renderBg = () => {

    return (
      prizeList.map((item, i) => {
        const l = prizeList.length
        const bigAgeLen = l > 2 ? i * 360 / l : 0;
        const skewMain = l <= 2 ? 0 : -(l - 4) * 90 / l;
        const rightBig = l == 2 ? 50 : 0;
        const heightBig = l <= 3 ? 100 : 50;
        const topBig = l == 3 ? -50 : 0;
        return (
          <div className={styles["luckWhellSector"]} key={i}
            style={{
              WebkitTransform: ` rotate(${bigAgeLen}deg)`,
              transform: `rotate(${bigAgeLen}deg) skewY(${skewMain}deg)`,
              right: `${rightBig * i}%`,
              height: `${heightBig}%`,
              top: `${topBig}%`,
              width: `${l == 1 ? 100 : 50}%`,
            }}
          >
          </div>
        )
      })
    )
  }


  const renderIem = () => {
    return (

      prizeList.map((item, i) => {
        const l = prizeList.length
        const average = CIRCLE_ANGLE / l; //60
        const half = average / 2; //30		
        const angle = -(i * average + half)
        return (
          <div className={styles["prize-item"]} key={i}
            style={{
              WebkitTransform: ` rotate(${-angle}deg)`,
              transform: `rotate(${-angle}deg)`,
              width: `${100 / l * 2}%`,
              marginLeft: ` -${100 / l}%`,
              fontSize: `${BIGSIZE - l}px`
            }}
          >
            <div>
              {item.prize_name}
            </div>
            <div style={{ paddingTop: '5px' }}>
              <img src={item.img} style={{ width: '45%' }} />
            </div>
          </div>
        )
      })

    )
  }

  return (
    <div className={styles["luckBg"]}>
      <div className={styles["luckWhellBg"]}>
        <div className={cs(styles["luckWhellBgMain"], styles["rotateStyle"])}
          style={{
            transform: `rotate(${rotateAngle}deg)`
          }}
        >
          {renderBg()}
        </div>
        <div className={styles["wheel-main"]} >
          <div className={cs(styles["prize-list"], styles["rotateStyle"])}
            style={{
              transform: `rotate(${rotateAngle}deg)`
            }}
          >
            {renderIem()}
          </div>
          <div className={styles["prize_point"]} onClick={prizeRoll} />
        </div>
      </div>
    </div>
  )
}
export default memo(CssLottery)
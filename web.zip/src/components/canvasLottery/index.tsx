

import React, { memo, useEffect, useRef, useState } from 'react';
import styles from './style/index.module.less';
import srCoin from '@/assets/coin.png';
const useCanvasLottery = () => {
    const consts = {
        // 奖品清单
        prizeList: [
            {
                percent: 0.1,//配置概率
                prizeName: '1苹果',
                prizeImg: srCoin
            },
            {
                percent: 1,
                prizeName: '2谢谢参与',
                prizeImg: srCoin
            },
            {
                percent: 0.1,
                prizeName: '3火龙果',
                prizeImg: srCoin
            },
            {
                percent: 3,
                prizeName: '4梨子',
                prizeImg: srCoin
            },
            {
                percent: 1,
                prizeName: '5谢谢参与',
                prizeImg: srCoin
            },
            {
                percent: 5,
                prizeName: '6牛奶',
                prizeImg: srCoin
            },
            {
                percent: 6,
                prizeName: '7雪糕',
                prizeImg: srCoin
            },
            {
                percent: 7,
                prizeName: '8榴莲',
                prizeImg: srCoin
            }
        ],
        // 每一块扇形的背景色
        prizeBgColors: [
            'rgb(255, 231, 149)',
            'rgb(255, 247, 223)',
        ],
        // 每一块扇形的外边框颜色
        borderColor: '#ff9800'
    }

    const configCanvas = {
        width: '400px',
        height: '400px'
    }
    const prizeNum = consts.prizeList.length
    const perAngle = 360 / prizeNum
    const offsetAngle = perAngle / 2
    const circleCount = 3 //旋转圈数
    const rotateDuration = 3  // 持续时间
    const [isRotating, setIsRotating] = useState(false)
    const [rotateAngle, setRotateAngle] = useState(-offsetAngle)
    const refCanvas = useRef(null)
    useEffect(() => {
        drawPanel()
    })
    // 画出盘面
    const drawPanel = () => {

        const { current } = refCanvas
        const ctx = current.getContext('2d')
        const w = current?.width
        const h = current?.height
        // const dpr = window.devicePixelRatio
        // // 处理设备分辨率
        // current.width = w * dpr
        // current.height = h * dpr
        // ctx.scale(dpr, dpr)

        // 将画布逆时针旋转90°
        ctx.translate(0, h)
        ctx.rotate(-90 * Math.PI / 180)

        ctx.strokeStyle = consts.borderColor

        const perRadian = (Math.PI * 2) / prizeNum
        for (let i = 0; i < prizeNum; i++) {
            const radian = perRadian * i
            ctx.beginPath()
            //   console.log(i)
            if (i % 2 === 0) {
                ctx.fillStyle = consts.prizeBgColors[0]
            } else {
                ctx.fillStyle = consts.prizeBgColors[1]
            }
            //   console.log(ctx.fillStyle)
            ctx.moveTo(w / 2, h / 2)
            ctx.arc(w / 2, h / 2, w / 2, radian, radian + perRadian, false) // 顺时针
            ctx.closePath()
            ctx.stroke()
            ctx.fill()
        }
    }



    const prizeRoll = () => {
        if (isRotating) {
            return
        } else {
            setIsRotating(true)
        }
        const index = computedPrize()

        const rotateAnglevv =
            rotateAngle +
            circleCount * 360 +
            360 - (perAngle * index + offsetAngle) -
            rotateAngle % 360
        setRotateAngle(rotateAnglevv)
        setTimeout(() => {
            rotateEnd(index)
        }, rotateDuration * 1000);
    }

    const rotateEnd = (index) => {
        setIsRotating(false)
        console.log('选中后--->' + consts.prizeList[index].prizeName)
    }


    const computedPrize = () => {
        let sum = 0
        const prizeArr = []
        consts.prizeList.forEach(item => {
            sum += item.percent
            let percent = item.percent
            while (percent > 0) {
                prizeArr.push(item)
                percent--
            }
        })
        const prizeArrIndex = Math.floor(Math.random() * prizeArr.length)
        let index
        consts.prizeList.forEach((item, i) => {
            if (item === prizeArr[prizeArrIndex]) {
                index = i
                console.log('实际中奖index--->' + i)
            }
        })
        return index
    }

    const renderItem = () => {
        return (
            consts.prizeList.map((item, i) => {
                const currentAngle = perAngle * i + offsetAngle
                return (
                    <div className={styles["prize-item"]} key={i} style={{ transform: `rotate(${currentAngle}deg)` }}>
                        <div className={styles["prize-item__name"]}>{item.prizeName}</div>
                        <div className={styles["prize-item__img"]}>
                            <img src={srCoin} alt="" />
                        </div>
                    </div>
                )
            })
        )
    }

    return (
        <div className={styles["luckdraw"]} style={{ width: configCanvas.width, height: configCanvas.height }}>
            <div className={styles["luckpanel"]}
                style={{ transform: `rotate(${rotateAngle}deg)`, transitionDuration: `${rotateDuration}s` }}
            >
                <canvas id="canvas" ref={refCanvas} width={configCanvas.width} height={configCanvas.height}></canvas>
                <div className={styles["prize"]} >
                    {renderItem()}
                </div>
            </div>
            <div className={styles["pointer"]} onClick={prizeRoll}></div>
        </div>
    )

}


export default memo(useCanvasLottery)
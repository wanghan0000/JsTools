import React, { memo, useEffect, useState } from 'react';
import cs from 'classnames';
import './style/index.less';
import { dealAmountAnyValid, getCurrencyImagePath } from '@/Core/utils/currencyDealCenter';
import { useGlobalRefreshBonus } from '@/store/commonStore';

const CssLottery = ({ className, userCurrentTurntable, isOpen, data, isChecked, gift_id, remainingTimes, triggerSpin }) => {
  const CIRCLE_ANGLE = 360;
  const BIGSIZE = 24;
  const average = CIRCLE_ANGLE / data?.length; //40
  const half = average / 2 - 90; //正向旋转70度

  // // 记录每个奖的位置
  const [angleList, setAngleList] = useState([]);
  //奖品列表
  const [prizeList, setPrizeList] = useState([]);

  //为了防止重复点击
  const [isRotating, setIsRotating] = useState(false);

  //初始角度
  const [rotateAngle, setRotateAngle] = useState(-half);

  // 转盘结束：通知奖励中心刷新
  const [, setRefreshSpin] = useGlobalRefreshBonus();

  // 转盘：是否显示中奖底色
  const [spinEnd, setSpinEnd] = useState<boolean>(false);
  useEffect(() => {
    formatPrizeList(data); //有样式的奖品列表
  }, []);

  useEffect(() => {
    gift_id &&
      prizeList?.forEach((item, i) => {
        if (item.award == gift_id) {
          console.log('award', gift_id);
          rotating(i);
          console.log('gift_id----', gift_id, i);
        }
      });
  }, [gift_id]);

  //每个奖增加style
  const formatPrizeList = (list) => {
    // 计算单个奖项所占的角度

    // 循环计算给每个奖项添加style属性
    list?.forEach((_item: any, i: number) => {
      // 每个奖项旋转的位置为 当前 i * 平均值 + 平均值 / 2
      const angle = -(i * average + half);
      // 记录每个奖项的角度范围
      angleList.push(angle);
      // console.log('angleList',angleList)
    });
    setAngleList(angleList);
    setPrizeList(list);
  };
  //转盘转动角度
  const rotating = (i: number) => {
    setIsRotating(true);
    const config = {
      duration: 5000,
      circle: 8,
      mode: 'ease-in-out',
    };
    /* 计算角度=初始角度+多旋转的圈数角度+奖项的角度+背景/内容旋转的初始角度
    初始角度rotateAngle：默认-20
    多旋转的圈数config.circle：设置8圈
    一圈角度CIRCLE_ANGLE： 360
    当前奖项的角度： angleList[i] - (rotateAngle % CIRCLE_ANGLE)
     */
    console.log('rotateAngle', rotateAngle);
    const t = rotateAngle % CIRCLE_ANGLE;
    console.log('rotateAngle % CIRCLE_ANGLE', t);
    const angle = rotateAngle + config.circle * CIRCLE_ANGLE + (angleList[i] - (rotateAngle % CIRCLE_ANGLE)); //
    console.log('angle', angle);
    setRotateAngle(angle);

    // 旋转结束后，允许再次触发
    setTimeout(() => {
      setIsRotating(false); //允许再次点击
      setRefreshSpin(true); //转盘结束、触发奖励中心更新转盘次数
      setSpinEnd(true);
    }, config.duration + Math.random());
    console.log(' 旋转结束剩余次数 clickCount', remainingTimes);
    console.log('旋转s-->' + ((config.duration + Math.random() * 1000) >> 0));
  };

  //抽奖
  const prizeRoll = async () => {
    /* 
          isOpen: 当前转盘是否开启
          remainingTimes:当前转盘剩余抽奖次数
          isRotating：自定义，是否点击，判断--避免重复点击
          */
    if (userCurrentTurntable == isChecked && remainingTimes > 0) {
      //userCurrentTurntable!=isChecked: 判断切换的是否当前归属转盘
      if (isRotating || !isOpen) {
        //!isopen :为了兼容后台关闭青铜情况下（数据异常情况），  转盘返回false 得不能转
        return;
      }
      triggerSpin();
    }
  };

  const renderIem = () => {
    return prizeList?.map((item, i) => {
      const l = prizeList?.length;
      const average = CIRCLE_ANGLE / l; //60
      const half = average / 2; //
      const angle = -(i * average + half);

      return (
        <div
          className={'prize-item'}
          key={i}
          style={{
            WebkitTransform: ` rotate(${-angle}deg)`,
            transform: `rotate(${-angle}deg)`,
            width: `${(100 / l) * 2}%`,
            marginLeft: ` -${100 / l}%`,
            fontSize: `${BIGSIZE - l}px`,
          }}
        >
          <div className="icon">
            {/* <span>{item.award}</span> */}
            <img src={getCurrencyImagePath(item?.currency)} />
          </div>
          <div className="amount">
            {dealAmountAnyValid(item.num, 6, {
              currencyType: item.currency,
            })}
          </div>
        </div>
      );
    });
  };

  return (
    <>
      <div className={cs(className, 'luckBg', `luckBg${isChecked}`)}>
        {isChecked != 6 && <div className="luckBg-lightA"></div>}
        <div className="luckWhellBg">
          <div
            className={cs('luckWhellBgMain', 'rotateStyle')}
            style={{
              transform: `rotate(${rotateAngle}deg)`,
            }}
          >
            {/* {renderBg()} */}
          </div>
          <div className={'wheel-main'}>
            <div
              className={cs('prize-list', 'rotateStyle')}
              style={{
                transform: `rotate(${rotateAngle}deg)`,
              }}
            >
              {renderIem()}
            </div>
          </div>
          {/* <SpinUI loading={isMutating} className={cs('prize_point_spin', `prize_point_spin${isChecked}`)}>
        <div className='prize_point' onClick={prizeRoll} >
            <span className={cs('prize_point_text', `prize_point_text${isChecked}`)}></span>
          </div>
        </SpinUI> */}
          <div className={cs('prize_point_spin', `prize_point_spin${isChecked}`)}>
            <div className="prize_point" onClick={prizeRoll}>
              <span className={cs('prize_point_text', `prize_point_text${isChecked}`)}></span>
            </div>
          </div>
          <div className={cs('prize_point_selected', `prize_point_selected${isChecked}`)}></div>
          <div className={spinEnd ? `SectorGift` : ''}></div>
        </div>
      </div>
      <div className="lotteryBg"></div>
    </>
  );
};
export default memo(CssLottery);

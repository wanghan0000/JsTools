export interface cssLoterryProps{

    isChecked?:number
}
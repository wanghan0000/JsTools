
import React, { useEffect, useRef } from "react"
import { calcResetTime } from "@/Core/utils";
import { useResetTimerSpin } from "@/store/commonStore";
const useResetTimer = ({ resetTime, onRestTimeEnd }) => {
    const [time, setTime] = useResetTimerSpin()
    const cd = useRef<number>()
    const timer = useRef<any>(null)
    const IntervalDate = () => {
        timer.current = setInterval(() => {
            dealDate()
        }, 1000)
    }
    useEffect(() => {
        cd.current = resetTime;
    }, [resetTime])
    useEffect((): any => {

        setTime(calcResetTime(cd?.current))
        IntervalDate()
        return () => {
            setTime(calcResetTime(cd?.current))
            timer.current && clearInterval(timer?.current)
        }
    }, []);
    const dealDate = () => {
        if (cd.current <= 0) {
            setTime('')
            onRestTimeEnd()
            return timer.current && clearInterval(timer?.current)
        }
        cd.current--;
        setTime(calcResetTime(cd?.current))
    }
    return (
        <span className="timer"> {time}</span>
    )
}
export default useResetTimer

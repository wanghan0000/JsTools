import React, { useEffect, useState } from 'react';
import { ExpireIn } from '@/pages/cssLottery/LotteryElements';
import { useTranslationPlus } from '@/Core/i18n/useTranslationPlus';
import ResetTimer from '../bottom/resetTimer';
import cs from 'classnames';
import './index.less';
import { Spin } from '@arco-design/web-react'; //组件不用，因为组件不是响应式
import ButtonUI from '@/componentsUI/Button';
import LoadingSuperPlusUI from '@/componentsUI/LoadingSuperPlusUI/LoadingSuperPlusUI';

const WheelBottom = ({
  triggerSpin,
  className,
  ribbonSrc,
  isChecked,
  isMutating,
  userCurrentTurntable,
  resetTime,
  remainingTimes,
  isTimerExpired,
  timeEndRevalidate,
}) => {
  const { t } = useTranslationPlus('wheel');
  const [resTime, setResTime] = useState<number>();

  useEffect(() => {
    resetTime && setResTime(resetTime / 1000);
  }, [resetTime]);
  /* 倒计时回调 */
  const handleRestTimeEnd = () => {
    timeEndRevalidate();
  };
  return (
    <div className={className}>
      <div className={`bottom-winIcon`}>
        <img src={ribbonSrc} />
      </div>
      {isMutating ? (
        <ButtonUI disabled={isMutating} style={{ width: '220px' }} type="primary">
          <LoadingSuperPlusUI extraStyle={'SpinExtraStyle'} style={{ backgroundColor: 'transparent' }} dataList={[1]} loading={true} />
        </ButtonUI>
      ) : (
        <ExpireIn
          className={cs(
            'expireTime',
            isChecked == 4 ? 'isChecked4' : isChecked == 5 ? 'isChecked5' : 'isChecked6',
            isChecked == userCurrentTurntable && remainingTimes > 0 ? '' : 'bottom-expireDisable'
          )}
        >
          {isTimerExpired && resTime > 0 ? (
            <div>
              <span> {t('next', { resetTime: `` })}</span>
              <ResetTimer resetTime={resTime} onRestTimeEnd={handleRestTimeEnd}></ResetTimer>
            </div>
          ) : (
            <div onClick={triggerSpin}>
              {!isMutating && (
                <span>
                  {t(`wheelName`)} : {remainingTimes}
                </span>
              )}
            </div>
          )}
        </ExpireIn>
      )}
    </div>
  );
};

export default WheelBottom;

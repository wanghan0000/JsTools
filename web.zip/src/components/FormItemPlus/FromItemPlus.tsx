import React from "react";
import { Form, FormItemProps } from "@arco-design/web-react";
const FromItem = Form.Item;


const FromItemPlus = (props: FormItemProps) => {
    return <FromItem
        {...props}
    />
}


export default FromItemPlus

import { ReactNode } from "react";

export interface InputCommonProps {
    className?: string;
    /**
     * title
     */
    title?: string,
    /**
     * placeHolder
     */
    placeHolder?: string,
    /**
     * error
     */
    error?: string,
    /**
     * 是否禁用输入
     */
    disabled?: boolean,
    /**
     * 默認值
     */
    defaultValue?: string,
    /**
     * 输入框获取焦点
     */
    onFocus?: () => void,
    /**
     * 输入框失去焦点
     */
    onBlur?: () => void,
    /**
     * 输入时的回调
     */
    onChange?: (value: string, e: any) => void;
    /**
    * 是否只读
    */
    readOnly?: boolean;
    /**
    * 输入框前添加元素
    */
    addBefore?: ReactNode;
    /**
     * 输入框后添加元素
     */
    addAfter?: ReactNode;
    /**
     * 添加前缀文字或者图标
     */
    prefix?: ReactNode;
    /**
     * 添加后缀文字或者图标
     */
    suffix?: ReactNode;
    /**
     * 输入框的值，受控模式
     */
    value?: string;
    /**
     * 输入框最大输入的长度
     */
    maxLength?: number
    /**
    * 状态
    */
    status?: Status;
    /**
     * 是否是密码模式
     */
    password?: boolean;
    /**
     * 密码模式下有效
     */
    defaultVisibility?: boolean

}

export type Status = 'error' | 'warning' | undefined;
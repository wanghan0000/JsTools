import InputUI from "@/componentsUI/Input";
import InputPasswordUI from "@/componentsUI/InputPassword";
import { Input, Trigger, Typography } from "@arco-design/web-react"
import classNames from "classnames";
import React, { PropsWithChildren } from "react"
import { InputCommonProps } from "./interface";

const InputCommon = (props: PropsWithChildren<InputCommonProps>) => {
    const {
        title = '',
        placeHolder = '',
        error = '',
        className = '',
        disabled = false,
        defaultValue = '',
        onFocus,
        onBlur,
        value,
        onChange,
        maxLength,
        status,
        readOnly = false,
        addBefore,
        addAfter,
        prefix,
        suffix,
        password,
        defaultVisibility,
        children
    } = props;
    const prefixCls = 'jokerma-InputCommon';

    return (
        <div className={classNames([`${prefixCls}`, className])}>
            {title !== '' &&
                <Typography.Text className={'title'}>
                    {title}
                </Typography.Text>}
            <div className={classNames(['content', readOnly ? 'hide-fouce' : ''])}>
                <Trigger
                    popup={() => (<div></div>)}
                    trigger={'focus'}
                    onVisibleChange={(visible) => {
                        if (!visible) {
                            onBlur && onBlur()
                        } else {
                            onFocus && onFocus()
                        }
                    }}
                >
                    {
                        !password ? <InputUI
                            className={'input'}
                            defaultValue={defaultValue}
                            readOnly={readOnly}
                            disabled={disabled}
                            allowClear={false}
                            placeholder={placeHolder}
                            maxLength={maxLength}
                            value={value}
                            onChange={onChange}
                            addBefore={addBefore}
                            addAfter={addAfter}
                            prefix={prefix}
                            suffix={suffix}
                            status={status}
                        /> : <InputPasswordUI
                            className={'input'}
                            defaultValue={defaultValue}
                            readOnly={readOnly}
                            disabled={disabled}
                            allowClear={false}
                            placeholder={placeHolder}
                            maxLength={maxLength}
                            value={value}
                            onChange={onChange}
                            addBefore={addBefore}
                            addAfter={addAfter}
                            prefix={prefix}
                            suffix={suffix}
                            status={status}
                            defaultVisibility={defaultVisibility}
                        />
                    }

                </Trigger>
                {children}
            </div>

            {status === 'error' && error !== '' && (
                <Typography.Text className={'error input-error'}>{error}</Typography.Text>
            )}
        </div>
    )
}

export default InputCommon
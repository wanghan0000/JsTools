import './style/index.less'
import InputCommon from './InputCommon'

export default InputCommon
import InputUI from '@/componentsUI/Input';
import { Dropdown, Menu, Select, Space } from '@arco-design/web-react';
import { IconDown } from '@arco-design/web-react/icon';
import React, { useEffect, useState } from 'react';

export const ContryCodes: { name: string; code: number; max: number; regExp: string }[] = [
  { name: '中国', code: 86, max: 11, regExp: '^1[3|4|5|6|7|8|9][0-9][0-9]{4}[0-9]{4}$' },
  { name: 'Brazil', code: 55, max: 11, regExp: '^[1-9]{2}[9]{1}[0-9]{8}$' },
];

export const getConrtyCodeByCode = (code) => {
  for (const v of ContryCodes) {
    if (`${v?.code}` === `${code}`) {
      return `+${v?.code}`;
    }
  }
};

const InputPhone = (props) => {
  const { value = {}, onChange, disabled, readOnly } = props;
  const prefixCls = 'arco-mt2-input-phone';
  const [contryCode, setCountryCode] = useState<any>(value?.select || ContryCodes[0]);

  const dropList = (
    <Menu className={`${prefixCls}-menu`}>
      {ContryCodes.map((option, index) => {
        return (
          <Menu.Item
            key={index + ''}
            onClick={(e) => {
              setCountryCode(ContryCodes[index]);
              console.log(value);
              onChange && onChange({ ...value, select: ContryCodes[index] });
            }}
          >
            {`${option.name}  +${option.code}`}
          </Menu.Item>
        );
      })}
    </Menu>
  );

  const handleChange = (newValue) => {
    onChange && onChange({ ...newValue, select: contryCode });
  };

  return (
    <InputUI
      className={prefixCls}
      {...props}
      prefix={
        readOnly ? (
          '+' + (value?.select?.code || contryCode?.code)
        ) : (
          <Dropdown droplist={dropList} position={'bottom'} trigger={'click'} disabled={disabled}>
            <Space size={3}>
              <span className="text"> {'+' + (value?.select?.code || contryCode?.code)}</span>
              <IconDown />
              <div className="l"></div>
            </Space>
          </Dropdown>
        )
      }
      value={value.input}
      onChange={(v) => {
        handleChange({ ...value, input: v || undefined });
      }}
    ></InputUI>
  );
};

export default InputPhone;

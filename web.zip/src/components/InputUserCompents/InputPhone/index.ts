import './style/index.less'
import InputPhone from './InputPhone'

export default InputPhone
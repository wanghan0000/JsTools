import './style/index.less'
import InputEmail from './InputEmail'

export default InputEmail
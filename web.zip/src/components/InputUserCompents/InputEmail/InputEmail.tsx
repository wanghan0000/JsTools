import InputUI from '@/componentsUI/Input';
import React, { useEffect, useState } from 'react';

const EmailList = ['@gmail.com', '@outlook.com', '@yahoo.com', '@aol.com', '@zoho.com', '@icloud.com', '@mail.com', '@inbox.com'];

const reg = /@(gmail|outlook|yahoo|aol|zoho|icloud|mail|inbox)\.(com)$/;
// 匹配字段
const handlerAutoComp = function (inputStr) {
  if (reg.test(inputStr)) {
    return [];
  }
  if(!inputStr) {
    return [];
  }
  const outString = [];
  let exgStr = '';
  let str1 = '';
  const splitStr = inputStr?.split('@');
  if (splitStr.length === 2) {
    exgStr = '@' + splitStr[1];
    str1 = splitStr[0];
  } else {
    str1 = inputStr;
  }
  if (exgStr == '') {
    EmailList.forEach((value) => {
      outString.push(str1 + value);
    });
  } else {
    EmailList.forEach((value) => {
      if (value.indexOf(exgStr) == 0) {
        outString.push(str1 + value);
      }
    });
  }
  if (outString?.length === 1) {
    let flag = false;
    for (let i = 0; i < EmailList.length; ++i) {
      if (exgStr === EmailList[i]) {
        flag = true;
        break;
      }
    }
    flag && (outString.length = 0);
  }
  return outString;
};

const getEmailDomain = (email) => {
  const atIndex = email.indexOf('@');
  if (atIndex !== -1) {
    const domain = email.substring(atIndex + 1);
    return domain;
  }
  return '';
};

const InputEmail = (props) => {
  const { value, onChange } = props;

  const prefixCls = 'arco-input-email';

  const [emails, setEmails] = useState([]);

  useEffect(() => {
    if (value) {
      setEmails([...handlerAutoComp(value)]);
    } else {
      setEmails([]);
    }
  }, [value]);

  const handleClickInput = (v: string) => {
    onChange && onChange(v);
  };

  return (
    <div className={`${prefixCls}`}>
      <InputUI {...props} dataList={emails} onClickDropData={handleClickInput} />
    </div>
  );
};

export default InputEmail;

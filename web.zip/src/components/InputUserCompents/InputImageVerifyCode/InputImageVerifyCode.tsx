import omit from "@/Core/utils/omit";
import { Image } from "@arco-design/web-react";
import React from "react";
import InputUserBase from "../InputUserBase";

const InputImageVerifyCode = (props) => {
    const { verifyCodeImg, revalidate } = props;
    const prefixCls = 'arco-mt2-input-image-verify-code';
    const other = omit(props,['verifyCodeImg','revalidate'])
    return (<div className={`${prefixCls}`}>
        <InputUserBase {...other}></InputUserBase>
        <Image
            preview={false}
            onClick={() => {
                revalidate()
            }} src={verifyCodeImg} className={`verify-code-img`} alt="" />
    </div>)
}

export default InputImageVerifyCode
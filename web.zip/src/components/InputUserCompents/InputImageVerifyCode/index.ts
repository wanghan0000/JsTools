import './style/index.less'
import InputImageVerifyCode from './InputImageVerifyCode'
export default InputImageVerifyCode
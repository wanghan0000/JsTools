import './style/index.less'
import InputUserBase from './InputUserBase'
export default InputUserBase
import InputUI from '@/componentsUI/Input';
import InputPasswordUI from '@/componentsUI/InputPassword';
import omit from '@/Core/utils/omit';
import React from 'react';

const InputUserBase = (props) => {
  const { value, password, onChange } = props;

  const handleChange = (newValue) => {
    onChange && onChange(newValue);
  };
  //delete props?.password
  //delete props?.value
  //delete props?.onChange
  const other = omit(props, ['password']);
  return password ? (
    <InputPasswordUI
      {...other}
      value={value}
      onChange={(v) => {
        handleChange(v);
      }}
    />
  ) : (
    <InputUI
      {...other}
      value={value}
      onChange={(v) => {
        handleChange(v);
      }}
    />
  );
};

export default InputUserBase;

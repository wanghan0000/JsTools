import { styled } from 'styled-components';

export const InputPhoneContainer = styled.div`
  .arco-select .arco-select-view {
    max-height: 38px;
    line-height: 38px;
    background-color: transparent !important;
    border-color: transparent !important;
    color: var(--color-text-2);
  }
  .arco-select-arrow-icon {
    line-height: 100%;
  }

  .arco-trigger {
    width: 100% !important;
  }

  .arco-select-option {
    display: flex;
    justify-content: space-between;
  }
  .arco-select-popup {
    padding: 0;
  }

  .arco-select-suffix {
    svg {
      width: 13px;
      margin-top: 3px;
    }
  }

  .arco-input-group-prefix {
    position: relative;
  }
  .arco-input-group-prefix::after {
    content: '';
    position: absolute;
    top: 50%;
    bottom: 50%;
    transform: translateY(-50%);
    right: 0px;
    height: 12px;
    width: 1px;
    opacity: 0.5;
    background-color: var(--color-text-2);
  }
`;

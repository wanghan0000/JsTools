import React, { useEffect, useRef, useState } from 'react';
import { Select } from '@arco-design/web-react';
import CountrysJson from '@/assets/country-code.json';
import { InputPhoneContainer } from './indexEle';
import InputUI from '@/componentsUI/Input';
import { useBeforeSetting } from '@/store/beforeSetting';
import SelectUI from '@/componentsUI/Select';

/**筛选国码 */
const filterCountryJson = (countryJson: any[], countryCodes: any[]) => {
  const filteredCountryJson = countryJson.filter((item) => countryCodes.includes(parseInt(item.code.replace('+', ''))));
  filteredCountryJson.sort((a, b) => {
    const codeA = parseInt(a.code.replace('+', ''));
    const codeB = parseInt(b.code.replace('+', ''));
    return countryCodes.indexOf(codeA) - countryCodes.indexOf(codeB);
  });

  const formattedResult = filteredCountryJson.map((item) => ({
    ...item,
    code: parseInt(item.code.replace('+', '')),
    mask: item.mask,
  }));

  return formattedResult;
};

const InputPhonePlus = (props) => {
  const { value = {}, onChange, disabled } = props;

  const { data } = useBeforeSetting();
  const [countrys, setCountrys] = useState([]);
  //匹配国码
  useEffect(() => {
    let filterCountry;
    if (data && data?.countryCodes?.length) {
      filterCountry = filterCountryJson(CountrysJson, data.countryCodes);
    } else {
      filterCountry = filterCountryJson(CountrysJson, [55]);
    }
    setCountrys(filterCountry);
    handleChange({ ...value, select: filterCountry[0] });
  }, [data]);

  const groupRef = useRef(null);
  const handleChange = (newValue) => {
    if (newValue?.input) {
      const numericValue = newValue.input.replace(/\D/g, '');
      newValue.input = numericValue;
    }
    onChange && onChange({ ...newValue, select: newValue.select });
  };
  const handleCountry = (code) => {
    const country = countrys.find((item) => item.code.toString() === code.toString());
    handleChange({ select: country });
  };

  return (
    <InputPhoneContainer ref={groupRef}>
      <InputUI
        {...props}
        value={value.input}
        prefix={
          countrys.length === 1 ? (
            <span className="county-code-span">&nbsp;+{countrys?.[0]?.code}&nbsp;&nbsp;</span>
          ) : (
            <SelectUI
              getPopupContainer={() => groupRef.current}
              value={value?.select ? value?.select.code : countrys?.[0]?.code}
              onChange={(v) => handleCountry(v)}
              renderFormat={(option) => <span className="county-code-span">+{option?.value}</span>}
              disabled={disabled}
            >
              {countrys.map((item) => (
                <Select.Option key={item.code} value={item.code}>
                  <span>+{item.code}</span>
                  <span>{item.en}</span>
                </Select.Option>
              ))}
            </SelectUI>
          )
        }
        onChange={(v) => {
          handleChange({ ...value, input: v || undefined });
        }}
        disabled={disabled}
      ></InputUI>
    </InputPhoneContainer>
  );
};

export default InputPhonePlus;

﻿import React, { useEffect, useRef, useState } from 'react';
import { Select } from '@arco-design/web-react';
import CountrysJson from '@/assets/country-code.json';
import { InputPhoneContainer } from './indexEle';
import InputUI from '@/componentsUI/Input';
import { useBeforeSetting } from '@/store/beforeSetting';
import SelectUI from '@/componentsUI/Select';
import omit from '@/Core/utils/omit';


const EmailList = ['@gmail.com', '@outlook.com', '@yahoo.com', '@aol.com', '@zoho.com', '@icloud.com', '@mail.com', '@inbox.com'];

const reg = /@(gmail|outlook|yahoo|aol|zoho|icloud|mail|inbox)\.(com)$/;


const handlerAutoComp = function (inputStr) {
    if (reg.test(inputStr)) {
        return [];
    }
    if(!inputStr) {
        return [];
      }

    const outString = [];
    let exgStr = '';
    let str1 = '';
    const splitStr = inputStr?.split('@');
    if (splitStr.length === 2) {
        exgStr = '@' + splitStr[1];
        str1 = splitStr[0];
    } else {
        str1 = inputStr;
    }
    if (exgStr == '') {
        EmailList.forEach((value) => {
            outString.push(str1 + value);
        });
    } else {
        EmailList.forEach((value) => {
            if (value.indexOf(exgStr) == 0) {
                outString.push(str1 + value);
            }
        });
    }
    if (outString?.length === 1) {
        let flag = false;
        for (let i = 0; i < EmailList.length; ++i) {
            if (exgStr === EmailList[i]) {
                flag = true;
                break;
            }
        }
        flag && (outString.length = 0);
    }
    return outString;
};
/**筛选国码 */
const filterCountryJson = (countryJson: any[], countryCodes: any[]) => {
    const filteredCountryJson = countryJson.filter((item) => countryCodes.includes(parseInt(item.code.replace('+', ''))));
    filteredCountryJson.sort((a, b) => {
        const codeA = parseInt(a.code.replace('+', ''));
        const codeB = parseInt(b.code.replace('+', ''));
        return countryCodes.indexOf(codeA) - countryCodes.indexOf(codeB);
    });

    const formattedResult = filteredCountryJson.map((item) => ({
        ...item,
        code: parseInt(item.code.replace('+', '')),
        mask: item.mask,
    }));

    return formattedResult;
};

const InputLoginPlus = (props) => {
    const { value = {}, onChange, disabled, module , onChangeBefore } = props;
    const other = omit(props,['onChangeBefore'])
    const { data } = useBeforeSetting();
    const [countrys, setCountrys] = useState([]);
    //匹配国码
    useEffect(() => {
        if(module === 0){
            let filterCountry;
            if (data && data?.countryCodes?.length) {
                filterCountry = filterCountryJson(CountrysJson, data.countryCodes);
            } else {
                filterCountry = filterCountryJson(CountrysJson, [55]);
            }
            setCountrys(filterCountry);
            handleChange({ ...value, select: filterCountry[0] });
        }
    }, [data,module]);

    const groupRef = useRef(null);
    const handleChange = (newValue) => {
        // if (newValue?.input) {
        //     const numericValue = newValue.input.replace(/\D/g, '');
        //     newValue.input = numericValue;
        // }
        onChange && onChange({ ...newValue, select: newValue.select });
    };
    const handleCountry = (code) => {
        const country = countrys.find((item) => item.code.toString() === code.toString());
        handleChange({ select: country });
    };

    const [emails, setEmails] = useState([]);

    useEffect(() => {
        if (module === 1) {
            if (value) {
                setEmails([...handlerAutoComp(value?.input)]);
            } else {
                setEmails([]);
            }
        }
    }, [value, module]);

    const handleClickInput = (v: string) => {
        onChange && onChange({ ...value, input: v });
    };

    const inputRef = useRef(null);

    const initRef = useRef(false);

    useEffect(()=>{
        if(initRef.current) {
            inputRef.current.triggreBlur();
            setTimeout(()=>{
                inputRef.current.triggerFocus();
            },0)
        }else {
            initRef.current = true;
        }
    },[module])



    return (
        <InputPhoneContainer ref={groupRef}>
            <InputUI
                {...other}
                value={value.input}
                className={module === 0 ? '' : 'no-prefix'}
                prefix={
                    module === 0 ? countrys.length === 1 ? (
                        <span className="county-code-span">&nbsp;+{countrys?.[0]?.code}&nbsp;&nbsp;</span>
                    ) : (
                        <SelectUI
                            getPopupContainer={() => groupRef.current}
                            value={value?.select ? value?.select.code : countrys?.[0]?.code}
                            onChange={(v) => handleCountry(v)}
                            renderFormat={(option) => <span className="county-code-span">+{option?.value}</span>}
                            disabled={disabled}
                        >
                            {countrys.map((item) => (
                                <Select.Option key={item.code} value={item.code}>
                                    <span>+{item.code}</span>
                                    <span>{item.en}</span>
                                </Select.Option>
                            ))}
                        </SelectUI>
                    ) : <div></div>
                }
                onChange={(v) => {
                    onChangeBefore && onChangeBefore(v)
                    handleChange({ ...value, input: v || undefined });
                }}
                disabled={disabled}
                dataList={module === 1 && emails}
                onClickDropData={module === 1 && handleClickInput}
                ref={inputRef}
            ></InputUI>
        </InputPhoneContainer>
    );
};

export default InputLoginPlus;

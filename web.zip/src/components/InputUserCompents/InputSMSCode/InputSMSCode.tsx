import ButtonUI from '@/componentsUI/Button';
import InputUI from '@/componentsUI/Input';
import React, { forwardRef, useImperativeHandle } from 'react';
import useCountDown from '@/utils/useSmsCountDown';
import omit from '@/Core/utils/omit';
import { useTranslationPlus } from '@/Core/i18n/useTranslationPlus';
import LoadingSuperPlusUI from '@/componentsUI/LoadingSuperPlusUI/LoadingSuperPlusUI';

const InputSMSCode = (props, ref) => {
  const { sendSmsCode, disabled } = props;
  const { t } = useTranslationPlus('UserInput');
  const { secounds, start } = useCountDown('sendSmsCode');
  const prefixCls = 'arco-input-sms-code';

  const other = omit(props, ['sendSmsCode']);

  useImperativeHandle(ref, () => {
    return {
      start,
    };
  });

  return (
    <div className={`${prefixCls}`}>
      <InputUI {...other} />
      <ButtonUI type={'primary'} className={`${prefixCls}-smsSend`} onClick={sendSmsCode} disabled={!!secounds}>
        <span>
          {disabled ? (
            <LoadingSuperPlusUI extraStyle={'SpinExtraStyle'} style={{ backgroundColor: 'transparent' }} dataList={[1]} loading={true} />
          ) : (
            <span> {!!secounds ? `${t('SmsCode-5')}(${secounds}s)` : t('SmsCode-4')}</span>
          )}
        </span>
      </ButtonUI>
    </div>
  );
};

export default forwardRef(InputSMSCode);

import './style/index.less'
import InputSMSCode from './InputSMSCode'

export default InputSMSCode
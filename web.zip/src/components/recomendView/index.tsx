import React, { useEffect, useState } from 'react';
import ListView from "@/components/listView";
import { Ycyx } from "@/assets/svg-icon";
import { useNavigate } from "react-router";
import { useTranslationPlus } from "@/Core/i18n/useTranslationPlus";
import { useRecommendListPlus } from "@/store/game";
import { useGlobalOpenSearch } from '@/store/commonStore';
import { IFGameItem } from '@/api/apiRsp/IFGameTypeRsp';
import LoadingUI from '@/componentsUI/LoadingUI/LoadingUI';

/**
 * 作者: nick
 * 时间: 2023/6/10
 * 说明: 组件index
 */

const RecomendView = () => {
    const { t } = useTranslationPlus("HomeView")
    const [, setCloseSearch] = useGlobalOpenSearch();
    const navigate = useNavigate();

    const { data, isLoading, error, mutate } = useRecommendListPlus(9, 1)
    const [gameList, setGameList] = useState<IFGameItem[]>(data?.list || [])
    const [pageLoading, setPageLoading] = useState(isLoading);

    useEffect(()=>{
        if(data && data.page === 1) {
            setGameList(data.list)
            setPageLoading(false)
        }
    },[data])

    function listViewRightClick() {
        setCloseSearch(false);
        navigate('/recommendList')
    }

    return (

        <LoadingUI
            isLoading={pageLoading}
            dataList={gameList}
            error={error}
            retryFunc={mutate}
            style={{height: '150px'}}
        >
            <div className='web2-fadein'>
                {
                    <div className={"search-recommend-view"}>
                        <ListView list={gameList} icon={<Ycyx className={'arco-icon'} />}
                            title={t("Recommend")} rightBtnTitle={t("viewAll")}
                            minHeight={150} hideRightBtn={false}
                            rightClick={listViewRightClick}
                            refresh={true}
                        />
                    </div>
                }
            </div>
        </LoadingUI>

    )
};

export default React.memo(RecomendView);

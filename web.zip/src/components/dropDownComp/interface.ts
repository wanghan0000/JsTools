
export interface InputPasswordProps {
    className?: string ;
    /**
     * none 时 则隐藏title
     * 默认值 I18Key.key1
     */
    title?:I18Key | 'none',
    /**
     * none 时 则隐藏holder
     * 默认值 I18Key.key2
     */
    placeHolder?:I18Key | 'none',
    /**
     * none 时 则隐藏error不触发 
     * 默认值 I18Key.key3
     */
    error?:I18Key | 'none',
    /**
     * none 时 则不校验 
     * 默认值 VerifyRule.rule1
     */
    rule?:VerifyRule | 'none',
      /**
     * 是否禁用输入
     */
      disabled?: boolean,
}

export interface InputPasswordRef {
    /**
     * 数据
     */
    value: string;
    /**
     * 校验状态 false 失败 true 成功
     */
    status: ()=>boolean;
}

/**
 * 校验规则
 */
export enum VerifyRule {
    /**
     * 规则1 校验
     */
    rule1 = '[a-zA-Z0-9_]{6,20}'
}

export enum I18Key {
    /**
     * User name 6-20
     */
    key1 = 'Password-1',
    /**
     * User name
     */
    key2 = 'Password-2',
    /**
     * Please enter 6-20 letters beginning characters, only letters, numbers, and declines can be entered.
     */
    key3 = 'Password-3'
}
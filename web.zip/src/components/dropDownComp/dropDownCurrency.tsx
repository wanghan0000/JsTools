import mergeProps from '@/utils/mergeProps';
import { Input, Trigger, Typography } from '@arco-design/web-react';
import React, { forwardRef, useImperativeHandle, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { I18Key, InputPasswordProps, VerifyRule } from './interface';

const defaultProps: InputPasswordProps = {
    title: I18Key.key1,
    placeHolder: I18Key.key2,
    error: I18Key.key3,
    rule: VerifyRule.rule1,
};

type Status = 'error' | 'warning' | undefined;

const InputPassword = (baseProps: InputPasswordProps, ref) => {

    const props = mergeProps(baseProps, defaultProps);
    const { title, placeHolder, error, rule , className, disabled } = props;
    const { t } = useTranslation();
    const [inputValue, setInputValue] = useState('');
    const [status, setStatus] = useState<Status>();

    const prefixCls = 'jokerma-InputPassword';

    const verif = () => {
        if(rule !== 'none'){
            const flag = new RegExp(rule).test(inputValue);
            setStatus(flag ? undefined : 'error')
        }
    };

    const getStatus = ()=>{
        verif()
        return status === undefined && !!inputValue?.length
    }


    useImperativeHandle(ref, () => {
        return {
            value: inputValue,
            status: getStatus,
        };
    });

    return (
        <div className={className} ref={ref}>
            {title !== 'none' && 
            <Typography.Text className={`${prefixCls}-title`}>
                {t(title)}
            </Typography.Text>}
            <div className={`${prefixCls}-input`}>
                <Trigger
                    popup={() => (<div></div>)}
                    trigger={'focus'}
                    onVisibleChange={(visible) => {
                        if(!visible){
                            verif()
                        }
                    }}
                >
                    <Input.Password
                        disabled={disabled}
                        defaultVisibility={false}
                        placeholder={placeHolder !== 'none' ? t(props.placeHolder) : ''}
                        status={status}
                        maxLength={20}
                        value={inputValue}
                        onChange={(v) => { setInputValue(v) }}
                    />
                </Trigger>
            </div>

            {error !== 'none' && (status === 'error' || status === 'warning') && (
                <Typography.Text className={`${prefixCls}-error`}>{t(error)}</Typography.Text>
            )}
        </div>
    );
};

export default forwardRef(InputPassword);

import './styles/listItem.less'
import React, { forwardRef, useEffect, useState } from 'react';
import { Message } from "@arco-design/web-react";
import { IFGameItem } from "@/api/apiRsp/IFHomeRsp";
import useDialogManager from "@/utils/useDialogManager";
import { IconJqqd, IconWhz, SvgPlay } from "@/assets/svg-icon";
import { useLocation, useNavigate } from "react-router"
import { useTranslationPlus } from "@/Core/i18n/useTranslationPlus";
import { useGlobalCurrentWallet, useGlobalGameMobileDraw, useGlobalOpenSearch, useGlobalState } from "@/store/commonStore";
import NiceModal from '@ebay/nice-modal-react'
import CommonPopup from "@/pages/commonPopup";
import { covertTranslationImagePath } from '@/Core/utils';
import { useBeforeSetting } from '@/store/beforeSetting';
import GameImageLoad from '@/pages/home/components/gameImageLoad/GameImageLoad';
import useScreenDesign from '@/Core/utils/hooks/useScreenDesign';

interface ItemProps {
    data?: IFGameItem,
    onClick?: () => void;
    refresh?: boolean;
}

/**
 * 作者: nick
 * 时间: 2023/5/9
 * 说明: ***
 */

const ListItem = (Props: ItemProps, ref) => {
    const data = Props.data;
    const refresh = Props.refresh
    const navigate = useNavigate()
    const location = useLocation();
    const { isLogin } = useGlobalState()
    const { openSignIn, openWallet,openFunPage } = useDialogManager();
    const { t } = useTranslationPlus("ApiGame")
    const [walletData] = useGlobalCurrentWallet()
    const [, setCloseSearch] = useGlobalOpenSearch();
    const [ setGameDraw] = useGlobalGameMobileDraw()
    const mobile = useScreenDesign();
    const { data:sitting} = useBeforeSetting()

    /**
     * 返回 boolean  true 为需要弹窗显示 fun币的游戏， false 为不需要显示fun币游戏
     */
    function checkFunGame():boolean {
        let needTip = false;
        const plats4FUN = sitting.plats4FUN;
        const lockCurrency = sitting.lockCurrency;
        // 当前限制的fun币的游戏配置判断-- 当前货币为FUN时
        if(walletData?.currencyType === lockCurrency){
            needTip = true;
            if(sitting && plats4FUN && plats4FUN.length){
                for (let i = 0; i < plats4FUN.length; i++) {
                    if(plats4FUN[i] === data.platformCode) {
                        needTip = false
                    }
                }
            }
        }
        return needTip
    }

    const onClick = () => {
        if (!isLogin) {
            openSignIn();
            return
        }

        if (data.status == 3) {
            Message.info(t('GameStatusTip3'));
            return;
        }
        if (data.status == 4) {
            Message.info(t('GameStatusTip4'));
            return;
        }

        if(checkFunGame()) {
            openFunPage()
            return;
        }

        if (walletData?.allBalance >= data.goldRequire) {
            setCloseSearch(false)
            if (mobile) {
                setGameDraw({ gameId: data?.id });
            } else {
                navigate('/game/' + data.id, { state: { refresh: refresh } })
            }
            if (location.pathname.indexOf('game') != -1) {
                const ele = document.getElementById("game-container")
                ele && ele.scrollIntoView()
            }
        } else {
            NiceModal.show(CommonPopup, {
                ontentText: t('CanNotMoney'),
                rightBtnText: t('GameOriginal.Confirm'),
                rightCallback: ({ remove }) => {
                    remove()
                    openWallet()
                }
            })
        }
    }

    return (
        <div ref={ref} className={"game-item"} onClick={onClick}>
            <div className={"def-item--parent"} >
                <div className={'game-image-default'} />

                <GameImageLoad
                    src={covertTranslationImagePath(data?.id)}
                />

                {data && data.status == 4 &&
                    <div className={"def-item-jqqd"}>
                        <IconJqqd />
                        <span>{t('GameStatus4')}</span>
                    </div>
                }
                {data && data.status == 3 &&
                    <div className={"def-item-whz"}>
                        <IconWhz />
                        <span>{t('GameStatus3')}</span>
                    </div>
                }
                {(data && data.status != 3 && data.status != 4) &&
                    <div className={"def-item-hover"}>
                        <div className={"def-item-hover-bg"}></div>
                        <div className={"def-item-content"}>
                            <SvgPlay />
                        </div>
                    </div>
                }
            </div>
        </div>
    )
};

export default forwardRef(ListItem);

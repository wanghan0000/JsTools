import './index.less';
import { IconSc } from '@/pages/GameOriginal/Common/assets/icon';
import React from 'react';

const CollectButton = (props) => {
  const { isCollect, onClick } = props;

  return (
    <>
      <IconSc
        onClick={onClick}
        style={{
          color: isCollect ? 'var(--color-text-6coin)' : 'var(--color-bg-13)',
          width: '25px',
          height: '25px',
        }}
      />
    </>
  );
};

export default CollectButton;

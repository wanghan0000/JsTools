import React, { CSSProperties, useEffect, useState } from 'react';
import classNames from 'classnames';
import QRCode from 'qrcode';

interface IProps {
  className?: string;
  style?: CSSProperties;
  url?: any;
}

/** 二维码组件 */
const QrCodeCompoent = ({ url, style, className }: IProps) => {
  const [imagePath, setImagePath] = useState('');
  useEffect(() => {
    if (url) {
      QRCode.toDataURL(url).then((path) => {
        setImagePath(path);
      });
    }
  }, [url]);

  return (
    <div className={classNames(['mt-qrcode', className])} style={style}>
      <img style={{ width: '100%', height: '100%', display: 'block' }} src={imagePath}></img>
    </div>
  );
};

export default QrCodeCompoent;

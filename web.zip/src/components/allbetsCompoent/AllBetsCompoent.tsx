import './index.less'
import ButtonUI from "@/componentsUI/Button";
import { useTranslationPlus } from "@/Core/i18n/useTranslationPlus";
import { debounce, timeStampToDateDay } from "@/Core/utils";
import { numberDivisor, numberFixed, toLocaleString } from "@/Core/utils/currencyDealCenter";
import useScreenDesign, { screenType } from "@/Core/utils/hooks/useScreenDesign";
import { Table, TableColumnProps } from "@arco-design/web-react";
import classNames from "classnames";
import React, { useEffect, useRef, useState } from "react";
import CurrencyCompoent from "../currencyCompoent";

const AllBetsCompoent = (props) => {

    const { onClickItem, betData = [], style ,original = false} = props

    const { t } = useTranslationPlus('GameOriginal')
    const { t: thome } = useTranslationPlus('HomeView')

    const [domWidth, setDomWidth] = useState(0)
    const [showMore, setShowMore] = useState<boolean>(false)
    const domRef = useRef(null)
    const updateDow = debounce(() => {
        if (domRef && domRef.current) {
            setDomWidth(domRef.current?.clientWidth)
        }
    }, 300)
    const mobile = useScreenDesign(screenType.mobile, '<=', () => {
        updateDow()
    })
    useEffect(() => {
        setDomWidth(domRef.current?.clientWidth)
    }, [domRef])

    const columns: TableColumnProps[] = [
        {
            title: t('User'),
            headerCellStyle: { width: domWidth * (mobile ? 0.22 : 0.15) },
            bodyCellStyle: { width: domWidth * (mobile ? 0.22 : 0.15) },
            dataIndex: 'userName',
            render: (_col, item) => (
                <div style={{ width: domWidth * (mobile ? 0.22 : 0.15) }} onClick={() => { onClickItem(item) }}>
                    <div
                        style={{ paddingLeft: 5 }}
                    >{item.userName}</div>
                </div>
            )
        },
        {
            title: t('BetId'),
            headerCellStyle: { width: domWidth * (mobile ? 0.30 : 0.35) },
            bodyCellStyle: { width: domWidth * (mobile ? 0.30 : 0.35) },
            dataIndex: 'betId',
            render: (_col, item) => (
                <div style={{ width: domWidth * (mobile ? 0.30 : 0.35) }} onClick={() => { onClickItem(item) }}>
                    {item.betId}
                </div>
            )
        },
        {
            title: t('Time'),
            headerCellStyle: { width: domWidth * 0.2 },
            bodyCellStyle: { width: domWidth * 0.2 },
            dataIndex: 'betTime',
            render: (col, item) => (
                <div
                    onClick={() => { onClickItem(item) }}
                    style={{ width: domWidth * 0.2 }}>
                    {timeStampToDateDay(item.betTime)}</div>
            )
        },
        {
            title: t('Payout'),
            headerCellStyle: { width: domWidth * (mobile ? 0.175 : 0.10) },
            bodyCellStyle: { width: domWidth * (mobile ? 0.175 : 0.10) },
            dataIndex: 'payout',
            render: (col, item) => (
                <div style={{ width: domWidth * (mobile ? 0.175 : 0.10) }} onClick={() => { onClickItem(item) }}>
                    {item?.winAmount > 0 ? numberFixed(numberDivisor(
                        original ?  item?.winAmount + item?.betAmount : item?.winAmount,
                     item?.betAmount), 2) + 'x' : `${toLocaleString('0.00')}x`}
                </div>
            )
        },
        {
            title: t('Win'),
            headerCellStyle: { width: domWidth * (mobile ? 0.30 : 0.2) },
            bodyCellStyle: { width: domWidth * (mobile ? 0.30 : 0.2) },
            dataIndex: 'betAmount',
            render: (col, item) => (
                <div style={{ width: domWidth * (mobile ? 0.30 : 0.2) }} onClick={() => { onClickItem(item) }}>
                    <div style={{ paddingRight: 0 }}>
                        <CurrencyCompoent
                            className={classNames(["all-bets-currency-compoent", item?.winAmount >= 0 ? 'win' : 'lose'])}
                            iconPosition={'rt'}
                            amount={item?.winAmount}
                            showUnit={false}
                            type={'valid9'}
                            currencyType={item?.currencyType}
                        />
                    </div>

                </div>
            )
        }
    ]

    const prefixCls = 'game-all-bets-compoents';

    return (<div ref={domRef} className={`${prefixCls} web2-fadein`}>
        <Table style={style} columns={
            mobile ? columns.filter((v) => { return v.dataIndex !== 'betTime' }) :
                columns
        } data={
            showMore ? betData.slice(0, betData?.length > 30 ? 30 : betData?.length) :
                betData.slice(0, betData?.length > 10 ? 10 : betData?.length)
        } pagination={false}
            noDataElement={
                thome('NoData')
            }
        rowKey={'betId'}
        ></Table>
        {
            betData?.length > 10 &&
            <div className={'btn-more'}>
                <ButtonUI
                    type={'primary'}
                    buttonColor={'secondary'}
                    style={style}
                    onClick={() => { setShowMore(!showMore) }}>{
                        showMore ? t('ShowLess') : t('ShowMore')
                    }</ButtonUI>
            </div>
        }
    </div>)
}


export default AllBetsCompoent
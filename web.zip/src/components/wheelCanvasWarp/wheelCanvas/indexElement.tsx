import { styled } from 'styled-components';

import arrow1 from './img/whell_arrow.webp';
import arrow2 from './img/whell_arrow_face.webp';
import eye1 from './img/whell_arrow_eye.webp';
import eye2 from './img/whell_arrow_eye2.webp';

export const WheelWarper = styled.div`
  width: 100%;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 65px;
  @media screen and (max-width: 621px) {
    margin-top: 20px;
  }
`;

export const Arrows = styled.div`
  position: absolute;
  top: -20px;
  width: 58px;
  height: 79px;
  background: url(${arrow1}) no-repeat top left;
  background-size: 100% auto;
  &::before {
    content: '';
    width: 57px;
    height: 57px;
    position: absolute;
    top: 0;
    left: 50%;
    transform: translateX(-50%);
    background: url(${arrow2}) no-repeat center / 100% 100%;
    z-index: 2;
  }
  &::after {
    content: '';
    width: 40px;
    height: 40px;
    position: absolute;
    top: 14px;
    left: 54%;
    transform: translateX(-50%);
    background-color: rgba(0, 0, 0, 0.5);
    border-radius: 50%;
    z-index: 1;
  }
  @media screen and (max-width: 621px) {
    transform: scale(0.9);
  }
`;

export const EyeLeft = styled.div`
  width: 25px;
  height: 25px;
  position: absolute;
  top: 13px;
  left: 6px;
  background: url(${eye1}) no-repeat top left / 100% 100%;
  transform: rotate(-20deg);
  z-index: 3;
  &::before {
    content: '';
    position: absolute;
    bottom: 3px;
    right: 3px;
    width: 9px;
    height: 9px;
    background: url(${eye2}) no-repeat top left;
    background-size: 100% 100%;
  }
`;

export const EyeRight = styled.div`
  width: 25px;
  height: 25px;
  position: absolute;
  top: 13px;
  right: 6px;
  background: url(${eye1}) no-repeat top right / 100% 100%;
  z-index: 3;
  &::before {
    content: '';
    position: absolute;
    top: 9px;
    left: 2px;
    width: 9px;
    height: 9px;
    background: url(${eye2}) no-repeat top left;
    background-size: 100% 100%;
  }
`;

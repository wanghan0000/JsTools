// export const High = [
//   {
//     id: 0,
//     odds: 0,
//   },
//   {
//     id: 1,
//     odds: 0,
//   },
//   {
//     id: 2,
//     odds: 0,
//   },
//   {
//     id: 3,
//     odds: 0,
//   },
//   {
//     id: 4,
//     odds: 0,
//   },
//   {
//     id: 5,
//     odds: 0,
//   },
//   {
//     id: 6,
//     odds: 0,
//   },
//   {
//     id: 7,
//     odds: 0,
//   },
//   {
//     id: 8,
//     odds: 0,
//   },
//   {
//     id: 9,
//     odds: 9.9,
//   },
// ];

export const High = [];
for (let i = 0; i < 10; i++) {
  if (i === 9) {
    High[i] = { id: i, odds: 9.9 };
    break;
  }
  High[i] = { id: i, odds: 0 };
}

export const HighColor = {
  0: '#f6fbff',
  9.9: '#3c7eff',
};

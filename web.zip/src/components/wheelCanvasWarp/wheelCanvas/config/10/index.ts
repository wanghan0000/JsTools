import { High, HighColor } from './High';
import { Low, LowColor } from './Low';
import { Medium, MediumColor } from './Medium';
import { handlerData } from '../utils/index';

const Low10 = handlerData(Low, LowColor);
const Medium10 = handlerData(Medium, MediumColor);
const High10 = handlerData(High, HighColor);

export { Low10, Medium10, High10 };

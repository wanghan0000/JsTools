// export const Low = [
//   {
//     id: 0,
//     odds: 1.5,
//   },
//   {
//     id: 1,
//     odds: 1.2,
//   },
//   {
//     id: 2,
//     odds: 1.2,
//   },
//   {
//     id: 3,
//     odds: 1.2,
//   },
//   {
//     id: 4,
//     odds: 0,
//   },
//   {
//     id: 5,
//     odds: 1.2,
//   },
//   {
//     id: 6,
//     odds: 1.2,
//   },
//   {
//     id: 7,
//     odds: 1.2,
//   },
//   {
//     id: 8,
//     odds: 1.2,
//   },
//   {
//     id: 9,
//     odds: 0,
//   },
// ];

export const Low = [];

for (let i = 0; i < 10; i++) {
  let odds = (i + 1) % 5 === 0 ? 0 : 1.2;
  const id = i;
  if (i % 10 === 0) {
    odds = 1.5;
  }
  Low.push({ odds, id });
}

export const LowColor = {
  0: '#ffffff',
  1.2: '#3c7eff',
  1.5: '#1db440',
};

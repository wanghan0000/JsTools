export const Medium = [
  {
    id: 0,
    odds: 0,
  },
  {
    id: 1,
    odds: 1.5,
  },
  {
    id: 2,
    odds: 0,
  },
  {
    id: 3,
    odds: 1.5,
  },
  {
    id: 4,
    odds: 0,
  },
  {
    id: 5,
    odds: 1.9,
  },
  {
    id: 6,
    odds: 0,
  },
  {
    id: 7,
    odds: 2,
  },
  {
    id: 8,
    odds: 0,
  },
  {
    id: 9,
    odds: 3,
  },
];
export const MediumColor = {
  0: '#ffffff',
  1.5: '#3c7eff',
  1.9: '#1db440',
  2: '#ffa800',
  3: '#d940ff',
};

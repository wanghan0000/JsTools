import { Low10, Medium10, High10 } from './10';
import { Low20, Medium20, High20 } from './20';
import { Low30, Medium30, High30 } from './30';
import { Low40, Medium40, High40 } from './40';
import { Low50, Medium50, High50 } from './50';

const segment = {
  10: { 1: Low10, 2: Medium10, 3: High10 },
  20: { 1: Low20, 2: Medium20, 3: High20 },
  30: { 1: Low30, 2: Medium30, 3: High30 },
  40: { 1: Low40, 2: Medium40, 3: High40 },
  50: { 1: Low50, 2: Medium50, 3: High50 },
};

/* 匹配数据 */
const getWheelConfig = (s: number, r: number) => {
  return segment[s][r];
};

export default getWheelConfig;

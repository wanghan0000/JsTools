import { High, HighColor } from './High';
import { Low, LowColor } from './Low';
import { Medium, MediumColor } from './Medium';
import { handlerData } from '../utils/index';

const Low40 = handlerData(Low, LowColor);
const Medium40 = handlerData(Medium, MediumColor);
const High40 = handlerData(High, HighColor);

export { Low40, Medium40, High40 };
import { High, HighColor } from './High';
import { Low, LowColor } from './Low';
import { Medium, MediumColor } from './Medium';
import { handlerData } from '../utils/index';

const Low30 = handlerData(Low, LowColor);
const Medium30 = handlerData(Medium, MediumColor);
const High30 = handlerData(High, HighColor);

export { Low30, Medium30, High30 };
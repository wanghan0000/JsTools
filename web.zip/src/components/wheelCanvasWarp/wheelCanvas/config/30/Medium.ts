export const Medium = [
  {
    id: 0,
    odds: 1.5,
  },
  {
    id: 1,
    odds: 0,
  },
  {
    id: 2,
    odds: 1.5,
  },
  {
    id: 3,
    odds: 0,
  },
  {
    id: 4,
    odds: 2,
  },
  {
    id: 5,
    odds: 0,
  },
  {
    id: 6,
    odds: 1.5,
  },
  {
    id: 7,
    odds: 0,
  },
  {
    id: 8,
    odds: 2,
  },
  {
    id: 9,
    odds: 0,
  },
  {
    id: 10,
    odds: 2,
  },
  {
    id: 11,
    odds: 0,
  },
  {
    id: 12,
    odds: 1.5,
  },
  {
    id: 13,
    odds: 0,
  },
  {
    id: 14,
    odds: 3,
  },
  {
    id: 15,
    odds: 0,
  },
  {
    id: 16,
    odds: 1.5,
  },
  {
    id: 17,
    odds: 0,
  },
  {
    id: 18,
    odds: 2,
  },
  {
    id: 19,
    odds: 0,
  },
  {
    id: 20,
    odds: 2,
  },
  {
    id: 21,
    odds: 0,
  },
  {
    id: 22,
    odds: 1.7,
  },
  {
    id: 23,
    odds: 0,
  },
  {
    id: 24,
    odds: 4,
  },
  {
    id: 25,
    odds: 0,
  },
  {
    id: 26,
    odds: 1.5,
  },
  {
    id: 27,
    odds: 0,
  },
  {
    id: 28,
    odds: 2,
  },
  {
    id: 29,
    odds: 0,
  },
];

export const MediumColor = {
  0: '#ffffff',
  1.5: '#3c7eff',
  1.7: '#1db440',
  2.0: '#ffa800',
  3: '#d940ff',
  4: '#dd2149',
};

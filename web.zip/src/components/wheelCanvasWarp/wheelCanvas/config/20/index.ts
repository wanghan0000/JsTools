import { High, HighColor } from './High';
import { Low, LowColor } from './Low';
import { Medium, MediumColor } from './Medium';
import { handlerData } from '../utils/index';


const Low20 = handlerData(Low, LowColor);
const Medium20 = handlerData(Medium, MediumColor);
const High20 = handlerData(High, HighColor);

export { Low20, Medium20, High20 };

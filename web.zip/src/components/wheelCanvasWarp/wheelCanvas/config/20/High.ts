// export let High = [
//   {
//     id: 0,
//     odds: 0,
//   },
//   {
//     id: 1,
//     odds: 0,
//   },
//   {
//     id: 2,
//     odds: 0,
//   },
//   {
//     id: 3,
//     odds: 0,
//   },
//   {
//     id: 4,
//     odds: 0,
//   },
//   {
//     id: 5,
//     odds: 0,
//   },
//   {
//     id: 6,
//     odds: 0,
//   },
//   {
//     id: 7,
//     odds: 0,
//   },
//   {
//     id: 8,
//     odds: 0,
//   },
//   {
//     id: 9,
//     odds: 0,
//   },
//   {
//     id: 10,
//     odds: 0,
//   },
//   {
//     id: 11,
//     odds: 0,
//   },
//   {
//     id: 12,
//     odds: 0,
//   },
//   {
//     id: 13,
//     odds: 0,
//   },
//   {
//     id: 14,
//     odds: 0,
//   },
//   {
//     id: 15,
//     odds: 0,
//   },
//   {
//     id: 16,
//     odds: 0,
//   },
//   {
//     id: 17,
//     odds: 0,
//   },
//   {
//     id: 18,
//     odds: 0,
//   },
//   {
//     id: 19,
//     odds: 19.8,
//   },
// ];

export const High = [];

for (let i = 0; i < 20; i++) {
  if (i === 19) {
    High[i] = { id: i, odds: 19.8 };
    break;
  }
  High[i] = { id: i, odds: 0 };
}
export const HighColor = {
  0: '#ffffff',
  19.8: '#dd2149',
};

import { High, HighColor } from './High';
import { Low, LowColor } from './Low';
import { Medium, MediumColor } from './Medium';
import { handlerData } from '../utils/index';

const Low50 = handlerData(Low, LowColor);
const Medium50 = handlerData(Medium, MediumColor);
const High50 = handlerData(High, HighColor);

export { Low50, Medium50, High50 };
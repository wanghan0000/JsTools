/* 处理初始化数据 */
export function handlerData(data, color) {
  const initData = {
    wheel: null,
    result: [],
  };
  initData.wheel = data.map(({ odds, id }, index) => ({
    id,
    odds,
    borderColor: color[odds],
    // background: index % 2 === 0 ? '#24262b' : '#1e1f24',
    // borderWidth: 16,
    // borderWidthPD: 8,
  }));

  const arr = Object.entries(color).map(([odds, bg]) => ({ odds: Number(odds), bg }));

  arr.sort((a, b) => {
    return a.odds - b.odds;
  });

  initData.result = arr;
  return initData;
}

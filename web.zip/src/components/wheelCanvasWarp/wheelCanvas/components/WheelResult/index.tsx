import React, { useState } from 'react';
import { ResultWarper, Item, List, DetailPanel } from './indexElement';
import { dealNumberValid, getCurrencyImagePath } from '@/Core/utils/currencyDealCenter';
import { useGlobalCurrentWallet } from '@/store/commonStore';
import { useTranslationPlus } from '@/Core/i18n/useTranslationPlus';

const WheelResultElement = (props) => {
  const { segment, resultData, prizes, formData } = props;

  const [visible, setVisible] = useState(false); // 详情
  const [arrDown, setArrDown] = useState<number | string>(); // 箭头位置
  const [details, setDetail] = useState({
    quantity: 0,
    winAmount: '',
  }); // 详情内容

  const { t } = useTranslationPlus('wheelResult');

  const [data] = useGlobalCurrentWallet();

  /* 处理气泡弹窗数据 */
  const handleMouseEnter = (odds, bg, index, event) => {
    const filter = prizes.filter((item) => item.odds === odds).length;
    setDetail({ ...details, quantity: filter, winAmount: dealNumberValid(Number(odds * formData.amount)) });
    setVisible(true);

    /* 计算小三角的位置    */
    const width = event.target.offsetWidth;
    const totalWidth = event.target.offsetWidth * resultData.length;
    const position = ((width * index + width / 2) / totalWidth) * 100;
    setArrDown(position);
  };

  const handleMouseLeave = () => {
    setVisible(false);
  };
  return (
    <ResultWarper>
      <List>
        <DetailPanel data-left={arrDown} style={{ display: visible ? 'block' : 'none' }}>
          <div className="details">
            <div className="left">
              <div className="title">
                <span>{t('WinAmount')}</span>
                {/* <div>0 {data?.currencyType}</div> */}
              </div>
              <div className="input">
                <span>
                  <img
                    style={{ width: '15px', height: '15px', marginRight: '5px', verticalAlign: '-1px' }}
                    src={getCurrencyImagePath(data?.currencyType)}
                    alt=""
                  />
                </span>
                <span>{details.winAmount}</span>
              </div>
            </div>
            <div className="right">
              <div className="title">{t('Change')}</div>
              <div className="input">
                {details.quantity}/{segment}
              </div>
            </div>
          </div>
          <div className="arrDown"></div>
        </DetailPanel>
        {resultData?.map(({ odds, bg }, index) => (
          <Item key={index} onMouseEnter={(event) => handleMouseEnter(odds, bg, index, event)} onMouseLeave={handleMouseLeave}>
            <div className="bg" style={{ backgroundColor: bg }}></div>
            <div className="text">{Number(odds).toFixed(2)}x</div>
          </Item>
        ))}
      </List>
    </ResultWarper>
  );
};

export default WheelResultElement;

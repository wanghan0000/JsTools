import { styled } from 'styled-components';

export const ResultWarper = styled.div`
  width: 100%;
  margin-top: 10px;
  margin-bottom: 50px;
  box-sizing: border-box;
  padding: 0 10px;
`;

export const List = styled.div`
  display: flex;
  max-width: 60%;
  margin: 0 auto;
  position: relative;
  @media screen and (max-width: 621px) {
    max-width: 100%;
  }
`;

export const Item = styled.div`
  height: 47px;
  flex: 1;
  background-color: var(--color-bg-9);
  margin: 0px 1px;
  border-radius: 2px;
  position: relative;
  &:hover {
    :nth-child(1) {
      top: 0;
    }
  }
  .bg {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    top: 82%;
    transition: top 0.3s;
  }
  .text {
    width: 100%;
    height: 100%;
    position: relative;
    z-index: 2;
    text-align: center;
    line-height: 47px;
    font-size: 18px;
    color: var(--color-text-1);
    text-shadow: 1px 1px 4px #000000;
    @media screen and (max-width: 621px) {
      font-size: 14px;
      line-height: 36px;
    }
  }
  @media screen and (max-width: 621px) {
    height: 36px;
  }
`;

export const DetailPanel = styled.div`
  width: 100%;
  height: 90px;
  background-color: var(--color-bg-1);
  position: absolute;
  top: 0;
  left: 0;
  transform: translateY(-112%);
  box-sizing: border-box;
  padding: 10px;

  .details {
    width: 100%;
    height: 100%;
    display: flex;
    column-gap: 10px;
    color: var(--color-text-1);
    font-size: 12px;
    .left {
      flex: 1;
      display: flex;
      flex-direction: column;
      .title {
        width: 100%;
        box-sizing: border-box;
        padding: 0 10px;
        margin-bottom: 6px;
        display: flex;
        justify-content: space-between;
        height: 25px;
        word-break: break-all;
      }
      .input {
        text-align: left;
        padding: 0 10px;
        box-sizing: border-box;
        line-height: 42px;
        width: 100%;
        background-color: var(--color-bg-3);
        height: 42px;
        border-radius: 2px;
        font-size: 16px;
        font-weight: 700;
      }
    }

    .right {
      flex: 1;
      display: flex;
      flex-direction: column;
      .title {
        width: 100%;
        box-sizing: border-box;
        padding: 0 10px;
        margin-bottom: 6px;
        height: 25px;
      }
      .input {
        text-align: left;
        padding: 0 10px;
        box-sizing: border-box;
        line-height: 42px;
        width: 100%;
        background-color: var(--color-bg-3);
        height: 42px;
        border-radius: 2px;
        font-size: 16px;
        font-weight: 700;
      }
    }
  }

  .arrDown {
    /* 16.67%   50%   83.33% */
    left: ${(props) => props['data-left'] + '%'};
    position: absolute;
    bottom: 0;
    border: 10px solid transparent;
    border-top-color: var(--color-bg-1);
    transform: translateY(90%);
    margin-left: -10px;
  }
`;

import React, { useEffect, useRef, useState, useImperativeHandle, forwardRef } from 'react';
import { WheelWarper, Arrows, EyeLeft, EyeRight } from './indexElement';
import { LuckyWheel } from '@/libs/index.js';
import getWheelConfig from './config/wheelConfig';
import WheelResultElement from './components/WheelResult';
import { useGetWheelResponse } from '@/store/wheelGameOriginal';
import NiceModal from '@ebay/nice-modal-react';
import CommonPopup from '@/pages/commonPopup';
import { useNavigate } from 'react-router';
import { useCurrentGameData, useGlobalCurrentWallet, useGlobalTheme } from '@/store/commonStore';
import { AmountMultiplierConversion } from '@/Core/utils/currencyDealCenter';
import { useTranslationPlus } from '@/Core/i18n/useTranslationPlus';
import useScreenDesign from '@/Core/utils/hooks/useScreenDesign';

interface IProps {
  risk?: number;
  segment?: number;
  monitoring?: (val: any, betData: any) => void;
  uuid?: any;
}

const WheelCanvasWrap = forwardRef((props: IProps, ref) => {
  const wheelRef = useRef(null);
  // const StrDate = useRef<number>();
  const { monitoring, risk, segment, uuid } = props;

  const [currentGameData] = useCurrentGameData();

  const { id: gameId } = currentGameData;

  const navigate = useNavigate();

  const { data: betData, trigger: betTrigger } = useGetWheelResponse();

  //当前使用钱包
  const [currentWallet] = useGlobalCurrentWallet();

  /* Result列表 */
  const [Result, setResult] = useState();

  const [gameOver, setGameOver] = useState(true);

  // /* 转盘动画执行多少帧 */
  // const [FPS, setFPS] = useState(0);
  // const [blocks] = useState([{ padding: '1px', background: '#869cfa' }]);

  /* 转盘奖品配置 */
  const [prizes, setPrizes] = useState<[]>();

  // 监听主题色
  const { theme } = useGlobalTheme();

  const { t } = useTranslationPlus('GameOriginal');

  const isMobile = useScreenDesign();

  /* 转盘中间配置 */
  const buttonsRef = useRef([
    {
      radius: '33%',
      background: '#17181b',
    },
    {
      radius: '30%',
      background: '#24262b',
      fonts: [
        {
          text: '',
          fontSize: '35px',
          top: '-22',
          fontColor: '',
          fontWeight: 'bold',
        },
      ],
    },
  ]);

  const [size, setSize] = useState(420);

  /* 转盘加载完成 */
  function onSuccess() {
    console.log('success');
  }

  // /* FPS回调 */
  // function fpsCallback(fps) {
  //   setFPS(fps);
  // }

  function handleResize() {
    if (window.innerWidth > 850) {
      setSize(420);
      buttonsRef.current[1].fonts[0].fontSize = '35px';
      buttonsRef.current[1].fonts[0].top = '-22';
    }
    if (window.innerWidth < 850) {
      setSize(380);
      buttonsRef.current[1].fonts[0].fontSize = '25px';
      buttonsRef.current[1].fonts[0].top = '-15';
    }
    if (window.innerWidth < 621) {
      setSize(280);
      buttonsRef.current[1].fonts[0].fontSize = '25px';
      buttonsRef.current[1].fonts[0].top = '-15';
    }
  }

  /* 开始游戏 */
  function play({ amount, risk, segment }) {
    betTrigger(
      {
        gameId,
        betAmount: AmountMultiplierConversion(amount,{
          currencyType: currentWallet.currencyType
        }),
        currencyType: currentWallet.currencyType,
        uuid,
        risk: Number(risk),
        segment: Number(segment),
      },
      {
        timeout: 10000,
        timeOutCallback: () => {
          NiceModal.show(CommonPopup, {
            ontentText: t('GameServerAbnormal'),
            rightBtnText: t('Reconnect'),
            leftBtnText: t('BackHome'),
            leftCallback: ({ remove }) => {
              remove();
              navigate('/home');
            },
            rightCallback: ({ remove }) => {
              remove();
              wheelRef.current.init();
            },
          });
        },
      }
    ).then((res) => {
      const {
        extendInfo: { position },
      } = res;
      wheelRef.current.play();
      setGameOver(false);
      buttonsRef.current[1].fonts[0].text = '';
      stop(position);
    });
  }

  /* 停止游戏 */
  function stop(id) {
    wheelRef.current.stop(id);
  }

  /* 游戏结束回调 */
  function onEnd(val) {
    if (Object.keys(val).length) {
      buttonsRef.current[1].fonts[0].text = Number(val.odds).toFixed(2) + 'x';
      buttonsRef.current[1].fonts[0].fontColor = val.borderColor;
      monitoring(val, betData);
      setGameOver(true);
    }
  }

  useImperativeHandle(ref, () => ({
    play,
    stop,
  }));

  /* 初始化转盘数据 */
  useEffect(() => {
    if (!props) return;
    const { wheel, result } = getWheelConfig(props?.segment || 10, props?.risk || 1);
    const infoData = wheel.map(({ id, odds, borderColor }, index) => ({
      id,
      odds,
      borderColor,
      borderWidth: isMobile ? 12 : 16,
      background: theme === 'dark' ? (index % 2 === 0 ? '#3b3f49' : '#30333a') : index % 2 === 0 ? '#aaaeb9' : '#d5d9df',
      borderWidthPD: isMobile ? 6 : 8,
      borderColorPD: 'rgba(0,0,0,0.2)',
    }));
    buttonsRef.current[0].background = theme === 'dark' ? '#17181b' : '#ffffff';
    buttonsRef.current[1].background = theme === 'dark' ? '#24262b' : '#f2f3f5';
    setPrizes(infoData);
    setResult(result);
    buttonsRef.current[1].fonts[0].text = '';
  }, [risk, segment, theme, isMobile]);

  /* 设置转盘大小 */
  useEffect(() => {
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <WheelWarper>
      <LuckyWheel
        onSuccess={onSuccess}
        onEnd={onEnd}
        buttons={buttonsRef.current}
        prizes={prizes}
        // blocks={blocks}
        ref={wheelRef}
        width={size}
        height={size}
        // fpsCallback={fpsCallback}
        defaultConfig={{
          speed: 20,
          stopRange: 0.6,
          accelerationTime: 1500,
          decelerationTime: 2000,
        }}
      ></LuckyWheel>
      {/* <Arrows>&#x1F530;</Arrows> */}
      <Arrows data-status={gameOver}>
        <EyeLeft data-status={gameOver}></EyeLeft>
        <EyeRight data-status={gameOver}></EyeRight>
      </Arrows>
      <WheelResultElement formData={props} prizes={prizes} resultData={Result} segment={props.segment} risk={props.risk} />
    </WheelWarper>
  );
});

export default WheelCanvasWrap;

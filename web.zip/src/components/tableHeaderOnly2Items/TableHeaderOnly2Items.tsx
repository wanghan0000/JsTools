import './index.less'
import { Tabs } from "@arco-design/web-react";
import classNames from "classnames";
import React from "react";
const TabPane = Tabs.TabPane;

export interface TableHeaderOnly2ItemsProps {
    value?: '1' | '2' | '3',
    onChange?: (v: '1' | '2' | '3') => void,
    text1: string,
    text2: string,
    text3?: string
    className?: string
}

const TableHeaderOnly2Items = (props) => {
    const { value, onChange, text1, text2, text3, className } = props
    const prefixCls = 'table-header-only-2-items';
    const name = classNames([prefixCls, className])
    return (<Tabs className={`${name}`} activeTab={value} onChange={onChange} style={{ display: !text1 && !text2 && !text3 ? 'none' : 'block' }}>
        {text1 && <TabPane key={'1'} title={text1} >
        </TabPane>}
        {text2 && <TabPane key={'2'} title={text2} >
        </TabPane>}
        {
            text3 && <TabPane key={'3'} title={text3} >
            </TabPane>
        }
    </Tabs>)
}

export default TableHeaderOnly2Items
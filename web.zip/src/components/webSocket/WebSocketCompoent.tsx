import './style/index.less'
import { EventName } from "@/api/event/common";
import { SocketMgr } from "@/Core/net/socket/SocketMgr";
import { useBeforeSetting } from "@/store/beforeSetting";
import EventMgr from "@/utils/EventMgr";
import React, { memo, useCallback, useEffect, useRef } from "react";
import { useGlobalState } from '@/store/commonStore';

const WebSocketCompoent = () => {
    const { isLogin} = useGlobalState()
    const { data } = useBeforeSetting()
    const enterForeGround = useRef(true)
    const connectTimesRef = useRef(0);
    const connectSocket = useCallback(() => {
        if (!enterForeGround.current) {
            return
        }
        const token = localStorage.getItem('authToken') || ''
        SocketMgr.connect(data.wsAddr +'/'+ token, null, () => {
            console.log('链接断开了')
        }, () => {
            setTimeout(() => {
                retry()
            }, 1000);
        }, null, () => {
            EventMgr.getInstance().dispatchEvent(EventName.SocketRetrySuccess)
        })
        connectTimesRef.current += 1;
    }, [data, isLogin])

    const retry = useCallback(() => {
        const token = localStorage.getItem('authToken') || ''
        if (isLogin && token && data && !SocketMgr.isConnection()) {
            connectSocket()
        }
    }, [isLogin, data])

    useEffect(() => {
        const token = localStorage.getItem('authToken') || ''
        if (!isLogin || !token || !data?.wsAddr) {
        } else {
            retry()
        }
    }, [isLogin, data])


    useEffect(() => {
        EventMgr.getInstance().removeByTarget('SocketReconect')

        EventMgr.getInstance().addEventListener(EventName.EnterForeGround, () => {
            enterForeGround.current = true
            const token = localStorage.getItem('authToken') || ''
            if (isLogin && token && data) {
                if (!SocketMgr.isConnection()) {
                    connectSocket()
                }
            } else {
                SocketMgr.close()
            }
        }, 'SocketReconect')
        EventMgr.getInstance().addEventListener(EventName.EnterBackGround, () => {
            enterForeGround.current = false
        }, 'SocketReconect')
        return () => {
            EventMgr.getInstance().removeByTarget('SocketReconect')
        }
    }, [isLogin, data])

    return (<div className="socket"></div>)
}

export default memo(WebSocketCompoent)
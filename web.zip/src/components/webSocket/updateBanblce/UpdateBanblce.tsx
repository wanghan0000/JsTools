import { AmountDivisorConversion, dealAmount9Valid } from '@/Core/utils/currencyDealCenter';
import { IFWalletRsp } from '@/api/apiRsp/IFWalletRsp';
import { useGlobalWalletStore } from '@/store/commonStore';
import { useWsUpdateBanblce } from '@/store/hallSocket';
import { useWalletAll } from '@/store/walletStore';
import { Notification } from '@arco-design/web-react';
import React, { memo, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
const UpdateBanblce = () => {
  const { data } = useWsUpdateBanblce();
  const { mutate } = useWalletAll(false);
  const { t } = useTranslation();
  const walletRef = useRef<IFWalletRsp>(null);
  const [globalWallet, setGlobalWallet] = useGlobalWalletStore()
  useEffect(() => {
    walletRef.current = globalWallet;
  }, [globalWallet]);



  useEffect(() => {
    if (data) {
      const money = dealAmount9Valid(Number(data?.money), {
        currencyType: data?.currencyType,
      });

      if (isNaN(Number(money))) {
        return;
      }
      if (data?.tradeModeCode === 'GAME_BET' || data?.tradeModeCode === 'GAME_WIN' || data?.tradeModeCode === 'HBY_AWARD') {
        if (walletRef.current) {
          const setData = { ...walletRef.current };
          for (let i = 0; i < setData?.all?.length; ++i) {
            if (setData?.all?.[i].currencyType === data?.currencyType) {
              setData.all[i].balance = Number(data?.money);
              setData.all[i].allBalance = Number(data?.money);
              break;
            }
          }
          setGlobalWallet(setData)
          //mutate(setData, { revalidate: false });
        }
        if (data?.tradeModeCode === 'HBY_AWARD') {
          Notification.success({
            title: '',
            content: `${t('SUCC_AQUIRE_MONEY', { money: AmountDivisorConversion( Number(data?.changedMoney),{
              currencyType: data?.currencyType
            }) + `${data?.currencyType}` })}`,
          });
        }
        return;
      }
      if (data?.tradeModeCode === 'FIRST_RECHARGE_REBATE') {
        return;
      }
      if (data?.tradeModeCode?.includes('GAME')) {
        return;
      } else if (data?.tradeModeCode?.includes('RECHARGE_')) {
        const changedMoney = dealAmount9Valid(Number(data?.changedMoney), {
          currencyType: data?.currencyType,
        });
        //充值成功
        Notification.success({
          title: '',
          content: `${t('SUCC_pay', { coins: changedMoney + `${data?.currencyType}` })}`,
        });
        mutate();
      } else if (data?.tradeModeCode?.includes('VIP_TURNTABLE_AWARD')) {
        //转盘获奖提示
        // setTimeout(()=>{
        //     Notification.success({
        //         title: '',
        //         content: `${t('SUCC_GET_MAIL_COINS', { coins: money + `${data?.currencyType}` })}`
        //     })
        // },6000)
        // console.log(`${data?.currencyType}`)
      } else if (data?.tradeModeCode?.includes('CONSUME')) {
        // //钱包兑换 ：消耗
        // Notification.success({
        //   title: '',
        //   content: `${t('SUCC_CONSUME_MONEY', { money: money + `${data?.currencyType}` })}`,
        // });
        // revalidate();
      } else if (data?.tradeModeCode?.includes('ACQUIRE')) {
        const changedMoney = dealAmount9Valid(Number(data?.changedMoney), {
          currencyType: data?.currencyType,
        });
        //钱包兑换 ：获得
        Notification.success({
          title: '',
          content: `${t('SUCC_AQUIRE_MONEY', { money: changedMoney + `${data?.currencyType}` })}`,
        });
        mutate();
      } else if (data?.tradeModeCode?.includes('_WITHDRAW')) {
        const changedMoney = dealAmount9Valid(Number(data?.changedMoney), {
          currencyType: data?.currencyType,
        });
        //钱包提现
        Notification.success({
          title: '',
          content: `${t('SUCC_WITHDRAW_MONEY', { money: changedMoney + `${data?.currencyType}` })}`,
        });
        mutate();
      } else if (data?.tradeModeCode?.includes('GMARTIFICIAL')) {
        const changedMoney = dealAmount9Valid(Number(data?.changedMoney), {
          currencyType: data?.currencyType,
        });
        Notification.success({
          title: '',
          content: `${t('SUCC_pay', { coins: changedMoney + `${data?.currencyType}` })}`,
        });
        mutate();
      } else if (data?.tradeModeCode.includes('TRANSIN')) {
        // 进游戏更新钱包
        mutate();
      } else if (data?.tradeModeCode.includes('TRANSOUT')) {
        // 游戏退出刷新钱包
        mutate();
      } else {
        const changedMoney = dealAmount9Valid(Number(data?.changedMoney), {
          currencyType: data?.currencyType,
        });
        Notification.success({
          title: '',
          content: `${t('SUCC_GET_MAIL_COINS', { coins: changedMoney + `${data?.currencyType}` })}`,
        });
        mutate();
      }
    }
  }, [data]);
  return <></>;
};

export default memo(UpdateBanblce);

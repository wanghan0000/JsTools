import 'swiper/less';
import 'swiper/less/pagination';
import 'swiper/less/grid';
import './styles/listView.less'
import ListView from './ListView';
export default ListView;

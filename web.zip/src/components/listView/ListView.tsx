import React, { memo, PropsWithChildren, ReactNode, useEffect, useRef, useState } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import ButtonUI from '@/componentsUI/Button';
import { IconLeft, IconRight } from '@arco-design/web-react/icon';
import cs from 'classnames';
import ListItem from '@/components/listItem/ListItem';
import { IFGameItem } from '@/api/apiRsp/IFHomeRsp';
import useScreenDesign from '@/Core/utils/hooks/useScreenDesign';
import { sys } from '@/Core/utils/system';

interface listViewProps {
  title?: string;
  rightBtnTitle?: string;
  hideRightBtn?: boolean;
  minHeight?: number;
  list?: Array<any> | [];
  onClick?: (game: IFGameItem) => void;
  rightClick?: () => void;
  icon?: ReactNode | undefined;
  refresh?: boolean;
  isLazyLoading?: boolean;
}
const ListView = (Props: PropsWithChildren<listViewProps>) => {

  const { rightClick} = Props || {}
  
  const listViewRef = useRef(null);
  //当前显示的slide数量
  const [perViewNum, setPerViewNum] = useState(2);
  const [perVStatus, setPerVStatus] = useState(true);
  const [nextStatus, setNextStatus] = useState(true);

  const isMobile = useScreenDesign();

  const ref = useRef(null)



  //初始化swiper引用
  const onSwiper = (swiper) => {
    listViewRef.current = swiper;
  };
  //断点回调
  const onBreakpoint = (swiper) => {
    if (swiper.currentBreakpoint == 'max') {
      console.log(swiper.currentBreakpoint);
    } else {
      setPerViewNum(breakpoints?.[swiper?.currentBreakpoint]?.slidesPerView);
    }
    swiper.update();
  };

  //切换到上一页
  const slidePrev = () => {
    let prevNum = listViewRef.current?.activeIndex;
    prevNum -= perViewNum;
    prevNum = prevNum < 0 ? 0 : prevNum;
    listViewRef.current?.slideTo(prevNum, 300);
  };

  //切换到下一页
  const slideNext = () => {
    const totalSlideNum = Props?.list?.length || 0;
    let nextNum = listViewRef.current?.activeIndex;
    nextNum += perViewNum;
    nextNum = nextNum > totalSlideNum ? totalSlideNum : nextNum;
    listViewRef.current?.slideTo(nextNum, 300);
  };

  //切换完成回调
  const onSlideChange = () => {
    const totalSlideNum = Props?.list?.length || 0;
    if (listViewRef.current?.activeIndex == 0) {
      setPerVStatus(true); //禁用上一页
      setNextStatus(false); //启用下一页
    } else if (listViewRef.current?.activeIndex + perViewNum >= totalSlideNum || listViewRef.current?.activeIndex == totalSlideNum) {
      setPerVStatus(false); //启用上一页
      setNextStatus(true); //禁用下一页
    } else {
      setPerVStatus(false); //启用上一页
      setNextStatus(false); //启用下一页
    }
  };

  //响应式断点
  const breakpoints = {
    200: { slidesPerView: 3 },
    576: { slidesPerView: 3 },
    768: { slidesPerView: 5 },
    992: { slidesPerView: 6 },
    1200: { slidesPerView: 8 },
    1600: { slidesPerView: 8 },
  };

  //初始化按钮状态
  useEffect(() => {
    if (!Props?.list) {
      return
    }
    if (Props.list.length <= perViewNum) {
      setNextStatus(true);
      setPerVStatus(true);
    } else {
      setNextStatus(false);
    }
  }, [perViewNum]);

  return (
    <>
      {
        <div className={'list-view'} style={{ minHeight: Props.minHeight || 300 }} ref={ref}>

          {
            <>
              <div className={'list-top'}>
                <div className={'list-title'}>
                  {Props.icon && Props.icon}
                  {Props.title || ''}
                </div>
                <div className={'list-top-right'}>
                  {!Props.hideRightBtn && (
                    <div>
                      <ButtonUI className={cs('swiper-view-btn', 'list-btn1')} type={'text'} size={'mini'} onClick={rightClick}>
                        {Props.rightBtnTitle || 'View All'}
                      </ButtonUI>
                    </div>
                  )}
                  {!Props.hideRightBtn && !isMobile && (
                    <div className={'list-top-right-btn'}>
                      <ButtonUI
                        disabled={listViewRef.current?.activeIndex === 0 || perVStatus}
                        className={cs('swiper-view-btn', 'list-btn2')}
                        size={'mini'}
                        icon={<IconLeft />}
                        onClick={() => slidePrev()}
                      />
                      <ButtonUI
                        disabled={!listViewRef.current?.allowSlideNext || nextStatus}
                        className={cs('swiper-view-btn', 'list-btn3')}
                        size={'mini'}
                        icon={<IconRight />}
                        onClick={() => slideNext()}
                      />
                    </div>
                  )}
                </div>
              </div>
              {isMobile ? (
                <div className="ListItem-container">
                  {Props.list &&
                    Props.list.map((value, key) => {
                      return <ListItem key={key} data={{ ...value }} refresh={Props.refresh} />;
                    })}
                </div>
              ) : (
                <Swiper
                  spaceBetween={8}
                  onBreakpoint={onBreakpoint}
                  onSlideChange={onSlideChange}
                  slidesPerView={'auto'}
                  breakpoints={breakpoints}
                  onSwiper={onSwiper}
                >
                  {Props?.list &&
                    Props.list.map((value, key) => {
                      return (
                        <SwiperSlide key={key}>
                          <ListItem data={{ ...value }} refresh={Props.refresh} />
                        </SwiperSlide>
                      );
                    })}
                </Swiper>
              )}
            </>
          }



        </div>
      }
    </>

  );
};
export default memo(ListView);

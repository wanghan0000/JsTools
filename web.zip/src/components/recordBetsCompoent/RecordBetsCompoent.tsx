import './index.less'
import ButtonUI from "@/componentsUI/Button";
import { useTranslationPlus } from "@/Core/i18n/useTranslationPlus";
import { debounce, timeStampToDateDay } from "@/Core/utils";
import { numberDivisor, numberFixed, toLocaleString } from "@/Core/utils/currencyDealCenter";
import useScreenDesign, { screenType } from "@/Core/utils/hooks/useScreenDesign";
import { Table, TableColumnProps } from "@arco-design/web-react";
import classNames from "classnames";
import React, { useEffect, useRef, useState } from "react";
import CurrencyCompoent from "../currencyCompoent";

const RecordBetsCompoent = (props) => {

    const { onClickItem, betData = [], style, original = false } = props

    const { t } = useTranslationPlus('GameOriginal')
    const { t: thome } = useTranslationPlus('HomeView')

    const [domWidth, setDomWidth] = useState(0)
    const [showMore, setShowMore] = useState<boolean>(false)
    const domRef = useRef(null)
    const updateDow = debounce(() => {
        if (domRef && domRef.current) {
            setDomWidth(domRef.current?.clientWidth)
        }
    }, 300)
    const mobile = useScreenDesign(screenType.mobile, '<=', () => {
        updateDow()
    })
    useEffect(() => {
        setDomWidth(domRef.current?.clientWidth)
    }, [domRef])

    const columns: TableColumnProps[] = [
        {
            title: t('Time'),
            dataIndex: 'betTime',
            render: (col, item) => (
                <div
                    onClick={() => { onClickItem(item) }}
                    style={{ width: domWidth * 0.15 }}>
                    <div
                        style={{ paddingLeft: 5 }}
                    >
                        {timeStampToDateDay(item.betTime)}
                    </div>
                </div>
            )
        },
        {
            title: t('BetId'),
            dataIndex: 'betId',
            render: (col, item) => (
                <div onClick={() => { onClickItem(item) }}
                    style={{ width: domWidth * (mobile ? 0.23 : 0.35) }}>
                    <div
                        style={{ paddingLeft: mobile ? 5 : 0 }}
                    >
                        {item.betId}
                    </div>
                </div>
            )
        },
        {
            title: t('Bets'),
            dataIndex: 'betAmount',
            render: (col, item) => (
                <div onClick={() => { onClickItem(item) }}
                    style={{ width: domWidth * (mobile ? 0.28 : 0.2) }}>
                    <CurrencyCompoent
                        className={'record-bets-currency-compoent'}
                        iconPosition={'rt'}
                        amount={item?.betAmount}
                        showUnit={false}
                        currencyType={item?.currencyType}
                        type={'valid9'}
                    />
                </div>
            )
        },
        {
            title: t('Payout'),
            dataIndex: 'payout',
            render: (col, item) => (
                <div onClick={() => { onClickItem(item) }}
                    style={{ width: domWidth * (mobile ? 0.16 : 0.10) }}>
                    {item?.winAmount > 0 ? numberFixed(numberDivisor(
                        original ?  item?.winAmount + item?.betAmount :item?.winAmount, item?.betAmount
                    ), 2) + 'x' : `${toLocaleString('0.00')}x`}
                </div>
            )
        },
        {
            title: t('Win'),
            dataIndex: 'winAmount',
            render: (col, item) => (
                <div onClick={() => { onClickItem(item) }}
                    style={{ width: domWidth * (mobile ? 0.28 : 0.2) }}>
                    <div style={{ paddingRight: 0 }}>
                        <CurrencyCompoent
                            className={classNames(["record-bets-currency-compoent record-bets-currency-compoent-win", item?.winAmount >= 0 ? 'win' : 'lose'])}
                            iconPosition={'rt'}
                            amount={item?.winAmount}
                            showUnit={false}
                            showIcon={true}
                            type='valid9'
                            currencyType={item?.currencyType}
                        />
                    </div>
                </div>
            )
        }
    ]
    const prefixCls = 'game-record-bets-compoents';

    return (<div ref={domRef} className={`${prefixCls}`}>
        <Table style={style} columns={
            mobile ? columns.filter((v) => { return v.dataIndex !== 'betTime' }) :
                columns
        } data={
            showMore ? betData.slice(0, betData?.length > 30 ? 30 : betData?.length) :
                betData.slice(0, betData?.length > 10 ? 10 : betData?.length)
        } pagination={false}
            noDataElement={
                thome('NoData')
            }

            rowKey={'betId'}
        ></Table>
        {
            betData?.length > 10 &&
            <div className={'btn-more'}>
                <ButtonUI
                    type={'primary'}
                    buttonColor={'secondary'}
                    style={style}
                    onClick={() => { setShowMore(!showMore) }}>{
                        showMore ? t('ShowLess') : t('ShowMore')
                    }</ButtonUI>
            </div>
        }
    </div>)
}


export default RecordBetsCompoent
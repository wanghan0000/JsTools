import React, { useEffect, useMemo, useRef, useState } from 'react';
import { IconDelete, IconSearch } from '@arco-design/web-react/icon';
import ListItem from '@/components/listItem/ListItem';
import cs from 'classnames';
import { Grid } from '@arco-design/web-react';
import SpinUI from '@/componentsUI/Spin';
import Result from '@/componentsUI/Result';
import useStorage from '@/Core/utils/hooks/useStorage';
import { useSearchGame } from '@/store/game';
import TagUI from '@/componentsUI/Tag';
import { useTranslationPlus } from '@/Core/i18n/useTranslationPlus';
import RecomendView from '@/components/recomendView';
import './styles/searchView.less';
import InputUI from '@/componentsUI/Input';
import LoadingSuperPlusUI from '@/componentsUI/LoadingSuperPlusUI/LoadingSuperPlusUI';
/**
 * 作者: nick
 * 时间: 2023/5/11
 * 说明: ***
 */
const { GridItem } = Grid;

const SearchView = (Props) => {
  const { t } = useTranslationPlus('HomeView');
  const listItemRef = useRef(null);
  const { trigger } = useSearchGame();

  const [searchText, setSearchText] = useState(''); //搜索文本
  const [searchLoading, setSearchLoading] = useState(false); //搜索loading
  const searchTimer = useRef(null); //搜索倒计时-》请求
  const [searchList, setSearchList] = useState([]); //搜索后的数据

  const [historyListStorage, setHistoryListStorage] = useStorage('history');
  const list = (historyListStorage && JSON.parse(historyListStorage)) || [];
  const [historyList, setHistoryList] = useState(list);
  const charReg = new RegExp('[\\u4E00-\\u9FFF]+');

  const handleSearch = (e) => {
    e.stopPropagation();
    if (Props.onCancel) Props.onCancel();
  };

  const onClear = () => {
    console.log('onClear');
    console.log(searchList);
    setSearchList([]);
    console.log(searchList);
  };

  const searchGameList = () => {
    request(searchText)
      .then((res) => {
        setSearchLoading(false);
        historyList.unshift(searchText);
        setHistoryListStorage(JSON.stringify(historyList));
        setSearchList(res || []);
      })
      .catch((error) => {
        setSearchLoading(false);
        console.log(error);
      });
  };

  // 获取游戏列表
  const request = async (keyword) => {
    return await trigger({ keyword });
  };

  //清除选中history
  const handleCloseTag = (val) => {
    const newList = removeArr(historyList, val);
    setHistoryList(newList);
    setHistoryListStorage(JSON.stringify(newList));
  };
  //点击选中history
  const handelClickTag = (val) => {
    setSearchText(val);
  };
  //清除所有history
  const handleCloseAllTag = () => {
    setHistoryList([]);
    setHistoryListStorage(JSON.stringify([]));
  };

  //删除数组某个值
  const removeArr = (array, val) => {
    const arr = array;
    const index = arr.indexOf(val);
    if (index > -1) arr.splice(index, 1);
    return arr;
  };

  useEffect(() => {
    if (searchTimer.current) {
      clearTimeout(searchTimer.current);
    }

    if (searchText.length < 3 && !charReg.test(searchText)) {
      setSearchLoading(false);
      return;
    }
    setSearchLoading(true);
    setSearchList([]);
    searchTimer.current = setTimeout(() => {
      searchGameList();
    }, 1000);
  }, [searchText]);

  const renderHistory = useMemo(() => {
    return (
      <div className={'search-list'}>
        {historyList.map((item, index) => {
          return (
            <TagUI className={'search-history-tag'} key={index} size={'large'} onClose={() => handleCloseTag(item)}>
              <div onClick={() => handelClickTag(item)}>{item}</div>
            </TagUI>
          );
        })}
      </div>
    );
  }, [historyList, searchLoading, searchText]);

  return (
    <div className={'search-container'}>
      <div className={'search-input-inner'}>
        <InputUI
          className={'search-input-content'}
          value={searchText}
          prefix={<IconSearch />}
          allowClear={true}
          onChange={setSearchText}
          placeholder={t('SearchInput')}
          onClear={onClear}
          suffix={
            <span style={{ cursor: 'pointer' }} onClick={handleSearch}>
              {t('Cancel')}
            </span>
          }
          initFocus={true}
        />
      </div>
      {searchList.length > 0 && (
        <div className={'search-swiper-view'}>
          <div className={'search-scroll-view'}>
            <Grid cols={{ xs: 3, sm: 4, md: 5, lg: 6, xl: 8, xxl: 8 }} colGap={10} rowGap={10} className={'grid-responsive'}>
              {searchList.map((value, key) => {
                return (
                  <GridItem key={key} className={cs('grid--list-item')}>
                    <ListItem ref={listItemRef} data={value} onClick={() => console.log('click')} refresh={true} />
                  </GridItem>
                );
              })}
            </Grid>
          </div>
        </div>
      )}
      {/* loading */}
      {searchLoading && (
        <div className={'search-loading'}>
          <SpinUI loading={searchLoading} />
        </div>
      )}
      {/* loading 后无数据 */}
      {!searchLoading && searchList.length == 0 && searchText.length !== 0 && (
        <div className={'search-nodata-view'}>
          {/* <Result title={searchText.length >= 3 ? t('NoData') : charReg.test(searchText) ? t('NoData') : t('SearchTip')} /> */}
          {searchText.length < 3 ? (
            <Result status="warning" title={t('SearchTip')} />
          ) : (
            <LoadingSuperPlusUI error={false} dataList={searchList} loading={false} />
          )}
        </div>
      )}
      {/* 没有搜索时 */}
      {searchText.length == 0 && (
        <div className={'search-no-text-view'}>
          <div className={'search-tip-view'}>{t('SearchTip')}</div>
          {historyList.length > 0 && (
            <div className={'search-history-view'}>
              <div className={'search-history-header'}>
                <div className={'search-history-title'}>{t('SearchHistory')}</div>
                <IconDelete onClick={handleCloseAllTag} />
              </div>
              {renderHistory}
            </div>
          )}
        </div>
      )}
      <RecomendView />
    </div>
  );
};

export default SearchView;

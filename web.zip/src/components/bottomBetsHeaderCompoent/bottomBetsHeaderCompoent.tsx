import './index.less'
import TabsPlusButtonUI from "@/componentsUI/TabsPlusUI/TabsPlusButtonUI/TabsPlusButtonUI";
import TabsPlusUI from "@/componentsUI/TabsPlusUI/TabsPlusUI";
import { useTranslationPlus } from "@/Core/i18n/useTranslationPlus";
import { useChangeBetTab } from "@/store/commonStore";
import classNames from "classnames";
import React, { useEffect } from "react"

/**注单tab表 */
const TableBtnGroupConfig = [
    'All Bets',
    'Record'
]

const BottomBetsHeaderCompoent = (props) => {
    const { className } = props;
    const prefixCls = 'bottom-bets-header-compoent';
    const [, setChange] = useChangeBetTab()
    const { t } = useTranslationPlus('GameOriginal')
    useEffect(() => {
        setChange(TableBtnGroupConfig[0])
    }, [])
    return (
        <div className={classNames([prefixCls, className])}>
            <TabsPlusUI
                className={`${prefixCls}-tabs-ui`}
                interval={0}
                defaultValue={0}
                onSelect={(index) => { setChange(TableBtnGroupConfig[index]) }}>
                <TabsPlusButtonUI index={0} title={t('All Bets')} />
                <TabsPlusButtonUI index={1} title={t('Record')} />
            </TabsPlusUI>
        </div>
    )
}

export default BottomBetsHeaderCompoent
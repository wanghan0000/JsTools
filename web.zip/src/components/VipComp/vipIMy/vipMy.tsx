import { ProgressBar, ProgressNum } from '@/pages/farmElement/indexElement';

import { Typography } from '@arco-design/web-react';
import { useTranslationPlus } from '@/Core/i18n/useTranslationPlus';

import VipLock from '../vipLock';
import VipLogo from '../vipLogo';
import VipService from '../vipService';
import { AmountDivisorConversion, dealAmount0Fiexd, numberFixed } from '@/Core/utils/currencyDealCenter';
import useScreenDesign from '@/Core/utils/hooks/useScreenDesign';
import classNames from 'classnames';
import React from 'react';

const VipMy = (props) => {
  const { t } = useTranslationPlus('VIP');
  const isMobile = useScreenDesign();
  const { className, data, rankSrc, onClickService } = props;
  const calcCurrentProGress = () => {
    /*  进度=当前已获得 /  （下一等级总经验-当前等级总经验）
        *达到到当前等级后 后台需把已获得经验清空
        升级剩余经验值 =等级差值 -当前已获得经验值 
            如：
       */
    const levelTotalExp = AmountDivisorConversion(data?.levelTotalExp, {
      currencyType: data?.currencyType,
    }); //当前等级经验
    const totalExp = AmountDivisorConversion(data?.totalExp, {
      currencyType: data?.currencyType,
    }); //当前已获得经验
    const nextLevelTotalExp = AmountDivisorConversion(data?.nextLevelTotalExp, {
      currencyType: data?.currencyType,
    }); //下一等级总经验
    const per = (totalExp / (nextLevelTotalExp - levelTotalExp)) * 100;
    // return parseFloat(numberFixed(per > 100 ? 100 : per, 0)?.replace(',', '.')); //兼容服务端数据错误，百分比》100%
    return Math.round(per > 100 ? 100 : per);
  };

  return (
    <Typography.Paragraph className={classNames(`${className}-top`, isMobile ? `${className}-toph5` : `${className}-topweb`)}>
      <div className="left">
        <VipLogo
          fromComp="VipMy"
          className={classNames('vipLogo', `vipLogo${data?.level === 0 ? '0' : '100'}`)}
          srcVip={rankSrc}
          level={data?.level}
        ></VipLogo>
      </div>
      <div className="right">
        <div className="userInfo">
          <div className="info">
            <div className="name">{data?.userName}</div>
            <div className="id">ID: {data?.usrId}</div>
          </div>
          {Number(data?.level) >= 0 && !isMobile && (
            <div className="switch">
              {data?.lockLevel && data?.level >= data?.lockLevel ? (
                <VipService className="icon" onClickService={onClickService} />
              ) : (
                <VipLock className="icon" />
              )}
              <div className="lockedMsg">
                <span className="vipSever">{t('vipSever')}</span>
                {data?.level < data?.lockLevel && <span className="startVIP"> {t('start VIP', { lockLevel: data?.lockLevel })}</span>}
              </div>
            </div>
          )}
        </div>
        <div className="progerss-wrap">
          <div className="progerss">
            <ProgressBar data-progress={calcCurrentProGress() || 0}>
              <ProgressNum data-progress={calcCurrentProGress() || 0}>{`${calcCurrentProGress() || 0}%`}</ProgressNum>
            </ProgressBar>
          </div>
          {data?.level !== data?.nextLevel && ( //nextLevel 返回150  代表当前用户已是最高等级无下级，不必展示
            <div className="level">
              <div className="curxp">
                {t('xp', {
                  levelTotalExp: AmountDivisorConversion(data?.totalExp, {
                    currencyType: data?.currencyType,
                  }),
                })}
              </div>
              <div className="totalxp">
                <Typography.Text>
                  {t('xp up to', {
                    nextLevelTotalExp:
                      AmountDivisorConversion(data?.nextLevelTotalExp, {
                        currencyType: data?.currencyType,
                      }) -
                      AmountDivisorConversion(data?.levelTotalExp, {
                        currencyType: data?.currencyType,
                      }) -
                      AmountDivisorConversion(data?.totalExp, {
                        currencyType: data?.currencyType,
                      }),
                  })}
                </Typography.Text>
                <Typography.Text> {'VIP' + data?.nextLevel} </Typography.Text>
              </div>
            </div>
          )}
        </div>
      </div>
    </Typography.Paragraph>
  );
};
export default VipMy;

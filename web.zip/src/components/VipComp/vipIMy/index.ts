import './style/index.less'
import VipMy from './vipMy';

export default VipMy;
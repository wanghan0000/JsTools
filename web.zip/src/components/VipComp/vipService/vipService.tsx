import { Avatar } from "@arco-design/web-react"
import { IconCustomerService } from "@arco-design/web-react/icon"
import React from "react" 

const VipService=(props)=>{
 
    const {className,onClickService}=props
    return(
        <Avatar className={className} onClick={onClickService}>
            <IconCustomerService  style={{width:'24px',height: '28px'}} /> 
        </Avatar>
    )
}
export default VipService
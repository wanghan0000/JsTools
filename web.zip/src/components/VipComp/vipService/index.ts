import './style/index.less'
import VipService from './vipService';

export default VipService;
import React from "react"
import VipLogo from "../vipLogo"

const VipLevel = (props) => {
    const { className,rankSrc,rankTitle,levelRange } = props
    let levelRangeDesc=''
    if(levelRange?.length>0){
        levelRangeDesc=levelRange[0]+'~'+levelRange[1]
    }else{
        levelRangeDesc=''
    }
    return (
        <div className={`${className}-vipRanks`} >
            <VipLogo   fromComp='VipLevel'  className='ranksLogo' srcVip={rankSrc} level={levelRange[0]?? ''}></VipLogo>
            <div className='ranksInfo'>
                <span className="name">{rankTitle}</span>
                <span className="range">{`(${levelRangeDesc})`} </span>
            </div>
        </div>
    )
}
export default VipLevel
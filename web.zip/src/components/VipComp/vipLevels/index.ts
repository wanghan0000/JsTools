import './style/index.less'
import VipLevel from './vipLevel';

export default VipLevel;
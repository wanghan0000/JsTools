import classNames from "classnames"
import React from "react" 

const VipLogo=(props)=>{
 
    const {className,srcVip,level,fromComp}=props
    return(
        <div className={classNames(className,fromComp)}>
            <img src={srcVip}  />
            {
                   fromComp==='VipMy' &&
                   <div className="text">
                   <span className="text2">{level}</span>
           </div>
            }
           
        </div>
    )
}
export default VipLogo
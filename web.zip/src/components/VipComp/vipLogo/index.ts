import './style/index.less'
import VipLogo from './vipLogo';

export default VipLogo;
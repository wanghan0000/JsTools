import './style/index.less'
import VipBenefits from './vipBenefits';

export default VipBenefits;
import { useTranslationPlus } from '@/Core/i18n/useTranslationPlus';
import VipLock from "../vipLock"
import React from 'react';

const VipBenefits = (props) => {
    const { benefitId, benefitSrc,onClickItem,benefitName,startLevel,currentLevel } = props
    const { t } = useTranslationPlus('VIP');
  
    let startLev=0
    if(benefitId==7){//神秘宝箱有可能是多个等级"8,10,15,20"
        const arrLevel=startLevel?.split(',') || []
        if( arrLevel.length>1)
        startLev=(Number(arrLevel[0]))
    }else{
        startLev=(Number(startLevel))
    }
   
   let levDesc=''
   if(startLevel==0){
     levDesc=t('Every level')
   }else{
        if(currentLevel >= startLev ){
        levDesc='VIP'+ startLevel
       }else{
        levDesc=t('Unlock') + ' VIP' + startLevel
       }
   }
    return (
        <div onClick={onClickItem} className='collapseContent'>
        <div  className='itemInfo'>
            <div className="left">
                {
                   currentLevel >= startLev ? <img src={benefitSrc} />: <VipLock className='icon'  />
                }
            </div>
            <div className="right">
                <span className="name"> {benefitName}</span>
                <span className="range">{levDesc}</span>
            </div>
        </div>
    </div>
    )
}
export default VipBenefits
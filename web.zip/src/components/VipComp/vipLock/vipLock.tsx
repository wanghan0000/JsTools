import { Avatar } from "@arco-design/web-react"
import { IconLock } from "@arco-design/web-react/icon"
import React from "react" 

const VipLock=(props)=>{
    const {className}=props
    return(
        <Avatar className={className}>
            <IconLock /> 
        </Avatar>
    )
}
export default VipLock
import './style/index.less'
import VipLock from './vipLock';

export default VipLock;
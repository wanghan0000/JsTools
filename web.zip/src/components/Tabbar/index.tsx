import styles from '@/components/Tabbar/style/index.module.less';
import cs from 'classnames';
import React, { useEffect, useState } from 'react';
import { IconMenu, IconSearch } from '@arco-design/web-react/icon';
import { Dc, IconQb, Yaoqing } from '@/assets/svg-icon';
import { useTranslationPlus } from '@/Core/i18n/useTranslationPlus';
import { useLocation, useNavigate } from 'react-router';
import { useGlobalOpenSearch, useGlobalState, useMobileLeftSiderSwitch } from '@/store/commonStore';
import useDialogManager from '@/utils/useDialogManager';
import { sys } from '@/Core/utils/system';
import GameDrawer from '@/layout/components/gameDrawer/GameDrawer';

function Tabbar() {
  const navigate = useNavigate();
  const { isLogin } = useGlobalState();
  const { openSignIn, openWallet } = useDialogManager();
  //TabBar激活索引
  const [activeIndex, setActiveIndex] = useState(3);
  const [, setDrawerVisible] = useMobileLeftSiderSwitch();
  const [, setSearchVisible] = useGlobalOpenSearch();

  //const [isScrolling, setIsScrolling] = useState(true);

  //移动端底部tab点击
  function onClickTab(index) {
    switch (index) {
      case 0:
        setDrawerVisible(true);
        break;
      case 1:
        setActiveIndex(index);
        if (!pathname.includes('home')) {
          navigate('/home');
        }
        break;
      case 2:
        if (isLogin) {
          openWallet();
        } else {
          openSignIn();
        }

        break;
      case 3:
        setSearchVisible(true);

        break;
      case 4:
        if (isLogin) {
          // setOpenNotice(!openNotice);
          if(!pathname.includes('NationalProxy')){
            navigate('/NationalProxy');
          }
          setActiveIndex(4);
        } else {
          openSignIn();
        }
        break;
      default:
        setActiveIndex(index);
        break;
    }
  }

  const { t } = useTranslationPlus('HomeView');

  const tabs = [
    {
      title: t('tabMenu'),
      middleRadius: false,
      icon: <IconMenu className={'arco-icon'} />,
    },
    {
      title: t('tabHome'),
      middleRadius: false,
      icon: <Dc className={'arco-icon'} />,
    },
    {
      title: t('tabWallet'),
      middleRadius: true,
      icon: <IconQb className={''} />,
    },
    {
      title: t('tabSearch'),
      middleRadius: false,
      icon: <IconSearch className={'arco-icon'} />,
    },
    {
      title: t('Affiliate'),
      middleRadius: false,
      icon: <Yaoqing />,
    },
  ];
  //是否有凸出按钮
  const hasMiddle = true;

  const { pathname } = useLocation();
  useEffect(() => {
    if (pathname.includes('home')) {
      onClickTab(1);
    } else if (pathname.includes('NationalProxy')) {
      onClickTab(4);
    } else {
      onClickTab(-1);
    }
  }, [pathname]);

  // useEffect(() => {
  //   let prevScrollY = 0;
  //   const handleScroll = () => {
  //     const currentScrollPosition = window.scrollY;
  //     if (currentScrollPosition <= 0) {
  //       setIsScrolling(true);
  //       return;
  //     }
  //     const scrollDirection = currentScrollPosition > prevScrollY ? false : true;
  //     setIsScrolling(scrollDirection);
  //     prevScrollY = currentScrollPosition;
  //   };

  //   window.addEventListener('scroll', handleScroll);

  //   return () => window.removeEventListener('scroll', handleScroll);
  // }, []);

  function handlerIOS() {
    if (sys.isNative && sys.os === 'IOS') {
      return true;
    } else {
      return false;
    }
  }

  return (
    <>
      <div
        className={cs(styles['tabbar'])}
        style={{
          position: 'fixed',
          zIndex: '98',
       
        }}
      >
        <div className={cs(styles['tabbar-inner'])} >
          {tabs.map((tab, key) => {
            return (
              <div key={key} className={cs(styles['tabbar-item'], { [styles.active]: activeIndex === key })} onClick={() => onClickTab(key)}>
                {tab.middleRadius ? (
                  <>
                    <div className={cs(styles['tabbar-middle-view'])}>{tab.icon}</div>
                    <div className={cs(styles['tabbar-item-title'])}>{tab.title}</div>
                  </>
                ) : (
                  <div className={cs(styles['tabbar-item-inner'], { [styles.active]: activeIndex === key })}>
                    <div className={cs(styles['tabbar-item-icon'])}>{tab.icon}</div>
                    <div className={cs(styles['tabbar-item-title'])}>{tab.title}</div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
        {hasMiddle && (
          <div className={cs(styles['tabbar-center-bg'])} onClick={() => onClickTab(2)}>
            <div className={cs(styles['tabbar-middle'])}></div>
          </div>
        )}
      </div>
      <GameDrawer />
    </>
  );
}

export default Tabbar;

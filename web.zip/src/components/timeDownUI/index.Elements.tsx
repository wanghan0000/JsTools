import { Progress } from '@arco-design/web-react';
import { styled } from 'styled-components';

export const Container = styled.div`
  display: flex;
  align-items: center;
  margin: 0 auto;
`;

export const MyProgress = styled(Progress)`
  margin: 0 5px;
  .arco-progress-circle-wrapper {
    background-color: transparent !important;
    /* width: 70px !important;
    height: 70px !important; */
  }
`;

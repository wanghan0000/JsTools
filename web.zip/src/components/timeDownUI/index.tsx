import React, { useEffect, useState } from 'react';
import { Container, MyProgress } from './index.Elements';
import { useCountdown } from '@/utils/useCountdown';
import { useTranslationPlus } from '@/Core/i18n/useTranslationPlus';

interface Props {
  strTime: number;
  endTime: number;
}

const TimeDownUI: React.FC<Props> = ({ strTime, endTime }) => {
  const [dayOutTime, setDayOutTime] = useState(0);
  const { t } = useTranslationPlus('FORMATTIME');
  const countdown = useCountdown({
    futureDate: endTime,
    activeTime: strTime,
  });

  useEffect(() => {
    const days = (endTime - strTime) / (1000 * 60 * 60 * 24);
    const percent = Math.floor((countdown.days / days) * 100);
    setDayOutTime(percent);
  }, [countdown]);

  return (
    <Container>
      <MyProgress
        type="circle"
        percent={dayOutTime}
        color="var(--color-text-5time)"
        trailColor={'rgba(0, 0, 0,0.1)'}
        width={70}
        strokeWidth={3}
        formatText={() => {
          return (
            <div>
              <div style={{ fontSize: '18px', fontWeight: 'bold', color: 'var(--color-text-1)' }}>{countdown.days || 0}</div>
              <div style={{ fontSize: '12px', color: 'var(--color-text-2)' }}>{t('day')}</div>
            </div>
          );
        }}
      ></MyProgress>
      <MyProgress
        type="circle"
        percent={Number(((countdown.hours / 24) * 100).toFixed(0))}
        color="var(--color-text-5time)"
        trailColor={'rgba(0, 0, 0,0.1)'}
        width={70}
        strokeWidth={3}
        formatText={() => {
          return (
            <div>
              <div style={{ fontSize: '18px', fontWeight: 'bold', color: 'var(--color-text-1)' }}>{countdown.hours || 0}</div>
              <div style={{ fontSize: '10px', color: 'var(--color-text-2)' }}>{t('hour')}</div>
            </div>
          );
        }}
      ></MyProgress>
      <MyProgress
        type="circle"
        percent={Number(((countdown.minutes / 60) * 100).toFixed(0))}
        color="var(--color-text-5time)"
        trailColor={'rgba(0, 0, 0,0.1)'}
        width={70}
        strokeWidth={3}
        formatText={() => {
          return (
            <div>
              <div style={{ fontSize: '18px', fontWeight: 'bold', color: 'var(--color-text-1)' }}>{countdown.minutes || 0}</div>
              <div style={{ fontSize: '10px', color: 'var(--color-text-2)' }}>{t('minute')}</div>
            </div>
          );
        }}
      ></MyProgress>
      <MyProgress
        type="circle"
        percent={Number(((countdown.seconds / 60) * 100).toFixed(0))}
        color="var(--color-text-5time)"
        trailColor={'rgba(0, 0, 0,0.1)'}
        width={70}
        strokeWidth={3}
        formatText={() => {
          return (
            <div>
              <div style={{ fontSize: '18px', fontWeight: 'bold', color: 'var(--color-text-1)' }}>{countdown.seconds || 0}</div>
              <div style={{ fontSize: '10px', color: 'var(--color-text-2)' }}>{t('second')}</div>
            </div>
          );
        }}
      ></MyProgress>
    </Container>
  );
};

export default TimeDownUI;

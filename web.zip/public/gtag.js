window.googleTag = getUrlParam("gtag");
if ('%REACT_APP_BUILD%' === 'production') {
if (window.googleTag) {
    const script = document.createElement("script");
    script.async = true;
    script.src = "https://googletagmanager.com/gtag/js?id=" + window.googleTag;
    document.head.appendChild(script);
    window.dataLayer = window.dataLayer || [];
    function gtag() {
      dataLayer.push(arguments);
    }
    gtag("js", new Date());
    gtag("config", window.googleTag);
  }
}
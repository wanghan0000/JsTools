CASHBACK("57", "CASHBACK", TradeCategoryEnum.WITHDRAW, "提现退回"),
MANUALLYPAY("200", "MANUALLYPAY", TradeCategoryEnum.RECHARGE, "人工充值（线下）"),
ACTIVITY("201", "ACTIVITY", null, "活动"), // TODO 产品：此账变类型废弃
COMPENSATIONS("202", "COMPENSATIONS", TradeCategoryEnum.RECHARGE, "兑换补单（线下）"),
AGENTPAY("203", "AGENTPAY", TradeCategoryEnum.RECHARGE, "代理充值"),
OTHERPAY("204", "OTHERPAY", TradeCategoryEnum.RECHARGE, "其它（线下）"),
BROKERAGE("205", "BROKERAGE", null, "佣金"),
GMCOST("206", "GMCOST", TradeCategoryEnum.WITHDRAW, "GM 下分"),
GMPAY("208", "GMPAY", TradeCategoryEnum.RECHARGE, "GM 上分"),
PAYERRCOMP("209", "PAYERRCOMP", TradeCategoryEnum.RECHARGE, "线上掉单（补单）"),
GMARTIFICIAL("210", "GMARTIFICIAL", TradeCategoryEnum.RECHARGE, "GM 人工存入"),
WITHDRAWCOST("211", "WITHDRAWCOST", TradeCategoryEnum.WITHDRAW, "提现金额"),
CHECKIN("212", "CHECKIN", null, "活动签到"),

    RECHARGE("220", "RECHARGE", TradeCategoryEnum.RECHARGE, "充值"),
    WITHDRAW("221", "WITHDRAW", TradeCategoryEnum.WITHDRAW, "提现"),
    GAMESETTLE("222", "GAMESETTLE", null, "游戏损益"),
    REBATE("223", "REBATE", null, "洗码"),
    TRANSIN("225", "TRANSIN", TradeCategoryEnum.SYSTEM_FUND_SWITCH, "游戏上分"),
    TRANSOUT("226", "TRANSOUT", TradeCategoryEnum.SYSTEM_FUND_SWITCH, "游戏下分"),
    ADVANCEMONEY("227", "ADVANCEMONEY", null, "VIP晋级奖励"),
    MONTHMONEY("228", "MONTHMONEY", null, "VIP月奖金"),
    MAILSEND("229", "MAILSEND", null, "邮件发送"),
    AUTO_RECEIVE("230", "AUTO_RECEIVE", null, "自动领取洗码"),
    MANUAL_RECEIVE("231", "MANUAL_RECEIVE", null, "手动领取投注返利"),
    AUTO_PULL_ORDER("232", "AUTO_PULL_ORDER", null, "自动从三方拉取注单"),
    BANKCAR_WITHDRAW("233", "BANKCAR_WITHDRAW", TradeCategoryEnum.WITHDRAW, "银行卡提现"),
    ZFB_WITHDRAW("234", "ZFB_WITHDRAW", TradeCategoryEnum.WITHDRAW, "支付宝提现"),
    USDT_WITHDRAW("235", "USDT_WITHDRAW", TradeCategoryEnum.WITHDRAW, "USDT提现"),
    PIX_WITHDRAW("236", "PIX_WITHDRAW", TradeCategoryEnum.WITHDRAW, "PIX提现"),
    YZF_WITHDRAW("237", "YZF_WITHDRAW", TradeCategoryEnum.WITHDRAW, "云支付提现"),


    /******************添加游戏细分类 根据game名称匹配 开始 levi*******************/
    GAME_BET("238", "GAME_BET", TradeCategoryEnum.GAME, "投注"),


    GAME_WIN("239", "GAME_WIN", TradeCategoryEnum.GAME, "派彩"),
    /******************添加游戏细分类 根据game名称匹配 结束 levi*******************/




    /******************增加活动奖励类型 开始 levi*******************/
    VIP_TURNTABLE_AWARD("238", "VIP_TURNTABLE_AWARD", TradeCategoryEnum.REWARD, "幸运转盘"),


    VIP_WEEK_AWARD("239", "VIP_WEEK_AWARD", TradeCategoryEnum.REWARD, "周奖励"),


    VIP_FARM_AWARD("240", "VIP_FARM_AWARD", TradeCategoryEnum.REWARD, "金币农场"),


    VIP_TREASURE_AWARD("241", "VIP_TREASURE_AWARD", TradeCategoryEnum.REWARD, "神秘宝箱"),


    VIP_TASK_CENTER("242", "VIP_TASK_CENTER", TradeCategoryEnum.REWARD, "任务中心"),


    VIP_ACTIVITY_AWARD("243", "VIP_ACTIVITY_AWARD", TradeCategoryEnum.REWARD, "活动奖励"),


    VIP_REISSUE_AWARD("244", "VIP_REISSUE_AWARD", TradeCategoryEnum.REWARD, "活动补发"),


    /******************增加活动奖励类型 结束 levi*******************/


    // 钱包兑换
    CONSUME("250", "CONSUME", TradeCategoryEnum.EXCHANGE, "消耗"),
    ACQUIRE("251", "ACQUIRE", TradeCategoryEnum.EXCHANGE, "获得"),


    RECHARGE_VIP_PAY("600", "RECHARGE_VIP_PAY", TradeCategoryEnum.RECHARGE, "VIP支付"),
    RECHARGE_ZFB("601", "RECHARGE_ZFB", TradeCategoryEnum.RECHARGE, "支付宝充值"),
    RECHARGE_ALIPAYSCAN("602", "RECHARGE_ALIPAYSCAN", TradeCategoryEnum.RECHARGE, "支付宝扫码"),
    RECHARGE_WECHATPAY("603", "RECHARGE_WECHATPAY", TradeCategoryEnum.RECHARGE, "微信支付"),
    RECHARGE_WECHATSCAN("604", "RECHARGE_WECHATSCAN", TradeCategoryEnum.RECHARGE, "微信扫码"),
    RECHARGE_QQWALLET("606", "RECHARGE_QQWALLET", TradeCategoryEnum.RECHARGE, "QQ钱包"),
    RECHARGE_YZF("613", "RECHARGE_YZF", TradeCategoryEnum.RECHARGE, "云支付充值"),
    RECHARGE_SZRMB("614", "RECHARGE_SZRMB", TradeCategoryEnum.RECHARGE, "数字人民币"),
    RECHARGE_TOPAY("615", "RECHARGE_TOPAY", TradeCategoryEnum.RECHARGE, "Topay支付"),
    RECHARGE_YLZF("616", "RECHARGE_YLZF", TradeCategoryEnum.RECHARGE, "银联支付"),
    RECHARGE_WXDAER("617", "RECHARGE_WXDAER", TradeCategoryEnum.RECHARGE, "微信大额"),
    RECHARGE_WXDINGER("618", "RECHARGE_WXDINGER", TradeCategoryEnum.RECHARGE, "微信定额"),
    RECHARGE_WXXE("619", "RECHARGE_WXXE", TradeCategoryEnum.RECHARGE, "微信小额"),


    RECHARGE_PIX("629", "RECHARGE_PIX", TradeCategoryEnum.RECHARGE, "PIX充值"),
    RECHARGE_USDT("630", "RECHARGE_USDT", TradeCategoryEnum.RECHARGE, "USDT充值"),
    RECHARGE_PIX_QUOTA("631", "RECHARGE_PIX_QUOTA", TradeCategoryEnum.RECHARGE, "PIX定额支付"),
    RECHARGE_ZFBDINGER("632", "RECHARGE_ZFBDINGER", TradeCategoryEnum.RECHARGE, "支付宝定额"),
    RECHARGE_ZFBXE("633", "RECHARGE_ZFBXE", TradeCategoryEnum.RECHARGE, "支付宝小额"),
    RECHARGE_ZFBDAER("634", "RECHARGE_ZFBDAER", TradeCategoryEnum.RECHARGE, "支付宝大额"),
    RECHARGE_VIPUSDT("635", "RECHARGE_VIPUSDT", TradeCategoryEnum.RECHARGE, "VIP支付USDT"),
    RECHARGE_ZFBYS("636", "RECHARGE_ZFBYS", TradeCategoryEnum.RECHARGE, "支付宝原生"),
    RECHARGE_YZFZL("637", "RECHARGE_YZFZL", TradeCategoryEnum.RECHARGE, "云支付直连"),

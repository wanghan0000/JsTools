api/vip/ranks    缓存10s
api/captchaImage 缓存10s
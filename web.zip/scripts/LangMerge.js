/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @typescript-eslint/no-var-requires */
const fs = require("fs");
const path = require("path");

const allJson = [];

const findJSONFiles = (currentPath) => {
  fs.readdirSync(currentPath, { withFileTypes: true }).forEach((dirent) => {
    console.log(dirent);
    if (dirent.isDirectory()) {
      const filePath = currentPath + "/" + dirent.name;
      findJSONFiles(filePath);
    } else if (dirent.isFile() && dirent.name.includes("json")) {
      const path = currentPath + "/" + dirent.name;
      allJson.push(path);
    }
  });
};

//清除文件
const deleteDir = (url) => {
  let files = [];
  if (fs.existsSync(url)) {
    files = fs.readdirSync(url);
    files.forEach(function (file, index) {
      const curPath = path.join(url, file);
      if (fs.statSync(curPath).isDirectory()) {
        deleteDir(curPath);
      } else {
        fs.unlinkSync(curPath);
      }
    });
    fs.rmdirSync(url);
  }
};

//创建文件
const createFiles = () => {
  fs.mkdirSync("./lang/temp");
  fs.writeFileSync("./lang/temp/en_US.json", "", function () {});
  fs.writeFileSync("./lang/temp/pt_BR.json", "", function () {});
  fs.writeFileSync("./lang/temp/zh_CN.json", "", function () {});
  fs.writeFileSync("./lang/temp/zh_TW.json", "", function () {});
};

const writeJSONFiles = () => {
  return new Promise((resolve, reject) => {
    let enObj = {};
    let ptObj = {};
    let zhObj = {};
    let twObj = {};
    let index = 0;
    const end = allJson.length;
    return new Promise((res, rej) => {
      allJson.forEach((name) => {
        if (name.includes("en_US")) {
          fs.readFile(name, "utf-8", (err, data) => {
            if (!err) {
              try {
                data = JSON.parse(data);
                enObj = { ...enObj, ...data };
              } catch (error) {}
            }
            index += 1;
            if (index >= end) {
              res(true);
            }
          });
        } else if (name.includes("pt_BR") && !name.includes('arcolang')) {
          fs.readFile(name, "utf-8", (err, data) => {
            if (!err) {
              try {
                data = JSON.parse(data);

                ptObj = { ...ptObj, ...data };
              } catch (error) {}
            }
            index += 1;
            if (index >= end) {
              res(true);
            }
          });
        } else if (name.includes("zh_CN")) {
          fs.readFile(name, "utf-8", (err, data) => {
            if (!err) {
              try {
                data = JSON.parse(data);
                zhObj = { ...zhObj, ...data };
              } catch (error) {}
            }
            index += 1;
            if (index >= end) {
              res(true);
            }
          });
        } else if (name.includes("zh_TW")) {
          fs.readFile(name, "utf-8", (err, data) => {
            if (!err) {
              try {
                data = JSON.parse(data);
                twObj = { ...twObj, ...data };
              } catch (error) {}
            }
            index += 1;
            if (index >= end) {
              res(true);
            }
          });
        }
      });
    }).then(() => {
      fs.writeFileSync(
        "./lang/temp/en_US.json",
        JSON.stringify(enObj),
        function (err) {}
      );
      fs.writeFileSync(
        "./lang/temp/pt_BR.json",
        JSON.stringify(ptObj),
        function (err) {}
      );
      fs.writeFileSync(
        "./lang/temp/zh_CN.json",
        JSON.stringify(zhObj),
        function (err) {}
      );
      fs.writeFileSync(
        "./lang/temp/zh_TW.json",
        JSON.stringify(twObj),
        function (err) {
          if (!err) {
            copy("./lang/temp/zh_TW.json", "");
          }
        }
      );

      resolve(true);
    });
  });
};

const copy = (sd, td) => {
  const sourceFile = fs.readdirSync(sd, { withFileTypes: true });
  for (const file of sourceFile) {
    const srcFile = path.resolve(sd, file.name);
    const tagFile = path.resolve(td, file.name);
    if (file.isDirectory() && !fs.existsSync(tagFile)) {
      fs.mkdirSync(tagFile, (err) => console.log(err));
      copy(srcFile, tagFile);
    } else if (file.isDirectory() && fs.existsSync(tagFile)) {
      copy(srcFile, tagFile);
    }
    !file.isDirectory() && fs.copyFileSync(srcFile, tagFile);
  }
};

findJSONFiles("./lang");
deleteDir("./lang/temp");
createFiles();
writeJSONFiles().then(()=>{
    copy("./lang/temp", "./public/locales");
    // copy("./lang/arcolang", "./public/arcoLocale");
    deleteDir("./lang/temp");
});

//deleteDir("./lang/temp");

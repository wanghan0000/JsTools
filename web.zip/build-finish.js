/* eslint-disable @typescript-eslint/no-var-requires */
const path = require('path');
const fs = require('fs');
const archiver = require('archiver');
const cheerio = require('cheerio')

const originalHtml = fs.readFileSync('build/index.html', 'utf-8');

const $ = cheerio.load(originalHtml);

// $('script[src="https://c.brazilinstall.com/js/common/base-72cc57ccd6.min.js"]').remove()
// $('script[src="https://c.brazilinstall.com/js/page/jZinstall-4f18cb5af4.min.js"]').remove()
$('script:contains("loadZinstall")').remove()
$('link[href="./manifest.json"]').remove()
$('link[href="./favicon.ico"]').remove()
$('link[href="https://c.brazilinstall.com"]').remove()
$('link[href="https://connect.facebook.net"]').remove()

const newHtml = $.html();

fs.writeFileSync('build/Native.html',newHtml,'utf-8');


console.log('+++++++++++++++++++++++');
//执行版本号
const outputPath = path.resolve(__dirname, 'build');
const codeVersion = process.env.REACT_APP_CODE_VERSION;
const resVersion = process.env.REACT_APP_MEDIA_VERSION;
const langVersion = process.env.REACT_APP_LANG_VERSION;
const appVersion = process.env.REACT_APP_VERSION;
const androidVersion = process.env.REACT_ANDROID_VERSION;
const appDownLoadUrl = process.env.REACT_APP_DOWNLOAD_URL;
console.log('【build】当前打包代码版本:', codeVersion);
console.log('【build】当前打包资源版本:', resVersion);
console.log('【build】当前打包多语言版本:', langVersion);
console.log('【build】当前打包App版本:', appVersion);
console.log('【build】当前打包安卓版本:', androidVersion);
if(process.env.NODE_ENV !== 'development') {
    fs.unlinkSync('build/locales/zh_CN.json')
    fs.unlinkSync('build/locales/zh_TW.json')
}
const versionInfo = { 
  codeVersion: codeVersion, 
  resVersion: resVersion , 
  langVersion : langVersion , 
  appVersion:appVersion , 
  androidVersion: androidVersion,
  downLoadUrl: appDownLoadUrl
};
fs.writeFileSync(`build/version.json`, JSON.stringify(versionInfo));

const zipArr = [
  {
    //代码
    zipName: 'code.zip',
    directory: ['static/css', 'static/js'],
  },
  {
    //多媒体资源
    zipName: 'media.zip',
    directory: ['static/media'],
  },
  {
    //多语言
    zipName: 'lang.zip',
    directory: ['locales'],
  },
];

for (let i = 0; i < zipArr.length; ++i) {
      const { zipName , directory} = zipArr[i];
      //压缩文件名字
      const zipPath = path.resolve(__dirname, zipName);
      //创建一个输出zip包
      const output = fs.createWriteStream(path.join(__dirname, zipName));
      const archive = archiver('zip', { zlib: { level: 9 } });
      archive.pipe(output);
      archive.file('build/version.json',{
        name: 'version.json'
      });
      if(zipName === 'code.zip'){
        archive.file('build/index.html',{
          name: 'index.html'
        });
        archive.file('build/index.html',{
          name: 'Native.html'
        });
      }
      for(let j = 0 ; j < directory.length ; ++j){
        archive.directory("build/"+directory[j],directory[j])
      }
      archive.finalize().then((r) => {
        console.log('压缩完成');
      });
      output.on('close', function () {
        if (fs.existsSync(zipPath)) {
          fs.renameSync(zipPath, path.join(outputPath, zipName));
        }
      });

}

console.log('【build】build success');

/* eslint-disable @typescript-eslint/no-var-requires */
const path = require('path');
const paths = require('react-scripts/config/paths');
const fsExtra = require('fs-extra')
const fs = require('fs')
const archiver = require('archiver')

const { override, addWebpackModuleRule, addWebpackPlugin, addWebpackAlias, overrideDevServer, watchAll } = require('customize-cra');
const ArcoWebpackPlugin = require('@arco-plugins/webpack-react');
const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer');
//const { InjectManifest } = require('workbox-webpack-plugin')
//const compressionWebpackPlugin = require('compression-webpack-plugin')
const MiniCssExtractPlugin = require('mini-css-extract-plugin');

const lessLoaderOptions = {};
const cssLoaderOptions = {};
const lessRegex = /\.less$/;
const lessModuleRegex = /\.module\.less$/;
const webpackEnv = process.env.NODE_ENV;
const isEnvDevelopment = webpackEnv === 'development';
const isEnvProduction = webpackEnv === 'production';
const shouldUseSourceMap = isEnvProduction
  ? process.env.GENERATE_SOURCEMAP !== 'false'
  : isEnvDevelopment;

  const getStyleLoaders = (cssOptions, preProcessor) => {
    const postcssPlugins = [
      'postcss-flexbugs-fixes',
      [
        'postcss-preset-env',
        {
          autoprefixer: {
            flexbox: 'no-2009',
          },
          stage: 3,
        },
      ],
    ];

    postcssPlugins.push('postcss-normalize');

    const loaders = [
      isEnvDevelopment && require.resolve('style-loader'),
      isEnvProduction && {
        loader: MiniCssExtractPlugin.loader,
        // css is located in `static/css`, use '../../' to locate index.html folder
        // in production `paths.publicUrlOrPath` can be a relative path
        options: paths.publicUrlOrPath.startsWith('.')
          ? { publicPath: '../../' }
          : {},
      },
      {
        loader: require.resolve('css-loader'),
        options: cssOptions,
      },
      {
        // Options for PostCSS as we reference these options twice
        // Adds vendor prefixing based on your specified browser support in
        // package.json
        loader: require.resolve('postcss-loader'),
        options: {
          postcssOptions: {
            // Necessary for external CSS imports to work
            // https://github.com/facebook/create-react-app/issues/2677
            ident: 'postcss',
            config: false,
            plugins: postcssPlugins,
          },
          sourceMap: shouldUseSourceMap,
        },
      }
    ].filter(Boolean);

    if (preProcessor) {
      // not the same as react-scripts
      loaders.push(preProcessor);
    }

    loaders.push({
      loader: 'style-resources-loader',
      options: ({
        patterns: [path.resolve(__dirname, './src/style/variables.less')]
      })
    })

    return loaders;
  };

  const defaultCSSLoaderOption = {
    importLoaders: 2,
    sourceMap: shouldUseSourceMap,
  };

  const lessLoader = {
    loader: require.resolve('less-loader'),
    // not the same as react-scripts
    options: {
      sourceMap: shouldUseSourceMap,
      ...lessLoaderOptions,
      lessOptions: {
        rewriteUrls: 'local', // https://github.com/bholloway/resolve-url-loader/issues/200#issuecomment-999545339
        ...(lessLoaderOptions.lessOptions || {}),
      },
    },
  };

module.exports = {

  webpack: override(
    addWebpackModuleRule({
      test: lessRegex,
      exclude: lessModuleRegex,
      use: (getStyleLoaders(
        { ...defaultCSSLoaderOption, ...cssLoaderOptions, modules: false },
        lessLoader,
      ))
    }),
    addWebpackModuleRule({
      test: lessModuleRegex,
      use: getStyleLoaders(
        {
          ...defaultCSSLoaderOption,
          ...cssLoaderOptions,
          modules: {
            localIdentName: '[local]--[hash:base64:5]',
            ...cssLoaderOptions.modules,
          },
        },
        lessLoader,
      ),
    }),
    addWebpackModuleRule({
      test: /\.svg$/,  
      loader: '@svgr/webpack',
    }),
    addWebpackModuleRule({
      test: /\.(png|mp3|webp|jpe?g|gif|mp4)/,
      type: 'asset/resource',
      generator: {
        filename: 'static/media/[name][hash:5][ext][query]'
      }
    }),
    addWebpackPlugin(
      new ArcoWebpackPlugin({
        theme: '@arco-themes/react-webhall777',
        modifyVars: {
          
        },
      })
    ),
    // addWebpackPlugin(
    //   new MiniCssExtractPlugin({
    //     //filename: 'static/css/[name][hash:5][ext][query]'
    //   })
    // ),
    // addWebpackPlugin(
    //   new compressionWebpackPlugin({
    //     filename: 'static/js/[name].gz[query]',
    //     algorithm: 'gzip',
    //     test: /\.(js|css|svg)$/,
    //     threshold:10240,
    //     minRatio: 0.8,
    //     deleteOriginalAssets: false
    //   })
    // ),
    // addWebpackPlugin(
    // new InjectManifest({
    //   swSrc: path.resolve('src/service-worker.js'),
    //   swDest: path.resolve(routePreName, 'service-worker.js'),
    // })
    // ),

    addWebpackAlias({
      '@': path.resolve(__dirname, 'src'),
    }),
    process.env.ANALYZER && addWebpackPlugin(new BundleAnalyzerPlugin()),
    (config) => {
      if(process.env.REACT_APP_ENV === 'dev') {
        config.devtool = 'eval-source-map';
      }
      // config.plugins.push({
      //   apply:(compiler) => {
      //     compiler.hooks.done.tap('CustomAfterBuildPlugin',()=>{
      //       console.log('+++++++++++++++++++++++')
      //       //执行版本号
      //       const outputPath = path.resolve(encodeURIComponent(__dirname),'build')
      //       const appVersion = require('./package.json').version;
      //       console.log('【build】当前打包版本:',appVersion)
      //       const versionInfo = { version:appVersion };
      //       fs.writeFileSync(`build/version.json`,JSON.stringify(versionInfo));
      //       //压缩文件
      //       const zipPath = path.resolve(encodeURIComponent(__dirname),'build.zip');
      //       const output = fs.createWriteStream(path.join(encodeURIComponent(__dirname),'build.zip'));
      //       const archive = archiver('zip',{zlib:{level:9}})
      //       archive.pipe(output);
      //       archive.directory('build/',false);
      //       archive.finalize().then(r => {
      //         console.log('压缩完成')})
      //       console.log('【build】build success')
      //       output.on('close',function () {
      //         if(fs.existsSync(zipPath)){
      //           fs.renameSync(zipPath,path.join(outputPath,'build.zip'))
      //         }
      //       })
      //     })
      //   }
      // })
      return config
    }
  ),
  devServer: overrideDevServer(watchAll(),(config)=>{
    config.client = {
      overlay: false
    }
    return config
  })
};
